# React + TypeScript + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh

## Expanding the ESLint configuration

If you are developing a production application, we recommend updating the configuration to enable type-aware lint rules:

```js
export default tseslint.config([
  globalIgnores(['dist']),
  {
    files: ['**/*.{ts,tsx}'],
    extends: [
      ...tseslint.configs.recommendedTypeChecked,
      ...tseslint.configs.strictTypeChecked,
      ...tseslint.configs.stylisticTypeChecked,
    ],
    languageOptions: {
      parserOptions: {
        project: ['./tsconfig.node.json', './tsconfig.app.json'],
        tsconfigRootDir: import.meta.dirname,
      },
    },
  },
]);
```

You can also install [eslint-plugin-react-x](https://github.com/Rel1cx/eslint-react/tree/main/packages/plugins/eslint-plugin-react-x) and [eslint-plugin-react-dom](https://github.com/Rel1cx/eslint-react/tree/main/packages/plugins/eslint-plugin-react-dom) for React-specific lint rules:

```js
import reactX from 'eslint-plugin-react-x';
import reactDom from 'eslint-plugin-react-dom';

export default tseslint.config([
  globalIgnores(['dist']),
  {
    files: ['**/*.{ts,tsx}'],
    extends: [
      reactX.configs['recommended-typescript'],
      reactDom.configs.recommended,
    ],
    languageOptions: {
      parserOptions: {
        project: ['./tsconfig.node.json', './tsconfig.app.json'],
        tsconfigRootDir: import.meta.dirname,
      },
    },
  },
]);
```

```
ainext
├─ components.json
├─ eslint.config.js
├─ index.html
├─ package-lock.json
├─ package.json
├─ public
│  └─ vite.svg
├─ README.md
├─ src
│  ├─ App.css
│  ├─ App.tsx
│  ├─ assets
│  │  ├─ add_chat_widget-BLHgXHAq.svg
│  │  ├─ agent_login.svg
│  │  ├─ campaign.svg
│  │  ├─ generate_qr_code-DH6RvXvX.svg
│  │  ├─ images
│  │  │  ├─ backgrounds
│  │  │  │  ├─ bg.jpeg
│  │  │  │  ├─ bg.png
│  │  │  │  ├─ rocket.png
│  │  │  │  └─ whitebg.jpg
│  │  │  ├─ Fidget-spinner.gif
│  │  │  ├─ icons
│  │  │  │  ├─ attach-file.png
│  │  │  │  ├─ circle_green_icon.png
│  │  │  │  └─ pie-chart.png
│  │  │  ├─ logos
│  │  │  │  ├─ aiGreenTick.png
│  │  │  │  ├─ dark-logo.svg
│  │  │  │  └─ favicon.png
│  │  │  ├─ products
│  │  │  │  ├─ s1.jpg
│  │  │  │  ├─ s11.jpg
│  │  │  │  ├─ s4.jpg
│  │  │  │  ├─ s5.jpg
│  │  │  │  └─ s7.jpg
│  │  │  └─ profile
│  │  │     ├─ avatar.webp
│  │  │     └─ user-1.jpg
│  │  ├─ no_chats-qKotAZ9T.svg
│  │  ├─ phonebook_one.svg
│  │  └─ react.svg
│  ├─ components
│  │  ├─ ApiDocs.tsx
│  │  ├─ campaigns
│  │  │  ├─ BroadCast.tsx
│  │  │  ├─ CampaignDashboard.tsx
│  │  │  ├─ CampaignHistory.tsx
│  │  │  ├─ CampaignLayout.tsx
│  │  │  ├─ CampaignSidebar.tsx
│  │  │  ├─ ChatWidget.tsx
│  │  │  ├─ CsvCampaign.tsx
│  │  │  ├─ reserved.tsx
│  │  │  ├─ ScheduleCampaign
│  │  │  │  ├─ BroadcastForm.tsx
│  │  │  │  ├─ constants.ts
│  │  │  │  ├─ ContactSelector.tsx
│  │  │  │  ├─ CreateBroadcastView.tsx
│  │  │  │  ├─ index.ts
│  │  │  │  ├─ PhonePreview.tsx
│  │  │  │  ├─ ScheduledBroadcastsList.tsx
│  │  │  │  ├─ ScheduledCampaign.tsx
│  │  │  │  ├─ SchedulingSection.tsx
│  │  │  │  ├─ TemplatePreview.tsx
│  │  │  │  ├─ TemplateVariables.tsx
│  │  │  │  ├─ types.ts
│  │  │  │  └─ utils.ts
│  │  │  ├─ SendByTags.tsx
│  │  │  ├─ TemplateComponents.tsx
│  │  │  ├─ TemplateControls.tsx
│  │  │  ├─ TemplateForm.tsx
│  │  │  ├─ TemplateHeader.tsx
│  │  │  ├─ TemplateLibrary.tsx
│  │  │  ├─ TemplatePreview.tsx
│  │  │  ├─ TemplateTable.tsx
│  │  │  ├─ WhatsAppTemplateViewer.tsx
│  │  │  └─ YourTemplates.tsx
│  │  ├─ chatbots
│  │  │  ├─ NodePropertiesPanel.tsx
│  │  │  └─ WhatsappChatbotFlow.tsx
│  │  ├─ ChatSection.tsx
│  │  ├─ contacts
│  │  │  ├─ AddContactModal.tsx
│  │  │  ├─ AddPhonebookCard.tsx
│  │  │  ├─ constants.ts
│  │  │  ├─ ContactFilterModal.tsx
│  │  │  ├─ GlobalContactModal.tsx
│  │  │  ├─ GlobalContactsTable.tsx
│  │  │  ├─ index.ts
│  │  │  ├─ PhonebookContacts.tsx
│  │  │  ├─ PhonebookContactsTable.tsx
│  │  │  ├─ PhonebookSidebar.tsx
│  │  │  ├─ types.ts
│  │  │  └─ utils.ts
│  │  ├─ dashboard
│  │  │  ├─ ActiveChatbotsCard.tsx
│  │  │  ├─ Dashboard.tsx
│  │  │  ├─ DashboardHeader.tsx
│  │  │  ├─ ErrorBoundary.tsx
│  │  │  ├─ MessageActivityCard.tsx
│  │  │  ├─ RecentConversations.tsx
│  │  │  ├─ StatsGrid.tsx
│  │  │  ├─ UnreadMessagesCard.tsx
│  │  │  └─ UserProfileCard.tsx
│  │  ├─ ErrorBoundary.tsx
│  │  ├─ inbox
│  │  │  ├─ ChatHeader.tsx
│  │  │  ├─ ChatMessages.tsx
│  │  │  ├─ ChatSidebar.tsx
│  │  │  ├─ ConversationList.tsx
│  │  │  ├─ FilterModal.tsx
│  │  │  ├─ Inbox.tsx
│  │  │  ├─ MessageInput.tsx
│  │  │  └─ types.ts
│  │  ├─ LoadingAnimation.tsx
│  │  ├─ navbar
│  │  │  ├─ constants.ts
│  │  │  ├─ index.ts
│  │  │  ├─ LanguageButton.tsx
│  │  │  ├─ Logo.tsx
│  │  │  ├─ MetaConnectionButton.tsx
│  │  │  ├─ MobileMenu.tsx
│  │  │  ├─ MoreDropdown.tsx
│  │  │  ├─ Navbar.tsx
│  │  │  ├─ NavigationItems.tsx
│  │  │  ├─ NotificationDropdown.tsx
│  │  │  ├─ OptionsDropdown.tsx
│  │  │  ├─ types.ts
│  │  │  ├─ UIComponents.tsx
│  │  │  └─ UserDropdown.tsx
│  │  ├─ ProfilePage.tsx
│  │  ├─ Protect
│  │  ├─ ProtectedRoutes.tsx
│  │  ├─ settings
│  │  │  ├─ AttributeFormModal.tsx
│  │  │  ├─ BusinessProfile.tsx
│  │  │  ├─ constants.ts
│  │  │  ├─ GeneralSettings.tsx
│  │  │  ├─ ImportExport.tsx
│  │  │  ├─ index.ts
│  │  │  ├─ MessageDeletion.tsx
│  │  │  ├─ Pagination.tsx
│  │  │  ├─ ProfilePictureSection.tsx
│  │  │  ├─ Settings.tsx
│  │  │  ├─ Sidebar.tsx
│  │  │  ├─ TagFormModal.tsx
│  │  │  ├─ TagsAttributes.tsx
│  │  │  ├─ types.ts
│  │  │  └─ UserSettings.tsx
│  │  ├─ ui
│  │  │  ├─ accordion.tsx
│  │  │  ├─ alert-dialog.tsx
│  │  │  ├─ alert.tsx
│  │  │  ├─ aspect-ratio.tsx
│  │  │  ├─ avatar.tsx
│  │  │  ├─ badge.tsx
│  │  │  ├─ breadcrumb.tsx
│  │  │  ├─ button.tsx
│  │  │  ├─ calendar.tsx
│  │  │  ├─ card.tsx
│  │  │  ├─ carousel.tsx
│  │  │  ├─ chart.tsx
│  │  │  ├─ checkbox.tsx
│  │  │  ├─ collapsible.tsx
│  │  │  ├─ command.tsx
│  │  │  ├─ context-menu.tsx
│  │  │  ├─ dialog.tsx
│  │  │  ├─ drawer.tsx
│  │  │  ├─ dropdown-menu.tsx
│  │  │  ├─ form.tsx
│  │  │  ├─ hover-card.tsx
│  │  │  ├─ input-otp.tsx
│  │  │  ├─ input.tsx
│  │  │  ├─ label.tsx
│  │  │  ├─ menubar.tsx
│  │  │  ├─ navigation-menu.tsx
│  │  │  ├─ pagination.tsx
│  │  │  ├─ popover.tsx
│  │  │  ├─ progress.tsx
│  │  │  ├─ radio-group.tsx
│  │  │  ├─ resizable.tsx
│  │  │  ├─ scroll-area.tsx
│  │  │  ├─ select.tsx
│  │  │  ├─ separator.tsx
│  │  │  ├─ sheet.tsx
│  │  │  ├─ sidebar.tsx
│  │  │  ├─ skeleton.tsx
│  │  │  ├─ slider.tsx
│  │  │  ├─ sonner.tsx
│  │  │  ├─ switch.tsx
│  │  │  ├─ table.tsx
│  │  │  ├─ tabs.tsx
│  │  │  ├─ textarea.tsx
│  │  │  ├─ toggle-group.tsx
│  │  │  ├─ toggle.tsx
│  │  │  ├─ tooltip.tsx
│  │  │  └─ warning.tsx
│  │  └─ usermanagement
│  │     └─ UserManagement.tsx
│  ├─ features
│  │  └─ broadcast
│  ├─ hooks
│  │  └─ use-mobile.ts
│  ├─ index.css
│  ├─ lib
│  │  └─ utils.ts
│  ├─ main.tsx
│  ├─ pages
│  │  └─ Login.tsx
│  ├─ redux
│  │  ├─ authSlice.ts
│  │  ├─ broadcastSlice.ts
│  │  ├─ dashboardSlice.ts
│  │  ├─ languageSlice.ts
│  │  ├─ mediaSlice.ts
│  │  ├─ messageSlice.ts
│  │  ├─ reportsSlice.ts
│  │  ├─ store
│  │  │  └─ index.ts
│  │  ├─ tagsSlice.ts
│  │  └─ templateSlice.ts
│  ├─ services
│  │  └─ api.ts
│  ├─ swagger.yaml
│  ├─ types
│  │  └─ auth.ts
│  ├─ utils
│  └─ vite-env.d.ts
├─ tsconfig.app.json
├─ tsconfig.app.tsbuildinfo
├─ tsconfig.json
├─ tsconfig.node.json
└─ vite.config.ts

```