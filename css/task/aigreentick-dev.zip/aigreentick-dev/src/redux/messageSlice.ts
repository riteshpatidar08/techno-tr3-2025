import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import AiGreenTickApi from '@/services/api';

interface ChatMessage {
  id: number;
  user_id: number;
  contact_id: number;
  send_from: string;
  send_to: string;
  send_from_id: string;
  send_to_id: string;
  text: string;
  type: 'sent' | 'recieve';
  method: string;
  image_id: number | null;
  time: string;
  template_id: number | null;
  status: string;
  is_media: string;
  contact: string;
  response: string;
  message_id: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
}

interface ConversationMessage {
  id: number;
  user_id: number;
  contact_id: number;
  send_from: string;
  send_to: string;
  send_from_id: string;
  send_to_id: string;
  text: string;
  type: 'sent' | 'recieve';
  method: string;
  image_id: number | null;
  time: string;
  template_id: number | null;
  status: string;
  is_media: string;
  contact: string | null;
  response: string;
  message_id: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  user?: User;
  template?: any;
}

interface Contact {
  id: number;
  user_id: number;
  name: string;
  mobile: string;
  time: number;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  total_msg_count: number;
  last_chat: ChatMessage;
}

interface User {
  id: number;
  role_id: number;
  created_by: number | null;
  country_id: number;
  name: string;
  mobile: string;
  profile_photo: string | null;
  rememberToken: string | null;
  api_token: string;
  email: string;
  company_name: string | null;
  city: string | null;
  market_msg_charge: number;
  utilty_msg_charge: number;
  auth_msg_charge: number;
  balance: number;
  balance_enabled: number;
  online_status: string;
  agent_id: number | null;
  credit: number;
  debit: number;
  status: string;
  domain: string | null;
  logo: string | null;
  is_demo: string;
  demo_end: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  webhook_token: string | null;
}

interface Channel {
  id: number;
  user_id: number;
  created_by: number;
  whatsapp_no: string;
  whatsapp_no_id: string;
  whatsapp_biz_id: string;
  parmenent_token: string;
  token: string;
  status: string;
  response: string | null;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  user: User;
}

interface PaginationLink {
  url: string | null;
  label: string;
  active: boolean;
}

interface MessagesResponse {
  users: {
    current_page: number;
    data: Contact[];
    first_page_url: string;
    from: number;
    last_page: number;
    last_page_url: string;
    links: PaginationLink[];
    next_page_url: string | null;
    path: string;
    per_page: number;
    prev_page_url: string | null;
    to: number;
    total: number;
  };
  channel: Channel[];
}

interface ConversationResponse {
  chat: ConversationMessage[];
  channel: Channel[];
}

interface ConversationItem {
  id: number;
  contact_name: string;
  contact_number: string;
  contact_id: number;
  lastMessage: ChatMessage;
  lastMessageTime: string;
  unreadCount: number;
  totalMessageCount: number;
  isActive: boolean;
  isPinned?: boolean;
  isMuted?: boolean;
  isTyping?: boolean;
}


interface SendMessageData {
  message: string;
  recipient_mobile: string;
  recipient_name: string;
  template_id?: number | null;
  reaction?: string;
  isReply?: boolean;
  media_type?: string;
  media_url?: string;
  filename?: string;
  caption?: string;
  channel: string;
}


interface SocketMessage {
  id: number;
  text: string;
  send_from: string;
  send_to: string;
  send_from_user: string;
  send_to_user: string;
  created_at: string;
  user_id: number;
  type: 'sent' | 'recieve';
  status: string;
  method?: string;
  messageType?: string;
}

interface MessageState {
  contacts: Contact[];
  channels: Channel[];

  conversations: ConversationItem[];
  selectedConversation: ConversationItem | null;
  selectedContactId: number | null;

  currentConversationMessages: ConversationMessage[];
  conversationLoading: boolean;
  conversationError: string | null;

  currentPage: number;
  lastPage: number;
  total: number;
  perPage: number;
  hasMorePages: boolean;

  loading: boolean;
  error: string | null;
  sendingMessage: boolean;
  sendError: string | null;
  selectedChannelId: number | null;
  searchQuery: string;

 
  socketConnected: boolean;
  typingUsers: { [conversationId: string]: boolean };
  onlineUsers: { [userId: string]: boolean };
  lastSeenMessages: { [conversationId: string]: number };
}

const organizeContactsIntoConversations = (
  contacts: Contact[]
): ConversationItem[] => {
  return contacts
    .map((contact) => {
      const lastMessageTime = new Date(contact.last_chat.created_at);
      const now = new Date();
      const diffInHours =
        (now.getTime() - lastMessageTime.getTime()) / (1000 * 60 * 60);
      const isActive = diffInHours <= 24;

      const unreadCount =
        contact.last_chat.type === 'recieve' &&
        contact.last_chat.status !== 'read'
          ? 1
          : 0;

      return {
        id: contact.id,
        contact_name: contact.name,
        contact_number: contact.mobile,
        contact_id: contact.id,
        lastMessage: contact.last_chat,
        lastMessageTime: contact.last_chat.created_at,
        unreadCount,
        totalMessageCount: contact.total_msg_count,
        isActive,
        isPinned: false,
        isMuted: false,
        isTyping: false,
      };
    })
    .sort(
      (a, b) =>
        new Date(b.lastMessageTime).getTime() -
        new Date(a.lastMessageTime).getTime()
    );
};

const initialState: MessageState = {
  contacts: [],
  channels: [],
  conversations: [],
  selectedConversation: null,
  selectedContactId: null,
  currentConversationMessages: [],
  conversationLoading: false,
  conversationError: null,
  currentPage: 1,
  lastPage: 1,
  total: 0,
  perPage: 10,
  hasMorePages: false,
  loading: false,
  error: null,
  sendingMessage: false,
  sendError: null,
  selectedChannelId: null,
  searchQuery: '',
  socketConnected: false,
  typingUsers: {},
  onlineUsers: {},
  lastSeenMessages: {},
};

export const fetchMessages = createAsyncThunk(
  'messages/fetchAll',
  async (
    params: {
      selectedChannel?: string | null;
      chat?: string;
      page?: number;
      search?: string;
      per_page?: number;
      silent?: boolean;
    } = {},
    { rejectWithValue }
  ) => {
    try {
      const response = await AiGreenTickApi.messages.fetchAll(params);
      return response as MessagesResponse;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.error ||
          error.message ||
          'Failed to fetch messages'
      );
    }
  }
);

export const fetchConversation = createAsyncThunk(
  'messages/fetchConversation',
  async (
    params: {
      contactNumber: string;
      selectedChannel: string;
      page?: number;
    },
    { rejectWithValue }
  ) => {
    try {
      const response = await AiGreenTickApi.messages.fetchConversation(
        params.contactNumber,
        {
          selectedChannel: params.selectedChannel,
          page: params.page || 1,
        }
      );
      return response as ConversationResponse;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.error ||
          error.message ||
          'Failed to fetch conversation'
      );
    }
  }
);


export const sendMessage = createAsyncThunk(
  'messages/send',
  async (messageData: SendMessageData, { rejectWithValue, dispatch }) => {
    try {
      const response = await AiGreenTickApi.messages.send(messageData);

      dispatch(fetchMessages({}));

      return response;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.error || error.message || 'Failed to send message'
      );
    }
  }
);

const messageSlice = createSlice({
  name: 'messages',
  initialState,
  reducers: {
    clearError: (state) => {
      state.error = null;
      state.sendError = null;
    },

    setSelectedChannelId: (state, action: PayloadAction<number | null>) => {
      state.selectedChannelId = action.payload;
    },

    setSearchQuery: (state, action: PayloadAction<string>) => {
      state.searchQuery = action.payload;
    },

    selectConversation: (state, action: PayloadAction<string | number>) => {
      const identifier = action.payload;
      const conversation = state.conversations.find(
        (conv) =>
          conv.contact_number === identifier ||
          conv.contact_id === identifier ||
          conv.id === identifier
      );

      if (conversation) {
        state.selectedConversation = conversation;
        state.selectedContactId = conversation.contact_id;

        conversation.unreadCount = 0;

        state.currentConversationMessages = [];
        state.conversationError = null;
      }
    },

    clearSelectedConversation: (state) => {
      state.selectedConversation = null;
      state.selectedContactId = null;
      state.currentConversationMessages = [];
      state.conversationError = null;
    },

    resetMessages: (state) => {
      state.contacts = [];
      state.channels = [];
      state.conversations = [];
      state.selectedConversation = null;
      state.selectedContactId = null;
      state.currentConversationMessages = [];
      state.conversationLoading = false;
      state.conversationError = null;
      state.currentPage = 1;
      state.lastPage = 1;
      state.total = 0;
      state.hasMorePages = false;
      state.error = null;
      state.sendError = null;
    },

    addMessageToConversation: (
      state,
      action: PayloadAction<ConversationMessage>
    ) => {
      const newMessage = action.payload;
      state.currentConversationMessages.push(newMessage);

      if (state.selectedConversation) {
        state.selectedConversation.lastMessage = newMessage as ChatMessage;
        state.selectedConversation.lastMessageTime = newMessage.created_at;
      }
    },

    updateConversationMessage: (
      state,
      action: PayloadAction<{
        contactId: number;
        message: ChatMessage;
      }>
    ) => {
      const { contactId, message } = action.payload;
      const conversationIndex = state.conversations.findIndex(
        (conv) => conv.contact_id === contactId
      );

      if (conversationIndex !== -1) {
        state.conversations[conversationIndex].lastMessage = message;
        state.conversations[conversationIndex].lastMessageTime =
          message.created_at;

        if (message.type === 'recieve') {
          state.conversations[conversationIndex].unreadCount += 1;
        }

        const updatedConversation = state.conversations[conversationIndex];
        state.conversations.splice(conversationIndex, 1);
        state.conversations.unshift(updatedConversation);
      }
    },

    markConversationAsRead: (state, action: PayloadAction<string | number>) => {
      const identifier = action.payload;

    
      const conversation = state.conversations.find(
        (conv) =>
          conv.contact_number === identifier ||
          conv.contact_id === identifier ||
          conv.contact_number === String(identifier).replace(/^91/, '') ||
          String(identifier).replace(/^91/, '') === conv.contact_number
      );

      if (conversation) {
        conversation.unreadCount = 0;
      }
    },

  

   
    setSocketConnected: (state, action: PayloadAction<boolean>) => {
      console.log(action.payload)
      state.socketConnected = action.payload;
    },

    
    addNewMessage: (state, action: PayloadAction<SocketMessage>) => {
      const newMessage = action.payload;

    
      const cleanPhoneNumber = (phone: string) =>
        phone?.replace(/^91/, '') || phone;
      const messageFrom = cleanPhoneNumber(newMessage.send_from);
      const messageTo = cleanPhoneNumber(newMessage.send_to);
      const selectedPhone = cleanPhoneNumber(
        state.selectedConversation?.contact_number || ''
      );

    
      if (
        state.selectedConversation &&
        (messageFrom === selectedPhone || messageTo === selectedPhone)
      ) {
     
        const messageExists = state.currentConversationMessages.some(
          (msg) =>
            msg.id === newMessage.id || msg.message_id === String(newMessage.id)
        );

        if (!messageExists) {
          const conversationMessage: ConversationMessage = {
            id: newMessage.id,
            user_id: newMessage.user_id,
            contact_id: state.selectedConversation.contact_id,
            send_from: newMessage.send_from,
            send_to: newMessage.send_to,
            send_from_id: newMessage.send_from_user,
            send_to_id: newMessage.send_to_user,
            text: newMessage.text,
            type: newMessage.type,
            method: newMessage.method || 'text',
            image_id: null,
            time: newMessage.created_at,
            template_id: null,
            status: newMessage.status,
            is_media: '0',
            contact: null,
            response: '',
            message_id: String(newMessage.id),
            created_at: newMessage.created_at,
            updated_at: newMessage.created_at,
            deleted_at: null,
          };

          state.currentConversationMessages.push(conversationMessage);

      
          state.currentConversationMessages.sort(
            (a, b) =>
              new Date(a.created_at).getTime() -
              new Date(b.created_at).getTime()
          );
        }
      }
    },

  
    updateConversationLastMessage: (
      state,
      action: PayloadAction<{
        contactNumber: string;
        lastMessage: {
          text: string;
          created_at: string;
          type: 'sent' | 'recieve';
          status: string;
        };
      }>
    ) => {
      const { contactNumber, lastMessage } = action.payload;

      
      const cleanPhoneNumber = (phone: string) =>
        phone?.replace(/^91/, '') || phone;
      const cleanContactNumber = cleanPhoneNumber(contactNumber);

    
      const conversationIndex = state.conversations.findIndex((conv) => {
        const convPhone = cleanPhoneNumber(conv.contact_number);
        return convPhone === cleanContactNumber;
      });

      if (conversationIndex !== -1) {
        const conversation = state.conversations[conversationIndex];

        
        conversation.lastMessage = {
          ...conversation.lastMessage,
          text: lastMessage.text,
          created_at: lastMessage.created_at,
          type: lastMessage.type,
          status: lastMessage.status,
        };

      
        conversation.lastMessageTime = lastMessage.created_at;

      
        if (
          lastMessage.type === 'recieve' &&
          (!state.selectedConversation ||
            cleanPhoneNumber(state.selectedConversation.contact_number) !==
              cleanContactNumber)
        ) {
          conversation.unreadCount = (conversation.unreadCount || 0) + 1;
        }

    
        state.conversations.splice(conversationIndex, 1);
        state.conversations.unshift(conversation);
      }
    },

   
    updateContactOnlineStatus: (
      state,
      action: PayloadAction<{ contactNumber: string; isOnline: boolean }>
    ) => {
      const { contactNumber, isOnline } = action.payload;

     
      const conversationIndex = state.conversations.findIndex(
        (conv) => conv.contact_number === contactNumber
      );

      if (conversationIndex !== -1) {
        state.conversations[conversationIndex].isActive = isOnline;
      }

     
      if (
        state.selectedConversation &&
        state.selectedConversation.contact_number === contactNumber
      ) {
        state.selectedConversation.isActive = isOnline;
      }

     
      state.onlineUsers[contactNumber] = isOnline;
    },

    
    setTypingStatus: (
      state,
      action: PayloadAction<{ contactNumber: string; isTyping: boolean }>
    ) => {
      const { contactNumber, isTyping } = action.payload;

    
      const conversation = state.conversations.find(
        (conv) => conv.contact_number === contactNumber
      );

      if (conversation) {
        conversation.isTyping = isTyping;
      }

      
      if (
        state.selectedConversation &&
        state.selectedConversation.contact_number === contactNumber
      ) {
        state.selectedConversation.isTyping = isTyping;
      }

     
      if (isTyping) {
        state.typingUsers[contactNumber] = true;
      } else {
        delete state.typingUsers[contactNumber];
      }
    },

 
    updateMessageStatus: (
      state,
      action: PayloadAction<{ messageId: string; status: string }>
    ) => {
      const { messageId, status } = action.payload;

    
      const messageIndex = state.currentConversationMessages.findIndex(
        (msg) => msg.message_id === messageId || msg.id === parseInt(messageId)
      );

      if (messageIndex !== -1) {
        state.currentConversationMessages[messageIndex].status = status;
      }
    },

 
    toggleConversationPin: (state, action: PayloadAction<string>) => {
      const contactNumber = action.payload;
      const conversation = state.conversations.find(
        (conv) => conv.contact_number === contactNumber
      );

      if (conversation) {
        conversation.isPinned = !conversation.isPinned;

       
        state.conversations.sort((a, b) => {
       
          if (a.isPinned && !b.isPinned) return -1;
          if (!a.isPinned && b.isPinned) return 1;

         
          const timeA = new Date(a.lastMessageTime).getTime();
          const timeB = new Date(b.lastMessageTime).getTime();
          return timeB - timeA;
        });
      }
    },

 
    toggleConversationMute: (state, action: PayloadAction<string>) => {
      const contactNumber = action.payload;
      const conversation = state.conversations.find(
        (conv) => conv.contact_number === contactNumber
      );

      if (conversation) {
        conversation.isMuted = !conversation.isMuted;
      }
    },

 
    bulkMarkMessagesAsRead: (
      state,
      action: PayloadAction<{ conversationId: string; messageIds: string[] }>
    ) => {
      const { messageIds } = action.payload;

      
      messageIds.forEach((messageId) => {
        const messageIndex = state.currentConversationMessages.findIndex(
          (msg) =>
            msg.message_id === messageId || msg.id === parseInt(messageId)
        );

        if (messageIndex !== -1) {
          state.currentConversationMessages[messageIndex].status = 'read';
        }
      });
    },
  },
  extraReducers: (builder) => {
    builder

      .addCase(fetchMessages.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(
        fetchMessages.fulfilled,
        (state, action: PayloadAction<MessagesResponse>) => {
          state.loading = false;
          state.error = null;
          state.currentPage = action.payload.users.current_page;
          state.lastPage = action.payload.users.last_page;
          state.total = action.payload.users.total;
          state.perPage = action.payload.users.per_page;
          state.hasMorePages =
            action.payload.users.current_page < action.payload.users.last_page;

          if (action.payload.users.current_page === 1) {
            state.contacts = action.payload.users.data;
            state.conversations = organizeContactsIntoConversations(
              action.payload.users.data
            );
          } else {
            state.contacts = [...state.contacts, ...action.payload.users.data];
            const newConversations = organizeContactsIntoConversations(
              action.payload.users.data
            );
            state.conversations = [...state.conversations, ...newConversations];
          }

          state.channels = action.payload.channel;
        }
      )
      .addCase(fetchMessages.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      .addCase(fetchConversation.pending, (state) => {
        state.conversationLoading = true;
        state.conversationError = null;
      })
      .addCase(
        fetchConversation.fulfilled,
        (state, action: PayloadAction<ConversationResponse>) => {
          state.conversationLoading = false;
          state.conversationError = null;
          state.currentConversationMessages = action.payload.chat;
        }
      )
      .addCase(fetchConversation.rejected, (state, action) => {
        state.conversationLoading = false;
        state.conversationError = action.payload as string;
      })

      .addCase(sendMessage.pending, (state) => {
        state.sendingMessage = true;
        state.sendError = null;
      })
      .addCase(sendMessage.fulfilled, (state) => {
        state.sendingMessage = false;
        state.sendError = null;
      })
      .addCase(sendMessage.rejected, (state, action) => {
        state.sendingMessage = false;
        state.sendError = action.payload as string;
      });
  },
});

export const {
  clearError,
  setSelectedChannelId,
  setSearchQuery,
  selectConversation,
  clearSelectedConversation,
  resetMessages,
  updateConversationMessage,
  markConversationAsRead,
  addMessageToConversation,

 
  setSocketConnected,
  addNewMessage,
  updateConversationLastMessage,
  updateContactOnlineStatus,
  setTypingStatus,
  updateMessageStatus,
  toggleConversationPin,
  toggleConversationMute,
  bulkMarkMessagesAsRead,
} = messageSlice.actions;


export const selectMessages = (state: { messages: MessageState }) =>
  state.messages;
export const selectContacts = (state: { messages: MessageState }) =>
  state.messages?.contacts || [];
export const selectConversations = (state: { messages: MessageState }) =>
  state.messages?.conversations || [];
export const selectSelectedConversation = (state: { messages: MessageState }) =>
  state.messages?.selectedConversation;
export const selectChannels = (state: { messages: MessageState }) =>
  state.messages?.channels || [];
export const selectMessagesLoading = (state: { messages: MessageState }) =>
  state.messages?.loading || false;
export const selectMessagesError = (state: { messages: MessageState }) =>
  state.messages?.error;
export const selectSendingMessage = (state: { messages: MessageState }) =>
  state.messages?.sendingMessage || false;
export const selectSendError = (state: { messages: MessageState }) =>
  state.messages?.sendError;

export const selectCurrentConversationMessages = (state: {
  messages: MessageState;
}) => state.messages?.currentConversationMessages || [];
export const selectConversationLoading = (state: { messages: MessageState }) =>
  state.messages?.conversationLoading || false;
export const selectConversationError = (state: { messages: MessageState }) =>
  state.messages?.conversationError;

export const selectPaginationInfo = (state: { messages: MessageState }) => ({
  currentPage: state.messages?.currentPage || 1,
  lastPage: state.messages?.lastPage || 1,
  total: state.messages?.total || 0,
  perPage: state.messages?.perPage || 10,
  hasMorePages: state.messages?.hasMorePages || false,
});

export const selectFilteredConversations = (state: {
  messages: MessageState;
}) => {
  if (!state.messages) {
    console.warn('Messages state is undefined');
    return [];
  }

  const { conversations = [], searchQuery = '' } = state.messages;

  if (!searchQuery) return conversations;

  return conversations.filter(
    (conv) =>
      conv.contact_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      conv.contact_number?.includes(searchQuery) ||
      conv.lastMessage?.text?.toLowerCase().includes(searchQuery.toLowerCase())
  );
};

export const selectUnreadCount = (state: { messages: MessageState }) => {
  if (!state.messages || !state.messages.conversations) {
    return 0;
  }

  return state.messages.conversations.reduce(
    (total, conv) => total + (conv.totalMessageCount || 0),
    0
  );
};

export const selectActiveConversations = (state: {
  messages: MessageState;
}) => {
  const conversations = selectConversations(state);
  return conversations.filter((conv) => conv.isActive);
};

export const selectExpiredConversations = (state: {
  messages: MessageState;
}) => {
  const conversations = selectConversations(state);
  return conversations.filter((conv) => !conv.isActive);
};



export const selectSocketConnected = (state: { messages: MessageState }) =>
  state.messages?.socketConnected || false;

export const selectTypingUsers = (state: { messages: MessageState }) =>
  state.messages?.typingUsers || {};

export const selectOnlineUsers = (state: { messages: MessageState }) =>
  state.messages?.onlineUsers || {};

export const selectIsContactTyping =
  (contactNumber: string) => (state: { messages: MessageState }) =>
    state.messages?.typingUsers[contactNumber] || false;

export const selectIsContactOnline =
  (contactNumber: string) => (state: { messages: MessageState }) =>
    state.messages?.onlineUsers[contactNumber] || false;

export const selectPinnedConversations = (state: {
  messages: MessageState;
}) => {
  const conversations = selectConversations(state);
  return conversations.filter((conv) => conv.isPinned);
};

export const selectMutedConversations = (state: { messages: MessageState }) => {
  const conversations = selectConversations(state);
  return conversations.filter((conv) => conv.isMuted);
};

export const selectUnreadMessagesCount = (state: { messages: MessageState }) =>
  state.messages.conversations.reduce(
    (total, conv) => total + (conv.unreadCount || 0),
    0
  );

export const selectConversationUnreadCount =
  (contactNumber: string) => (state: { messages: MessageState }) => {
    const conversation = state.messages.conversations.find(
      (conv) => conv.contact_number === contactNumber
    );
    return conversation?.unreadCount || 0;
  };


  export const selectTotalMessagesCount = (state: { messages: MessageState }) =>
    state.messages.conversations.reduce(
      (total, conv) => total + (conv.totalMessageCount || 0),
      0
    );
    
export default messageSlice.reducer;
