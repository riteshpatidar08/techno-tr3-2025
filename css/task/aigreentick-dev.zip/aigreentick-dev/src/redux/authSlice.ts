import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import { LoginRequest, LoginResponse, AuthState, User } from '../types/auth';
import { AiGreenTickApi } from '@/services/api';
import { SecureAuth } from '@/services/secure-auth';

export const loginUser = createAsyncThunk<
  LoginResponse,
  LoginRequest,
  { rejectValue: string }
>('auth/loginUser', async (credentials, { rejectWithValue }) => {
  try {
    const data = await AiGreenTickApi.auth.login(credentials);

    if (data.success) {
      // Use SecureAuth to set authentication properly
      SecureAuth.setAuthenticated(data.success.api_token, data.success);
    }
    return data;
  } catch (error: any) {
    if (error.response) {
      const errorMessage =
        error.response.data?.error ||
        error.response.data?.message ||
        'Login failed';
      return rejectWithValue(errorMessage);
    } else if (error.request) {
      return rejectWithValue('Network error. Please check your connection.');
    } else {
      return rejectWithValue(error.message || 'An unexpected error occurred.');
    }
  }
});

export const logoutUser = createAsyncThunk('auth/logoutUser', async () => {
  try {
    await AiGreenTickApi.auth.logout();
  } catch (error) {
    console.warn('Logout request failed, but clearing local data anyway');
  }

  // Use SecureAuth to clear everything
  SecureAuth.clearAuthentication();
});

export const signupUser = createAsyncThunk<
  LoginResponse,
  { name: string; email: string; password: string; mobile: string },
  { rejectValue: string }
>('auth/signupUser', async (userData, { rejectWithValue }) => {
  try {
    const data = await AiGreenTickApi.auth.register(userData);

    if ('success' in data && data.success) {
      // Use SecureAuth to set authentication properly
      SecureAuth.setAuthenticated(data.success.api_token, data.success);
      return data;
    } else {
      return rejectWithValue(data.error || 'Registration failed');
    }
  } catch (error: any) {
    if (error.response) {
      const errorMessage =
        error.response.data?.error ||
        error.response.data?.message ||
        'Registration failed';
      return rejectWithValue(errorMessage);
    } else if (error.request) {
      return rejectWithValue('Network error. Please check your connection.');
    } else {
      return rejectWithValue(error.message || 'An unexpected error occurred.');
    }
  }
});

export const initializeAuth = createAsyncThunk(
  'auth/initializeAuth',
  async () => {
    // Validate authentication properly
    if (!SecureAuth.isValidlyAuthenticated()) {
      throw new Error('No valid authentication data');
    }

    const token = SecureAuth.getCurrentToken();
    const user = SecureAuth.getCurrentUser();

    if (token && user) {
      try {
        AiGreenTickApi.utils.setAuthToken(token);
        return { user, token };
      } catch (error) {
        SecureAuth.clearInvalidAuth();
        throw new Error('Stored user data is corrupted');
      }
    }

    throw new Error('No stored authentication data');
  }
);

const initialState: AuthState = {
  user: null,
  token: SecureAuth.getCurrentToken(), // This will return null if invalid
  isLoading: false,
  error: null,
  isAuthenticated: SecureAuth.isValidlyAuthenticated(), // Properly validate
};

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    clearError: (state) => {
      state.error = null;
    },
    setCredentials: (
      state,
      action: PayloadAction<{ user: User; token: string }>
    ) => {
      state.user = action.payload.user;
      state.token = action.payload.token;
      state.isAuthenticated = true;

     
      SecureAuth.setAuthenticated(action.payload.token, action.payload.user);
      AiGreenTickApi.utils.setAuthToken(action.payload.token);
    },
    clearCredentials: (state) => {
      state.user = null;
      state.token = null;
      state.isAuthenticated = false;

     
      SecureAuth.clearAuthentication();
    },
    logout: (state) => {
      state.user = null;
      state.token = null;
      state.isAuthenticated = false;
      state.error = null;
      state.isLoading = false;

    
      SecureAuth.clearAuthentication();
    },
    setLoading: (state, action: PayloadAction<boolean>) => {
      state.isLoading = action.payload;
    },
    
    validateAuthState: (state) => {
      const isValid = SecureAuth.isValidlyAuthenticated();
      if (!isValid && state.isAuthenticated) {
      
        state.user = null;
        state.token = null;
        state.isAuthenticated = false;
        state.error = 'Authentication invalid';
        SecureAuth.clearInvalidAuth();
      }
    },
  },
  extraReducers: (builder) => {
    builder
     
      .addCase(loginUser.pending, (state, action) => {
        const isLoginPage = window.location.pathname === '/login';
        if (!isLoginPage) {
          state.isLoading = true;
        }
        state.error = null;
      })
      .addCase(loginUser.fulfilled, (state, action) => {
        state.isLoading = false;
        state.user = action.payload.success;
        state.token = action.payload.success.api_token;
        state.isAuthenticated = true;
        state.error = null;
      })
      .addCase(loginUser.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload || 'Login failed';
        state.isAuthenticated = false;
        state.user = null;
        state.token = null;
      })

     
      .addCase(signupUser.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(signupUser.fulfilled, (state, action) => {
        state.isLoading = false;
        state.user = action.payload.success;
        state.token = action.payload.success.api_token;
        state.isAuthenticated = true;
        state.error = null;
      })
      .addCase(signupUser.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload || 'Registration failed';
        state.isAuthenticated = false;
      })

      // Logout cases
      .addCase(logoutUser.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(logoutUser.fulfilled, (state) => {
        state.isLoading = false;
        state.user = null;
        state.token = null;
        state.isAuthenticated = false;
        state.error = null;
      })
      .addCase(logoutUser.rejected, (state) => {
        state.isLoading = false;
        state.user = null;
        state.token = null;
        state.isAuthenticated = false;
      })

      // Initialize auth cases
      .addCase(initializeAuth.fulfilled, (state, action) => {
        state.user = action.payload.user;
        state.token = action.payload.token;
        state.isAuthenticated = true;
        state.error = null;
      })
      .addCase(initializeAuth.rejected, (state) => {
        state.user = null;
        state.token = null;
        state.isAuthenticated = false;
      });
  },
});

export const {
  clearError,
  setCredentials,
  clearCredentials,
  setLoading,
  logout,
  validateAuthState, // New action
} = authSlice.actions;

// Updated selectors with validation
export const selectAuth = (state: { auth: AuthState }) => state.auth;
export const selectUser = (state: { auth: AuthState }) => {
  // Always validate before returning user
  const isValid = SecureAuth.isValidlyAuthenticated();
  return isValid ? state.auth.user : null;
};
export const selectToken = (state: { auth: AuthState }) => {
  // Always validate before returning token
  const isValid = SecureAuth.isValidlyAuthenticated();
  return isValid ? state.auth.token : null;
};
export const selectIsAuthenticated = (state: { auth: AuthState }) => {
  // Always validate authentication state
  return SecureAuth.isValidlyAuthenticated();
};
export const selectIsLoading = (state: { auth: AuthState }) =>
  state.auth.isLoading;
export const selectError = (state: { auth: AuthState }) => state.auth.error;

export default authSlice.reducer;
