import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import AiGreenTickApi from '@/services/api'; // Adjust path as needed

// Types - using the actual interfaces from your API
interface Country {
  id: number;
  name: string;
  mobile_code: string;
  iso_code?: string;
  flag?: string;
  currency?: string;
  timezone?: string;
  status?: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
}

// Updated to match your API response structure
interface CountriesResponse {
  success: Country[];
  // Add other properties if your API returns them
}

interface CountriesState {
  countries: Country[];
  loading: boolean;
  error: string | null;
}

// Initial state
const initialState: CountriesState = {
  countries: [],
  loading: false,
  error: null,
};

// Async thunk for fetching countries
export const fetchCountries = createAsyncThunk(
  'countries/fetchAll',
  async (_, { rejectWithValue }) => {
    try {
      const response = await AiGreenTickApi.countries.fetchAll();
      return response;
    } catch (error: any) {
      // Handle different error types
      if (error.response?.data?.error) {
        return rejectWithValue(error.response.data.error);
      }
      if (error.response?.data?.message) {
        return rejectWithValue(error.response.data.message);
      }
      return rejectWithValue(error.message || 'Failed to fetch countries');
    }
  }
);

// Countries slice
const countriesSlice = createSlice({
  name: 'countries',
  initialState,
  reducers: {
    // Clear countries
    clearCountries: (state) => {
      state.countries = [];
      state.error = null;
    },

    // Clear error
    clearError: (state) => {
      state.error = null;
    },

    // Set loading state manually if needed
    setLoading: (state, action: PayloadAction<boolean>) => {
      state.loading = action.payload;
    },

    // Reset state to initial
    resetState: (state) => {
      return initialState;
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch countries pending
      .addCase(fetchCountries.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      // Fetch countries fulfilled
      .addCase(
        fetchCountries.fulfilled,
        (state, action: PayloadAction<CountriesResponse>) => {
          state.loading = false;
          // Extract the array from the success property
          state.countries = action.payload.success || [];
          state.error = null;
        }
      )
      // Fetch countries rejected
      .addCase(fetchCountries.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
        state.countries = [];
      });
  },
});

// Export actions
export const { clearCountries, clearError, setLoading, resetState } =
  countriesSlice.actions;

// Selectors
export const selectCountries = (state: { countries: CountriesState }) =>
  state.countries.countries;
export const selectCountriesLoading = (state: { countries: CountriesState }) =>
  state.countries.loading;
export const selectCountriesError = (state: { countries: CountriesState }) =>
  state.countries.error;

// Derived selectors
export const selectCountriesCount = (state: { countries: CountriesState }) =>
  state.countries.countries.length;
export const selectCountryById =
  (id: number) => (state: { countries: CountriesState }) =>
    state.countries.countries.find((country) => country.id === id);
export const selectCountryByMobileCode =
  (mobileCode: string) => (state: { countries: CountriesState }) =>
    state.countries.countries.find(
      (country) => country.mobile_code === mobileCode
    );
export const selectCountriesSorted = (state: { countries: CountriesState }) =>
  [...state.countries.countries].sort((a, b) => a.name.localeCompare(b.name));

// Export reducer
export default countriesSlice.reducer;
