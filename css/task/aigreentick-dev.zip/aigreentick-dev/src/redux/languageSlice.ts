import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import AiGreenTickApi from '@/services/api';

// Types
export interface Language {
  id: number;
  name: string;
  code: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
}

export interface LanguageResponse {
  data: Language[];
}

export interface LanguageState {
  languages: Language[];
  loading: boolean;
  error: string | null;
  selectedLanguage: Language | null;
}

// Async thunk for fetching all languages
export const fetchAllLanguages = createAsyncThunk<
  LanguageResponse,
  void,
  { rejectValue: string }
>('language/fetchAll', async (_, { rejectWithValue }) => {
  try {
    const response = await AiGreenTickApi.language.fetchAll();
    return response;
  } catch (error: any) {
    return rejectWithValue(
      error.response?.data?.message || 'Failed to fetch languages'
    );
  }
});

// Initial state
const initialState: LanguageState = {
  languages: [],
  loading: false,
  error: null,
  selectedLanguage: null,
};

// Language slice
const languageSlice = createSlice({
  name: 'language',
  initialState,
  reducers: {
    setSelectedLanguage: (state, action: PayloadAction<Language>) => {
      state.selectedLanguage = action.payload;
    },

    clearSelectedLanguage: (state) => {
      state.selectedLanguage = null;
    },

    clearError: (state) => {
      state.error = null;
    },

    resetLanguageState: (state) => {
      state.languages = [];
      state.loading = false;
      state.error = null;
      state.selectedLanguage = null;
    },
  },
  extraReducers: (builder) => {
    builder

      .addCase(fetchAllLanguages.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAllLanguages.fulfilled, (state, action) => {
        state.loading = false;
        console.log(action.payload);
        state.languages = action.payload.data || [];
        state.error = null;
      })
      .addCase(fetchAllLanguages.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload || 'An error occurred';
      });
  },
});

// Export actions
export const {
  setSelectedLanguage,
  clearSelectedLanguage,
  clearError,
  resetLanguageState,
} = languageSlice.actions;

// Selectors - These match the variables used in TemplateForm
export const selectLanguages = (state: {
  language: LanguageState;
}): Language[] => state.language.languages;

export const selectLanguagesLoading = (state: {
  language: LanguageState;
}): boolean => state.language.loading;

export const selectLanguagesError = (state: {
  language: LanguageState;
}): string | null => state.language.error;

export const selectSelectedLanguage = (state: {
  language: LanguageState;
}): Language | null => state.language.selectedLanguage;

export const selectLanguageByCode = (
  state: { language: LanguageState },
  code: string
): Language | undefined =>
  state.language.languages.find((lang) => lang.code === code);

export const selectLanguageById = (
  state: { language: LanguageState },
  id: number
): Language | undefined =>
  state.language.languages.find((lang) => lang.id === id);

export const selectLanguagesByRegion = (
  state: { language: LanguageState },
  region: string
): Language[] => {
  return state.language.languages.filter((lang) =>
    lang.code.startsWith(region)
  );
};

// Export reducer
export default languageSlice.reducer;
