
import { configureStore } from '@reduxjs/toolkit';
import { useDispatch, useSelector, TypedUseSelectorHook } from 'react-redux';
import authReducer from './../authSlice'
import dashboardReducer from './../dashboardSlice'
import templateReducer from './../templateSlice'
import messageReducer from './../messageSlice'
import tagsReducer from './../tagsSlice'
import reportsReducer from './../reportsSlice'
import broadcastReducer from './../broadcastSlice' ;
import mediaReducer from './../mediaSlice'
import languageReducer from './../languageSlice'
import countryReducer from './../countrySlice'
import whatsappReducer from './../whatsappSlice' 
import contactsReducer from './../contactSlice'
export const store = configureStore({
  reducer: {
    auth: authReducer,
    dashboard : dashboardReducer,
    templates : templateReducer,
    messages : messageReducer,
    tags : tagsReducer,
    reports : reportsReducer,
    broadcast : broadcastReducer,
    media : mediaReducer ,
    language : languageReducer,
    countries : countryReducer,
    whatsapp : whatsappReducer,
    contacts : contactsReducer

  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

export const useAppDispatch = () => useDispatch<AppDispatch>();
export const useAppSelector: TypedUseSelectorHook<RootState> = useSelector;
