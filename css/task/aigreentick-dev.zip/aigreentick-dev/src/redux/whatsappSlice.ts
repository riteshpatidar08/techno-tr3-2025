import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { AiGreenTickApi } from '../services/api';


interface WhatsAppNumber {
  id: number;
  user_id: number;
  created_by: number;
  whatsapp_no: string;
  whatsapp_no_id: string;
  whatsapp_biz_id: string;
  parmenent_token: string;
  token: string;
  status: string;
  response: string | null;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  user: {
    id: number;
    role_id: number;
    created_by: number | null;
    country_id: number;
    name: string;
    mobile: string;
    profile_photo: string | null;
    rememberToken: string | null;
    api_token: string;
    email: string;
    company_name: string | null;
    city: string | null;
    market_msg_charge: number;
    utilty_msg_charge: number;
    auth_msg_charge: number;
    balance: number;
    balance_enabled: number;
    online_status: string;
    agent_id: number | null;
    credit: number;
    debit: number;
    status: string;
    domain: string | null;
    logo: string | null;
    is_demo: string;
    demo_end: string;
    created_at: string;
    updated_at: string;
    deleted_at: string | null;
    webhook_token: string | null;
  };
}

interface PaginationLink {
  url: string | null;
  label: string;
  active: boolean;
}

interface WhatsAppResponse {
  current_page: number;
  data: WhatsAppNumber[];
  first_page_url: string;
  from: number;
  last_page: number;
  last_page_url: string;
  links: PaginationLink[];
  next_page_url: string | null;
  path: string;
  per_page: number;
  prev_page_url: string | null;
  to: number;
  total: number;
}

interface WhatsAppState {
  numbers: WhatsAppNumber[];
  pagination: {
    current_page: number;
    last_page: number;
    per_page: number;
    total: number;
    from: number;
    to: number;
    first_page_url: string;
    last_page_url: string;
    next_page_url: string | null;
    prev_page_url: string | null;
    links: PaginationLink[];
    path: string;
  } | null;
  loading: boolean;
  error: string | null;
}

const initialState: WhatsAppState = {
  numbers: [],
  pagination: null,
  loading: false,
  error: null,
};


export const fetchWhatsAppNumbers = createAsyncThunk(
  'whatsapp/fetchAll',
  async (page: number = 1, { rejectWithValue }) => {
    try {
      const response = await AiGreenTickApi.whatsapp.fetchAll(page);
      return response as WhatsAppResponse;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || 'Failed to fetch WhatsApp numbers'
      );
    }
  }
);


const whatsappSlice = createSlice({
  name: 'whatsapp',
  initialState,
  reducers: {
    clearError: (state) => {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchWhatsAppNumbers.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchWhatsAppNumbers.fulfilled, (state, action) => {
        state.loading = false;
        state.numbers = action.payload.data;
        state.pagination = {
          current_page: action.payload.current_page,
          last_page: action.payload.last_page,
          per_page: action.payload.per_page,
          total: action.payload.total,
          from: action.payload.from,
          to: action.payload.to,
          first_page_url: action.payload.first_page_url,
          last_page_url: action.payload.last_page_url,
          next_page_url: action.payload.next_page_url,
          prev_page_url: action.payload.prev_page_url,
          links: action.payload.links,
          path: action.payload.path,
        };
      })
      .addCase(fetchWhatsAppNumbers.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { clearError } = whatsappSlice.actions;
export default whatsappSlice.reducer;
