import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import { AiGreenTickApi } from '@/services/api';
import type {
  ContactData,
  ContactsResponse,
  CreateContactData,
  UpdateContactData,
} from '@/services/api';

export interface ContactState {
  contacts: ContactData[];
  currentContact: ContactData | null;
  pagination: {
    current_page: number;
    last_page: number;
    per_page: number;
    total: number;
    from: number;
    to: number;
  } | null;
  isLoading: boolean;
  isCreating: boolean;
  isUpdating: boolean;
  isDeleting: boolean;
  error: string | null;
  searchTerm: string;
}

export const fetchContacts = createAsyncThunk<
  ContactsResponse,
  { page?: number; per_page?: number; search?: string },
  { rejectValue: string }
>('contacts/fetchContacts', async (params = {}, { rejectWithValue }) => {
  try {
    console.log('Redux: Fetching contacts with params:', params);
    const data = await AiGreenTickApi.contacts.fetchAll(params);
    console.log('Redux: Contacts fetch successful:', data);
    return data;
  } catch (error: any) {
    console.error('Redux: Contacts fetch error:', error);
    if (error.response) {
      const errorMessage =
        error.response.data?.message ||
        error.response.data?.error ||
        'Failed to fetch contacts';
      return rejectWithValue(errorMessage);
    } else if (error.request) {
      return rejectWithValue('Network error. Please check your connection.');
    } else {
      return rejectWithValue(error.message || 'An unexpected error occurred.');
    }
  }
});

export const createContact = createAsyncThunk<
  { success: boolean; message: string; contact?: ContactData },
  CreateContactData,
  { rejectValue: string }
>(
  'contacts/createContact',
  async (contactData, { rejectWithValue, dispatch }) => {
    try {
      console.log('Redux: Creating contact with data:', contactData);
      const response = await AiGreenTickApi.contacts.create(contactData);
      console.log('Redux: Contact creation successful:', response);

      dispatch(fetchContacts({}));

      return {
        success: response.status,
        message: response.message,
      };
    } catch (error: any) {
      console.error('Redux: Contact creation error:', error);
      if (error.response) {
        const errorMessage =
          error.response.data?.message ||
          error.response.data?.error ||
          'Failed to create contact';
        return rejectWithValue(errorMessage);
      } else if (error.request) {
        return rejectWithValue('Network error. Please check your connection.');
      } else {
        return rejectWithValue(
          error.message || 'An unexpected error occurred.'
        );
      }
    }
  }
);

export const updateContact = createAsyncThunk<
  { success: boolean; message: string; contact?: ContactData },
  { id: number | string; data: UpdateContactData },
  { rejectValue: string }
>(
  'contacts/updateContact',
  async ({ id, data }, { rejectWithValue, dispatch }) => {
    try {
      console.log('Redux: Updating contact ID:', id, 'with data:', data);
      const response = await AiGreenTickApi.contacts.update(id, data);
      console.log('Redux: Contact update successful:', response);

      dispatch(fetchContacts({}));

      return {
        success: response.status,
        message: response.message,
      };
    } catch (error: any) {
      console.error('Redux: Contact update error:', error);
      if (error.response) {
        const errorMessage =
          error.response.data?.message ||
          error.response.data?.error ||
          'Failed to update contact';
        return rejectWithValue(errorMessage);
      } else if (error.request) {
        return rejectWithValue('Network error. Please check your connection.');
      } else {
        return rejectWithValue(
          error.message || 'An unexpected error occurred.'
        );
      }
    }
  }
);

export const deleteContact = createAsyncThunk<
  { message: string },
  number | string,
  { rejectValue: string }
>('contacts/deleteContact', async (id, { rejectWithValue, dispatch }) => {
  try {
    console.log('Redux: Deleting contact ID:', id);
    const response = await AiGreenTickApi.contacts.delete(id);
    console.log('Redux: Contact deletion successful:', response);

    dispatch(fetchContacts({}));

    return response;
  } catch (error: any) {
    console.error('Redux: Contact deletion error:', error);
    if (error.response) {
      const errorMessage =
        error.response.data?.message ||
        error.response.data?.error ||
        'Failed to delete contact';
      return rejectWithValue(errorMessage);
    } else if (error.request) {
      return rejectWithValue('Network error. Please check your connection.');
    } else {
      return rejectWithValue(error.message || 'An unexpected error occurred.');
    }
  }
});

export const searchContacts = createAsyncThunk<
  ContactsResponse,
  string,
  { rejectValue: string }
>('contacts/searchContacts', async (searchTerm, { rejectWithValue }) => {
  try {
    console.log('Redux: Searching contacts with term:', searchTerm);
    const data = await AiGreenTickApi.contacts.search(searchTerm);
    console.log('Redux: Contact search successful:', data);
    return data;
  } catch (error: any) {
    console.error('Redux: Contact search error:', error);
    if (error.response) {
      const errorMessage =
        error.response.data?.message ||
        error.response.data?.error ||
        'Failed to search contacts';
      return rejectWithValue(errorMessage);
    } else if (error.request) {
      return rejectWithValue('Network error. Please check your connection.');
    } else {
      return rejectWithValue(error.message || 'An unexpected error occurred.');
    }
  }
});

export const getContactById = createAsyncThunk<
  ContactData | null,
  number | string,
  { rejectValue: string }
>('contacts/getContactById', async (id, { rejectWithValue }) => {
  try {
    console.log('Redux: Fetching contact by ID:', id);
    const contact = await AiGreenTickApi.contacts.getById(id);
    console.log('Redux: Contact fetch by ID successful:', contact);
    return contact;
  } catch (error: any) {
    console.error('Redux: Contact fetch by ID error:', error);
    if (error.response) {
      const errorMessage =
        error.response.data?.message ||
        error.response.data?.error ||
        'Failed to fetch contact';
      return rejectWithValue(errorMessage);
    } else if (error.request) {
      return rejectWithValue('Network error. Please check your connection.');
    } else {
      return rejectWithValue(error.message || 'An unexpected error occurred.');
    }
  }
});

const initialState: ContactState = {
  contacts: [],
  currentContact: null,
  pagination: null,
  isLoading: false,
  isCreating: false,
  isUpdating: false,
  isDeleting: false,
  error: null,
  searchTerm: '',
};

const contactSlice = createSlice({
  name: 'contacts',
  initialState,
  reducers: {
    clearError: (state) => {
      state.error = null;
    },
    setCurrentContact: (state, action: PayloadAction<ContactData | null>) => {
      state.currentContact = action.payload;
    },
    clearCurrentContact: (state) => {
      state.currentContact = null;
    },
    setSearchTerm: (state, action: PayloadAction<string>) => {
      state.searchTerm = action.payload;
    },
    clearSearchTerm: (state) => {
      state.searchTerm = '';
    },
    clearContacts: (state) => {
      state.contacts = [];
      state.pagination = null;
    },
    setLoading: (state, action: PayloadAction<boolean>) => {
      state.isLoading = action.payload;
    },

    addContactOptimistic: (state, action: PayloadAction<ContactData>) => {
      state.contacts.unshift(action.payload);
    },
    updateContactOptimistic: (
      state,
      action: PayloadAction<{ id: number; data: Partial<ContactData> }>
    ) => {
      const index = state.contacts.findIndex(
        (contact) => contact.id === action.payload.id
      );
      if (index !== -1) {
        state.contacts[index] = {
          ...state.contacts[index],
          ...action.payload.data,
        };
      }
    },
    removeContactOptimistic: (state, action: PayloadAction<number>) => {
      state.contacts = state.contacts.filter(
        (contact) => contact.id !== action.payload
      );
    },
  },
  extraReducers: (builder) => {
    builder

      .addCase(fetchContacts.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchContacts.fulfilled, (state, action) => {
        state.isLoading = false;
        state.contacts = action.payload.contacts.data;
        state.pagination = {
          current_page: action.payload.contacts.current_page,
          last_page: action.payload.contacts.last_page,
          per_page: action.payload.contacts.per_page,
          total: action.payload.contacts.total,
          from: action.payload.contacts.from,
          to: action.payload.contacts.to,
        };
        state.error = null;
      })
      .addCase(fetchContacts.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload || 'Failed to fetch contacts';
      })

      .addCase(createContact.pending, (state) => {
        state.isCreating = true;
        state.error = null;
      })
      .addCase(createContact.fulfilled, (state, action) => {
        state.isCreating = false;
        state.error = null;
      })
      .addCase(createContact.rejected, (state, action) => {
        state.isCreating = false;
        state.error = action.payload || 'Failed to create contact';
      })

      .addCase(updateContact.pending, (state) => {
        state.isUpdating = true;
        state.error = null;
      })
      .addCase(updateContact.fulfilled, (state, action) => {
        state.isUpdating = false;
        state.error = null;
      })
      .addCase(updateContact.rejected, (state, action) => {
        state.isUpdating = false;
        state.error = action.payload || 'Failed to update contact';
      })

      .addCase(deleteContact.pending, (state) => {
        state.isDeleting = true;
        state.error = null;
      })
      .addCase(deleteContact.fulfilled, (state, action) => {
        state.isDeleting = false;
        state.error = null;
      })
      .addCase(deleteContact.rejected, (state, action) => {
        state.isDeleting = false;
        state.error = action.payload || 'Failed to delete contact';
      })

      .addCase(searchContacts.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(searchContacts.fulfilled, (state, action) => {
        state.isLoading = false;
        state.contacts = action.payload.contacts.data;
        state.pagination = {
          current_page: action.payload.contacts.current_page,
          last_page: action.payload.contacts.last_page,
          per_page: action.payload.contacts.per_page,
          total: action.payload.contacts.total,
          from: action.payload.contacts.from,
          to: action.payload.contacts.to,
        };
        state.error = null;
      })
      .addCase(searchContacts.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload || 'Failed to search contacts';
      })

      .addCase(getContactById.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(getContactById.fulfilled, (state, action) => {
        state.isLoading = false;
        state.currentContact = action.payload;
        state.error = null;
      })
      .addCase(getContactById.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload || 'Failed to fetch contact';
      });
  },
});

export const {
  clearError,
  setCurrentContact,
  clearCurrentContact,
  setSearchTerm,
  clearSearchTerm,
  clearContacts,
  setLoading,
  addContactOptimistic,
  updateContactOptimistic,
  removeContactOptimistic,
} = contactSlice.actions;

// Selectors
export const selectContacts = (state: { contacts: ContactState }) =>
  state.contacts.contacts;
export const selectCurrentContact = (state: { contacts: ContactState }) =>
  state.contacts.currentContact;
export const selectContactsPagination = (state: { contacts: ContactState }) =>
  state.contacts.pagination;
export const selectContactsLoading = (state: { contacts: ContactState }) =>
  state.contacts.isLoading;
export const selectContactsCreating = (state: { contacts: ContactState }) =>
  state.contacts.isCreating;
export const selectContactsUpdating = (state: { contacts: ContactState }) =>
  state.contacts.isUpdating;
export const selectContactsDeleting = (state: { contacts: ContactState }) =>
  state.contacts.isDeleting;
export const selectContactsError = (state: { contacts: ContactState }) =>
  state.contacts.error;
export const selectContactsSearchTerm = (state: { contacts: ContactState }) =>
  state.contacts.searchTerm;


export const selectContactById =
  (id: number) => (state: { contacts: ContactState }) =>
    state.contacts.contacts.find((contact) => contact.id === id);

export const selectContactsByAttribute =
  (attribute: string, value: string) => (state: { contacts: ContactState }) =>
    state.contacts.contacts.filter((contact) =>
      contact.attributes.some(
        (attr) => attr.attribute === attribute && attr.attribute_value === value
      )
    );

export const selectContactsWithBroadcastAllowed = (state: {
  contacts: ContactState;
}) =>
  state.contacts.contacts.filter(
    (contact) =>
    
      true 
  );

export const selectTotalContacts = (state: { contacts: ContactState }) =>
  state.contacts.pagination?.total || 0;

export const selectIsLastPage = (state: { contacts: ContactState }) =>
  state.contacts.pagination
    ? state.contacts.pagination.current_page >=
      state.contacts.pagination.last_page
    : true;

export const selectIsFirstPage = (state: { contacts: ContactState }) =>
  state.contacts.pagination
    ? state.contacts.pagination.current_page <= 1
    : true;

export default contactSlice.reducer;
