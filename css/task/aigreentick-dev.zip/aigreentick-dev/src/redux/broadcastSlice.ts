import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import AiGreenTickApi from '@/services/api';

// Types for broadcast
export interface BroadcastPayload {
  template_id: string;
  country_id: number;
  camp_name: string;
  mobile_numbers: string[];
  is_media: boolean;
  media_type: string;
  media_url: string;
  schedule_date: string;
  variables: string;
}

// Types for CSV broadcast
export interface CSVVariable {
  variable: string;
  value?: number | string;
}

export interface CSVMobileVariable {
  mobile: number;
  variable: CSVVariable[];
}

export interface CSVBroadcastPayload {
  template_id: string;
  col_name: string;
  country_id: number;
  camp_name: string;
  is_media: boolean;
  media_type: string;
  media_url: string;
  mobile_numbers: number[];
  schedule_date: string;
  variables: (CSVMobileVariable | { variable: CSVVariable[] })[];
}

export interface BroadcastResponse {
  success: boolean;
  message: string;
  data?: any;
  campaign_id?: number;
  delivery_status?: string;
}

export interface CSVBroadcastResponse {
  success: string;
}

interface BroadcastState {
  loading: boolean;
  error: string | null;
  success: boolean;
  lastCampaign: BroadcastResponse | null;
  campaignHistory: BroadcastResponse[];
  // CSV broadcast specific state
  csvLoading: boolean;
  csvError: string | null;
  csvSuccess: boolean;
  lastCSVCampaign: CSVBroadcastResponse | null;
}

/* ---------- Async Thunks ---------- */

/**
 * Send broadcast campaign
 */
export const sendBroadcast = createAsyncThunk<
  BroadcastResponse,
  BroadcastPayload
>('broadcast/send', async (campaignData, thunkAPI) => {
  try {
    console.log('Sending broadcast campaign:', campaignData);
    const data = await AiGreenTickApi.broadcast.send(campaignData);
    console.log('Broadcast API Response:', data);
    return data as BroadcastResponse;
  } catch (err: any) {
    console.error('Broadcast API Error:', err);
    return thunkAPI.rejectWithValue(
      err?.response?.data?.message ||
        err?.response?.data?.error ||
        err.message ||
        'Failed to send broadcast campaign'
    );
  }
});

/**
 * Send CSV broadcast campaign
 */
export const sendCSVBroadcast = createAsyncThunk<
  CSVBroadcastResponse,
  CSVBroadcastPayload
>('broadcast/sendCSV', async (campaignData, thunkAPI) => {
  try {
    console.log('Sending CSV broadcast campaign:', campaignData);
    const data = await AiGreenTickApi.broadcast.sendCSVCampaign(campaignData);
    console.log('CSV Broadcast API Response:', data);
    return data as CSVBroadcastResponse;
  } catch (err: any) {
    console.error('CSV Broadcast API Error:', err);
    return thunkAPI.rejectWithValue(
      err?.response?.data?.message ||
        err?.response?.data?.error ||
        err.message ||
        'Failed to send CSV broadcast campaign'
    );
  }
});

const initialState: BroadcastState = {
  loading: false,
  error: null,
  success: false,
  lastCampaign: null,
  campaignHistory: [],
  // CSV broadcast initial state
  csvLoading: false,
  csvError: null,
  csvSuccess: false,
  lastCSVCampaign: null,
};

const broadcastSlice = createSlice({
  name: 'broadcast',
  initialState,
  reducers: {
    clearError(state) {
      state.error = null;
    },
    clearSuccess(state) {
      state.success = false;
    },
    clearCSVError(state) {
      state.csvError = null;
    },
    clearCSVSuccess(state) {
      state.csvSuccess = false;
    },
    resetBroadcast(state) {
      state.loading = false;
      state.error = null;
      state.success = false;
      state.lastCampaign = null;
    },
    resetCSVBroadcast(state) {
      state.csvLoading = false;
      state.csvError = null;
      state.csvSuccess = false;
      state.lastCSVCampaign = null;
    },
    clearHistory(state) {
      state.campaignHistory = [];
    },
  },
  extraReducers: (builder) => {
    builder
      // Regular broadcast cases
      .addCase(sendBroadcast.pending, (state) => {
        state.loading = true;
        state.error = null;
        state.success = false;
      })
      .addCase(sendBroadcast.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.success = true;
        state.lastCampaign = action.payload;
        state.campaignHistory.unshift(action.payload);
        console.log('Broadcast campaign sent successfully:', action.payload);
      })
      .addCase(sendBroadcast.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
        state.success = false;
        console.error('Failed to send broadcast campaign:', action.payload);
      })

      // CSV broadcast cases
      .addCase(sendCSVBroadcast.pending, (state) => {
        state.csvLoading = true;
        state.csvError = null;
        state.csvSuccess = false;
      })
      .addCase(sendCSVBroadcast.fulfilled, (state, action) => {
        state.csvLoading = false;
        state.csvError = null;
        state.csvSuccess = true;
        state.lastCSVCampaign = action.payload;
        console.log(
          'CSV Broadcast campaign sent successfully:',
          action.payload
        );
      })
      .addCase(sendCSVBroadcast.rejected, (state, action) => {
        state.csvLoading = false;
        state.csvError = action.payload as string;
        state.csvSuccess = false;
        console.error('Failed to send CSV broadcast campaign:', action.payload);
      });
  },
});

export const {
  clearError,
  clearSuccess,
  clearCSVError,
  clearCSVSuccess,
  resetBroadcast,
  resetCSVBroadcast,
  clearHistory,
} = broadcastSlice.actions;

// Regular broadcast selectors
export const selectBroadcastLoading = (state: { broadcast: BroadcastState }) =>
  state.broadcast.loading;

export const selectBroadcastError = (state: { broadcast: BroadcastState }) =>
  state.broadcast.error;

export const selectBroadcastSuccess = (state: { broadcast: BroadcastState }) =>
  state.broadcast.success;

export const selectLastCampaign = (state: { broadcast: BroadcastState }) =>
  state.broadcast.lastCampaign;

export const selectCampaignHistory = (state: { broadcast: BroadcastState }) =>
  state.broadcast.campaignHistory;

// CSV broadcast selectors
export const selectCSVBroadcastLoading = (state: {
  broadcast: BroadcastState;
}) => state.broadcast.csvLoading;

export const selectCSVBroadcastError = (state: { broadcast: BroadcastState }) =>
  state.broadcast.csvError;

export const selectCSVBroadcastSuccess = (state: {
  broadcast: BroadcastState;
}) => state.broadcast.csvSuccess;

export const selectLastCSVCampaign = (state: { broadcast: BroadcastState }) =>
  state.broadcast.lastCSVCampaign;

export default broadcastSlice.reducer;
