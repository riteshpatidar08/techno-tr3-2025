import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import { RootState } from './store';
import {
  AiGreenTickApi,
  Tag,
  TagsResponse,
  CreateTagData,
  UpdateTagData,
} from '@/services/api';

interface TagsState {
  tags: Tag[];
  selectedTag: Tag | null;
  loading: boolean;
  creating: boolean;
  updating: boolean;
  deleting: boolean;
  addingNumber: boolean;
  removingNumber: boolean;
  error: string | null;
  pagination: {
    currentPage: number;
    totalPages: number;
    totalItems: number;
    hasMore: boolean;
  };
  filters: {
    search: string;
    from: string;
    to: string;
  };
}

const initialState: TagsState = {
  tags: [],
  selectedTag: null,
  loading: false,
  creating: false,
  updating: false,
  deleting: false,
  addingNumber: false,
  removingNumber: false,
  error: null,
  pagination: {
    currentPage: 1,
    totalPages: 1,
    totalItems: 0,
    hasMore: false,
  },
  filters: {
    search: '',
    from: '',
    to: '',
  },
};

/**
 * Fetch all tags with optional filtering
 */
export const fetchTags = createAsyncThunk(
  'tags/fetchTags',
  async (
    params: {
      search?: string;
      from?: string;
      to?: string;
      page?: number;
    } = {},
    { rejectWithValue }
  ) => {
    try {
      const response = await AiGreenTickApi.tags.fetchAll(params);
      return response;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || error.message || 'Failed to fetch tags'
      );
    }
  }
);

/**
 * Create a new tag
 */
export const createTag = createAsyncThunk(
  'tags/createTag',
  async (tagData: CreateTagData, { rejectWithValue }) => {
    try {
      const response = await AiGreenTickApi.tags.create(tagData);
      return response;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || error.message || 'Failed to create tag'
      );
    }
  }
);

/**
 * Update an existing tag
 */
export const updateTag = createAsyncThunk(
  'tags/updateTag',
  async (
    { id, tagData }: { id: number; tagData: UpdateTagData },
    { rejectWithValue }
  ) => {
    try {
      const response = await AiGreenTickApi.tags.update(id, tagData);
      return response;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || error.message || 'Failed to update tag'
      );
    }
  }
);

/**
 * Delete a tag
 */
export const deleteTag = createAsyncThunk(
  'tags/deleteTag',
  async (id: number, { rejectWithValue }) => {
    try {
      await AiGreenTickApi.tags.delete(id);
      return id;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || error.message || 'Failed to delete tag'
      );
    }
  }
);

/**
 * Get a specific tag by ID
 */
export const fetchTagById = createAsyncThunk(
  'tags/fetchTagById',
  async (id: number, { rejectWithValue }) => {
    try {
      const response = await AiGreenTickApi.tags.getById(id);
      return response;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || error.message || 'Failed to fetch tag'
      );
    }
  }
);

/**
 * Add a number to a tag
 */
export const addNumberToTag = createAsyncThunk(
  'tags/addNumberToTag',
  async (
    {
      tagId,
      mobile,
      countryId,
    }: {
      tagId: number;
      mobile: string;
      countryId: number;
    },
    { rejectWithValue }
  ) => {
    try {
      const response = await AiGreenTickApi.tags.addNumber(
        tagId,
        mobile,
        countryId
      );
      return { tagId, response };
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message ||
          error.message ||
          'Failed to add number to tag'
      );
    }
  }
);

/**
 * Remove a number from a tag
 */
export const removeNumberFromTag = createAsyncThunk(
  'tags/removeNumberFromTag',
  async (
    { tagId, numberId }: { tagId: number; numberId: number },
    { rejectWithValue }
  ) => {
    try {
      await AiGreenTickApi.tags.removeNumber(tagId, numberId);
      return { tagId, numberId };
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message ||
          error.message ||
          'Failed to remove number from tag'
      );
    }
  }
);

/**
 * Get tags by mobile number
 */
export const fetchTagsByMobile = createAsyncThunk(
  'tags/fetchTagsByMobile',
  async (mobile: string, { rejectWithValue }) => {
    try {
      const response = await AiGreenTickApi.tags.getByMobile(mobile);
      return response;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message ||
          error.message ||
          'Failed to fetch tags by mobile'
      );
    }
  }
);

const tagsSlice = createSlice({
  name: 'tags',
  initialState,
  reducers: {
    setSelectedTag: (state, action: PayloadAction<Tag | null>) => {
      state.selectedTag = action.payload;
    },

    clearSelectedTag: (state) => {
      state.selectedTag = null;
    },

    setFilters: (
      state,
      action: PayloadAction<{
        search?: string;
        from?: string;
        to?: string;
      }>
    ) => {
      state.filters = { ...state.filters, ...action.payload };
    },

    clearFilters: (state) => {
      state.filters = {
        search: '',
        from: '',
        to: '',
      };
    },

    clearError: (state) => {
      state.error = null;
    },

    resetTagsState: (state) => {
      return initialState;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchTags.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTags.fulfilled, (state, action) => {
        state.loading = false;
        state.tags = action.payload.data || [];

        state.pagination = {
          currentPage: 1,
          totalPages: 1,
          totalItems: action.payload.data?.length || 0,
          hasMore: false,
        };
      })
      .addCase(fetchTags.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });

    builder
      .addCase(createTag.pending, (state) => {
        state.creating = true;
        state.error = null;
      })
      .addCase(createTag.fulfilled, (state, action) => {
        state.creating = false;
        state.tags.unshift(action.payload);
      })
      .addCase(createTag.rejected, (state, action) => {
        state.creating = false;
        state.error = action.payload as string;
      });

    builder
      .addCase(updateTag.pending, (state) => {
        state.updating = true;
        state.error = null;
      })
      .addCase(updateTag.fulfilled, (state, action) => {
        state.updating = false;
        const index = state.tags.findIndex(
          (tag) => tag.id === action.payload.id
        );
        if (index !== -1) {
          state.tags[index] = action.payload;
        }
        if (state.selectedTag?.id === action.payload.id) {
          state.selectedTag = action.payload;
        }
      })
      .addCase(updateTag.rejected, (state, action) => {
        state.updating = false;
        state.error = action.payload as string;
      });

    builder
      .addCase(deleteTag.pending, (state) => {
        state.deleting = true;
        state.error = null;
      })
      .addCase(deleteTag.fulfilled, (state, action) => {
        state.deleting = false;
        state.tags = state.tags.filter((tag) => tag.id !== action.payload);
        if (state.selectedTag?.id === action.payload) {
          state.selectedTag = null;
        }
      })
      .addCase(deleteTag.rejected, (state, action) => {
        state.deleting = false;
        state.error = action.payload as string;
      });

    builder
      .addCase(fetchTagById.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTagById.fulfilled, (state, action) => {
        state.loading = false;
        state.selectedTag = action.payload;

        const index = state.tags.findIndex(
          (tag) => tag.id === action.payload.id
        );
        if (index !== -1) {
          state.tags[index] = action.payload;
        }
      })
      .addCase(fetchTagById.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });

    builder
      .addCase(addNumberToTag.pending, (state) => {
        state.addingNumber = true;
        state.error = null;
      })
      .addCase(addNumberToTag.fulfilled, (state, action) => {
        state.addingNumber = false;
      })
      .addCase(addNumberToTag.rejected, (state, action) => {
        state.addingNumber = false;
        state.error = action.payload as string;
      });

    builder
      .addCase(removeNumberFromTag.pending, (state) => {
        state.removingNumber = true;
        state.error = null;
      })
      .addCase(removeNumberFromTag.fulfilled, (state, action) => {
        state.removingNumber = false;

        const tag = state.tags.find((t) => t.id === action.payload.tagId);
        if (tag) {
          tag.number = tag.number.filter(
            (num) => num.id !== action.payload.numberId
          );
          tag.number_count = tag.number.length;
        }

        if (state.selectedTag?.id === action.payload.tagId) {
          state.selectedTag.number = state.selectedTag.number.filter(
            (num) => num.id !== action.payload.numberId
          );
          state.selectedTag.number_count = state.selectedTag.number.length;
        }
      })
      .addCase(removeNumberFromTag.rejected, (state, action) => {
        state.removingNumber = false;
        state.error = action.payload as string;
      });

    builder
      .addCase(fetchTagsByMobile.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTagsByMobile.fulfilled, (state, action) => {
        state.loading = false;
      })
      .addCase(fetchTagsByMobile.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const {
  setSelectedTag,
  clearSelectedTag,
  setFilters,
  clearFilters,
  clearError,
  resetTagsState,
} = tagsSlice.actions;

export const selectTags = (state: RootState) => state.tags.tags;
export const selectSelectedTag = (state: RootState) => state.tags.selectedTag;
export const selectTagsLoading = (state: RootState) => state.tags.loading;
export const selectTagsCreating = (state: RootState) => state.tags.creating;
export const selectTagsUpdating = (state: RootState) => state.tags.updating;
export const selectTagsDeleting = (state: RootState) => state.tags.deleting;
export const selectTagsAddingNumber = (state: RootState) =>
  state.tags.addingNumber;
export const selectTagsRemovingNumber = (state: RootState) =>
  state.tags.removingNumber;
export const selectTagsError = (state: RootState) => state.tags.error;
export const selectTagsPagination = (state: RootState) => state.tags.pagination;
export const selectTagsFilters = (state: RootState) => state.tags.filters;

export const selectTagById = (id: number) => (state: RootState) =>
  state.tags.tags.find((tag) => tag.id === id);

export const selectTagsByStatus = (status: string) => (state: RootState) =>
  state.tags.tags.filter((tag) => tag.status === status);

export const selectTagsWithNumbers = (state: RootState) =>
  state.tags.tags.filter((tag) => tag.number_count > 0);

export const selectTagsByMobile = (mobile: string) => (state: RootState) =>
  state.tags.tags.filter((tag) =>
    tag.number.some((num) => num.mobile === mobile)
  );

export default tagsSlice.reducer;
