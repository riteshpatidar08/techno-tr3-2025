import axios, { AxiosInstance, AxiosResponse } from 'axios';
import { SecureAuth } from './secure-auth';
import { secureStorage } from './secure-storage';
interface LoginCredentials {
  email: string;
  password: string;
}


interface ContactAttribute {
  id: number;
  contact_id: number;
  attribute: string;
  attribute_value: string;
}

interface ContactData {
  id: number;
  name: string;
  mobile: string;
  user_id: number;
  attributes: ContactAttribute[];
}

interface ContactsResponse {
  status: boolean;
  contacts: {
    current_page: number;
    data: ContactData[];
    first_page_url: string;
    from: number;
    last_page: number;
    last_page_url: string;
    links: Array<{
      url: string | null;
      label: string;
      active: boolean;
    }>;
    next_page_url: string | null;
    path: string;
    per_page: number;
    prev_page_url: string | null;
    to: number;
    total: number;
  };
}

interface CreateContactData {
  phone_number: string;
  name: string;
  allowed_broadcast: boolean;
  allowed_sms: boolean;
  attributes?: {
    [key: string]: string;
  };
}

interface CreateContactResponse {
  status: boolean;
  message: string;
}

interface UpdateContactData {
  phone_number?: string;
  name?: string;
  allowed_broadcast?: boolean;
  allowed_sms?: boolean;
  attributes?: {
    [key: string]: string;
  };
}

interface UpdateContactResponse {
  status: boolean;
  message: string;
}

interface DeleteContactResponse {
  message: string;
}

interface RegisterData {
  name: string;
  email: string;
  password: string;
  mobile: string;
}

interface SendMessageData {
  message: string;
  recipient_mobile: string;
  recipient_name: string;
  template_id?: number | null;
  reaction?: string;
  isReply?: boolean;
  media_type?: string;
  media_url?: string;
  filename?: string;
  caption?: string;
  channel: string;
}

interface User {
  id: number;
  role_id: number;
  created_by: number | null;
  country_id: number;
  name: string;
  mobile: string;
  profile_photo: string | null;
  rememberToken: string | null;
  api_token: string;
  email: string;
  company_name: string | null;
  city: string | null;
  market_msg_charge: number | null;
  utilty_msg_charge: number;
  auth_msg_charge: number;
  balance: number;
  balance_enabled: number;
  online_status: string;
  agent_id: number | null;
  credit: number;
  debit: number;
  status: string;
  domain: string | null;
  logo: string | null;
  is_demo: string;
  demo_end: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  webhook_token: string | null;
  permission?: any[];
}

interface LoginResponse {
  success: User;
}

interface DashboardData {
  data: {
    chatbot_count: number;
    template_count: number;
    report_count: number;
    user: User & {
      country: {
        id: number;
        name: string;
        mobile_code: string;
        created_at: string;
        updated_at: string;
        deleted_at: string | null;
      };
      agents: any[];
      users: any[];
    };
    balance: number;
  };
}

interface ChatMessage {
  id: number;
  user_id: number;
  contact_id: number;
  send_from: string;
  send_to: string;
  send_from_id: string;
  send_to_id: string;
  text: string;
  type: string;
  method: string;
  image_id: number | null;
  time: string;
  template_id: number | null;
  status: string;
  is_media: string;
  contact: string;
  response: string;
  message_id: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
}

// Country interfaces
interface Country {
  id: number;
  name: string;
  mobile_code: string;
  iso_code?: string;
  flag?: string;
  currency?: string;
  timezone?: string;
  status?: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
}

interface RegisterData {
  name: string;
  email: string;
  mobile: string;
  password: string;
}

interface RegisterResponse {
  success: boolean;
  message: string;
  data?: {
    user: {
      id: number;
      name: string;
      email: string;
      mobile: string;
      created_at: string;
      updated_at: string;
    };
    token?: string; 
    verification_required?: boolean;
  };
}

interface ApiError {
  success: false;
  message: string;
  errors?: {
    [key: string]: string[];
  };
}
interface CountriesResponse {
  data: Country[];
  current_page?: number;
  last_page?: number;
  per_page?: number;
  total?: number;
}


interface CSVVariable {
  variable: string;
  value?: number | string;
}

interface CSVMobileVariable {
  mobile: number;
  variable: CSVVariable[];
}

interface CSVBroadcastPayload {
  template_id: string;
  col_name: string;
  country_id: number;
  camp_name: string;
  is_media: boolean;
  media_type: string;
  media_url: string;
  mobile_numbers: number[];
  schedule_date: string;
  variables: (CSVMobileVariable | { variable: CSVVariable[] })[];
}
interface CreateCountryData {
  name: string;
  mobile_code: string;
  iso_code?: string;
  flag?: string;
  currency?: string;
  timezone?: string;
  status?: string;
}

interface UpdateCountryData {
  name?: string;
  mobile_code?: string;
  iso_code?: string;
  flag?: string;
  currency?: string;
  timezone?: string;
  status?: string;
}
interface Contact {
  id: number;
  user_id: number;
  name: string;
  mobile: string;
  time: number;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  total_msg_count: number;
  last_chat: ChatMessage;
}

interface Channel {
  id: number;
  user_id: number;
  created_by: number;
  whatsapp_no: string;
  whatsapp_no_id: string;
  whatsapp_biz_id: string;
  parmenent_token: string;
  token: string;
  status: string;
  response: string | null;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  user: User;
}

interface MessagesResponse {
  users: {
    current_page: number;
    data: Contact[];
    first_page_url: string;
    from: number;
    last_page: number;
    last_page_url: string;
    links: Array<{
      url: string | null;
      label: string;
      active: boolean;
    }>;
    next_page_url: string | null;
    path: string;
    per_page: number;
    prev_page_url: string | null;
    to: number;
    total: number;
  };
  channel: Channel[];
}

interface TagNumber {
  id: number;
  user_id: number;
  tag_id: number;
  mobile: string;
  country_id: number;
  status: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
}

interface Tag {
  id: number;
  user_id: number;
  name: string;
  tag_color: string;
  status: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  number_count: number;
  keyword: any[];
  number: TagNumber[];
}

interface TagsResponse {
  data: Tag[];
}

interface CreateTagData {
  tags: string[];
  keywords: string[];
  selectedColor: string;
  status: string;
}

interface UpdateTagData {
  name?: string;
  tag_color?: string;
  status?: string;
}

interface ConversationResponse {
  data: any;
}

interface ApiError {
  error: string;
}

/**
 * Create a configured Axios instance for all API requests
 * This ensures consistent configuration across the application
 */
const apiClient: AxiosInstance = axios.create({
  baseURL: 'https://aigreentick.com/api/v1',
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
    Accept: 'application/json',
  },
});

/**
 * Request interceptor
 * Adds authentication token to requests if available
 */
apiClient.interceptors.request.use(
  (config) => {
   
    const token = SecureAuth.getCurrentToken();

    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    console.log(
      `Making ${config.method?.toUpperCase()} request to ${config.url}`
    );

    return config;
  },
  (error) => {
    console.error('Request interceptor error:', error);
    return Promise.reject(error);
  }
);


apiClient.interceptors.response.use(
  (response) => {
    
    return response;
  },
  (error) => {
   
    if (error.response && error.response.status === 401) {
      console.warn('Token expired or invalid, clearing auth data');

     
      SecureAuth.clearAuthentication();

     
      window.location.href = '/login';
    }

    console.error('API Error:', error.response?.data || error.message);
    return Promise.reject(error);
  }
);

/**
 * Response interceptor
 * Handles global response processing and error handling
 */
apiClient.interceptors.response.use(
  (response: AxiosResponse) => {
    console.log(`Response from ${response.config.url}:`, response.status);
    return response;
  },
  (error) => {
    if (error.response) {
      const status = error.response.status;
      const data = error.response.data;

      switch (status) {
        case 401:
          console.error('Unauthorized access - clearing stored token');
          localStorage.removeItem('ai_green_tick_token');
          localStorage.removeItem('ai_green_tick_user');
          break;
        case 403:
          console.error('Forbidden - insufficient permissions');
          break;
        case 404:
          console.error('Resource not found');
          break;
        case 422:
          console.error('Validation error:', data);
          break;
        case 500:
          console.error('Server error occurred');
          break;
        default:
          console.error(`API error (${status}):`, data);
      }
    } else if (error.request) {
      console.error('Network error - no response received');
    } else {
      console.error('Request setup error:', error.message);
    }

    return Promise.reject(error);
  }
);

/**
 * AI Green Tick API Service
 * Organizes endpoints into logical groups
 */
export const AiGreenTickApi = {
  /**
   * Authentication endpoints
   */
  auth: {
    /**
     * User login
     * @param credentials - User email and password
     * @returns Promise resolving to user data with auth token
     */
    login: async (credentials: LoginCredentials): Promise<LoginResponse> => {
      const response = await apiClient.post<LoginResponse>(
        '/login',
        credentials
      );

      if (response.data.success) {
        // CHANGED: Use secure storage instead of localStorage
        secureStorage.setItem('auth_token', response.data.success.api_token);
        secureStorage.setItem('ai_green_tick_user', response.data.success);
        localStorage.setItem('isAuthenticated', 'true'); // Keep this for auth flag
      }

      return response.data;
    },

    /**
     * User logout
     * Clears stored authentication data
     */
    logout: async (): Promise<void> => {
      try {
        await apiClient.post('/logout');
      } catch (error) {
        console.warn('Logout endpoint not available, clearing local data only');
      } finally {
        // CHANGED: Clear secure storage
        secureStorage.removeItem('auth_token');
        secureStorage.removeItem('ai_green_tick_user');
        localStorage.removeItem('isAuthenticated');
      }
    },

    /**
     * Register a new user
     * @param userData - New user registration data
     * @returns Promise resolving to registration result
     */
    register: async (
      userData: RegisterData
    ): Promise<RegisterResponse | ApiError> => {
      try {
        const response = await apiClient.post<RegisterResponse | ApiError>(
          '/signup',
          userData
        );

        // CHANGED: If registration successful, store data securely
        if (
          response.data &&
          'success' in response.data &&
          response.data.success
        ) {
          secureStorage.setItem('auth_token', response.data.success.api_token);
          secureStorage.setItem('ai_green_tick_user', response.data.success);
          localStorage.setItem('isAuthenticated', 'true');
        }

        return response.data;
      } catch (error: any) {
        if (error.response?.data) {
          return error.response.data;
        } else if (error.request) {
          return {
            success: false,
            message:
              'Network error. Please check your connection and try again.',
          };
        } else {
          return {
            success: false,
            message: 'An unexpected error occurred. Please try again.',
          };
        }
      }
    },

    /**
     * Get stored user data
     * @returns User data from secure storage or null
     */
    getCurrentUser: (): User | null => {
      // CHANGED: Use secure storage with validation
      if (!secureStorage.getItem('auth_token')) {
        return null; // No valid token, no user
      }

      const userData = secureStorage.getItem('ai_green_tick_user');
      return userData || null;
    },

    /**
     * Get stored auth token
     * @returns Auth token from secure storage or null
     */
    getCurrentToken: (): string | null => {
      return secureStorage.getItem('auth_token');
    },

    /**
     * Check if user is authenticated
     * @returns Boolean indicating authentication status
     */
    isAuthenticated: (): boolean => {
      const token = secureStorage.getItem('auth_token');
      const user = secureStorage.getItem('ai_green_tick_user');
      const authFlag = localStorage.getItem('isAuthenticated') === 'true';

      // CHANGED: Triple validation - all three must be present
      return !!(token && user && user.id && authFlag);
    },

    /**
     * Clear all authentication data (useful for cleanup)
     */
    clearAuthData: (): void => {
      secureStorage.removeItem('auth_token');
      secureStorage.removeItem('ai_green_tick_user');
      localStorage.removeItem('isAuthenticated');
    },

    /**
     * Validate current authentication state
     * Clears invalid data if found
     * @returns Boolean indicating if auth state is valid
     */
    validateAuthState: (): boolean => {
      const isValid = this.isAuthenticated();

      if (!isValid) {
        // Clean up any partial/invalid data
        this.clearAuthData();
      }

      return isValid;
    },
  },
  whatsapp: {
    /**
     * Fetch all official WhatsApp numbers with pagination
     * @param page - Page number (default: 1)
     * @returns Promise resolving to WhatsApp numbers data
     */
    fetchAll: async (page: number = 1): Promise<any> => {
      const response = await apiClient.get(`/wa?page=${page}`);
      return response.data;
    },
  },  

  /**
   * Dashboard endpoints
   */
  dashboard: {
    /**
     * Fetch dashboard data including counts and user info
     * @returns Promise resolving to dashboard statistics
     */
    fetchData: async (): Promise<DashboardData> => {
      const response = await apiClient.get<DashboardData>('/dashboard');
      return response.data;
    },
  },

  /**
   * Broadcast endpoints
   */
  broadcast: {
    /**
     * Send broadcast campaign
     * @param campaignData - Campaign configuration and message data
     * @returns Promise resolving to campaign send result
     */
    send: async (campaignData: any): Promise<any> => {
      const response = await apiClient.post('/broadcast', campaignData);
      return response.data;
    },

    sendCSVCampaign: async (
      payload: CSVBroadcastPayload
    ): Promise<CSVBroadcastResponse> => {
      const response = await apiClient.post('/csv', payload);
      return response.data;
    },
  },

  /**
   * Messaging endpoints
   */
  messages: {
    /**
     * Fetch messages with optional filtering
     * @param params - Query parameters for filtering
     * @returns Promise resolving to messages and contacts data
     */
    fetchAll: async (
      params: {
        selectedChannel?: string | null;
        chat?: string;
        page?: number;
        search?: string;
      } = {}
    ): Promise<MessagesResponse> => {
      const queryParams = new URLSearchParams();
      if (params.selectedChannel !== undefined) {
        queryParams.append('selectedChannel', params.selectedChannel || '');
      }
      if (params.chat !== undefined) {
        queryParams.append('chat', params.chat);
      }
      if (params.page !== undefined) {
        queryParams.append('page', params.page.toString());
      }
      if (params.search !== undefined) {
        queryParams.append('search', params.search);
      }

      const response = await apiClient.get<MessagesResponse>(
        `/sendMessage?${queryParams.toString()}`
      );
      return response.data;
    },

    /**
     * Fetch individual conversation messages
     * @param contactNumber - Contact phone number
     * @param params - Query parameters
     * @returns Promise resolving to conversation messages
     */
    fetchConversation: async (
      contactNumber: string,
      params: {
        selectedChannel: string;
        page?: number;
      }
    ): Promise<ConversationResponse> => {
      const queryParams = new URLSearchParams();
      queryParams.append('selectedChannel', params.selectedChannel);
      queryParams.append('chat', contactNumber);
      if (params.page !== undefined) {
        queryParams.append('page', params.page.toString());
      }

      console.log(
        'API Call URL:',
        `/sendMessage/${contactNumber}?${queryParams.toString()}`
      );

      const response = await apiClient.get<ConversationResponse>(
        `/sendMessage/${contactNumber}?${queryParams.toString()}`
      );

      console.log('API Response:', response.data);
      return response.data;
    },

    /**
     * Send a message
     * @param messageData - Message content and recipient info
     * @returns Promise resolving to send result
     */
    send: async (messageData: SendMessageData): Promise<any> => {
      const response = await apiClient.post('/sendMessage', messageData);
      return response.data;
    },
  },

  language: {
    fetchAll: async (): Promise<any> => {
      const response = await apiClient.get('/language');
      return response.data;
    },
  },

  media: {
    upload: async (
      file: File
    ): Promise<{
      image: string;
      public_url: string;
      handle?: string;
    }> => {
      const formData = new FormData();
      formData.append('image', file);

      const response = await apiClient.post('wa-template/media', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      return response.data;
    },
  },
    /**
     * Tags endpoints
     */
    tags: {
      /**
       * Fetch all tags with optional filtering
       * @param params - Query parameters for filtering
       * @returns Promise resolving to tags data
       */
      fetchAll: async (
        params: {
          search?: string;
          from?: string;
          to?: string;
          page?: number;
        } = {}
      ): Promise<TagsResponse> => {
        const queryParams = new URLSearchParams();

        if (params.search) {
          queryParams.append('search', params.search);
        }
        if (params.from) {
          queryParams.append('from', params.from);
        }
        if (params.to) {
          queryParams.append('to', params.to);
        }
        if (params.page) {
          queryParams.append('page', params.page.toString());
        }

        const url = queryParams.toString()
          ? `/tag?${queryParams.toString()}`
          : '/tag';

        const response = await apiClient.get<TagsResponse>(url);
        return response.data;
      },

      /**
       * Create a new tag
       * @param tagData - Tag configuration data
       * @returns Promise resolving to created tag
       */
      create: async (tagData: CreateTagData): Promise<Tag> => {
        const response = await apiClient.post<Tag>('/tag', tagData);
        return response.data;
      },

      /**
       * Update an existing tag
       * @param id - Tag ID
       * @param tagData - Updated tag configuration
       * @returns Promise resolving to updated tag
       */
      update: async (id: number, tagData: UpdateTagData): Promise<Tag> => {
        const response = await apiClient.put<Tag>(`/tag/${id}`, tagData);
        return response.data;
      },

      /**
       * Delete a tag
       * @param id - Tag ID
       * @returns Promise resolving to deletion result
       */
      delete: async (id: number): Promise<any> => {
        const response = await apiClient.delete(`/tag/${id}`);
        return response.data;
      },

      /**
       * Get a specific tag by ID
       * @param id - Tag ID
       * @returns Promise resolving to tag details
       */
      getById: async (id: number): Promise<Tag> => {
        const response = await apiClient.get<Tag>(`/tag/${id}`);
        return response.data;
      },

      /**
       * Add a number to a tag
       * @param tagId - Tag ID
       * @param mobile - Mobile number to add
       * @param countryId - Country ID for the mobile number
       * @returns Promise resolving to the result
       */
      addNumber: async (
        tagId: number,
        mobile: string,
        countryId: number
      ): Promise<any> => {
        const response = await apiClient.post(`/tag/${tagId}/number`, {
          mobile,
          country_id: countryId,
        });
        return response.data;
      },

      /**
       * Remove a number from a tag
       * @param tagId - Tag ID
       * @param numberId - Number ID to remove
       * @returns Promise resolving to the result
       */
      removeNumber: async (tagId: number, numberId: number): Promise<any> => {
        const response = await apiClient.delete(
          `/tag/${tagId}/number/${numberId}`
        );
        return response.data;
      },

      /**
       * Get tags by mobile number
       * @param mobile - Mobile number to search for
       * @returns Promise resolving to tags containing this number
       */
      getByMobile: async (mobile: string): Promise<TagsResponse> => {
        const response = await apiClient.get<TagsResponse>(
          `/tag?mobile=${mobile}`
        );
        return response.data;
      },
    },

    contacts: {
      /**
       * Fetch all contacts with pagination
       * @param params - Query parameters for filtering and pagination
       * @returns Promise resolving to paginated contacts data
       */
      fetchAll: async (
        params: {
          page?: number;
          per_page?: number;
          search?: string;
        } = {}
      ): Promise<ContactsResponse> => {
        try {
          const queryParams = new URLSearchParams();
          
          if (params.page) {
            queryParams.append('page', params.page.toString());
          }
          if (params.per_page) {
            queryParams.append('per_page', params.per_page.toString());
          }
          if (params.search) {
            queryParams.append('search', params.search);
          }
  
          const url = queryParams.toString() 
            ? `/contacts?${queryParams.toString()}` 
            : '/contacts';
  
          console.log('API: Fetching contacts from:', url);
          const response = await apiClient.get<ContactsResponse>(url);
          console.log('API: Contacts fetch response:', response.data);
          
          return response.data;
        } catch (error: any) {
          console.error('API: Contacts fetch error:', error);
          throw error;
        }
      },
  
      /**
       * Create a new contact
       * @param contactData - Contact information and preferences
       * @returns Promise resolving to contact creation result
       */
      create: async (contactData: CreateContactData): Promise<CreateContactResponse> => {
        try {
          console.log('API: Creating contact with data:', contactData);
          
          const response = await apiClient.post<CreateContactResponse>('/contacts', contactData);
          
          console.log('API: Contact creation response:', response.data);
          return response.data;
        } catch (error: any) {
          console.error('API: Contact creation error:', error);
          
          if (error.response?.data) {
            throw error;
          }
          
          if (error.response) {
            console.error('API: Server error response:', error.response.data);
            throw error;
          } else if (error.request) {
            console.error('API: Network error:', error.request);
            const networkError = new Error('Network error occurred');
            (networkError as any).response = {
              data: { message: 'Network error occurred' },
            };
            throw networkError;
          } else {
            console.error('API: Unexpected error:', error.message);
            throw error;
          }
        }
      },
  
      /**
       * Update an existing contact
       * @param id - Contact ID
       * @param contactData - Updated contact data
       * @returns Promise resolving to update result
       */
      update: async (id: number | string, contactData: UpdateContactData): Promise<UpdateContactResponse> => {
        try {
          console.log('API: Updating contact ID:', id, 'with data:', contactData);
          
          const response = await apiClient.put<UpdateContactResponse>(`/contacts/${id}`, contactData);
          
          console.log('API: Contact update response:', response.data);
          return response.data;
        } catch (error: any) {
          console.error('API: Contact update error:', error);
          
          if (error.response?.data) {
            throw error;
          }
          
          if (error.response) {
            console.error('API: Server error response:', error.response.data);
            throw error;
          } else if (error.request) {
            console.error('API: Network error:', error.request);
            const networkError = new Error('Network error occurred');
            (networkError as any).response = {
              data: { message: 'Network error occurred' },
            };
            throw networkError;
          } else {
            console.error('API: Unexpected error:', error.message);
            throw error;
          }
        }
      },
  
      /**
       * Delete a contact
       * @param id - Contact ID
       * @returns Promise resolving to deletion result
       */
      delete: async (id: number | string): Promise<DeleteContactResponse> => {
        try {
          console.log('API: Deleting contact ID:', id);
          
          const response = await apiClient.delete<DeleteContactResponse>(`/contacts/${id}`);
          
          console.log('API: Contact deletion response:', response.data);
          return response.data;
        } catch (error: any) {
          console.error('API: Contact deletion error:', error);
          
          if (error.response?.data) {
            throw error;
          }
          
          if (error.response) {
            console.error('API: Server error response:', error.response.data);
            throw error;
          } else if (error.request) {
            console.error('API: Network error:', error.request);
            const networkError = new Error('Network error occurred');
            (networkError as any).response = {
              data: { message: 'Network error occurred' },
            };
            throw networkError;
          } else {
            console.error('API: Unexpected error:', error.message);
            throw error;
          }
        }
      },

    /**
     * Chatbot endpoints
     */
    chatbots: {
      /**
       * Fetch all chatbots
       * @returns Promise resolving to chatbots list
       */
      fetchAll: async (): Promise<any> => {
        const response = await apiClient.get('/chatbots');
        return response.data;
      },

      /**
       * Create a new chatbot
       * @param chatbotData - Chatbot configuration
       * @returns Promise resolving to created chatbot
       */
      create: async (chatbotData: any): Promise<any> => {
        const response = await apiClient.post('/chatbots', chatbotData);
        return response.data;
      },

      /**
       * Update a chatbot
       * @param id - Chatbot ID
       * @param chatbotData - Updated chatbot configuration
       * @returns Promise resolving to updated chatbot
       */
      update: async (id: number, chatbotData: any): Promise<any> => {
        const response = await apiClient.put(`/chatbots/${id}`, chatbotData);
        return response.data;
      },

      /**
       * Delete a chatbot
       * @param id - Chatbot ID
       * @returns Promise resolving to deletion result
       */
      delete: async (id: number): Promise<any> => {
        const response = await apiClient.delete(`/chatbots/${id}`);
        return response.data;
      },
    },
  },
  /**
   * Template endpoints
   */
  templates: {
    /**
     * Fetch all message templates
     * @returns Promise resolving to templates list
     */
    fetchAll: async (page: number = 1): Promise<any> => {
      const response = await apiClient.get(
        `/wa-templates?type=get&page=${page}`
      );
      return response.data;
    },

    /**
     * Fetch templates by page
     * @param page - Page number
     * @returns Promise resolving to templates list
     */
    fetchByPage: async (page: number): Promise<any> => {
      const response = await apiClient.get(
        `/wa-templates?type=get&page=${page}`
      );
      return response.data;
    },

    create: async (templateData: any): Promise<any> => {
      console.log('API: Creating template with data:', templateData);

      try {
        const response = await apiClient.post('/wa-templates', templateData);
        console.log('API: Template creation response:', response.data);

        if (response.data && response.data.error) {
          console.error(
            'API: WhatsApp returned error in success response:',
            response.data.error
          );

          const error = new Error(
            response.data.error.message || 'Template creation failed'
          );

          (error as any).response = {
            data: response.data.error,
          };

          throw error;
        }

        if (response.data && response.data.success === false) {
          console.error('API: Response indicates failure:', response.data);

          const error = new Error(
            response.data.message || 'Template creation failed'
          );
          (error as any).response = {
            data: response.data,
          };

          throw error;
        }

        return response.data;
      } catch (error: any) {
        console.error('API: Template creation error:', error);

        if (error.response?.data) {
          throw error;
        }

        if (error.response) {
          console.error('API: Server error response:', error.response.data);
          throw error;
        } else if (error.request) {
          console.error('API: Network error:', error.request);
          const networkError = new Error('Network error occurred');
          (networkError as any).response = {
            data: { message: 'Network error occurred' },
          };
          throw networkError;
        } else {
          console.error('API: Unexpected error:', error.message);
          throw error;
        }
      }
    },

    /**
     * Update a template
     * @param id - Template ID
     * @param templateData - Updated template configuration
     * @returns Promise resolving to updated template
     */
    update: async (id: number, templateData: any): Promise<any> => {
      const response = await apiClient.put(`/wa-templates/${id}`, templateData);
      return response.data;
    },

    /**
     * Delete a template
     * @param id - Template ID
     * @returns Promise resolving to deletion result
     */
    delete: async (id: number): Promise<any> => {
      console.log('API: Deleting template with ID:', id);

      try {
        const response = await apiClient.delete(`/wa-templates/${id}`);
        console.log('API: Template deletion response:', response.data);

        // Handle different response formats
        if (response.data && response.data.error) {
          console.error(
            'API: WhatsApp returned error in delete response:',
            response.data.error
          );

          const error = new Error(
            response.data.error.message || 'Template deletion failed'
          );
          (error as any).response = {
            data: response.data.error,
          };
          throw error;
        }

        if (response.data && response.data.success === false) {
          console.error(
            'API: Delete response indicates failure:',
            response.data
          );

          const error = new Error(
            response.data.message || 'Template deletion failed'
          );
          (error as any).response = {
            data: response.data,
          };
          throw error;
        }

        return response.data;
      } catch (error: any) {
        console.error('API: Template deletion error:', error);

        if (error.response?.data) {
          throw error;
        }

        if (error.response) {
          console.error('API: Server error response:', error.response.data);
          throw error;
        } else if (error.request) {
          console.error('API: Network error:', error.request);
          const networkError = new Error('Network error occurred');
          (networkError as any).response = {
            data: { message: 'Network error occurred' },
          };
          throw networkError;
        } else {
          console.error('API: Unexpected error:', error.message);
          throw error;
        }
      }
    },

    /**
     * Fetch template by ID from external API
     * @param id - Template ID
     * @returns Promise resolving to template data
     */
    fetchById: async (id: number): Promise<any> => {
      console.log('API: Fetching template by ID:', id);

      try {
        const response = await apiClient.get(`/wa-templates/${id}`);
        console.log('API: Template by ID response:', response.data);
        return response.data;
      } catch (error: any) {
        console.error('API: Template fetch by ID error:', error);
        throw error;
      }
    },
  },
  roles: {
    fetchAgents: async (): Promise<any> => {
      const response = await apiClient.get('/role?type=agent');
      return response.data;
    },
  },

  /**
   * Reports endpoints
   */
  reports: {
    /**
     * Fetch reports with optional filtering
     * @param params - Query parameters for filtering
     * @returns Promise resolving to reports data
     */
    fetchAll: async (
      params: {
        search?: string;
        from?: string;
        to?: string;
        type?: string;
        page?: number;
      } = {}
    ): Promise<any> => {
      const queryParams = {
        search: params.search || '',
        from: params.from || '',
        to: params.to || '',
        type: params.type || '',
        page: params.page || 1,
      };

      const response = await apiClient.get('/report', { params: queryParams });
      return response.data;
    },
    fetchById: async (
      id: string | number,
      params: {
        type?: string;
      } = {}
    ): Promise<any> => {
      const queryParams = {
        type: params.type || 'all',
      };

      const response = await apiClient.get(`/report/${id}`, {
        params: queryParams,
      });
      return response.data;
    },
    fetchByUrl: async (
      id: string | number,
      params: {
        type?: string;
        page?: number;
        per_page?: number;
      } = {}
    ): Promise<any> => {
      const queryParams = {
        type: params.type || '',
        page: params.page || 1,
        per_page: params.per_page || 10,
      };

      const response = await apiClient.get(`/report/${id}`, {
        params: queryParams,
      });
      return response.data;
    },
  },

  countries: {
    /**
     * Fetch all countries
     * @returns Promise resolving to countries data
     */
    fetchAll: async (): Promise<CountriesResponse> => {
      const response = await apiClient.get<CountriesResponse>('/country');
      return response.data;
    },
  },

  utils: {
    getClient: (): AxiosInstance => apiClient,

    setHeaders: (headers: Record<string, string>): void => {
      Object.keys(headers).forEach((key) => {
        apiClient.defaults.headers.common[key] = headers[key];
      });
    },

    clearHeaders: (): void => {
      apiClient.defaults.headers.common = {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      };
    },
  },
}

export { apiClient };
export type {
  LoginCredentials,
  CountriesResponse,
  RegisterData,
  User,
  LoginResponse,
  DashboardData,
  CountriesResponse,
  UpdateCountryData,
  UpdateTagData,
  ChatMessage,
  Contact,
  Channel,
  MessagesResponse,
  ConversationResponse,
  Tag,
  TagNumber,
  TagsResponse,
  CreateTagData,
  UpdateTagData,
  ApiError,
  ContactAttribute,
  ContactData,
  ContactsResponse,
  CreateContactData,
  CreateContactResponse,
  UpdateContactData,
  UpdateContactResponse,
  DeleteContactResponse,
};
export default AiGreenTickApi;
