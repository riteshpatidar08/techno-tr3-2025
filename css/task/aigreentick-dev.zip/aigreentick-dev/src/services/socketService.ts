// services/socketService.js (or .ts if using TypeScript)
import { io, Socket } from 'socket.io-client';

class SocketService {
  private socket: Socket | null = null;
  private listeners: Map<string, Function[]> = new Map();

  constructor() {
    this.connect();
  }

  connect() {
    if (this.socket?.connected) return;

    // ❌ WRONG - Don't use the full polling URL with session parameters
    // 'https://socket.aigreentick.com/socket.io/?EIO=4&transport=polling&t=ekqz8rnn&sid=AVOXPW01OTS3BpKEAAMA'

    // ✅ CORRECT - Use just the base URL
    const socketUrl = 'https://socket.aigreentick.com';

    console.log('🔌 Connecting to Socket.IO server:', socketUrl);

    this.socket = io(socketUrl, {
      // Transport configuration
      transports: ['websocket', 'polling'], // Try websocket first, fallback to polling
      upgrade: true,

      // Connection options
      autoConnect: true,
      reconnection: true,
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      timeout: 20000,

      // CORS and authentication (if needed)
      withCredentials: false, // Set to true if your server requires credentials

    // Additional headers (if your server requires authentication)
      extraHeaders: {
        // Add any required headers here
        // 'Authorization': 'Bearer your-token',
        // 'X-User-ID': 'your-user-id'
      },

      // Query parameters (if your server needs them)
      query: {
        // Add any required query parameters here
        // 'userId': 'your-user-id',
        // 'token': 'your-auth-token'
      },
    });

    this.setupDefaultListeners();
  }

  private setupDefaultListeners() {
    if (!this.socket) return;

    this.socket.on('connect', () => {
      console.log('✅ Socket connected successfully!');
      console.log('🆔 Socket ID:', this.socket?.id);
      console.log('🚀 Transport:', this.socket?.io?.engine?.transport?.name);
      console.log('🌐 URL:', this.socket?.io?.uri);
    });

    this.socket.on('disconnect', (reason) => {
      console.log('❌ Socket disconnected:', reason);

      // Auto-reconnect for certain disconnect reasons
      if (reason === 'io server disconnect') {
        console.log('🔄 Server initiated disconnect, reconnecting...');
        this.socket?.connect();
      }
    });

    this.socket.on('connect_error', (error) => {
      console.error('🔴 Socket connection error:', error);
      console.error('🔍 Error details:', {
        message: error.message,
        description: error.description,
        context: error.context,
        type: error.type,
      });

      // Handle specific error types
      if (error.message.includes('xhr poll error')) {
        console.log('🔄 XHR polling failed, trying websocket...');
      } else if (error.message.includes('websocket error')) {
        console.log('🔄 WebSocket failed, falling back to polling...');
        // Force polling transport
        if (this.socket) {
          this.socket.io.opts.transports = ['polling'];
        }
      }
    });

    this.socket.on('reconnect', (attemptNumber) => {
      console.log('🔄 Socket reconnected after', attemptNumber, 'attempts');
      console.log(
        '🚀 New transport:',
        this.socket?.io?.engine?.transport?.name
      );
    });

    this.socket.on('reconnect_attempt', (attemptNumber) => {
      console.log(`🔄 Reconnection attempt #${attemptNumber}`);
    });

    this.socket.on('reconnect_error', (error) => {
      console.error('🔴 Reconnection error:', error);
    });

    this.socket.on('reconnect_failed', () => {
      console.error('💥 Reconnection failed after maximum attempts');
      console.log('🔄 Will retry connection in 10 seconds...');

      // Custom retry logic
      setTimeout(() => {
        console.log('🔄 Manual reconnection attempt...');
        this.connect();
      }, 10000);
    });

    // Listen for transport upgrade
    this.socket.io.on('upgrade', () => {
      console.log(
        '🚀 Transport upgraded to:',
        this.socket?.io?.engine?.transport?.name
      );
    });

    // Listen for transport upgrade error
    this.socket.io.on('upgradeError', (error) => {
      console.warn('⚠️ Transport upgrade failed:', error);
    });
  }

  // Join user-specific room
  joinUserRoom(userId: string | number) {
    if (this.socket?.connected) {
      this.socket.emit('join_user_room', userId);
      console.log('📡 Joined user room:', userId);
    } else {
      console.warn('⚠️ Cannot join user room - socket not connected');
    }
  }

  // Join conversation room
  joinConversationRoom(conversationId: string | number) {
    if (this.socket?.connected) {
      this.socket.emit('join_conversation', conversationId);
      console.log('💬 Joined conversation room:', conversationId);
    } else {
      console.warn('⚠️ Cannot join conversation room - socket not connected');
    }
  }

  // Leave conversation room
  leaveConversationRoom(conversationId: string | number) {
    if (this.socket?.connected) {
      this.socket.emit('leave_conversation', conversationId);
      console.log('📤 Left conversation room:', conversationId);
    }
  }

  // Send message through socket
  sendMessage(messageData: any) {
    console.log(messageData)
    if (this.socket?.connected) {
      this.socket.emit('send_message', messageData);
      console.log('📨 Message sent via socket:', messageData);
    } else {
      console.warn('⚠️ Cannot send message - socket not connected');
    }
  }

  // Send typing indicator
  sendTyping(data: {
    conversationId: string;
    isTyping: boolean;
    userId: string;
  }) {
    if (this.socket?.connected) {
      this.socket.emit('typing', data);
    }
  }

  // Send read receipt
  sendReadReceipt(data: {
    messageId: string;
    conversationId: string;
    userId: string;
  }) {
    if (this.socket?.connected) {
      this.socket.emit('message_read', data);
    }
  }

  
  onNewMessage(callback: (messageData: any) => void) {
    if (this.socket) {
      this.socket.on('receive_msg', callback);
      this.addListener('receive_msg', callback);
    }
  }

  
  onTyping(
    callback: (data: {
      conversationId: string;
      isTyping: boolean;
      userId: string;
    }) => void
  ) {
    if (this.socket) {
      this.socket.on('user_typing', callback);
      this.addListener('user_typing', callback);
    }
  }

  // Listen for online/offline status
  onUserStatusChange(
    callback: (data: { userId: string; isOnline: boolean }) => void
  ) {
    if (this.socket) {
      this.socket.on('user_status_change', callback);
      this.addListener('user_status_change', callback);
    }
  }

  // Listen for message status updates (read, delivered)
  onMessageStatusUpdate(
    callback: (data: { messageId: string; status: string }) => void
  ) {
    if (this.socket) {
      this.socket.on('message_status_update', callback);
      this.addListener('message_status_update', callback);
    }
  }

  // Generic event listener
  on(event: string, callback: Function) {
    if (this.socket) {
      this.socket.on(event, callback);
      this.addListener(event, callback);
    }
  }

  // Remove event listener
  off(event: string, callback?: Function) {
    if (this.socket) {
      if (callback) {
        this.socket.off(event, callback);
        this.removeListener(event, callback);
      } else {
        this.socket.off(event);
        this.listeners.delete(event);
      }
    }
  }

  // Emit custom event
  emit(event: string, data?: any) {
    if (this.socket?.connected) {
      this.socket.emit(event, data);
    } else {
      console.warn(`⚠️ Cannot emit event '${event}' - socket not connected`);
    }
  }

  // Check connection status
  isConnected(): boolean {
    return this.socket?.connected || false;
  }

  // Get socket ID
  getSocketId(): string | undefined {
    return this.socket?.id;
  }

  // Disconnect socket
  disconnect() {
    if (this.socket) {
      console.log('🔌 Disconnecting socket...');
      this.socket.disconnect();
      this.listeners.clear();
    }
  }

  // Reconnect socket
  reconnect() {
    if (this.socket) {
      console.log('🔄 Manual reconnection...');
      this.socket.connect();
    } else {
      console.log('🔄 Creating new connection...');
      this.connect();
    }
  }

  // Force new connection
  forceReconnect() {
    console.log('🔄 Forcing new connection...');
    this.disconnect();
    setTimeout(() => {
      this.connect();
    }, 1000);
  }

  // Private helper methods
  private addListener(event: string, callback: Function) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, []);
    }
    this.listeners.get(event)?.push(callback);
  }

  private removeListener(event: string, callback: Function) {
    const eventListeners = this.listeners.get(event);
    if (eventListeners) {
      const index = eventListeners.indexOf(callback);
      if (index > -1) {
        eventListeners.splice(index, 1);
      }
    }
  }

  // Advanced features

  // Send bulk message read receipts
  sendBulkReadReceipts(
    messageIds: string[],
    conversationId: string,
    userId: string
  ) {
    if (this.socket?.connected) {
      this.socket.emit('bulk_messages_read', {
        messageIds,
        conversationId,
        userId,
      });
    }
  }

  // Join multiple rooms at once
  joinMultipleRooms(rooms: string[]) {
    if (this.socket?.connected) {
      this.socket.emit('join_multiple_rooms', rooms);
    }
  }

  // Send presence update
  updatePresence(status: 'online' | 'away' | 'busy' | 'offline') {
    if (this.socket?.connected) {
      this.socket.emit('update_presence', { status });
    }
  }

  // Get current connection info
  getConnectionInfo() {
    return {
      connected: this.isConnected(),
      socketId: this.getSocketId(),
      transport: this.socket?.io?.engine?.transport?.name,
      url: this.socket?.io?.uri,
      listeners: Array.from(this.listeners.keys()),
      readyState: this.socket?.io?.readyState,
    };
  }

  // Test connection
  testConnection() {
    console.log('🧪 Testing socket connection...');
    console.log('📊 Connection info:', this.getConnectionInfo());

    if (this.socket?.connected) {
      // Send a test ping
      this.socket.emit('ping', { timestamp: Date.now() });
      console.log('📡 Ping sent to server');
    } else {
      console.log('❌ Socket not connected');
    }
  }
}

// Create singleton instance
const socketService = new SocketService();

export default socketService;

// Alternative export for TypeScript projects
export { SocketService };
