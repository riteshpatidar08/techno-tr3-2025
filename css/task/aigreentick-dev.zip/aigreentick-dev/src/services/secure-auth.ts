
import { secureStorage } from './secure-storage';

class SecureAuth {
  
  static isValidlyAuthenticated(): boolean {
    const isAuthenticated = localStorage.getItem('isAuthenticated') === 'true';
    const token = secureStorage.getItem('auth_token');
    const user = secureStorage.getItem('ai_green_tick_user');

   
    return isAuthenticated && !!token && !!user && user.id;
  }

  
  static getCurrentUser() {
    if (!this.isValidlyAuthenticated()) {
      this.clearInvalidAuth();
      return null;
    }
    return secureStorage.getItem('ai_green_tick_user');
  }


  static getCurrentToken() {
    if (!this.isValidlyAuthenticated()) {
      this.clearInvalidAuth();
      return null;
    }
    return secureStorage.getItem('auth_token');
  }

  
  static clearInvalidAuth() {
    localStorage.removeItem('isAuthenticated');
    secureStorage.removeItem('auth_token');
    secureStorage.removeItem('ai_green_tick_user');
  }

  
  static setAuthenticated(token: string, user: any) {
    secureStorage.setItem('auth_token', token);
    secureStorage.setItem('ai_green_tick_user', user);
    localStorage.setItem('isAuthenticated', 'true');
  }

 
  static clearAuthentication() {
    localStorage.removeItem('isAuthenticated');
    secureStorage.removeItem('auth_token');
secureStorage.removeItem('ai_green_tick_user');
  }
}

export { SecureAuth };
