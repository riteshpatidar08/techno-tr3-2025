import { useState, useEffect, Suspense, lazy } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAppSelector } from '@/redux/store';
import { useSocket } from '@/hooks/useSocket'; // Your existing hook
import Navbar from '@/components/navbar/Navbar';
import ProtectedRoutes, { PublicRoutes } from './components/ProtectedRoutes';
import LoadingAnimation from './components/LoadingAnimation';
import ErrorBoundary from './components/ErrorBoundary';
import CampaignsInfoPage from './components/campaigns/CampaignsInfoPage';

// Authentication Pages
const Login = lazy(() => import('./pages/Login'));
const Signup = lazy(() => import('./pages/Signup'));

// Protected Pages
const Dashboard = lazy(() => import('@/components/dashboard/Dashboard'));
const PhonebookContacts = lazy(
  () => import('@/components/contacts/PhonebookContacts')
);
const CampaignLayout = lazy(
  () => import('./components/campaigns/CampaignLayout')
);
const CompleteWhatsAppCRM = lazy(
  () => import('./components/chatbots/WhatsappChatbotFlow')
);
const ApiDocs = lazy(() => import('./components/ApiDocs'));
const Inbox = lazy(() => import('./components/inbox/Inbox'));
const ProfilePage = lazy(() => import('./components/ProfilePage'));
const UserManagement = lazy(
  () => import('./components/usermanagement/UserManagement')
);
const UserSettings = lazy(() => import('./components/settings/UserSettings'));

// Campaign Pages
const TemplateLibrary = lazy(
  () => import('./components/campaigns/TemplateLibrary')
);
const YourTemplates = lazy(
  () => import('./components/campaigns/YourTemplates')
);
const SendByTags = lazy(() => import('./components/campaigns/SendByTags'));
const CampaignHistory = lazy(
  () => import('./components/campaigns/CampaignHistory')
);
const CsvCampaign = lazy(() => import('./components/campaigns/CsvCampaign'));
const ScheduledCampaign = lazy(
  () => import('./components/campaigns/ScheduleCampaign/ScheduledCampaign')
);
const BroadCast = lazy(() => import('./components/campaigns/BroadCast'));
const CampaignDashboard = lazy(
  () => import('./components/campaigns/CampaignDashboard')
);

const protectedRoutes = [
  { path: '/dashboard', component: Dashboard },
  { path: '/inbox', component: Inbox },
  { path: '/api-docs', component: ApiDocs },
  { path: '/chatbots', component: CompleteWhatsAppCRM },
  { path: '/phonebook', component: PhonebookContacts },
  { path: '/user/profile', component: ProfilePage },
  { path: '/users', component: UserManagement },
  { path: '/manage', component: UserSettings },
];

// Global Socket Manager Component
const SocketManager = ({ children, currentUser }) => {
  const { isConnected, connectionInfo, playNotificationSound, updatePresence } =
    useSocket(currentUser);

  // Update presence based on page visibility
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        updatePresence('away');
      } else {
        updatePresence('online');
      }
    };

    const handleBeforeUnload = () => {
      updatePresence('offline');
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [updatePresence]);

  // Set initial presence to online when socket connects
  useEffect(() => {
    if (isConnected && currentUser) {
      updatePresence('online');
    }
  }, [isConnected, currentUser, updatePresence]);

  return (
    <>
      {children}
      {/* Global Socket Status Indicator */}
      <SocketStatusIndicator isConnected={isConnected} />
    </>
  );
};

// Socket Status Indicator Component
const SocketStatusIndicator = ({ isConnected }) => {
  const [showIndicator, setShowIndicator] = useState(false);

  useEffect(() => {
    // Show indicator when connection status changes
    setShowIndicator(true);
    const timer = setTimeout(() => setShowIndicator(false), 3000);
    return () => clearTimeout(timer);
  }, [isConnected]);

  if (!showIndicator) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 animate-in slide-in-from-right duration-300">
      <div
        className={`flex items-center space-x-2 px-3 py-2 rounded-full shadow-lg transition-all duration-300 ${
          isConnected
            ? 'bg-green-100 text-green-800 border border-green-200'
            : 'bg-red-100 text-red-800 border border-red-200'
        }`}
      >
        <div
          className={`w-2 h-2 rounded-full ${
            isConnected ? 'bg-green-500' : 'bg-red-500'
          }`}
        />
        <span className="text-xs font-medium">
          {isConnected ? 'Connected' : 'Disconnected'}
        </span>
      </div>
    </div>
  );
};

const AuthenticatedLayout = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);

  // Get current user from storage
  useEffect(() => {
    const getCurrentUser = async () => {
      try {
        const userData =
          localStorage.getItem('currentUser') ||
          sessionStorage.getItem('currentUser');
        if (userData) {
          const user = JSON.parse(userData);
          setCurrentUser(user);
        }
      } catch (error) {
        console.error('Failed to get current user:', error);
      }
    };
    getCurrentUser();
  }, []);

  return (
    <div className="min-h-[92vh] bg-gray-50">
      <Navbar />
      <main className="transition-all duration-200">
        <SocketManager currentUser={currentUser}>{children}</SocketManager>
      </main>
    </div>
  );
};

const PageLoadingFallback = () => (
  <div className="flex items-center justify-center min-h-[400px]">
    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
  </div>
);

const ErrorFallback = ({ error, resetErrorBoundary }) => (
  <div className="flex flex-col items-center justify-center min-h-[400px] p-4">
    <div className="text-center">
      <h2 className="text-xl font-semibold text-gray-900 mb-2">
        Something went wrong
      </h2>
      <p className="text-gray-600 mb-4">
        We're sorry, but something unexpected happened.
      </p>
      <button
        onClick={resetErrorBoundary}
        className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
      >
        Try again
      </button>
    </div>
  </div>
);

function App() {
  const [isInitialLoading, setIsInitialLoading] = useState(true);
  const { isAuthenticated } = useAppSelector((state) => state.auth);

  useEffect(() => {
    const initializeApp = async () => {
      try {
        await new Promise((resolve) => setTimeout(resolve, 1500));
      } catch (error) {
        console.error('Failed to initialize app:', error);
      } finally {
        setIsInitialLoading(false);
      }
    };

    initializeApp();
  }, []);

  // Request notification permission when app loads
  useEffect(() => {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission().then((permission) => {
        console.log('🔔 Notification permission:', permission);
      });
    }
  }, []);

  if (isInitialLoading) {
    return <LoadingAnimation />;
  }

  return (
    <ErrorBoundary fallback={ErrorFallback}>
      <div className="App mt-16">
        <Suspense fallback={<LoadingAnimation />}>
          <Routes>
            {/* Public Authentication Routes */}
            <Route
              path="/login"
              element={
                <PublicRoutes>
                  <Suspense fallback={<PageLoadingFallback />}>
                    <Login />
                  </Suspense>
                </PublicRoutes>
              }
            />

            <Route
              path="/signup"
              element={
                <PublicRoutes>
                  <Suspense fallback={<PageLoadingFallback />}>
                    <Signup />
                  </Suspense>
                </PublicRoutes>
              }
            />

            {/* Protected Routes */}
            {protectedRoutes.map(({ path, component: Component }) => (
              <Route
                key={path}
                path={path}
                element={
                  <ProtectedRoutes>
                    <AuthenticatedLayout>
                      <Suspense fallback={<PageLoadingFallback />}>
                        <Component />
                      </Suspense>
                    </AuthenticatedLayout>
                  </ProtectedRoutes>
                }
              />
            ))}

            {/* Campaign Routes */}
            <Route
              path="/campaigns"
              element={
                <ProtectedRoutes>
                  <AuthenticatedLayout>
                    <Suspense fallback={<PageLoadingFallback />}>
                      <CampaignLayout />
                    </Suspense>
                  </AuthenticatedLayout>
                </ProtectedRoutes>
              }
            >
              <Route
                index
                element={
                  <Suspense fallback={<PageLoadingFallback />}>
                  <CampaignsInfoPage/>
                  </Suspense>
                }
              />
              <Route
                path="template-library"
                element={
                  <Suspense fallback={<PageLoadingFallback />}>
                    <TemplateLibrary />
                  </Suspense>
                }
              />
              <Route
                path="campaign-dashboard"
                element={
                  <Suspense fallback={<PageLoadingFallback />}>
                    <CampaignDashboard />
                  </Suspense>
                }
              />
              <Route
                path="your-templates"
                element={
                  <Suspense fallback={<PageLoadingFallback />}>
                    <YourTemplates />
                  </Suspense>
                }
              />
              <Route
                path="campaigns-history"
                element={
                  <Suspense fallback={<PageLoadingFallback />}>
                    <CampaignHistory />
                  </Suspense>
                }
              />
              <Route
                path="scheduled-campaigns"
                element={
                  <Suspense fallback={<PageLoadingFallback />}>
                    <ScheduledCampaign />
                  </Suspense>
                }
              />
              <Route
                path="send-by-tags"
                element={
                  <Suspense fallback={<PageLoadingFallback />}>
                    <SendByTags />
                  </Suspense>
                }
              />
              <Route
                path="csv-campaign"
                element={
                  <Suspense fallback={<PageLoadingFallback />}>
                    <CsvCampaign />
                  </Suspense>
                }
              />
              <Route
                path="broadcast"
                element={
                  <Suspense fallback={<PageLoadingFallback />}>
                    <BroadCast />
                  </Suspense>
                }
              />

              {/* Default redirect for campaigns */}
              <Route
                path=""
                element={<Navigate to="template-library" replace />}
              />
            </Route>

            {/* Root Route */}
            <Route
              path="/"
              element={
                <Navigate
                  to={isAuthenticated ? '/dashboard' : '/login'}
                  replace
                />
              }
            />

            {/* Catch-all Route */}
            <Route
              path="*"
              element={
                <Navigate
                  to={isAuthenticated ? '/dashboard' : '/login'}
                  replace
                />
              }
            />
          </Routes>
        </Suspense>
      </div>
    </ErrorBoundary>
  );
}

export default App;
