import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Menu,
  X,
  ArrowLeft,
  Info,
  MessageSquare,
  Users,
  Settings,
  Search,
  Send,
  Loader2,
  AlertCircle,
  RotateCcw,
} from 'lucide-react';
import { useAppDispatch, useAppSelector } from '@/redux/store';
import {
  fetchMessages,
  fetchConversation,
  sendMessage,
  selectConversation,
  selectSelectedConversation,
  selectCurrentConversationMessages,
  selectConversationLoading,
  selectChannels,
  selectSendingMessage,
  selectSocketConnected,
  selectUnreadMessagesCount,
  markConversationAsRead,
} from '@/redux/messageSlice';
import {
  fetchTemplates,
  selectTemplates,
  selectTemplatesLoading,
  selectTemplatesError,
  Template,
} from '@/redux/templateSlice';
import { useSocket } from '@/hooks/useSocket';

import ConversationList from './ConversationList';
import ChatHeader from './ChatHeader';
import ChatMessages from './ChatMessages';
import MessageInput from './MessageInput';
import ChatSidebar from './ChatSidebar';
import FilterModal from './FilterModal';
import { PanelGroup, Panel, PanelResizeHandle } from 'react-resizable-panels';

const BREAKPOINTS = {
  sm: 640,
  md: 768,
  lg: 1024,
  xl: 1280,
};

interface TemplateVariable {
  index: number;
  placeholder: string;
  value: string;
}

export default function Inbox() {
  const dispatch = useAppDispatch();

  const selectedConversation = useAppSelector(selectSelectedConversation);
  const conversationMessages = useAppSelector(
    selectCurrentConversationMessages
  );
  const conversationLoading = useAppSelector(selectConversationLoading);
  const channels = useAppSelector(selectChannels);
  const sendingMessage = useAppSelector(selectSendingMessage);
  const socketConnected = useAppSelector(selectSocketConnected);
  const totalUnreadCount = useAppSelector(selectUnreadMessagesCount);
  const templates = useAppSelector(selectTemplates);
  const templatesLoading = useAppSelector(selectTemplatesLoading);
  const templatesError = useAppSelector(selectTemplatesError);

  const [windowWidth, setWindowWidth] = useState(
    typeof window !== 'undefined' ? window.innerWidth : 1024
  );
  const [isMobile, setIsMobile] = useState(false);
  const [isTablet, setIsTablet] = useState(false);
  const [activeView, setActiveView] = useState('conversations');
  const [showMobileSidebar, setShowMobileSidebar] = useState(false);
  const [showConversationList, setShowConversationList] = useState(false);

  const [isInitialLoad, setIsInitialLoad] = useState(true);
  const [newMessage, setNewMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [chatNote, setChatNote] = useState('');
  const [rating, setRating] = useState(0);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);

  const [showTemplateModal, setShowTemplateModal] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(
    null
  );
  const [templateVariables, setTemplateVariables] = useState<
    TemplateVariable[]
  >([]);
  const [templateSearch, setTemplateSearch] = useState('');
  const [showVariableForm, setShowVariableForm] = useState(false);

  const selectedChannel = channels[0]?.whatsapp_no || '';

  useEffect(() => {
    if (templates.length === 0 && !templatesLoading) {
      dispatch(fetchTemplates());
    }
  }, [dispatch, templates.length, templatesLoading]);

  const extractTemplateVariables = (template: Template): TemplateVariable[] => {
    const variables: TemplateVariable[] = [];

    template.components.forEach((component) => {
      if (component.text) {
        const matches = component.text.match(/\{\{(\d+)\}\}/g);
        if (matches) {
          matches.forEach((match) => {
            const index = parseInt(match.replace(/[{}]/g, ''));
            if (!variables.find((v) => v.index === index)) {
              variables.push({
                index,
                placeholder: `Variable ${index}`,
                value: '',
              });
            }
          });
        }
      }
    });

    return variables.sort((a, b) => a.index - b.index);
  };

  const handleTemplateSelect = (template: Template) => {
    setSelectedTemplate(template);
    const variables = extractTemplateVariables(template);
    setTemplateVariables(variables);

    if (variables.length > 0) {
      setShowVariableForm(true);
    } else {
      sendTemplateMessage(template, []);
    }
  };

  const sendTemplateMessage = async (
    template: Template,
    variables: TemplateVariable[]
  ) => {
    if (!selectedConversation) return;

    try {
      const variableValues = variables
        .sort((a, b) => a.index - b.index)
        .map((v) => v.value);

      const variablesPayload =
        variableValues.length === 1
          ? variableValues[0]
          : variableValues.join(',');

      const hasMedia = template.components.some(
        (component) =>
          component.format === 'IMAGE' ||
          component.format === 'VIDEO' ||
          component.format === 'DOCUMENT' ||
          component.image_url
      );

      const mediaComponent = template.components.find(
        (component) => component.image_url || component.format
      );

      const getDynamicCountryId = () => {
        if (channels[0]?.country_id) {
          return channels[0].country_id;
        }

        if (currentUser?.country_id) {
          return currentUser.country_id;
        }

        if (selectedConversation?.country_id) {
          return selectedConversation.country_id;
        }

        const phoneNumber = selectedConversation?.contact_number;
        if (phoneNumber) {
          if (phoneNumber.startsWith('91') || phoneNumber.startsWith('+91')) {
            return 98;
          }

          if (phoneNumber.startsWith('1') || phoneNumber.startsWith('+1')) {
            return 1;
          }

          if (phoneNumber.startsWith('44') || phoneNumber.startsWith('+44')) {
            return 44;
          }
        }

        return 98;
      };

      const templatePayload = {
        template_id: template.id.toString(),
        country_id: getDynamicCountryId(),
        camp_name: template.name,
        mobile_numbers: [selectedConversation.contact_number],
        is_media: hasMedia,
        media_type: hasMedia ? mediaComponent?.format || 'IMAGE' : '',
        media_url: hasMedia ? mediaComponent?.image_url || '' : '',
        schedule_date: '',
        variables: variablesPayload,
      };

      console.log('Sending template with payload:', templatePayload);

      await dispatch(sendMessage(templatePayload)).unwrap();

      setSelectedTemplate(null);
      setTemplateVariables([]);
      setShowVariableForm(false);
      setShowTemplateModal(false);

      if (selectedChannel) {
        await dispatch(
          fetchConversation({
            contactNumber: selectedConversation.contact_number,
            selectedChannel: selectedChannel,
            page: 1,
          })
        );
      }
    } catch (error) {
      console.error('Failed to send template message:', error);

      if (error.response) {
        console.error('Response error:', error.response.data);
        alert(
          `Failed to send template: ${
            error.response.data.message || error.message
          }`
        );
      } else if (error.request) {
        console.error('Request error:', error.request);
        alert('Network error: Please check your connection and try again.');
      } else {
        console.error('Error:', error.message);
        alert(`Error: ${error.message}`);
      }
    }
  };

  const handleVariableChange = (index: number, value: string) => {
    setTemplateVariables((prev) =>
      prev.map((v) => (v.index === index ? { ...v, value } : v))
    );
  };

  const handleSendTemplate = () => {
    if (!selectedTemplate) return;

    const hasEmptyVariables = templateVariables.some((v) => !v.value.trim());
    if (hasEmptyVariables) {
      alert('Please fill in all template variables.');
      return;
    }

    sendTemplateMessage(selectedTemplate, templateVariables);
  };

  const filteredTemplates = templates.filter(
    (template) =>
      template.name.toLowerCase().includes(templateSearch.toLowerCase()) ||
      template.category.toLowerCase().includes(templateSearch.toLowerCase())
  );

  const getTemplatePreview = (template: Template): string => {
    const textComponent = template.components.find((c) => c.text);
    if (!textComponent?.text) return 'No preview available';

    let preview = textComponent.text;
    preview = preview.replace(/\{\{(\d+)\}\}/g, '[Variable $1]');
    return preview.length > 100 ? preview.substring(0, 100) + '...' : preview;
  };

  useEffect(() => {
    const handleResize = () => {
      const width = window.innerWidth;
      setWindowWidth(width);
      setIsMobile(width < BREAKPOINTS.md);
      setIsTablet(width >= BREAKPOINTS.md && width < BREAKPOINTS.lg);

      if (width >= BREAKPOINTS.lg) {
        setActiveView('conversations');
        setShowMobileSidebar(false);
        setShowConversationList(false);
      } else if (width < BREAKPOINTS.md) {
        if (!selectedConversation) {
          setActiveView('conversations');
        }
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [selectedConversation]);

  useEffect(() => {
    const getCurrentUser = async () => {
      try {
        const userData =
          localStorage.getItem('currentUser') ||
          sessionStorage.getItem('currentUser');
        if (userData) {
          const user = JSON.parse(userData);
          setCurrentUser(user);
        }
      } catch (error) {
        console.error('Failed to get current user:', error);
      }
    };
    getCurrentUser();
  }, []);

  const { isConnected, sendTyping, updatePresence } = useSocket(currentUser);

  useEffect(() => {
    if (currentUser && socketConnected) {
      updatePresence('online');
    }
  }, [currentUser, socketConnected, updatePresence]);

  useEffect(() => {
    if (selectedConversation && selectedChannel) {
      setIsInitialLoad(true);
      dispatch(markConversationAsRead(selectedConversation.contact_number));
      dispatch(
        fetchConversation({
          contactNumber: selectedConversation.contact_number,
          selectedChannel: selectedChannel,
          page: 1,
        })
      );
    }
  }, [selectedConversation, selectedChannel, dispatch]);

  useEffect(() => {
    dispatch(fetchMessages());
  }, [dispatch]);

  const formattedMessages = conversationMessages.map((msg) => ({
    id: msg.id.toString(),
    text: msg.text,
    sender: msg.type === 'sent' ? 'user' : 'contact',
    timestamp: new Date(msg.created_at).toLocaleString('en-GB', {
      day: '2-digit',
      month: '2-digit',
      year: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    }),
    status: msg.status,
    messageType: msg.method,
    isMedia: msg.is_media === '1',
    buttons: undefined,
  }));

  const formattedSelectedConversation = selectedConversation
    ? {
        id: selectedConversation.id.toString(),
        name: selectedConversation.contact_name,
        phone: selectedConversation.contact_number,
        avatar: selectedConversation.contact_name.charAt(0).toUpperCase(),
        isOnline: selectedConversation.isActive,
        isTyping: selectedConversation.isTyping || false,
        messages: formattedMessages,
      }
    : null;

  const handleSelectConversation = (conversation) => {
    setIsInitialLoad(true);
    handleTypingChange(false);

    if (isMobile) {
      setActiveView('chat');
      setShowConversationList(false);
    }
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !selectedConversation || sendingMessage) return;

    const messageToSend = newMessage.trim();
    setNewMessage('');
    setIsInitialLoad(false);

    try {
      await dispatch(
        sendMessage({
          message: messageToSend,
          recipient_mobile: selectedConversation.contact_number,
          recipient_name: selectedConversation.contact_name,
          template_id: null,
          reaction: '',
          isReply: false,
          media_type: 'text',
          media_url: '',
          filename: '',
          caption: '',
          channel: selectedChannel,
        })
      ).unwrap();

      if (selectedChannel) {
        dispatch(
          fetchConversation({
            contactNumber: selectedConversation.contact_number,
            selectedChannel: selectedChannel,
            page: 1,
          })
        );
      }
    } catch (error) {
      console.error('Failed to send message:', error);
      setNewMessage(messageToSend);
    }
  };

  const handleTypingChange = (isTyping) => {
    if (selectedConversation) {
      sendTyping(isTyping);
    }
  };

  const handleMessageChange = (value) => {
    setNewMessage(value);
    if (value.trim() && !newMessage.trim()) {
      handleTypingChange(true);
    }
    if (!value.trim() && newMessage.trim()) {
      handleTypingChange(false);
    }
  };

  const handleInputBlur = () => {
    handleTypingChange(false);
  };

  const handleBackToConversations = () => {
    setActiveView('conversations');
    setShowConversationList(false);
  };

  const handleShowSidebar = () => {
    if (isMobile) {
      setShowMobileSidebar(true);
    } else {
      setActiveView('sidebar');
    }
  };

  const handleCloseSidebar = () => {
    setShowMobileSidebar(false);
  };

  // const toggleConversationList = () => {
  //   setShowConversationList(!showConversationList);
  // };

  const handleOpenTemplateModal = () => {
    setShowTemplateModal(true);
  };

  useEffect(() => {
    const baseTitle = 'Inbox - ChatApp';
    if (totalUnreadCount > 0) {
      document.title = `(${totalUnreadCount}) ${baseTitle}`;
    } else {
      document.title = baseTitle;
    }
  }, [totalUnreadCount]);

  const MobileNavBar = () => (
    <div className="lg:hidden bg-white border-b border-border px-4 py-3 flex items-center justify-between">
      {activeView === 'chat' && selectedConversation ? (
        <>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleBackToConversations}
            className="p-2"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1 mx-3">
            <h2 className="font-semibold text-foreground truncate">
              {formattedSelectedConversation?.name}
            </h2>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleShowSidebar}
            className="p-2"
          >
            <Info className="w-5 h-5" />
          </Button>
        </>
      ) : (
        <>
          <div className="flex items-center space-x-3">
            <h1 className="text-xl font-semibold text-foreground">Chats</h1>
            {totalUnreadCount > 0 && (
              <div className="bg-primary text-primary-foreground text-xs rounded-full px-2 py-1 min-w-[20px] text-center">
                {totalUnreadCount > 99 ? '99+' : totalUnreadCount}
              </div>
            )}
          </div>
          <div className="flex items-center space-x-2">
            <div
              className={`w-2 h-2 rounded-full ${
                isConnected ? 'bg-green-500' : 'bg-red-500'
              }`}
            />
            <Button variant="ghost" size="sm" className="p-2">
              <Settings className="w-5 h-5" />
            </Button>
          </div>
        </>
      )}
    </div>
  );

  return (
    <div className="h-[92vh] flex flex-col overflow-hidden">
      <MobileNavBar />

      <div className="flex-1 flex min-h-0 overflow-hidden">
        {windowWidth >= BREAKPOINTS.lg && (
          <PanelGroup direction="horizontal" className="flex-1">
            <Panel
              defaultSize={25}
              minSize={20}
              maxSize={35}
              className="bg-card border-r border-border"
            >
              <ConversationList
                onSelectConversation={handleSelectConversation}
                currentUser={currentUser}
              />
            </Panel>

            <PanelResizeHandle className="w-2 bg-border hover:bg-primary/20 transition-colors" />

            <Panel
              defaultSize={selectedConversation ? 50 : 75}
              minSize={40}
              className="flex flex-col min-w-0"
            >
              {selectedConversation ? (
                <>
                  <div className="flex-shrink-0 border-b border-border bg-white">
                    <ChatHeader
                      selectedConversation={formattedSelectedConversation}
                      showFilterModal={showFilterModal}
                      onToggleFilter={() =>
                        setShowFilterModal(!showFilterModal)
                      }
                      selectedAgent={selectedAgent}
                      onAgentChange={setSelectedAgent}
                      socketConnected={socketConnected}
                    />
                  </div>

                  <div className="flex-1 bg-muted/30 overflow-hidden">
                    <ChatMessages
                      messages={formattedMessages}
                      isInitialLoad={isInitialLoad}
                      isLoading={conversationLoading}
                      currentUser={currentUser}
                      selectedConversation={formattedSelectedConversation}
                    />
                  </div>

                  <div className="flex-shrink-0 bg-white border-t border-border">
                    <MessageInput
                      newMessage={newMessage}
                      onMessageChange={handleMessageChange}
                      onSendMessage={handleSendMessage}
                      onInputBlur={handleInputBlur}
                      isSending={sendingMessage}
                      onOpenTemplateModal={handleOpenTemplateModal}
                      onFileSelect={(files) =>
                        console.log('Files selected:', files)
                      }
                      placeholder={
                        formattedSelectedConversation?.isTyping
                          ? `${formattedSelectedConversation.name} is typing...`
                          : `Message ${
                              formattedSelectedConversation?.name || ''
                            }...`
                      }
                      disabled={!socketConnected}
                    />
                  </div>
                </>
              ) : (
                <WelcomeScreen
                  isConnected={isConnected}
                  totalUnreadCount={totalUnreadCount}
                  socketConnected={socketConnected}
                />
              )}
            </Panel>

            {/* Chat Sidebar Panel - Only show when conversation is selected */}
            {selectedConversation && (
              <>
                <PanelResizeHandle className="w-2 bg-border hover:bg-primary/20 transition-colors" />
                <Panel
                  defaultSize={25}
                  minSize={20}
                  maxSize={35}
                  className="bg-muted/30 border-l border-border"
                >
                  <ChatSidebar
                    selectedConversation={formattedSelectedConversation}
                    chatNote={chatNote}
                    onChatNoteChange={setChatNote}
                    rating={rating}
                    onRatingChange={setRating}
                  />
                </Panel>
              </>
            )}
          </PanelGroup>
        )}

        {isTablet && (
          <>
            {showConversationList && (
              <div className="fixed inset-0 z-50 lg:hidden">
                <div
                  className="absolute inset-0 bg-black/50"
                  onClick={() => setShowConversationList(false)}
                />
                <div className="absolute left-0 top-0 h-full w-80 bg-card border-r border-border shadow-xl">
                  <div className="flex items-center justify-between p-4 border-b border-border">
                    <h2 className="text-lg font-semibold text-foreground">
                      Conversations
                    </h2>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowConversationList(false)}
                      className="p-2"
                    >
                      <X className="w-5 h-5" />
                    </Button>
                  </div>
                  <ConversationList
                    onSelectConversation={handleSelectConversation}
                    currentUser={currentUser}
                  />
                </div>
              </div>
            )}

            <div className="flex-1 flex flex-col min-w-0 h-full">
              {selectedConversation ? (
                <>
                  <div className="flex-1 bg-muted/30 overflow-hidden">
                    <ChatMessages
                      messages={formattedMessages}
                      isInitialLoad={isInitialLoad}
                      isLoading={conversationLoading}
                      currentUser={currentUser}
                      selectedConversation={formattedSelectedConversation}
                    />
                  </div>

                  <div className="flex-shrink-0 bg-white border-t border-border">
                    <MessageInput
                      newMessage={newMessage}
                      onMessageChange={handleMessageChange}
                      onSendMessage={handleSendMessage}
                      onInputBlur={handleInputBlur}
                      isSending={sendingMessage}
                      onOpenTemplateModal={handleOpenTemplateModal}
                      onFileSelect={(files) =>
                        console.log('Files selected:', files)
                      }
                      placeholder={
                        formattedSelectedConversation?.isTyping
                          ? `${formattedSelectedConversation.name} is typing...`
                          : `Message ${
                              formattedSelectedConversation?.name || ''
                            }...`
                      }
                      disabled={!socketConnected}
                    />
                  </div>
                </>
              ) : (
                <WelcomeScreen
                  isConnected={isConnected}
                  totalUnreadCount={totalUnreadCount}
                  socketConnected={socketConnected}
                />
              )}
            </div>
          </>
        )}

        {isMobile && (
          <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
            {activeView === 'conversations' && (
              <ConversationList
                onSelectConversation={handleSelectConversation}
                currentUser={currentUser}
              />
            )}

            {activeView === 'chat' && selectedConversation && (
              <div className="flex-1 flex flex-col min-w-0 h-full">
                <div className="flex-1 bg-muted/30 overflow-hidden">
                  <ChatMessages
                    messages={formattedMessages}
                    isInitialLoad={isInitialLoad}
                    isLoading={conversationLoading}
                    currentUser={currentUser}
                    selectedConversation={formattedSelectedConversation}
                  />
                </div>

                <div className="flex-shrink-0 bg-white border-t border-border">
                  <MessageInput
                    newMessage={newMessage}
                    onMessageChange={handleMessageChange}
                    onSendMessage={handleSendMessage}
                    onInputBlur={handleInputBlur}
                    isSending={sendingMessage}
                    onOpenTemplateModal={handleOpenTemplateModal}
                    placeholder={
                      formattedSelectedConversation?.isTyping
                        ? `${formattedSelectedConversation.name} is typing...`
                        : `Message ${
                            formattedSelectedConversation?.name || ''
                          }...`
                    }
                    disabled={!socketConnected}
                  />
                </div>
              </div>
            )}

            {!selectedConversation && activeView !== 'conversations' && (
              <WelcomeScreen
                isConnected={isConnected}
                totalUnreadCount={totalUnreadCount}
                socketConnected={socketConnected}
              />
            )}
          </div>
        )}
      </div>

      {showMobileSidebar && selectedConversation && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={handleCloseSidebar}
          />
          <div className="absolute right-0 top-0 h-full w-full max-w-sm bg-card shadow-xl">
            <div className="flex items-center justify-between p-4 border-b border-border">
              <h2 className="text-lg font-semibold text-foreground">
                Chat Info
              </h2>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleCloseSidebar}
                className="p-2"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
            <ChatSidebar
              selectedConversation={formattedSelectedConversation}
              chatNote={chatNote}
              onChatNoteChange={setChatNote}
              rating={rating}
              onRatingChange={setRating}
            />
          </div>
        </div>
      )}

      {showTemplateModal && (
        <div
          className="fixed inset-0 z-[1000]"
          onClick={() => setShowTemplateModal(false)}
        >
          <div
            className="absolute bottom-20 left-4 right-4 max-w-md mx-auto bg-card rounded-xl shadow-xl border border-border h-[450px] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            {!showVariableForm ? (
              <>
                <div className="p-4 border-b border-border bg-muted/50 rounded-t-xl shrink-0">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-lg font-semibold text-foreground">
                      Templates
                    </h3>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowTemplateModal(false)}
                      className="w-8 h-8 p-0 text-muted-foreground hover:text-foreground hover:bg-accent rounded-full"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                    <Input
                      placeholder="Search templates..."
                      value={templateSearch}
                      onChange={(e) => setTemplateSearch(e.target.value)}
                      className="pl-9 h-9 text-sm border-border focus:border-primary focus:ring-1 focus:ring-primary/20"
                    />
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-muted-foreground/20 scrollbar-track-transparent">
                  {templatesLoading ? (
                    <div className="flex items-center justify-center h-full">
                      <div className="text-center">
                        <Loader2 className="w-8 h-8 animate-spin mx-auto mb-3 text-primary" />
                        <p className="text-muted-foreground text-sm">
                          Loading templates...
                        </p>
                      </div>
                    </div>
                  ) : templatesError ? (
                    <div className="flex items-center justify-center h-full">
                      <div className="text-center px-4">
                        <AlertCircle className="w-8 h-8 mx-auto mb-3 text-destructive" />
                        <p className="text-destructive text-sm mb-3">
                          Failed to load templates
                        </p>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => dispatch(fetchTemplates())}
                          className="px-4 py-2 text-sm"
                        >
                          <RotateCcw className="w-4 h-4 mr-2" />
                          Retry
                        </Button>
                      </div>
                    </div>
                  ) : filteredTemplates.length === 0 ? (
                    <div className="flex items-center justify-center h-full">
                      <div className="text-center px-4">
                        <MessageSquare className="w-8 h-8 mx-auto mb-3 text-muted-foreground" />
                        <p className="text-muted-foreground text-sm">
                          No templates found
                        </p>
                        <p className="text-muted-foreground text-xs mt-1">
                          Try different search terms
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="p-4">
                      <div className="space-y-3">
                        {filteredTemplates.map((template) => (
                          <div
                            key={template.id}
                            onClick={() => handleTemplateSelect(template)}
                            className="p-4 border border-border rounded-lg hover:border-primary hover:bg-accent/50 cursor-pointer transition-all duration-200 hover:shadow-sm group"
                          >
                            <div className="flex items-start justify-between mb-2">
                              <h4 className="font-semibold text-foreground text-sm truncate pr-2 group-hover:text-primary">
                                {template.name}
                              </h4>
                              <span
                                className={`px-2.5 py-1 text-xs font-medium rounded-full shrink-0 ${
                                  template.status === 'APPROVED'
                                    ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400'
                                    : template.status === 'PENDING'
                                    ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400'
                                    : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
                                }`}
                              >
                                {template.status}
                              </span>
                            </div>
                            <p className="text-xs text-muted-foreground mb-2 font-medium">
                              Category: {template.category}
                            </p>
                            <p className="text-xs text-muted-foreground leading-relaxed">
                              {getTemplatePreview(template)}
                            </p>
                          </div>
                        ))}
                      </div>

                      {filteredTemplates.length > 0 && (
                        <div className="text-center py-3 mt-4 border-t border-border">
                          <p className="text-xs text-muted-foreground">
                            {filteredTemplates.length} template
                            {filteredTemplates.length !== 1 ? 's' : ''} found
                          </p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </>
            ) : (
              <>
                <div className="p-4 border-b border-border bg-muted/50 rounded-t-xl shrink-0">
                  <div className="flex items-center gap-3">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowVariableForm(false)}
                      className="w-8 h-8 p-0 text-primary hover:text-primary/80 hover:bg-primary/10 rounded-full"
                    >
                      <ArrowLeft className="w-4 h-4" />
                    </Button>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-lg font-semibold text-foreground">
                        Fill Variables
                      </h3>
                      <p className="text-xs text-muted-foreground truncate">
                        {selectedTemplate?.name}
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setShowTemplateModal(false);
                        setShowVariableForm(false);
                        setSelectedTemplate(null);
                        setTemplateVariables([]);
                      }}
                      className="w-8 h-8 p-0 text-muted-foreground hover:text-foreground hover:bg-accent rounded-full"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-muted-foreground/20 scrollbar-track-transparent">
                  <div className="p-4">
                    <div className="space-y-4">
                      {templateVariables.map((variable) => (
                        <div key={variable.index} className="space-y-2">
                          <label className="block text-sm font-medium text-foreground">
                            Variable {variable.index}{' '}
                            <span className="text-destructive">*</span>
                          </label>
                          <Input
                            placeholder={`Enter value for {{${variable.index}}}`}
                            value={variable.value}
                            onChange={(e) =>
                              handleVariableChange(
                                variable.index,
                                e.target.value
                              )
                            }
                            className="w-full h-9 text-sm border-border focus:border-primary focus:ring-1 focus:ring-primary/20"
                          />
                          <p className="text-xs text-muted-foreground">
                            This will replace {`{{${variable.index}}}`} in your
                            template
                          </p>
                        </div>
                      ))}
                    </div>

                    {selectedTemplate && (
                      <div className="mt-6 p-4 bg-muted/30 rounded-lg border border-border">
                        <h4 className="text-sm font-semibold text-foreground mb-2">
                          Template Preview:
                        </h4>
                        <div className="text-sm text-muted-foreground leading-relaxed">
                          {getTemplatePreview(selectedTemplate)}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                <div className="p-4 border-t border-border bg-muted/30 rounded-b-xl shrink-0">
                  <div className="flex gap-3">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowVariableForm(false)}
                      className="flex-1 h-9 text-sm border-border hover:bg-accent"
                    >
                      <ArrowLeft className="w-4 h-4 mr-2" />
                      Back
                    </Button>
                    <Button
                      onClick={handleSendTemplate}
                      disabled={
                        sendingMessage ||
                        templateVariables.some((v) => !v.value.trim())
                      }
                      size="sm"
                      className="flex-1 h-9 text-sm bg-primary hover:bg-primary/90 text-primary-foreground disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {sendingMessage ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin mr-2" />
                          Sending...
                        </>
                      ) : (
                        <>
                          <Send className="w-4 h-4 mr-2" />
                          Send Template
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      <FilterModal
        show={showFilterModal}
        onClose={() => setShowFilterModal(false)}
        startDate={startDate}
        endDate={endDate}
        onStartDateChange={setStartDate}
        onEndDateChange={setEndDate}
        onApplyFilters={() => setShowFilterModal(false)}
        onResetFilters={() => {
          setStartDate('');
          setEndDate('');
        }}
      />

      <style jsx>{`
        .scrollbar-hide {
          scrollbar-width: none;
          -ms-overflow-style: none;
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .min-h-0 {
          min-height: 0;
        }

        /* Custom scrollbar styles for resizable panels */
        .scrollbar-thin {
          scrollbar-width: thin;
        }
        .scrollbar-thumb-muted-foreground\/20::-webkit-scrollbar-thumb {
          background-color: rgba(113, 113, 122, 0.2);
        }
        .scrollbar-track-transparent::-webkit-scrollbar-track {
          background: transparent;
        }
        .scrollbar-thin::-webkit-scrollbar {
          width: 6px;
          height: 6px;
        }
      `}</style>
    </div>
  );
}

// Welcome Screen Component
const WelcomeScreen = ({ isConnected, totalUnreadCount, socketConnected }) => (
  <div className="flex-1 flex items-center justify-center relative overflow-hidden ">
    <div className="text-center z-10 max-w-md mx-auto px-6">
      <div className="relative mb-8">
        <div className="w-24 h-24 bg-primary rounded-2xl flex items-center justify-center mx-auto shadow-lg">
          <MessageSquare className="w-12 h-12 text-primary-foreground" />
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-xl font-semibold text-foreground">
          Welcome to your inbox
        </h3>
        <p className="text-muted-foreground leading-relaxed">
          Select a conversation to start messaging, or create a new conversation
          to connect with your contacts.
        </p>

   
        {totalUnreadCount > 0 && (
          <div className="bg-primary/10 rounded-lg p-4 mt-6">
            <p className="text-primary font-medium">
              You have {totalUnreadCount} unread message
              {totalUnreadCount > 1 ? 's' : ''}
            </p>
          </div>
        )}

        <div className="flex flex-col sm:flex-row gap-3 justify-center mt-8">
          <Button
            className="px-6 py-3 shadow-md hover:shadow-lg"
            disabled={!socketConnected}
          >
            Start New Chat
          </Button>
          <Button variant="outline" className="px-6 py-3">
            View All Contacts
          </Button>
        </div>
      </div>
    </div>
  </div>
);
