import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Filter,
  Languages,
  ChevronDown,
  User,
  CheckCircle,
  Circle,
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';

interface Agent {
  id: number;
  name: string;
  email: string;
  isOnline: boolean;
  avatar?: string;
  initials: string;
}

interface ChatHeaderProps {
  selectedConversation: {
    name: string;
    phone: string;
    avatar: string;
  };
  showFilterModal: boolean;
  onToggleFilter: () => void;
  selectedAgent?: Agent;
  onAgentChange: (agent: Agent) => void;
}

export default function ChatHeader({
  selectedConversation,
  showFilterModal,
  onToggleFilter,
  selectedAgent,
  onAgentChange,
}: ChatHeaderProps) {
  const agents: Agent[] = [
    {
      id: 1,
      name: 'John Doe',
      email: 'john@company.com',
      isOnline: true,
      initials: 'JD',
    },
    {
      id: 2,
      name: 'Sarah Wilson',
      email: 'sarah@company.com',
      isOnline: true,
      initials: 'SW',
    },
    {
      id: 3,
      name: 'Mike Johnson',
      email: 'mike@company.com',
      isOnline: false,
      initials: 'MJ',
    },
    {
      id: 4,
      name: 'Emily Chen',
      email: 'emily@company.com',
      isOnline: true,
      initials: 'EC',
    },
  ];

  const onlineAgents = agents.filter((agent) => agent.isOnline);
  const offlineAgents = agents.filter((agent) => !agent.isOnline);

  return (
    <div className="px-4 py-3 border-b border-gray-200 flex items-center justify-between bg-white">
    
      <div className="flex items-center space-x-3">
        <div className="w-10 h-10 bg-[#b4bab6] rounded-full flex items-center justify-center text-white font-semibold text-sm">
          {selectedConversation.avatar}
        </div>
        <div>
          <h3 className="font-bold  text-sm">
            {selectedConversation.name}
          </h3>
          <p className="text-xs text-gray-500">{selectedConversation.phone}</p>
        </div>
      </div>

      {/* Agent Selection and Actions */}
      <div className="flex items-center space-x-3">
        {/* Agent Dropdown */}
        {/* <div className="flex items-center space-x-2">
          <span className="text-xs text-gray-600 font-medium">Send as:</span>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className="flex items-center space-x-2 min-w-[130px] justify-between h-8 px-3"
              >
                <div className="flex items-center space-x-1.5">
                  {selectedAgent ? (
                    <>
                      <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center text-white text-xs font-semibold">
                        {selectedAgent.initials}
                      </div>
                      <span className="text-xs truncate max-w-[70px] font-medium">
                        {selectedAgent.name}
                      </span>
                      <div
                        className={`w-1.5 h-1.5 rounded-full ${
                          selectedAgent.isOnline
                            ? 'bg-green-500'
                            : 'bg-gray-400'
                        }`}
                      />
                    </>
                  ) : (
                    <>
                      <User className="w-3.5 h-3.5 text-gray-400" />
                      <span className="text-xs text-gray-500">
                        Select Agent
                      </span>
                    </>
                  )}
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-64">
              <DropdownMenuLabel className="flex items-center justify-between py-2">
                <span className="text-sm font-medium">Available Agents</span>
                <Badge variant="secondary" className="text-xs px-2 py-0.5">
                  {onlineAgents.length} online
                </Badge>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />

              {onlineAgents.length > 0 && (
                <>
                  <div className="px-3 py-1.5">
                    <div className="flex items-center space-x-2 text-xs text-green-600 font-medium">
                      <CheckCircle className="w-3 h-3" />
                      <span>Online ({onlineAgents.length})</span>
                    </div>
                  </div>
                  {onlineAgents.map((agent) => (
                    <DropdownMenuItem
                      key={agent.id}
                      onClick={() => onAgentChange(agent)}
                      className="flex items-center space-x-3 p-3 cursor-pointer hover:bg-gray-50"
                    >
                      <div className="relative">
                        <div className="w-7 h-7 bg-green-500 rounded-full flex items-center justify-center text-white text-xs font-semibold">
                          {agent.initials}
                        </div>
                        <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-green-500 border-2 border-white rounded-full" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium text-gray-900 truncate">
                          {agent.name}
                        </div>
                        <div className="text-xs text-gray-500 truncate">
                          {agent.email}
                        </div>
                      </div>
                      {selectedAgent?.id === agent.id && (
                        <CheckCircle className="w-4 h-4 text-green-500" />
                      )}
                    </DropdownMenuItem>
                  ))}
                </>
              )}

              {offlineAgents.length > 0 && (
                <>
                  <DropdownMenuSeparator />
                  <div className="px-3 py-1.5">
                    <div className="flex items-center space-x-2 text-xs text-gray-500 font-medium">
                      <Circle className="w-3 h-3" />
                      <span>Offline ({offlineAgents.length})</span>
                    </div>
                  </div>
                  {offlineAgents.map((agent) => (
                    <DropdownMenuItem
                      key={agent.id}
                      onClick={() => onAgentChange(agent)}
                      className="flex items-center space-x-3 p-3 cursor-pointer opacity-60 hover:bg-gray-50"
                    >
                      <div className="relative">
                        <div className="w-7 h-7 bg-gray-400 rounded-full flex items-center justify-center text-white text-xs font-semibold">
                          {agent.initials}
                        </div>
                        <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-gray-400 border-2 border-white rounded-full" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium text-gray-900 truncate">
                          {agent.name}
                        </div>
                        <div className="text-xs text-gray-500 truncate">
                          {agent.email}
                        </div>
                      </div>
                      {selectedAgent?.id === agent.id && (
                        <CheckCircle className="w-4 h-4 text-gray-500" />
                      )}
                    </DropdownMenuItem>
                  ))}
                </>
              )}

              {agents.length === 0 && (
                <div className="p-4 text-center text-gray-500 text-sm">
                  No agents available
                </div>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div> */}

        {/* Action Buttons */}
        {/* <div className="flex items-center space-x-1.5">
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggleFilter}
            className={`relative h-8 w-8 p-0 ${
              showFilterModal ? 'bg-gray-100' : ''
            }`}
          >
            <Filter className="w-3.5 h-3.5" />
          </Button>
          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
            <Languages className="w-3.5 h-3.5" />
          </Button>
        </div> */}
      </div>
    </div>
  );
}
