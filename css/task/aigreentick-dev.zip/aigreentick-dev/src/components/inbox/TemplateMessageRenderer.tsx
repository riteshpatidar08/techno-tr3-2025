import React, { useState } from 'react';
import {
  Check,
  CheckCheck,
  Copy,
  ExternalLink,
  Phone,
  MessageSquare,
  Tag,
  Clock,
  ChevronDown,
  ChevronUp,
  Image,
  Video,
  FileText,
  PlayCircle,
} from 'lucide-react';

// Extended Message interface for templates
interface TemplateMessage extends Message {
  messageType: 'template';
  template_data: {
    template_name: string;
    template_id: string;
    category: string;
    language: string;
    components: TemplateComponent[];
    variables?: { [key: string]: string };
    campaign_name?: string;
    delivery_status?: string;
  };
}

interface TemplateComponent {
  type: 'HEADER' | 'BODY' | 'FOOTER' | 'BUTTONS';
  format?: 'TEXT' | 'IMAGE' | 'VIDEO' | 'DOCUMENT';
  text?: string;
  image_url?: string;
  video_url?: string;
  document_url?: string;
  buttons?: TemplateButton[];
}

interface TemplateButton {
  type: 'QUICK_REPLY' | 'PHONE_NUMBER' | 'URL' | 'otp';
  text: string;
  url?: string;
  phone_number?: string;
  otp_type?: 'copy_code';
}

interface TemplateMessageRendererProps {
  message: TemplateMessage;
  isUser: boolean;
  timestamp: string;
  status: string;
}

export const TemplateMessageRenderer: React.FC<
  TemplateMessageRendererProps
> = ({ message, isUser, timestamp, status }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [copiedText, setCopiedText] = useState('');

  const { template_data } = message;

  const formatMessageTime = (timestamp: string) => {
    if (timestamp.includes(',')) {
      const timePart = timestamp.split(',')[1]?.trim();
      if (timePart) {
        return timePart.replace(/am/g, 'AM').replace(/pm/g, 'PM');
      }
    }
    try {
      const date = new Date(timestamp);
      return date.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: false,
      });
    } catch {
      return timestamp;
    }
  };

  const getMessageStatusIcon = (status: string) => {
    if (!isUser) return null;
    switch (status?.toLowerCase()) {
      case 'sent':
        return <Check className="w-3 h-3 text-gray-400" />;
      case 'delivered':
        return <CheckCheck className="w-3 h-3 text-gray-400" />;
      case 'read':
        return <CheckCheck className="w-3 h-3 text-blue-500" />;
      default:
        return <Check className="w-3 h-3 text-gray-400" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category.toUpperCase()) {
      case 'MARKETING':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'UTILITY':
        return 'bg-green-50 text-green-700 border-green-200';
      case 'AUTHENTICATION':
        return 'bg-orange-50 text-orange-700 border-orange-200';
      default:
        return 'bg-gray-50 text-gray-700 border-gray-200';
    }
  };

  const getDeliveryStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'delivered':
        return 'bg-green-50 text-green-700 border-green-200';
      case 'failed':
        return 'bg-red-50 text-red-700 border-red-200';
      case 'pending':
        return 'bg-yellow-50 text-yellow-700 border-yellow-200';
      default:
        return 'bg-gray-50 text-gray-700 border-gray-200';
    }
  };

  const processTextWithVariables = (text: string) => {
    if (!text) return text;

    let processedText = text;

    // Replace variables with actual values
    if (template_data.variables) {
      Object.entries(template_data.variables).forEach(([key, value]) => {
        const variablePattern = new RegExp(`\\{\\{${key}\\}\\}`, 'g');
        processedText = processedText.replace(
          variablePattern,
          `<span class="template-variable">${value}</span>`
        );
      });
    }

    return processedText;
  };

  const handleCopyText = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    setTimeout(() => setCopiedText(''), 2000);
  };

  const handleButtonClick = (button: TemplateButton) => {
    switch (button.type) {
      case 'URL':
        if (button.url) {
          window.open(button.url, '_blank');
        }
        break;
      case 'PHONE_NUMBER':
        if (button.phone_number) {
          window.location.href = `tel:${button.phone_number}`;
        }
        break;
      case 'otp':
        // For OTP buttons, copy the verification code from the body
        const bodyComponent = template_data.components.find(
          (c) => c.type === 'BODY'
        );
        if (bodyComponent?.text) {
          const codeMatch = bodyComponent.text.match(/\d{4,8}/);
          if (codeMatch) {
            handleCopyText(codeMatch[0]);
          }
        }
        break;
      case 'QUICK_REPLY':
        // Handle quick reply action
        console.log('Quick reply:', button.text);
        break;
    }
  };

  const renderTemplateHeader = () => {
    const headerComponent = template_data.components.find(
      (c) => c.type === 'HEADER'
    );
    if (!headerComponent) return null;

    if (headerComponent.format === 'IMAGE' && headerComponent.image_url) {
      return (
        <div className="relative rounded-t-lg overflow-hidden">
          <img
            src={headerComponent.image_url}
            alt="Template header"
            className="w-full h-40 object-cover"
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              target.style.display = 'none';
            }}
          />
          <div className="absolute top-2 left-2">
            <div className="bg-black/50 text-white px-2 py-1 rounded text-xs flex items-center gap-1">
              <Image className="w-3 h-3" />
              Header Image
            </div>
          </div>
        </div>
      );
    }

    if (headerComponent.format === 'VIDEO' && headerComponent.video_url) {
      return (
        <div className="relative rounded-t-lg overflow-hidden">
          <video
            src={headerComponent.video_url}
            className="w-full h-40 object-cover"
            controls
            preload="metadata"
          />
          <div className="absolute top-2 left-2">
            <div className="bg-black/50 text-white px-2 py-1 rounded text-xs flex items-center gap-1">
              <Video className="w-3 h-3" />
              Header Video
            </div>
          </div>
        </div>
      );
    }

    if (headerComponent.format === 'DOCUMENT' && headerComponent.document_url) {
      return (
        <div className="p-3 bg-gray-50 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-gray-500" />
            <div className="flex-1">
              <p className="text-sm font-medium text-gray-700">
                Document Header
              </p>
              <button
                onClick={() =>
                  window.open(headerComponent.document_url, '_blank')
                }
                className="text-xs text-blue-600 hover:text-blue-800"
              >
                View Document
              </button>
            </div>
          </div>
        </div>
      );
    }

    if (headerComponent.text) {
      return (
        <div className="p-3 bg-gradient-to-r from-blue-50 to-blue-100 border-b border-blue-200">
          <p
            className="font-semibold text-blue-900 text-sm leading-relaxed"
            dangerouslySetInnerHTML={{
              __html: processTextWithVariables(headerComponent.text),
            }}
          />
        </div>
      );
    }

    return null;
  };

  const renderTemplateBody = () => {
    const bodyComponent = template_data.components.find(
      (c) => c.type === 'BODY'
    );
    if (!bodyComponent?.text) return null;

    return (
      <div className="p-4">
        <p
          className="text-gray-900 text-[15px] leading-relaxed whitespace-pre-wrap break-words"
          dangerouslySetInnerHTML={{
            __html: processTextWithVariables(bodyComponent.text),
          }}
        />
      </div>
    );
  };

  const renderTemplateFooter = () => {
    const footerComponent = template_data.components.find(
      (c) => c.type === 'FOOTER'
    );
    if (!footerComponent?.text) return null;

    return (
      <div className="px-4 pb-3">
        <p
          className="text-gray-600 text-xs leading-relaxed"
          dangerouslySetInnerHTML={{
            __html: processTextWithVariables(footerComponent.text),
          }}
        />
      </div>
    );
  };

  const renderTemplateButtons = () => {
    const buttonsComponent = template_data.components.find(
      (c) => c.type === 'BUTTONS'
    );
    if (!buttonsComponent?.buttons || buttonsComponent.buttons.length === 0)
      return null;

    const urlButtons = buttonsComponent.buttons.filter(
      (btn) => btn.type === 'URL'
    );
    const phoneButtons = buttonsComponent.buttons.filter(
      (btn) => btn.type === 'PHONE_NUMBER'
    );
    const quickReplyButtons = buttonsComponent.buttons.filter(
      (btn) => btn.type === 'QUICK_REPLY'
    );
    const otpButtons = buttonsComponent.buttons.filter(
      (btn) => btn.type === 'otp'
    );

    return (
      <div className="border-t border-gray-100">
        {/* URL and Phone buttons */}
        {(urlButtons.length > 0 ||
          phoneButtons.length > 0 ||
          otpButtons.length > 0) && (
          <div className="p-2 space-y-1">
            {phoneButtons.map((button, index) => (
              <button
                key={`phone-${index}`}
                onClick={() => handleButtonClick(button)}
                className="w-full flex items-center justify-center gap-2 py-2 px-3 text-sm font-medium text-green-700 bg-green-50 hover:bg-green-100 border border-green-200 rounded-lg transition-colors"
              >
                <Phone className="w-4 h-4" />
                {button.text}
              </button>
            ))}
            {urlButtons.map((button, index) => (
              <button
                key={`url-${index}`}
                onClick={() => handleButtonClick(button)}
                className="w-full flex items-center justify-center gap-2 py-2 px-3 text-sm font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition-colors"
              >
                <ExternalLink className="w-4 h-4" />
                {button.text}
              </button>
            ))}
            {otpButtons.map((button, index) => (
              <button
                key={`otp-${index}`}
                onClick={() => handleButtonClick(button)}
                className="w-full flex items-center justify-center gap-2 py-2 px-3 text-sm font-medium text-orange-700 bg-orange-50 hover:bg-orange-100 border border-orange-200 rounded-lg transition-colors relative"
              >
                <Copy className="w-4 h-4" />
                {button.text}
                {copiedText && (
                  <span className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-black text-white text-xs px-2 py-1 rounded">
                    Copied!
                  </span>
                )}
              </button>
            ))}
          </div>
        )}

        {/* Quick Reply buttons */}
        {quickReplyButtons.length > 0 && (
          <div className="border-t border-gray-100 p-2">
            <div className="flex items-center gap-2 mb-2">
              <MessageSquare className="w-3 h-3 text-gray-500" />
              <span className="text-xs text-gray-500 font-medium">
                Quick Replies
              </span>
            </div>
            <div className="flex flex-wrap gap-1">
              {quickReplyButtons.map((button, index) => (
                <button
                  key={`reply-${index}`}
                  onClick={() => handleButtonClick(button)}
                  className="px-3 py-1 text-xs font-medium text-gray-700 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-full transition-colors"
                >
                  {button.text}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="max-w-[85%] min-w-[280px]">
      {/* Template Card */}
      <div
        className={`${
          isUser ? 'bg-green-50' : 'bg-white'
        } rounded-lg shadow-sm border border-gray-200 overflow-hidden`}
      >
        {/* Template Header Badge */}
        <div className="flex items-center justify-between p-2 bg-gray-50 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <Tag className="w-3 h-3 text-gray-500" />
            <span className="text-xs font-medium text-gray-600">
              Template Message
            </span>
            <span
              className={`px-2 py-0.5 text-xs font-medium rounded-full border ${getCategoryColor(
                template_data.category
              )}`}
            >
              {template_data.category}
            </span>
          </div>
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 hover:bg-gray-100 rounded text-gray-500"
          >
            {isExpanded ? (
              <ChevronUp className="w-3 h-3" />
            ) : (
              <ChevronDown className="w-3 h-3" />
            )}
          </button>
        </div>

        {/* Template Content */}
        <div>
          {renderTemplateHeader()}
          {renderTemplateBody()}
          {renderTemplateFooter()}
          {renderTemplateButtons()}
        </div>

        {/* Expanded Template Details */}
        {isExpanded && (
          <div className="border-t border-gray-100 p-3 bg-gray-50">
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-gray-500">Template Name:</span>
                <span className="font-medium text-gray-700">
                  {template_data.template_name}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-gray-500">Language:</span>
                <span className="font-medium text-gray-700">
                  {template_data.language}
                </span>
              </div>
              {template_data.campaign_name && (
                <div className="flex items-center justify-between text-xs">
                  <span className="text-gray-500">Campaign:</span>
                  <span className="font-medium text-gray-700 truncate ml-2">
                    {template_data.campaign_name}
                  </span>
                </div>
              )}
              {template_data.delivery_status && (
                <div className="flex items-center justify-between text-xs">
                  <span className="text-gray-500">Status:</span>
                  <span
                    className={`px-2 py-0.5 text-xs font-medium rounded-full border ${getDeliveryStatusColor(
                      template_data.delivery_status
                    )}`}
                  >
                    {template_data.delivery_status}
                  </span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Message Timestamp and Status */}
        <div className="flex items-end justify-end space-x-1 px-3 pb-2">
          <span className="text-[11px] text-gray-500">
            {formatMessageTime(timestamp)}
          </span>
          {getMessageStatusIcon(status)}
        </div>
      </div>

      {/* Custom CSS for template variables */}
      <style jsx>{`
        :global(.template-variable) {
          background-color: rgba(59, 130, 246, 0.1);
          color: rgb(37, 99, 235);
          padding: 1px 4px;
          border-radius: 3px;
          font-weight: 500;
          border: 1px solid rgba(59, 130, 246, 0.2);
        }
      `}</style>
    </div>
  );
};

// Updated Message interface to include template support
export interface ExtendedMessage extends Message {
  messageType?: 'text' | 'media' | 'template';
  template_data?: {
    template_name: string;
    template_id: string;
    category: string;
    language: string;
    components: TemplateComponent[];
    variables?: { [key: string]: string };
    campaign_name?: string;
    delivery_status?: string;
  };
}

// Usage in your existing ChatMessages component
export const renderMessage = (
  message: ExtendedMessage,
  isUser: boolean,
  timestamp: string,
  status: string
) => {
  if (message.messageType === 'template' && message.template_data) {
    return (
      <TemplateMessageRenderer
        message={message as TemplateMessage}
        isUser={isUser}
        timestamp={timestamp}
        status={status}
      />
    );
  }

  // Fall back to your existing message rendering logic
  return null;
};
