import React, { useRef, useEffect } from 'react';
import {
  Check,
  CheckCheck,
  Loader2,
  Download,
  FileText,
  Volume2,
  Image,
  Video,
} from 'lucide-react';
import bgimage from '@/assets/images/backgrounds/whitebg.jpg';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'contact';
  timestamp: string;
  status: string;
  buttons?: string[];
  media_url?: string;
  media_type?: string;
  filename?: string;
  caption?: string;
  isMedia?: boolean;
  messageType?: string | null;
}

interface ChatMessagesProps {
  messages: Message[];
  isInitialLoad: boolean;
  isLoading?: boolean;
}

export default function ChatMessages({
  messages,
  isInitialLoad,
  isLoading = false,
}: ChatMessagesProps) {
  const messagesContainerRef = useRef<HTMLDivElement>(null);

  // Force scroll to bottom - multiple approaches to ensure it works
  const scrollToBottom = () => {
    if (messagesContainerRef.current) {
      const container = messagesContainerRef.current;
      container.scrollTop = container.scrollHeight;
    }
  };

  // Scroll on messages change
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Scroll on initial mount - multiple attempts
  useEffect(() => {
    // Immediate scroll
    scrollToBottom();

    // Backup scroll after short delay
    const timer1 = setTimeout(() => {
      scrollToBottom();
    }, 50);

    // Another backup after longer delay
    const timer2 = setTimeout(() => {
      scrollToBottom();
    }, 200);

    // Final backup
    const timer3 = setTimeout(() => {
      scrollToBottom();
    }, 500);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, []);

  // Force scroll when loading changes
  useEffect(() => {
    if (!isLoading) {
      setTimeout(() => {
        scrollToBottom();
      }, 100);
    }
  }, [isLoading]);

  const formatMessageTime = (timestamp: string) => {
    if (timestamp.includes(',')) {
      const timePart = timestamp.split(',')[1]?.trim();
      if (timePart) {
        return timePart.replace(/am/g, 'AM').replace(/pm/g, 'PM');
      }
    }

    try {
      const date = new Date(timestamp);
      return date.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: false,
      });
    } catch {
      return timestamp;
    }
  };

  const getMessageStatusIcon = (status: string, sender: string) => {
    if (sender !== 'user') return null;

    switch (status?.toLowerCase()) {
      case 'sent':
        return <Check className="w-4 h-4 text-gray-400" />;
      case 'delivered':
        return <CheckCheck className="w-4 h-4 text-gray-400" />;
      case 'read':
        return <CheckCheck className="w-4 h-4 text-blue-500" />;
      default:
        return <Check className="w-4 h-4 text-gray-400" />;
    }
  };

  const isImageUrl = (text: string): boolean => {
    if (!text) return false;

    const imageExtensions = [
      '.jpg',
      '.jpeg',
      '.png',
      '.gif',
      '.webp',
      '.bmp',
      '.svg',
    ];
    const url = text.trim().toLowerCase();
    const isUrl = url.startsWith('http://') || url.startsWith('https://');
    const hasImageExtension = imageExtensions.some((ext) => url.includes(ext));

    const imageHostingPatterns = [
      'aigreentick.com/storage/uploads',
      'imgur.com',
      'cloudinary.com',
      'amazonaws.com',
      'googleusercontent.com',
    ];
    const hasImageHosting = imageHostingPatterns.some((pattern) =>
      url.includes(pattern)
    );

    return isUrl && (hasImageExtension || hasImageHosting);
  };

  const isVideoUrl = (text: string): boolean => {
    if (!text) return false;

    const videoExtensions = [
      '.mp4',
      '.webm',
      '.ogg',
      '.avi',
      '.mov',
      '.wmv',
      '.flv',
    ];
    const url = text.trim().toLowerCase();
    const isUrl = url.startsWith('http://') || url.startsWith('https://');
    const hasVideoExtension = videoExtensions.some((ext) => url.includes(ext));

    return isUrl && hasVideoExtension;
  };

  const getFilenameFromUrl = (url: string): string => {
    try {
      const urlObj = new URL(url);
      const pathname = urlObj.pathname;
      const filename = pathname.split('/').pop() || 'file';
      return filename;
    } catch {
      return 'file';
    }
  };

  const getFileExtension = (filename: string) => {
    return filename?.split('.').pop()?.toLowerCase() || '';
  };

  const getFileIcon = (extension: string) => {
    const ext = extension.toLowerCase();
    if (['pdf'].includes(ext)) {
      return <FileText className="w-8 h-8 text-red-500" />;
    }
    if (['doc', 'docx'].includes(ext)) {
      return <FileText className="w-8 h-8 text-blue-500" />;
    }
    if (['xls', 'xlsx'].includes(ext)) {
      return <FileText className="w-8 h-8 text-green-500" />;
    }
    return <FileText className="w-8 h-8 text-gray-500" />;
  };

  const renderMediaContent = (message: Message) => {
    // Check for media in your actual data structure
    const hasMediaField = message.media_url && message.media_type;
    const hasIsMediaFlag = message.isMedia && message.text;
    const isTextImage = isImageUrl(message.text);
    const isTextVideo = isVideoUrl(message.text);

    // Handle your specific data structure where isMedia: true and URL is in text field
    if (hasIsMediaFlag) {
      const mediaUrl = message.text.trim();

      // Determine media type from URL extension
      const url = mediaUrl.toLowerCase();
      let mediaType = 'unknown';

      if (
        url.includes('.mp4') ||
        url.includes('.webm') ||
        url.includes('.ogg') ||
        url.includes('.avi') ||
        url.includes('.mov')
      ) {
        mediaType = 'video';
      } else if (
        url.includes('.jpg') ||
        url.includes('.jpeg') ||
        url.includes('.png') ||
        url.includes('.gif') ||
        url.includes('.webp')
      ) {
        mediaType = 'image';
      } else if (
        url.includes('.mp3') ||
        url.includes('.wav') ||
        url.includes('.ogg') ||
        url.includes('.m4a')
      ) {
        mediaType = 'audio';
      } else {
        mediaType = 'document';
      }

      switch (mediaType) {
        case 'image':
          return (
            <div className="relative group">
              <img
                src={mediaUrl}
                alt="Shared image"
                className="w-full h-auto max-w-sm max-h-80 object-cover rounded-lg cursor-pointer"
                onClick={() => window.open(mediaUrl, '_blank')}
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.style.display = 'none';
                  const fallback = target.nextElementSibling as HTMLElement;
                  if (fallback) fallback.style.display = 'flex';
                }}
              />
              <div className="w-full h-32 bg-gray-200 rounded-lg items-center justify-center text-gray-500 hidden">
                <div className="text-center">
                  <Image className="w-8 h-8 mx-auto mb-2" />
                  <p className="text-sm">Image unavailable</p>
                  <button
                    onClick={() => window.open(mediaUrl, '_blank')}
                    className="mt-2 px-3 py-1 bg-blue-500 text-white text-xs rounded hover:bg-blue-600 transition-colors"
                  >
                    Open in new tab
                  </button>
                </div>
              </div>
            </div>
          );

        case 'video':
          return (
            <div className="relative max-w-sm">
              <video
                src={mediaUrl}
                className="w-full h-auto max-h-80 object-cover rounded-lg"
                controls
                preload="metadata"
                onError={(e) => {
                  console.log('Video error:', e);
                  const target = e.target as HTMLVideoElement;
                  target.style.display = 'none';
                  const fallback = target.nextElementSibling as HTMLElement;
                  if (fallback) fallback.style.display = 'flex';
                }}
              >
                Your browser does not support the video tag.
              </video>
              <div className="w-full h-32 bg-gray-200 rounded-lg items-center justify-center text-gray-500 hidden">
                <div className="text-center">
                  <Video className="w-8 h-8 mx-auto mb-2" />
                  <p className="text-sm">Video unavailable</p>
                  <button
                    onClick={() => window.open(mediaUrl, '_blank')}
                    className="mt-2 px-3 py-1 bg-blue-500 text-white text-xs rounded hover:bg-blue-600 transition-colors"
                  >
                    Open in new tab
                  </button>
                </div>
              </div>
            </div>
          );

        case 'audio':
          return (
            <div
              className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg min-w-[250px]"
              style={{ backgroundImage: { bg } }}
            >
              <div className="flex-shrink-0">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  <Volume2 className="w-5 h-5 text-green-600" />
                </div>
              </div>
              <div className="flex-1">
                <audio
                  controls
                  className="w-full h-8"
                  onError={() => {
                    console.log('Audio playback error');
                  }}
                >
                  <source src={mediaUrl} />
                  Your browser does not support the audio element.
                </audio>
                <div className="text-xs text-gray-500 mt-1">Audio file</div>
              </div>
            </div>
          );

        case 'document':
        default:
          const extension =
            getFilenameFromUrl(mediaUrl).split('.').pop()?.toLowerCase() || '';
          return (
            <div className="p-3 bg-gray-50 rounded-lg border min-w-[250px] max-w-sm">
              <div className="flex items-center space-x-3">
                <div className="flex-shrink-0">{getFileIcon(extension)}</div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">
                    {getFilenameFromUrl(mediaUrl)}
                  </p>
                  <p className="text-xs text-gray-500">
                    {extension.toUpperCase()} • Click to download
                  </p>
                </div>
                <div className="flex-shrink-0">
                  <button
                    onClick={() => window.open(mediaUrl, '_blank')}
                    className="p-2 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100 transition-colors"
                    title="Download file"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
      }
    }

    // Handle standard media_url and media_type fields (fallback)
    if (hasMediaField) {
      const mediaUrl = message.media_url;
      const mediaType = message.media_type.toLowerCase();

      switch (mediaType) {
        case 'image':
          return (
            <div className="relative group">
              <img
                src={mediaUrl}
                alt={message.filename || 'Shared image'}
                className="w-full h-auto max-w-sm max-h-80 object-cover rounded-lg cursor-pointer"
                onClick={() => window.open(mediaUrl, '_blank')}
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.style.display = 'none';
                  const fallback = target.nextElementSibling as HTMLElement;
                  if (fallback) fallback.style.display = 'flex';
                }}
              />
              <div className="w-full h-32 bg-gray-200 rounded-lg items-center justify-center text-gray-500 hidden">
                <div className="text-center">
                  <Image className="w-8 h-8 mx-auto mb-2" />
                  <p className="text-sm">Image unavailable</p>
                </div>
              </div>
            </div>
          );

        case 'video':
          return (
            <div className="relative max-w-sm">
              <video
                src={mediaUrl}
                className="w-full h-auto max-h-80 object-cover rounded-lg"
                controls
                preload="metadata"
                onError={(e) => {
                  console.log('Video error:', e);
                  const target = e.target as HTMLVideoElement;
                  target.style.display = 'none';
                  const fallback = target.nextElementSibling as HTMLElement;
                  if (fallback) fallback.style.display = 'flex';
                }}
              >
                Your browser does not support the video tag.
              </video>
              <div className="w-full h-32 bg-gray-200 rounded-lg items-center justify-center text-gray-500 hidden">
                <div className="text-center">
                  <Video className="w-8 h-8 mx-auto mb-2" />
                  <p className="text-sm">Video unavailable</p>
                  <button
                    onClick={() => window.open(mediaUrl, '_blank')}
                    className="mt-2 px-3 py-1 bg-blue-500 text-white text-xs rounded hover:bg-blue-600 transition-colors"
                  >
                    Open in new tab
                  </button>
                </div>
              </div>
            </div>
          );

        case 'audio':
          return (
            <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg min-w-[250px]">
              <div className="flex-shrink-0">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  <Volume2 className="w-5 h-5 text-green-600" />
                </div>
              </div>
              <div className="flex-1">
                <audio
                  controls
                  className="w-full h-8"
                  onError={() => {
                    console.log('Audio playback error');
                  }}
                >
                  <source src={mediaUrl} />
                  Your browser does not support the audio element.
                </audio>
                <div className="text-xs text-gray-500 mt-1">
                  {message.filename || 'Audio file'}
                </div>
              </div>
            </div>
          );

        case 'document':
        default:
          const extension = getFileExtension(message.filename || '');
          return (
            <div className="p-3 bg-gray-50 rounded-lg border min-w-[250px] max-w-sm">
              <div className="flex items-center space-x-3">
                <div className="flex-shrink-0">{getFileIcon(extension)}</div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">
                    {message.filename || 'Document'}
                  </p>
                  <p className="text-xs text-gray-500">
                    {extension.toUpperCase()} • Click to download
                  </p>
                </div>
                <div className="flex-shrink-0">
                  <button
                    onClick={() => window.open(mediaUrl, '_blank')}
                    className="p-2 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100 transition-colors"
                    title="Download file"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
      }
    }

    if (isTextImage && !hasIsMediaFlag) {
      return (
        <div className="relative group">
          <img
            src={message.text.trim()}
            alt={getFilenameFromUrl(message.text)}
            className="w-full h-auto max-w-sm max-h-80 object-cover rounded-lg cursor-pointer"
            onClick={() => window.open(message.text.trim(), '_blank')}
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              target.style.display = 'none';
              const fallback = target.nextElementSibling as HTMLElement;
              if (fallback) fallback.style.display = 'flex';
            }}
          />
          <div className="w-full h-32 bg-gray-200 rounded-lg items-center justify-center text-gray-500 hidden">
            <div className="text-center">
              <Image className="w-8 h-8 mx-auto mb-2" />
              <p className="text-sm">Image unavailable</p>
            </div>
          </div>
        </div>
      );
    }

    if (isTextVideo && !hasIsMediaFlag) {
      return (
        <div className="relative max-w-sm">
          <video
            src={message.text.trim()}
            className="w-full h-auto max-h-80 object-cover rounded-lg"
            controls
            preload="metadata"
            onError={(e) => {
              console.log('Video error for text video:', e);
              const target = e.target as HTMLVideoElement;
              target.style.display = 'none';
              const fallback = target.nextElementSibling as HTMLElement;
              if (fallback) fallback.style.display = 'flex';
            }}
          >
            Your browser does not support the video tag.
          </video>
          <div className="w-full h-32 bg-gray-200 rounded-lg items-center justify-center text-gray-500 hidden">
            <div className="text-center">
              <Video className="w-8 h-8 mx-auto mb-2" />
              <p className="text-sm">Video unavailable</p>
              <button
                onClick={() => window.open(message.text.trim(), '_blank')}
                className="mt-2 px-3 py-1 bg-blue-500 text-white text-xs rounded hover:bg-blue-600 transition-colors"
              >
                Open in new tab
              </button>
            </div>
          </div>
        </div>
      );
    }

    return null;
  };

  const groupMessagesByDate = (messages: Message[]) => {
    const groups: { [date: string]: Message[] } = {};

    messages.forEach((message) => {
      let messageDate;
      try {
        if (message.timestamp.includes(',')) {
          const datePart = message.timestamp.split(',')[0].trim();
          const [day, month, year] = datePart.split('/');
          const fullYear = 2000 + parseInt(year);
          messageDate = new Date(fullYear, parseInt(month) - 1, parseInt(day));
        } else {
          messageDate = new Date(message.timestamp);
        }

        if (isNaN(messageDate.getTime())) {
          messageDate = new Date();
        }
      } catch {
        messageDate = new Date();
      }

      const today = new Date();
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);

      const isToday = messageDate.toDateString() === today.toDateString();
      const isYesterday =
        messageDate.toDateString() === yesterday.toDateString();

      let dateLabel;
      if (isToday) {
        dateLabel = 'Today';
      } else if (isYesterday) {
        dateLabel = 'Yesterday';
      } else {
        dateLabel = messageDate.toLocaleDateString('en-US', {
          month: 'short',
          day: 'numeric',
          year: 'numeric',
        });
      }

      if (!groups[dateLabel]) {
        groups[dateLabel] = [];
      }
      groups[dateLabel].push(message);
    });

    return groups;
  };

  const groupedMessages =
    messages.length > 0 ? groupMessagesByDate(messages) : {};

  return (
    <div
      className="h-full flex shrink-0 flex-col relative"
      style={{
        backgroundImage: `url(${bgimage})`,
        backgroundSize: 'contain',
        backgroundPosition: 'center',
        backgroundRepeat: 'repeat',
        backgroundColor: '#efeae2',
      }}
    >
      {isLoading && messages.length === 0 ? (
        <div className="flex-1 flex items-center justify-center">
          <div className="flex items-center space-x-3 bg-white/90 backdrop-blur-sm rounded-full px-6 py-3 shadow-lg">
            <Loader2 className="w-5 h-5 animate-spin text-green-500" />
            <span className="text-gray-700 font-medium">
              Loading messages...
            </span>
          </div>
        </div>
      ) : messages.length === 0 ? (
        <div className="flex-1 flex items-center justify-center p-8">
          <div className="text-center">
            <div className="w-20 h-20 mx-auto mb-6 bg-white/80 rounded-full flex items-center justify-center shadow-lg">
              <svg
                className="w-10 h-10 text-gray-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1.5}
                  d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                />
              </svg>
            </div>
            <div className="bg-white/80 backdrop-blur-sm rounded-lg px-6 py-4 shadow-lg">
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No messages yet
              </h3>
              <p className="text-gray-600">
                Send a message to start the conversation
              </p>
            </div>
          </div>
        </div>
      ) : (
        <div
          className="flex-1 overflow-y-auto scrollbar-hide"
          ref={messagesContainerRef}
        >
          <div className="p-3 pb-6">
            {Object.entries(groupedMessages).map(([date, dateMessages]) => (
              <div key={date} className="mb-6">
                <div className="flex justify-center mb-4">
                  <div className="bg-white/90 backdrop-blur-sm rounded-lg px-3 py-1 shadow-sm">
                    <span className="text-xs font-medium text-gray-600 uppercase tracking-wide">
                      {date}
                    </span>
                  </div>
                </div>

                <div className="space-y-1">
                  {dateMessages.map((message, index) => {
                    const isUser = message.sender === 'user';
                    const prevMessage =
                      index > 0 ? dateMessages[index - 1] : null;
                    const nextMessage =
                      index < dateMessages.length - 1
                        ? dateMessages[index + 1]
                        : null;

                    const isFirstInGroup =
                      !prevMessage || prevMessage.sender !== message.sender;
                    const isLastInGroup =
                      !nextMessage || nextMessage.sender !== message.sender;

                    const hasMedia =
                      message.isMedia || // Check your isMedia flag first
                      (message.media_url && message.media_type) ||
                      isImageUrl(message.text) ||
                      isVideoUrl(message.text);

                    const hasText =
                      message.text &&
                      !message.isMedia && // Don't show text if isMedia is true
                      !isImageUrl(message.text) &&
                      !isVideoUrl(message.text);

                    return (
                      <div
                        key={message.id}
                        className={`flex ${
                          isUser ? 'justify-end' : 'justify-start'
                        } px-2`}
                      >
                        <div
                          className={`relative max-w-[75%] min-w-[100px] ${
                            isUser ? 'bg-green-100' : 'bg-white'
                          } rounded-lg shadow-sm ${
                            isFirstInGroup ? 'mt-2' : 'mt-0.5'
                          }`}
                          style={{
                            borderTopLeftRadius: isUser
                              ? '18px'
                              : isFirstInGroup
                              ? '18px'
                              : '4px',
                            borderTopRightRadius: isUser
                              ? isFirstInGroup
                                ? '18px'
                                : '4px'
                              : '18px',
                            borderBottomLeftRadius: isUser
                              ? '18px'
                              : isLastInGroup
                              ? '18px'
                              : '4px',
                            borderBottomRightRadius: isUser
                              ? isLastInGroup
                                ? '18px'
                                : '4px'
                              : '18px',
                          }}
                        >
                          {isLastInGroup && (
                            <div
                              className={`absolute bottom-0 w-3 h-3 ${
                                isUser
                                  ? 'bg-green-100 -right-1'
                                  : 'bg-white -left-1'
                              }`}
                              style={{
                                clipPath: isUser
                                  ? 'polygon(0 0, 100% 0, 0 100%)'
                                  : 'polygon(100% 0, 0 0, 100% 100%)',
                              }}
                            />
                          )}

                          <div className="overflow-hidden rounded-lg">
                            {hasMedia && (
                              <div className={hasText ? 'mb-1' : ''}>
                                {renderMediaContent(message)}
                              </div>
                            )}

                            {hasText && (
                              <div
                                className={`px-3 ${
                                  hasMedia ? 'pt-1 pb-2' : 'py-2'
                                }`}
                              >
                                <p className="text-[15px] leading-relaxed break-words whitespace-pre-wrap text-gray-900">
                                  {message.text}
                                </p>
                              </div>
                            )}

                            {message.caption && hasMedia && (
                              <div className="px-3 pt-1 pb-2">
                                <p className="text-[15px] leading-relaxed break-words whitespace-pre-wrap text-gray-900">
                                  {message.caption}
                                </p>
                              </div>
                            )}

                            <div
                              className={`flex items-end justify-end space-x-1 ${
                                hasText || message.caption
                                  ? 'px-3 pb-1'
                                  : 'absolute bottom-2 right-2'
                              }`}
                            >
                              <span
                                className={`text-[11px] ${
                                  hasText || message.caption
                                    ? 'text-gray-500'
                                    : 'text-white bg-black/30 rounded px-1'
                                }`}
                              >
                                {formatMessageTime(message.timestamp)}
                              </span>
                              {getMessageStatusIcon(
                                message.status,
                                message.sender
                              )}
                            </div>
                          </div>

                          {message.buttons && message.buttons.length > 0 && (
                            <div className="border-t border-gray-200 p-2">
                              <div className="space-y-1">
                                {message.buttons.map((button, buttonIndex) => (
                                  <button
                                    key={buttonIndex}
                                    className="w-full text-center py-2 px-3 text-[14px] font-medium text-blue-600 hover:bg-blue-50 rounded-lg transition-colors border border-blue-200"
                                  >
                                    {button}
                                  </button>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <style jsx>{`
        .scrollbar-hide {
          scrollbar-width: none;
          -ms-overflow-style: none;
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
      `}</style>
    </div>
  );
}
