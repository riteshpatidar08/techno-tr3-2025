import React, { useState, useRef, useEffect } from 'react';
import {
  Search,
  Plus,
  ArrowLeft,
  Bot,
  MessageSquare,
  Loader2,
  AlertCircle,
  Users,
  Zap,
  Check,
  MessageSquareMore,
  CheckCheck,
} from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import PhoneInput from 'react-phone-number-input';
import 'react-phone-number-input/style.css';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useAppDispatch, useAppSelector } from '@/redux/store';
import {
  fetchMessages,
  fetchConversation,
  selectConversation,
  selectSelectedConversation,
  selectFilteredConversations,
  selectChannels,
  selectMessagesLoading,
  selectMessagesError,
  selectPaginationInfo,
  clearError,
  markConversationAsRead,
  selectSocketConnected,
  selectTotalMessagesCount,
} from '@/redux/messageSlice';

import { useSocket } from '@/hooks/useSocket';

const channels = [
  { id: 'all', name: 'All', icon: MessageSquare, description: 'All messages' },
  {
    id: 'unread',
    name: 'Unread',
    icon: AlertCircle,
    description: 'Unread messages',
  },
  { id: 'active', name: 'Active', icon: Zap, description: 'Active chats' },
];

const ContactAvatar = ({ contact, size = 48, className = '' }) => {
  const [imageError, setImageError] = useState(false);
  const [imageLoading, setImageLoading] = useState(false);

  const avatarUrl =
    contact.avatar ||
    contact.profile_picture ||
    contact.profilePicture ||
    contact.image ||
    contact.photo ||
    contact.picture ||
    contact.profile_image ||
    contact.avatar_url;

  const contactName =
    contact.contact_name ||
    contact.name ||
    contact.display_name ||
    contact.first_name ||
    'Unknown';

  const initials = contactName.charAt(0)?.toUpperCase() || '?';

  const handleImageLoad = () => {
    setImageLoading(false);
    setImageError(false);
  };

  const handleImageError = () => {
    setImageLoading(false);
    setImageError(true);
  };

  React.useEffect(() => {
    if (avatarUrl && !imageError) {
      setImageLoading(true);
    } else {
      setImageLoading(false);
    }
  }, [avatarUrl, imageError]);

  return (
    <div
      className={`relative overflow-hidden rounded-full bg-[#dcdddc] flex items-center justify-center transition-transform duration-200 ease-[cubic-bezier(0.4,0,0.2,1)] hover:scale-[1.02] ${className}`}
      style={{ width: size, height: size }}
    >
      {avatarUrl && !imageError ? (
        <>
          {imageLoading && (
            <div className="flex items-center justify-center w-full h-full font-semibold text-white text-base uppercase tracking-wide bg-gradient-to-r from-slate-300 via-slate-300/50 to-slate-300 bg-[length:200%_100%] animate-[shimmer_2s_infinite] bg-[position:200%_0]">
              {initials}
            </div>
          )}
          <img
            src={avatarUrl}
            alt={contactName}
            onLoad={handleImageLoad}
            onError={handleImageError}
            className={`w-full h-full object-cover transition-transform duration-200 ease-[cubic-bezier(0.4,0,0.2,1)] hover:scale-105 ${
              imageLoading ? 'hidden' : 'block'
            }`}
            crossOrigin="anonymous"
          />
        </>
      ) : (
        <div className="flex items-center justify-center w-full h-full font-semibold text-white text-base uppercase tracking-wide">
          {initials}
        </div>
      )}
    </div>
  );
};

// Date grouping utility functions
const getDateGroup = (timestamp) => {
  const date =
    typeof timestamp === 'number'
      ? new Date(timestamp * 1000)
      : new Date(timestamp);
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const yesterday = new Date(today.getTime() - 24 * 60 * 60 * 1000);
  const messageDate = new Date(
    date.getFullYear(),
    date.getMonth(),
    date.getDate()
  );

  if (messageDate.getTime() === today.getTime()) {
    return 'Today';
  } else if (messageDate.getTime() === yesterday.getTime()) {
    return 'Yesterday';
  } else if (now.getTime() - messageDate.getTime() < 7 * 24 * 60 * 60 * 1000) {
    return date.toLocaleDateString('en-US', { weekday: 'long' });
  } else if (now.getFullYear() === date.getFullYear()) {
    return date.toLocaleDateString('en-US', { month: 'long', day: 'numeric' });
  } else {
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  }
};

const groupConversationsByDate = (conversations) => {
  const groups = {};

  conversations.forEach((conversation) => {
    const dateGroup = getDateGroup(conversation.lastMessageTime);
    if (!groups[dateGroup]) {
      groups[dateGroup] = [];
    }
    groups[dateGroup].push(conversation);
  });

  const sortedGroups = {};
  const groupOrder = ['Today', 'Yesterday'];

  // Add Today and Yesterday first if they exist
  groupOrder.forEach((group) => {
    if (groups[group]) {
      sortedGroups[group] = groups[group];
    }
  });

  Object.keys(groups)
    .filter((group) => !groupOrder.includes(group))
    .sort((a, b) => {
      const aDate = new Date(a);
      const bDate = new Date(b);
      return bDate.getTime() - aDate.getTime();
    })
    .forEach((group) => {
      sortedGroups[group] = groups[group];
    });

  return sortedGroups;
};

const DateHeader = ({ dateGroup, conversationCount }) => {
  return (
    <div className="sticky top-0 z-10 bg-white px-6 py-3 mb-1">
      <div className="flex items-center">
        <div className="flex-1 h-px bg-border"></div>
        <h3 className="px-4 text-xs font-medium text-muted-foreground uppercase tracking-wide">
          {dateGroup}
        </h3>
        <div className="flex-1 h-px bg-border"></div>
      </div>
    </div>
  );
};

export default function ConversationList({
  onSelectConversation,
  currentUser,
}) {
  const dispatch = useAppDispatch();

  // Your existing selectors with safe fallbacks
  const conversations = useAppSelector(selectFilteredConversations) || [];
  const selectedConversation = useAppSelector(selectSelectedConversation);
  const apiChannels = useAppSelector(selectChannels) || [];
  const loading = useAppSelector(selectMessagesLoading) || false;
  const error = useAppSelector(selectMessagesError);
  const paginationInfo = useAppSelector(selectPaginationInfo);

  const socketConnected = useAppSelector((state) => {
    try {
      return selectSocketConnected(state);
    } catch {
      return false;
    }
  });

  const totalMessagesCount = useAppSelector((state) => {
    try {
      return selectTotalMessagesCount(state);
    } catch {
      return 0;
    }
  });
  const allTypingUsers = useAppSelector((state) => {
    try {
      return state.messages?.typingUsers || {};
    } catch {
      return {};
    }
  });

  const allOnlineUsers = useAppSelector((state) => {
    try {
      return state.messages?.onlineUsers || {};
    } catch {
      return {};
    }
  });

  // Helper functions for status
  const isContactTyping = (contactNumber) => {
    return allTypingUsers[contactNumber] || false;
  };

  const isContactOnline = (contactNumber) => {
    return allOnlineUsers[contactNumber] || false;
  };

  // Socket connection with enhanced error handling
  const { isConnected, connectionInfo } = useSocket(currentUser);

  const [selectedChannel, setSelectedChannel] = useState('all');
  const [showChooseContact, setShowChooseContact] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState('+91');
  const [contactSearchQuery, setContactSearchQuery] = useState('');
  const [localSearchQuery, setLocalSearchQuery] = useState('');
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [prefetchedPages, setPrefetchedPages] = useState(new Set());
  const [connectionAttempts, setConnectionAttempts] = useState(0);
  const [searchTimeout, setSearchTimeout] = useState(null);

  const dropdownRef = useRef(null);
  const containerRef = useRef(null);
  const scrollContainerRef = useRef(null);

  React.useEffect(() => {
    if (conversations.length > 0) {
      console.log('Conversation data structure:', conversations[0]);
      console.log('Available properties:', Object.keys(conversations[0]));
    }
  }, [conversations]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        await dispatch(fetchMessages()).unwrap();
      } catch (error) {
        console.error('Failed to fetch messages:', error);
      }
    };
    fetchData();
  }, [dispatch]);

  useEffect(() => {
    if (searchTimeout) {
      clearTimeout(searchTimeout);
    }

    const newTimeout = setTimeout(async () => {
      console.log('Searching for:', localSearchQuery);

      try {
        await dispatch(
          fetchMessages({
            page: 1,
            search: localSearchQuery.trim() || undefined, // Only pass search if not empty
            selectedChannel:
              selectedChannel !== 'all' ? selectedChannel : undefined,
            per_page: 15,
          })
        ).unwrap();
      } catch (error) {
        console.error('Search failed:', error);
      }
    }, 500);

    setSearchTimeout(newTimeout);

    return () => {
      if (newTimeout) {
        clearTimeout(newTimeout);
      }
    };
  }, [localSearchQuery, selectedChannel, dispatch]);

  useEffect(() => {
    setPrefetchedPages(new Set());
  }, [selectedChannel, localSearchQuery]);

  useEffect(() => {
    if (!isConnected && connectionAttempts < 5) {
      const retryTimer = setTimeout(() => {
        setConnectionAttempts((prev) => prev + 1);
      }, 2000 * Math.pow(2, connectionAttempts));

      return () => clearTimeout(retryTimer);
    } else if (isConnected) {
      setConnectionAttempts(0);
    }
  }, [isConnected, connectionAttempts]);

  useEffect(() => {
    const scrollContainer = scrollContainerRef.current;
    if (!scrollContainer) return;

    let isScrolling = false;
    let scrollTimeout;

    const handleScroll = async () => {
      if (isScrolling) return;

      const { scrollTop, scrollHeight, clientHeight } = scrollContainer;
      const scrollThreshold = 400;
      const prefetchThreshold = 800;

      const distanceFromBottom = scrollHeight - (scrollTop + clientHeight);
      const isNearBottom = distanceFromBottom <= scrollThreshold;
      const isPrefetchZone = distanceFromBottom <= prefetchThreshold;

      const canLoadMore = paginationInfo.currentPage < paginationInfo.lastPage;
      const nextPage = paginationInfo.currentPage + 1;

      if (isNearBottom && canLoadMore && !loading && !isLoadingMore) {
        isScrolling = true;
        setIsLoadingMore(true);

        try {
          await dispatch(
            fetchMessages({
              page: nextPage,
              selectedChannel:
                selectedChannel !== 'all' ? selectedChannel : undefined,
              search: localSearchQuery.trim() || undefined,
              per_page: 15,
            })
          ).unwrap();
        } catch (error) {
          console.error('Failed to load more conversations:', error);
        } finally {
          setIsLoadingMore(false);
          isScrolling = false;
        }
      }
    };

    const throttledScroll = () => {
      if (scrollTimeout) clearTimeout(scrollTimeout);
      scrollTimeout = setTimeout(() => {
        requestAnimationFrame(handleScroll);
      }, 16); // ~60fps
    };

    scrollContainer.addEventListener('scroll', throttledScroll, {
      passive: true,
    });

    return () => {
      scrollContainer.removeEventListener('scroll', throttledScroll);
      if (scrollTimeout) clearTimeout(scrollTimeout);
    };
  }, [
    dispatch,
    paginationInfo,
    loading,
    isLoadingMore,
    selectedChannel,
    localSearchQuery,
    prefetchedPages,
  ]);

  const handleChannelChange = async (channelId) => {
    setSelectedChannel(channelId);

    try {
      await dispatch(
        fetchMessages({
          page: 1,
          search: localSearchQuery.trim() || undefined,
          selectedChannel: channelId !== 'all' ? channelId : undefined,
          per_page: 15,
        })
      ).unwrap();
    } catch (error) {
      console.error('Failed to fetch messages for channel:', error);
    }
  };

  const formatTimestamp = (timestamp) => {
    const date =
      typeof timestamp === 'number'
        ? new Date(timestamp * 1000)
        : new Date(timestamp);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);
    const diffInMinutes = diffInHours * 60;

    if (diffInMinutes < 1) return 'now';
    if (diffInMinutes < 60) return `${Math.floor(diffInMinutes)}m`;
    if (diffInHours < 24)
      return date.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
      });
    if (diffInHours < 48) return 'Yesterday';
    if (diffInHours < 168)
      return date.toLocaleDateString('en-US', { weekday: 'short' });
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const getMessageStatusIcon = (message) => {
    if (!message) return null;
    switch (message.status) {
      case 'sent':
        return <Check className="w-3 h-3 text-muted-foreground" />;
      case 'delivered':
        return <CheckCheck className="w-3 h-3 text-muted-foreground" />;
      case 'read':
        return <CheckCheck className="w-3 h-3 text-blue-500" />;
      default:
        return null;
    }
  };

  const truncateMessage = (text, maxLength = 35) => {
    if (!text) return 'No messages yet';
    return text.length > maxLength
      ? text.substring(0, maxLength) + '...'
      : text;
  };

  const getMessagePreview = (message) => {
    if (!message) return 'No messages yet';
    if (message.is_media === '1') {
      switch (message.method) {
        case 'image':
          return '📷 Photo';
        case 'video':
          return '🎥 Video';
        case 'document':
          return '📄 Document';
        case 'audio':
          return '🎵 Audio';
        default:
          return '📎 Media';
      }
    }
    return truncateMessage(message.text);
  };

  // const { sortedConversations, groupedConversations } = React.useMemo(() => {
  //   if (!conversations || conversations.length === 0)
  //     return { sortedConversations: [], groupedConversations: {} };

  //   const sorted = [...conversations].sort((a, b) => {
  //     if (a.unreadCount > 0 && b.unreadCount === 0) return -1;
  //     if (a.unreadCount === 0 && b.unreadCount > 0) return 1;
  //     const timeA = new Date(a.lastMessageTime).getTime();
  //     const timeB = new Date(b.lastMessageTime).getTime();
  //     return timeB - timeA;
  //   });

  //   const grouped = groupConversationsByDate(sorted);

  //   return { sortedConversations: sorted, groupedConversations: grouped };
  // }, [conversations]);

  const groupedConversations = React.useMemo(() => {
    if (!conversations || conversations.length === 0) return {};

    return groupConversationsByDate(conversations);
  }, [conversations]);

  const handleConversationSelect = async (conversation) => {
    console.log('Selecting conversation:', conversation);

    try {
      dispatch(markConversationAsRead(conversation.contact_number));
    } catch (error) {
      console.warn('markConversationAsRead action not available:', error);
    }

    dispatch(selectConversation(conversation.contact_id || conversation.id));

    if (apiChannels.length > 0) {
      const selectedChannelNumber = apiChannels[0].whatsapp_no;
      try {
        await dispatch(
          fetchConversation({
            contactNumber: conversation.contact_number,
            selectedChannel: selectedChannelNumber,
            page: 1,
          })
        ).unwrap();
      } catch (error) {
        console.error('Failed to fetch conversation:', error);
      }
    }

    onSelectConversation?.(conversation);
  };

  const handleContactSelect = (contactId, contactName) => {
    setShowChooseContact(false);
    setPhoneNumber('+91');
    setContactSearchQuery('');
    dispatch(selectConversation(contactId));
  };

  const handleBackToChats = () => {
    setShowChooseContact(false);
    setPhoneNumber('+91');
    setContactSearchQuery('');
  };

  const handleNextClick = () => {
    if (phoneNumber.length > 3) {
      console.log('Starting conversation with:', phoneNumber);
      setShowChooseContact(false);
      setPhoneNumber('+91');
      setContactSearchQuery('');
      dispatch(selectConversation(phoneNumber));
    }
  };

  useEffect(() => {
    return () => {
      dispatch(clearError());
      if (searchTimeout) {
        clearTimeout(searchTimeout);
      }
    };
  }, [dispatch, searchTimeout]);

  if (showChooseContact) {
    return (
      <div className="h-full border-r border-border flex flex-col overflow-hidden">
        <div className="flex-shrink-0 p-4 border-b border-border">
          <div className="flex items-center space-x-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleBackToChats}
              className="p-2 hover:bg-accent text-muted-foreground hover:text-foreground"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h2 className="font-semibold text-lg text-foreground">
                New chat
              </h2>
              <p className="text-sm text-muted-foreground">
                {conversations.length} contacts
              </p>
            </div>
          </div>
        </div>

        <div className="flex-shrink-0 p-4 border-b border-border">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search contacts..."
              value={contactSearchQuery}
              onChange={(e) => setContactSearchQuery(e.target.value)}
              className="pl-10 border-input"
            />
          </div>
        </div>

        <div className="flex-shrink-0 p-4 border-b border-border">
          <div className="space-y-3">
            <div className="flex items-center space-x-3 p-3 hover:bg-accent cursor-pointer rounded-lg">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <Users className="w-5 h-5 text-primary-foreground" />
              </div>
              <div className="flex-1">
                <p className="font-medium text-foreground">New group</p>
              </div>
            </div>
            <div className="flex items-center space-x-3 p-3 hover:bg-accent cursor-pointer rounded-lg">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <Plus className="w-5 h-5 text-primary-foreground" />
              </div>
              <div className="flex-1">
                <p className="font-medium text-foreground">New contact</p>
                <PhoneInput
                  international
                  defaultCountry="IN"
                  value={phoneNumber}
                  onChange={(value) => setPhoneNumber(value || '+91')}
                  className="text-sm text-muted-foreground mt-1"
                />
              </div>
              {phoneNumber.length > 3 && (
                <Button size="sm" onClick={handleNextClick}>
                  <MessageSquare className="w-4 h-4" />
                </Button>
              )}
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto scrollbar-none -webkit-overflow-scrolling-touch scroll-smooth transform-gpu will-change-scroll backface-hidden">
          <div className="p-4">
            <h3 className="text-sm font-medium text-muted-foreground mb-3 uppercase tracking-wide">
              Contacts on WhatsApp
            </h3>
            <div className="space-y-1">
              {conversations
                .filter(
                  (conv) =>
                    !contactSearchQuery ||
                    conv.contact_name
                      .toLowerCase()
                      .includes(contactSearchQuery.toLowerCase()) ||
                    conv.contact_number.includes(contactSearchQuery)
                )
                .map((conversation) => (
                  <div
                    key={conversation.id}
                    onClick={() =>
                      handleContactSelect(
                        conversation.contact_id || conversation.id,
                        conversation.contact_name
                      )
                    }
                    className="flex items-center space-x-3 p-3 rounded-lg hover:bg-accent cursor-pointer transition-all duration-200 ease-[cubic-bezier(0.4,0,0.2,1)]"
                  >
                    <ContactAvatar contact={conversation} size={40} />
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground truncate">
                        {conversation.contact_name}
                      </p>
                      <p className="text-sm text-muted-foreground truncate">
                        {conversation.contact_number}
                      </p>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="h-full border-r border-border flex flex-col overflow-hidden"
    >
      <div className="flex-shrink-0 p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <MessageSquareMore className="h-6 w-6 text-foreground" />
            <h1 className="text-xl font-semibold text-foreground">All Chats</h1>

            <div className="flex items-center space-x-2">
              {totalMessagesCount > 0 && (
                <Badge className="bg-[#25d366] text-white rounded-full  flex justify-center items-center text-xs h-5 w-5 px-2 ">
                  {totalMessagesCount > 99 ? '99+' : totalMessagesCount}
                </Badge>
              )}
            </div>
          </div>

          <div className="flex items-center space-x-1">
            <Button
              onClick={() => setShowChooseContact(true)}
              size="sm"
              className="h-9 w-9 p-0"
              disabled={!isConnected}
            >
              <Plus className="w-5 h-5" />
            </Button>
          </div>
        </div>

        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <Input
            placeholder="Search or start new chat"
            value={localSearchQuery}
            onChange={(e) => setLocalSearchQuery(e.target.value)}
            className="pl-10 bg-muted/30 border-0 focus-visible:ring-1 focus-visible:ring-primary"
          />
          {loading && localSearchQuery && (
            <Loader2 className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 animate-spin text-muted-foreground" />
          )}
        </div>

        <div className="flex space-x-0 mb-2">
          {channels.map((channel) => (
            <button
              key={channel.id}
              onClick={() => handleChannelChange(channel.id)}
              className={`px-4 py-2 text-sm cursor-pointer font-bold rounded-full transition-colors ease-[cubic-bezier(0.4,0,0.2,1)] duration-200 ${
                selectedChannel === channel.id
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent'
              }`}
              disabled={loading}
            >
              {channel.name}
            </button>
          ))}
        </div>
      </div>

      {!isConnected && (
        <div className="bg-red-500/10 backdrop-blur border border-red-500/20 rounded-lg p-2 mx-4 mb-2">
          <div className="flex items-center">
            <div className="w-4 h-4 bg-red-500 rounded-full mr-2 animate-pulse" />
            <div className="flex-1">
              <p className="text-sm font-medium text-red-700">
                Connection lost
              </p>
              <p className="text-xs text-red-600">
                Attempting to reconnect... (Attempt {connectionAttempts}/5)
              </p>
            </div>
          </div>
        </div>
      )}

      {error && (
        <div className="flex-shrink-0 p-4 bg-destructive/10 border-l-4 border-destructive text-destructive">
          <div className="flex">
            <div className="flex-1">
              <p className="text-sm font-medium">Error loading conversations</p>
              <p className="text-sm">{error}</p>
            </div>
            <button
              onClick={() => dispatch(fetchMessages())}
              className="text-sm underline hover:no-underline font-medium"
            >
              Try again
            </button>
          </div>
        </div>
      )}

      {loading && conversations.length === 0 && (
        <div className="flex-shrink-0 flex items-center justify-center p-8">
          <div className="flex items-center space-x-3">
            <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
            <span className="text-muted-foreground">
              {localSearchQuery ? 'Searching...' : 'Loading chats...'}
            </span>
          </div>
        </div>
      )}

      {!loading && conversations.length === 0 && localSearchQuery && (
        <div className="flex flex-col items-center justify-center p-8 text-center h-full">
          <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mb-4">
            <Search className="w-10 h-10 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-medium text-foreground mb-2">
            No results found
          </h3>
          <p className="text-sm text-muted-foreground mb-6 max-w-sm">
            No conversations found for "{localSearchQuery}". Try a different
            search term.
          </p>
          <Button
            onClick={() => setLocalSearchQuery('')}
            variant="outline"
            size="sm"
          >
            Clear search
          </Button>
        </div>
      )}

      <div
        ref={scrollContainerRef}
        className="flex-1 min-h-0 overflow-y-auto scrollbar-none -webkit-overflow-scrolling-touch scroll-smooth transform-gpu will-change-scroll backface-hidden"
      >
        {!loading && conversations.length === 0 && !localSearchQuery && (
          <div className="flex flex-col items-center justify-center p-8 text-center h-full">
            <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mb-4">
              <MessageSquare className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-medium text-foreground mb-2">
              No chats yet
            </h3>
            <p className="text-sm text-muted-foreground mb-6 max-w-sm">
              Start a conversation with your contacts to see them here.
            </p>
            <Button
              onClick={() => setShowChooseContact(true)}
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
              disabled={!isConnected}
            >
              <Plus className="w-4 h-4 mr-2" />
              Start new chat
            </Button>
          </div>
        )}

        {Object.entries(groupedConversations).map(
          ([dateGroup, dateConversations]) => (
            <div key={dateGroup} className="mb-4">
              <DateHeader
                dateGroup={dateGroup}
                conversationCount={dateConversations.length}
              />

              {dateConversations.map((conversation, index) => {
                console.log(conversation);
                const isSelected = selectedConversation?.id === conversation.id;
                const isTyping = isContactTyping(conversation.contact_number);
                const isOnline = isContactOnline(conversation.contact_number);

                return (
                  <div key={conversation.id}>
                    <div
                      onClick={() => handleConversationSelect(conversation)}
                      className={`flex items-center px-6 py-5 cursor-pointer relative group transition-all duration-150 ease-[cubic-bezier(0.4,0,0.2,1)] border-l-3 border-transparent transform-gpu will-change-transform backface-hidden hover:bg-accent hover:border-l-primary/30 hover:translate-x-0.5 active:translate-x-0 active:scale-[0.98] ${
                        isSelected ? 'bg-accent border-l-primary' : ''
                      } ${
                        conversation.totalMessagesCount > 0
                          ? 'border-l-[#25d366]'
                          : ''
                      }`}
                    >
                      <div className="relative mr-3 flex-shrink-0">
                        <ContactAvatar contact={conversation} size={48} />

                        {isTyping && (
                          <div className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-[#128c7e] border-2 border-white rounded-full flex items-center justify-center animate-[typingPulse_1s_ease-in-out_infinite] z-10">
                            <div className="flex gap-0.5">
                              <div className="w-0.5 h-0.5 bg-white rounded-full animate-[typingDots_1.4s_ease-in-out_infinite_0s]" />
                              <div className="w-0.5 h-0.5 bg-white rounded-full animate-[typingDots_1.4s_ease-in-out_infinite_0.2s]" />
                              <div className="w-0.5 h-0.5 bg-white rounded-full animate-[typingDots_1.4s_ease-in-out_infinite_0.4s]" />
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center space-x-2 min-w-0 flex-1">
                            <h4 className="font-bold text-[14px] text-foreground truncate">
                              {conversation.contact_name}
                            </h4>

                            {isOnline && (
                              <div
                                className="w-2 h-2 bg-[#25d366] rounded-full flex-shrink-0"
                                title="Online"
                              />
                            )}
                          </div>

                          <div className="flex items-center space-x-2 flex-shrink-0 ml-2">
                            <span className="text-xs text-muted-foreground">
                              {formatTimestamp(conversation.lastMessageTime)}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-1 flex-1 min-w-0 mr-3">
                            {conversation.lastMessage?.method === 'bot' && (
                              <Bot className="w-4 h-4 text-blue-500 flex-shrink-0" />
                            )}
                            {getMessageStatusIcon(conversation.lastMessage)}

                            <div className="flex-1 min-w-0">
                              {isTyping ? (
                                <p className="text-sm text-blue-600 font-medium italic">
                                  typing...
                                </p>
                              ) : (
                                <p className="text-[13px] font-medium text-muted-foreground truncate overflow-hidden whitespace-nowrap">
                                  {getMessagePreview(conversation.lastMessage)}
                                </p>
                              )}
                            </div>
                          </div>

                          <div className="flex items-center space-x-1 flex-shrink-0">
                            {conversation.totalMessageCount > 0 && (
                              <Badge
                                className={`bg-[#25d366] text-white text-xs h-5 px-2 min-w-[20px] text-center flex justify=center items-center w-5 rounded-full ${
                                  conversation.totalMessageCount > 5
                                    ? 'animate-pulse'
                                    : ''
                                }`}
                              >
                                {conversation.totalMessageCount > 99
                                  ? '99+'
                                  : conversation.totalMessageCount}
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Add separator between conversations within the same date group, but not after the last one */}
                    {index < dateConversations.length - 1 && (
                      <Separator className="mx-4" />
                    )}
                  </div>
                );
              })}
            </div>
          )
        )}

        {/* Enhanced Loading conversation skeletons */}
        {isLoadingMore && (
          <>
            {[...Array(3)].map((_, index) => (
              <div
                key={`skeleton-${index}`}
                className="flex items-center px-4 py-3 animate-pulse"
              >
                <div className="relative mr-3 flex-shrink-0">
                  <div className="w-12 h-12 bg-gradient-to-r from-slate-300 via-slate-300/50 to-slate-300 bg-[length:200%_100%] animate-[shimmer_2s_infinite] bg-[position:200%_0] rounded-full" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <div className="h-4 bg-gradient-to-r from-slate-300 via-slate-300/50 to-slate-300 bg-[length:200%_100%] animate-[shimmer_2s_infinite] bg-[position:200%_0] rounded w-24" />
                    <div className="h-3 bg-gradient-to-r from-slate-300 via-slate-300/50 to-slate-300 bg-[length:200%_100%] animate-[shimmer_2s_infinite] bg-[position:200%_0] rounded w-12" />
                  </div>
                  <div className="h-3 bg-gradient-to-r from-slate-300 via-slate-300/50 to-slate-300 bg-[length:200%_100%] animate-[shimmer_2s_infinite] bg-[position:200%_0] rounded w-32" />
                </div>
              </div>
            ))}
          </>
        )}

        {/* Loading More Indicator */}
        {isLoadingMore && (
          <div className="flex items-center justify-center p-4 border-t border-border/50">
            <div className="flex items-center space-x-3">
              <Loader2 className="w-4 h-4 animate-spin text-primary" />
              <span className="text-sm text-muted-foreground font-medium">
                Loading more conversations...
              </span>
            </div>
          </div>
        )}

        {/* End of List */}
        {!loading &&
          !isLoadingMore &&
          conversations.length > 0 &&
          paginationInfo.currentPage >= paginationInfo.lastPage && (
            <div className="flex items-center justify-center p-6">
              <span className="text-sm text-muted-foreground">
                You're all caught up ✨
              </span>
            </div>
          )}
      </div>

      {/* Custom Tailwind Keyframes - Add to your global CSS */}
      <style jsx global>{`
        @keyframes shimmer {
          0% {
            background-position: 200% 0;
          }
          100% {
            background-position: -200% 0;
          }
        }

        @keyframes unreadPulse {
          0%,
          100% {
            transform: scale(1);
          }
          50% {
            transform: scale(1.05);
          }
        }

        @keyframes onlinePulse {
          0%,
          100% {
            transform: scale(1);
          }
          50% {
            transform: scale(1.1);
          }
        }

        @keyframes typingPulse {
          0%,
          100% {
            transform: scale(1);
          }
          50% {
            transform: scale(1.1);
          }
        }

        @keyframes typingDots {
          0%,
          60%,
          100% {
            transform: scale(1);
            opacity: 0.5;
          }
          30% {
            transform: scale(1.2);
            opacity: 1;
          }
        }

        @keyframes connectionPulse {
          0%,
          100% {
            opacity: 1;
          }
          50% {
            opacity: 0.7;
          }
        }

        @keyframes disconnectedBlink {
          0%,
          50% {
            opacity: 1;
          }
          51%,
          100% {
            opacity: 0.3;
          }
        }

        .scrollbar-none {
          scrollbar-width: none;
          -ms-overflow-style: none;
        }

        .scrollbar-none::-webkit-scrollbar {
          display: none;
        }
      `}</style>
    </div>
  );
}
