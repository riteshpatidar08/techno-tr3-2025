import React, { useState, useEffect, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  Plus,
  Eye,
  Trash2,
  UserCheck,
  X,
  Users,
  Phone,
  Edit,
  Loader2,
  CheckCircle,
  XCircle,
  AlertTriangle,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import agentLoginIcon from '@/assets/agent_login.svg';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  fetchWhatsAppNumbers,
  clearError,
  addWhatsAppNumber,
} from '@/redux/whatsappSlice';
import type { RootState, AppDispatch } from '@/redux/store/index';

// Facebook SDK Declaration
declare global {
  interface Window {
    FB: any;
    fbAsyncInit: () => void;
  }
}

interface NewAgent {
  email: string;
  password: string;
  name: string;
  mobile: string;
  comments: string;
}

interface Agent {
  id: number;
  name: string;
  email: string;
  mobile: string;
  comments: string;
  isActive: boolean;
  chats: number;
}

interface FacebookSignupData {
  phone_number_id: string;
  waba_id: string;
  business_id: string;
}

interface WhatsAppOnboardingPayload {
  code: string;
  phone_number_id: string;
  waba_id: string;
  business_id: string;
}

// Facebook WhatsApp Onboarding Component
const FacebookWhatsAppOnboarding = ({
  onClose,
  onSuccess,
}: {
  onClose: () => void;
  onSuccess: (data: any) => void;
}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [authCode, setAuthCode] = useState<string>('');
  const [signupData, setSignupData] = useState<FacebookSignupData | null>(null);
  const [submittedOnboarding, setSubmittedOnboarding] = useState(false);
  const [sdkResponse, setSdkResponse] = useState<string>('');
  const [sessionInfoResponse, setSessionInfoResponse] = useState<string>('');

  // Facebook App Configuration
  const FB_APP_ID = '1016495153990147'; // Replace with your App ID
  const FB_CONFIG_ID = '1166327075264525'; // Replace with your Config ID

  // Load Facebook SDK
  const loadFacebookSDK = useCallback(() => {
    if (window.fbAsyncInit) return;

    window.fbAsyncInit = () => {
      window.FB.init({
        appId: FB_APP_ID,
        autoLogAppEvents: true,
        xfbml: true,
        version: 'v23.0',
      });
    };

    const script = document.createElement('script');
    script.src = 'https://connect.facebook.net/en_US/sdk.js';
    script.async = true;
    script.defer = true;
    script.crossOrigin = 'anonymous';
    document.body.appendChild(script);
  }, []);

  
  const handleFBMessages = useCallback(
    (event: MessageEvent) => {
      const isValidOrigin =
        event.origin === 'https://www.facebook.com' ||
        event.origin === 'https://web.facebook.com';
      if (!isValidOrigin) return;

      try {
        const data = JSON.parse(event.data);
        console.log('FB Embedded Response:', data);
        setSessionInfoResponse(JSON.stringify(data, null, 2));

        if (data.type === 'WA_EMBEDDED_SIGNUP' && data.event === 'FINISH') {
          const newSignupData: FacebookSignupData = {
            phone_number_id: data.data.phone_number_id,
            waba_id: data.data.waba_id,
            business_id: data.data.business_id,
          };
          setSignupData(newSignupData);
          trySubmitOnboarding(authCode, newSignupData);
        }
      } catch {
        console.warn('Non-JSON response from Facebook:', event.data);
      }
    },
    [authCode]
  );


  const fbLoginCallback = (response: any) => {
    if (response.authResponse?.code) {
      console.log('FB Login Response:', response);
      const code = response.authResponse.code;
      setAuthCode(code);
      setSdkResponse(JSON.stringify(response, null, 2));

      if (signupData) {
        trySubmitOnboarding(code, signupData);
      }
    } else {
      setError('Facebook login failed. Please try again.');
    }
  };

  const trySubmitOnboarding = async (
    code: string,
    data: FacebookSignupData
  ) => {
    if (submittedOnboarding || !code || !data) return;

    setSubmittedOnboarding(true);
    setLoading(true);
    setError(null);

    const payload: WhatsAppOnboardingPayload = {
      code,
      phone_number_id: data.phone_number_id,
      waba_id: data.waba_id,
      business_id: data.business_id,
    };

    try {
     
      const response = await fetch(
        'https://aigreentick.com/api/v1/fb-embedded-signup',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(payload),
        }
      );

      if (!response.ok) {
        throw new Error('Failed to onboard WhatsApp account');
      }

      const result = await response.json();
      setSuccess('WhatsApp account connected successfully!');
      onSuccess(result);

      // Reset state
      setTimeout(() => {
        onClose();
      }, 2000);
    } catch (err: any) {
      setError(err.message || 'Failed to onboard WhatsApp account');
      setSubmittedOnboarding(false); // Allow retry
    } finally {
      setLoading(false);
    }
  };

  // Launch WhatsApp Signup Flow
  const launchWhatsAppSignup = () => {
    if (!window.FB) {
      setError('Facebook SDK not loaded. Please refresh and try again.');
      return;
    }

    setSubmittedOnboarding(false);
    setError(null);
    setSuccess(null);

    window.FB.login(fbLoginCallback, {
      config_id: FB_CONFIG_ID,
      response_type: 'code',
      override_default_response_type: true,
      extras: {
        version: 'v3',
      },
    });
  };

  useEffect(() => {
    loadFacebookSDK();
    window.addEventListener('message', handleFBMessages);

    return () => {
      window.removeEventListener('message', handleFBMessages);
    };
  }, [loadFacebookSDK, handleFBMessages]);

  return (
    <div className="bg-card rounded-lg border border-border p-6 mb-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-card-foreground">
            Connect WhatsApp Business Account
          </h2>
          <p className="text-muted-foreground mt-1">
            Connect your official WhatsApp Business account through Facebook
          </p>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={onClose}
          className="text-muted-foreground hover:text-foreground"
        >
          <X className="w-4 h-4" />
        </Button>
      </div>

      {/* Status Messages */}
      {error && (
        <Alert className="mb-4 border-destructive/20 bg-destructive/10">
          <XCircle className="h-4 w-4 text-destructive" />
          <AlertDescription className="text-destructive">
            {error}
          </AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="mb-4 border-green-200 bg-green-50">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800">
            {success}
          </AlertDescription>
        </Alert>
      )}

      {/* Connection Flow */}
      <div className="space-y-4">
        <div className="text-center">
          <div className="w-16 h-16 bg-[#25D366] rounded-full flex items-center justify-center mx-auto mb-4">
            <Phone className="w-8 h-8 text-white" />
          </div>

          {!authCode && !signupData && (
            <div>
              <h3 className="text-lg font-medium mb-2">
                Step 1: Connect with Facebook
              </h3>
              <p className="text-muted-foreground mb-4">
                Click the button below to start the WhatsApp Business onboarding
                process
              </p>
              <Button
                onClick={launchWhatsAppSignup}
                disabled={loading}
                className="bg-[#1877F2] hover:bg-[#166FE5] text-white"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Connecting...
                  </>
                ) : (
                  <>
                    <Phone className="w-4 h-4 mr-2" />
                    Connect WhatsApp Business
                  </>
                )}
              </Button>
            </div>
          )}

          {authCode && !signupData && (
            <div>
              <h3 className="text-lg font-medium mb-2">
                Step 2: Select WhatsApp Account
              </h3>
              <p className="text-muted-foreground mb-4">
                Facebook login successful! Please complete the WhatsApp account
                selection.
              </p>
              <div className="flex items-center justify-center">
                <Loader2 className="w-6 h-6 animate-spin text-primary mr-2" />
                <span>Waiting for account selection...</span>
              </div>
            </div>
          )}

          {authCode && signupData && loading && (
            <div>
              <h3 className="text-lg font-medium mb-2">
                Step 3: Finalizing Connection
              </h3>
              <p className="text-muted-foreground mb-4">
                Setting up your WhatsApp Business account...
              </p>
              <div className="flex items-center justify-center">
                <Loader2 className="w-6 h-6 animate-spin text-primary mr-2" />
                <span>Please wait...</span>
              </div>
            </div>
          )}
        </div>

        {/* Connection Steps */}
        <div className="border-t pt-4">
          <h4 className="font-medium mb-3">Connection Steps:</h4>
          <div className="space-y-2 text-sm">
            <div
              className={`flex items-center ${
                authCode ? 'text-green-600' : 'text-muted-foreground'
              }`}
            >
              {authCode ? (
                <CheckCircle className="w-4 h-4 mr-2" />
              ) : (
                <div className="w-4 h-4 rounded-full border-2 mr-2" />
              )}
              Facebook Authentication
            </div>
            <div
              className={`flex items-center ${
                signupData ? 'text-green-600' : 'text-muted-foreground'
              }`}
            >
              {signupData ? (
                <CheckCircle className="w-4 h-4 mr-2" />
              ) : (
                <div className="w-4 h-4 rounded-full border-2 mr-2" />
              )}
              WhatsApp Account Selection
            </div>
            <div
              className={`flex items-center ${
                success ? 'text-green-600' : 'text-muted-foreground'
              }`}
            >
              {success ? (
                <CheckCircle className="w-4 h-4 mr-2" />
              ) : (
                <div className="w-4 h-4 rounded-full border-2 mr-2" />
              )}
              Account Setup Complete
            </div>
          </div>
        </div>

        {/* Debug Information (Development Only) */}
        {process.env.NODE_ENV === 'development' &&
          (sdkResponse || sessionInfoResponse) && (
            <div className="border-t pt-4">
              <details className="text-xs">
                <summary className="cursor-pointer font-medium mb-2">
                  Debug Information
                </summary>
                {sdkResponse && (
                  <div className="mb-2">
                    <strong>SDK Response:</strong>
                    <pre className="bg-muted p-2 rounded text-xs overflow-x-auto">
                      {sdkResponse}
                    </pre>
                  </div>
                )}
                {sessionInfoResponse && (
                  <div>
                    <strong>Session Info:</strong>
                    <pre className="bg-muted p-2 rounded text-xs overflow-x-auto">
                      {sessionInfoResponse}
                    </pre>
                  </div>
                )}
              </details>
            </div>
          )}
      </div>
    </div>
  );
};

// Rest of your existing components (AgentSidebar, AddAgentForm, etc.) remain the same...
const AgentSidebar = ({
  activeTab,
  setActiveTab,
}: {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}) => {
  const sidebarItems = [
    { key: 'agents', icon: Users, label: 'Agents Login' },
    { key: 'whatsapp', icon: Phone, label: 'Manage Official Numbers' },
  ];

  return (
    <div className="w-64 bg-card border-r border-border min-h-full">
      <div className="p-4 space-y-1">
        <div className="flex flex-col gap-2 mb-5 mt-5 items-center space-y-3">
          <div className="w-full overflow-hidden flex items-center justify-center">
            <img
              src={agentLoginIcon}
              alt="Campaign Logo"
              className="w-full h-full object-cover"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
              }}
            />
          </div>
          <div className="text-center">
            <h2 className="text-lg font-semibold text-gray-900">
              Agent Manager
            </h2>
            <p className="text-sm text-gray-600">
              Manage your Agents and WhatsApp Account
            </p>
          </div>
        </div>
        {sidebarItems.map((item) => (
          <Button
            key={item.key}
            variant={activeTab === item.key ? 'default' : 'ghost'}
            onClick={() => setActiveTab(item.key)}
            className={`w-full justify-start ${
              activeTab === item.key
                ? 'bg-primary/10 text-primary border-r-2 border-primary'
                : 'text-muted-foreground hover:text-foreground hover:bg-accent'
            }`}
          >
            <item.icon className="w-4 h-4 mr-3" />
            {item.label}
          </Button>
        ))}
      </div>
    </div>
  );
};

// Enhanced WhatsAppNumbersTab with Facebook Integration
const WhatsAppNumbersTab = () => {
  const dispatch = useDispatch<AppDispatch>();
  const whatsappState = useSelector((state: RootState) => state.whatsapp);
  const [currentPage, setCurrentPage] = useState(1);
  const [showOnboarding, setShowOnboarding] = useState(false);

  const {
    numbers = [],
    loading = false,
    error = null,
    pagination = null,
  } = whatsappState || {};

  useEffect(() => {
    dispatch(fetchWhatsAppNumbers(currentPage));
  }, [dispatch, currentPage]);

  useEffect(() => {
    if (error) {
      console.error('WhatsApp numbers error:', error);
      setTimeout(() => {
        dispatch(clearError());
      }, 5000);
    }
  }, [error, dispatch]);

  const handleOnboardingSuccess = (data: any) => {
    console.log('WhatsApp onboarding successful:', data);
    // Refresh the numbers list
    dispatch(fetchWhatsAppNumbers(currentPage));
    setShowOnboarding(false);
  };

  const handleEdit = (id: number) => {
    console.log('Edit WhatsApp number:', id);
  };

  const handleDelete = (id: number) => {
    console.log('Delete WhatsApp number:', id);
  };

  const getStatusBadge = (status: string) => {
    const isActive = status === '1';
    return (
      <Badge
        variant={isActive ? 'default' : 'secondary'}
        className={
          isActive
            ? 'bg-primary/10 text-primary hover:bg-primary/10'
            : 'bg-muted text-muted-foreground hover:bg-muted'
        }
      >
        {isActive ? 'Active' : 'Inactive'}
      </Badge>
    );
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  return (
    <div className="space-y-4">
      {/* Facebook WhatsApp Onboarding Form */}
      {showOnboarding && (
        <FacebookWhatsAppOnboarding
          onClose={() => setShowOnboarding(false)}
          onSuccess={handleOnboardingSuccess}
        />
      )}

      {error && (
        <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-4">
          <p className="text-destructive">{error}</p>
        </div>
      )}

      <div className="bg-card rounded-lg border border-border overflow-hidden">
        <Table className="border-0">
          <TableHeader className="border-0">
            <TableRow className="bg-muted/50 border-0">
              <TableHead className="text-muted-foreground font-medium">
                WhatsApp Number
              </TableHead>
              <TableHead className="text-muted-foreground font-medium">
                Token
              </TableHead>
              <TableHead className="text-muted-foreground font-medium">
                Status
              </TableHead>
              <TableHead className="text-muted-foreground font-medium">
                Actions
              </TableHead>
            </TableRow>
          </TableHeader>

          {loading ? (
            <TableBody>
              {Array.from({ length: 3 }).map((_, index) => (
                <TableRow key={index}>
                  <TableCell>
                    <Skeleton className="h-4 w-32" />
                  </TableCell>
                  <TableCell>
                    <Skeleton className="h-4 w-24" />
                  </TableCell>
                  <TableCell>
                    <Skeleton className="h-6 w-20 rounded-full" />
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Skeleton className="h-8 w-8 rounded-full" />
                      <Skeleton className="h-8 w-8 rounded-full" />
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          ) : (
            <TableBody>
              {numbers.data?.map((number) => (
                <TableRow key={number.id} className="hover:bg-muted/20">
                  <TableCell className="text-card-foreground font-medium">
                    +{number.whatsapp_no}
                  </TableCell>
                  <TableCell className="text-muted-foreground font-mono text-sm">
                    {number.token.substring(0, 12)}...
                  </TableCell>
                  <TableCell>{getStatusBadge(number.status)}</TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEdit(number.id)}
                        className="p-1 h-8 w-8 rounded-full bg-primary/10 hover:bg-primary/20 text-primary"
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(number.id)}
                        className="p-1 h-8 w-8 rounded-full bg-destructive/10 hover:bg-destructive/20 text-destructive"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          )}
        </Table>

        {!loading && (!numbers.data || numbers.data.length === 0) && (
          <div className="text-center py-12">
            <div className="text-muted-foreground mb-4">
              <Phone className="w-12 h-12 mx-auto" />
            </div>
            <h3 className="text-lg font-medium text-card-foreground mb-2">
              No WhatsApp numbers found
            </h3>
            <p className="text-muted-foreground mb-4">
              Get started by connecting your first official WhatsApp Business
              account.
            </p>
            <Button
              onClick={() => setShowOnboarding(true)}
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              <Plus className="w-4 h-4 mr-2" />
              Connect WhatsApp Business
            </Button>
          </div>
        )}
      </div>

      {pagination && pagination.last_page > 1 && (
        <div className="flex items-center justify-between">
          <div className="text-sm text-muted-foreground">
            Showing {pagination.from} to {pagination.to} of {pagination.total}{' '}
            results
          </div>
          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 1}
              className="border-border text-foreground"
            >
              Previous
            </Button>
            <span className="px-3 py-1 text-sm text-muted-foreground">
              Page {pagination.current_page} of {pagination.last_page}
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage === pagination.last_page}
              className="border-border text-foreground"
            >
              Next
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

// Main UserManagement component with enhanced WhatsApp button
const UserManagement = () => {
  const [activeTab, setActiveTab] = useState('agents');
  const [showForm, setShowForm] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);

  const getTabTitle = () => {
    switch (activeTab) {
      case 'agents':
        return {
          title: 'Agents',
          description:
            'Add or remove agent account. An agent is someone to whom you can assign chats.',
          showAddButton: true,
          buttonText: 'Add Agent',
        };
      case 'whatsapp':
        return {
          title: 'Manage Official Numbers',
          description:
            'Manage your official WhatsApp numbers for business messaging.',
          showAddButton: true,
          buttonText: 'Connect WhatsApp Business',
        };
      default:
        return {
          title: 'Agents',
          description:
            'Add or remove agent account. An agent is someone to whom you can assign chats.',
          showAddButton: true,
          buttonText: 'Add Agent',
        };
    }
  };

  const tabInfo = getTabTitle();

  return (
    <div className="flex mt-12 min-h-screen">
      <AgentSidebar activeTab={activeTab} setActiveTab={setActiveTab} />

      <div className="flex-1 flex flex-col">
        <div className="bg-card border-b border-border px-6 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-card-foreground mb-2">
                {tabInfo.title}
              </h1>
              <p className="text-muted-foreground">{tabInfo.description}</p>
            </div>
            <div className="flex items-center gap-3">
              {tabInfo.showAddButton && activeTab === 'agents' && (
                <Button
                  onClick={() => setShowForm(!showForm)}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  {tabInfo.buttonText}
                </Button>
              )}
              {tabInfo.showAddButton && activeTab === 'whatsapp' && (
                <Button
                  onClick={() => setShowOnboarding(true)}
                  className="bg-[#25D366] hover:bg-[#20b358] text-white"
                >
                  <Phone className="w-4 h-4 mr-2" />
                  {tabInfo.buttonText}
                </Button>
              )}
            </div>
          </div>
        </div>

        <div className="flex-1 p-6">
          {activeTab === 'agents' && (
            <div>
              {/* Add Agent Form and Table components would go here */}
              <div className="text-center py-12">
                <p className="text-muted-foreground">
                  Agents management content would go here
                </p>
              </div>
            </div>
          )}
          {activeTab === 'whatsapp' && <WhatsAppNumbersTab />}
        </div>
      </div>
    </div>
  );
};

export default UserManagement;
