import {
  BusinessProfile,
  GeneralSettings,
  ContactAttribute,
  Tag,
} from './types';
import {
  Building2,
  Settings,
  Tag as TagIcon,
  Download,
  MessageSquare,
} from 'lucide-react';

export const staticBusinessProfile: BusinessProfile = {
  id: '1',
  name: 'aiGreenTick',
  profilePicture: '',
  phoneNumber: '+14798024855',
  businessAddress: '123 Business St, Suite 100, Business City, BC 12345',
  emailForBusinessContact: 'support@wati.io',
  businessWebsite1: 'https://wati.io',
  businessWebsite2: 'https://docs.wati.io',
  about: 'WATI.io - WhatsApp Official API Partner',
  businessDescription: 'WATI Trial Sandbox for WhatsApp Business API',
  businessIndustry: 'Professional Services',
};

export const staticGeneralSettings: GeneralSettings = {
  customerTimeZone:
    '(GMT+08:00) Beijing, Chongqing, Hong Kong, Urumqi, Kuala Lumpur, Singapore, Taipei, Perth, Irkutsk, Ulaanbaatar',
  language: 'English',
  supportButtonEnabled: false,
  contentDirection: 'Initial',
  sendReportSchedule: '',
};

export const staticAttributes: ContactAttribute[] = [
  {
    id: '1',
    name: 'Channel',
    type: 'text',
    required: false,
    createdAt: '2024-01-15',
  },
  {
    id: '2',
    name: 'Source',
    type: 'text',
    required: false,
    createdAt: '2024-01-10',
  },
  {
    id: '3',
    name: 'type',
    type: 'text',
    required: false,
    createdAt: '2024-01-05',
  },
  {
    id: '4',
    name: 'Priority',
    type: 'text',
    required: true,
    defaultValue: 'Medium',
    createdAt: '2024-01-01',
  },
  {
    id: '5',
    name: 'Lead Score',
    type: 'number',
    required: false,
    createdAt: '2023-12-20',
  },
];

export const staticTags: Tag[] = [
  {
    id: '1',
    name: 'VIP Customer',
    color: '#10b981',
    usageCount: 45,
    createdAt: '2024-01-15',
  },
  {
    id: '2',
    name: 'Lead',
    color: '#f59e0b',
    usageCount: 123,
    createdAt: '2024-01-10',
  },
  {
    id: '3',
    name: 'Support',
    color: '#ef4444',
    usageCount: 67,
    createdAt: '2024-01-05',
  },
  {
    id: '4',
    name: 'Newsletter',
    color: '#3b82f6',
    usageCount: 89,
    createdAt: '2024-01-01',
  },
];

export const sidebarItems = [
  { id: 'business-profile', label: 'Business Profile', icon: Building2 },
  { id: 'general', label: 'General Settings', icon: Settings },
  { id: 'tags-attributes', label: 'Tags & Attributes', icon: TagIcon },
  { id: 'import-export', label: 'Import/Export', icon: Download },
  { id: 'message-deletion', label: 'Message Deletion', icon: MessageSquare },
];
