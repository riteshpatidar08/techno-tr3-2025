import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useAppDispatch, useAppSelector } from '@/redux/store';
import {
  createTag,
  updateTag,
  selectTagsCreating,
  selectTagsUpdating,
  selectTagsError,
  clearError,
} from '@/redux/tagsSlice';
import { Tag } from '@/services/api';
import { ErrorWarning, SuccessWarning } from '@/components/ui/warning';
import { RefreshCw, CheckCircle } from 'lucide-react';

interface TagFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  editingTag?: Tag | null;
  title: string;
  description: string;
}

export const TagFormModal: React.FC<TagFormModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  editingTag,
  title,
  description,
}) => {
  const dispatch = useAppDispatch();
  const isCreating = useAppSelector(selectTagsCreating);
  const isUpdating = useAppSelector(selectTagsUpdating);
  const error = useAppSelector(selectTagsError);

  const [formData, setFormData] = useState({
    name: '',
    selectedColor: '#3b82f6',
    status: 'active' as const,
    keywords: [] as string[],
  });

  const [showSuccess, setShowSuccess] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  const [validationErrors, setValidationErrors] = useState<{
    name?: string;
    selectedColor?: string;
  }>({});

  useEffect(() => {
    if (isOpen) {
      dispatch(clearError());
      setShowSuccess(false);
      setSuccessMessage('');
    }
  }, [isOpen, dispatch]);

  useEffect(() => {
    if (editingTag && isOpen) {
      setFormData({
        name: editingTag.name,
        selectedColor: editingTag.tag_color,
        status: editingTag.status as 'active' | 'inactive',
        keywords: editingTag.keyword || [],
      });
    } else if (isOpen) {
      setFormData({
        name: '',
        selectedColor: '#3b82f6',
        status: 'active',
        keywords: [],
      });
    }

    setValidationErrors({});
  }, [editingTag, isOpen]);

  const validateForm = () => {
    const errors: { name?: string; selectedColor?: string } = {};

    if (!formData.name.trim()) {
      errors.name = 'Tag name is required';
    } else if (formData.name.trim().length < 2) {
      errors.name = 'Tag name must be at least 2 characters';
    } else if (formData.name.trim().length > 50) {
      errors.name = 'Tag name must be less than 50 characters';
    }

    if (
      !formData.selectedColor ||
      !/^#[0-9A-F]{6}$/i.test(formData.selectedColor)
    ) {
      errors.selectedColor = 'Please select a valid color';
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSave = async () => {
    if (!validateForm()) {
      return;
    }

    try {
      if (editingTag) {
        const resultAction = await dispatch(
          updateTag({
            id: editingTag.id,
            tagData: {
              name: formData.name.trim(),
              tag_color: formData.selectedColor,
              status: formData.status,
            },
          })
        );

        if (updateTag.fulfilled.match(resultAction)) {
          setSuccessMessage('Tag updated successfully!');
          setShowSuccess(true);
          onSuccess?.();

          setTimeout(() => {
            onClose();
          }, 2000);
        } else {
          console.error('Failed to update tag');
        }
      } else {
        const tagPayload = {
          tags: [formData.name.trim()],
          keywords: formData.keywords,
          selectedColor: formData.selectedColor,
          status: formData.status,
        };

        const resultAction = await dispatch(createTag(tagPayload));

        if (createTag.fulfilled.match(resultAction)) {
          setSuccessMessage('Tag created successfully!');
          setShowSuccess(true);
          onSuccess?.();

          setTimeout(() => {
            onClose();
          }, 2000);
        } else {
          console.error('Failed to create tag');
        }
      }
    } catch (error) {
      console.error('Error saving tag:', error);
    }
  };

  const handleClose = () => {
    setValidationErrors({});
    setShowSuccess(false);
    setSuccessMessage('');
    dispatch(clearError());
    onClose();
  };

  const isLoading = isCreating || isUpdating;

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="border-0 shadow-xl">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>

        {showSuccess && (
          <SuccessWarning
            title="Success!"
            message={successMessage}
            size="sm"
            className="mb-2"
            dismissible
            onClose={() => setShowSuccess(false)}
            actions={[
              {
                label: 'Close',
                onClick: handleClose,
                variant: 'outline',
                className: 'border-green-300 text-green-700 hover:bg-green-50',
              },
            ]}
          />
        )}

        {error && (
          <ErrorWarning
            title="Error"
            message={error}
            size="sm"
            className="mb-2"
            dismissible
            onClose={() => dispatch(clearError())}
            actions={[
              {
                label: 'Retry',
                onClick: handleSave,
                variant: 'outline',
                icon: RefreshCw,
                loading: isLoading,
                className: 'border-red-300 text-red-700 hover:bg-red-50',
              },
            ]}
          />
        )}

        <div className="space-y-4">
          {/* Tag Name */}
          <div className="space-y-2">
            <Label htmlFor="tag-name">
              Tag Name <span className="text-destructive">*</span>
            </Label>
            <Input
              id="tag-name"
              value={formData.name}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, name: e.target.value }))
              }
              placeholder="e.g., VIP Customer, Lead"
              className={validationErrors.name ? 'border-destructive' : ''}
              disabled={isLoading}
            />
            {validationErrors.name && (
              <p className="text-sm text-destructive">
                {validationErrors.name}
              </p>
            )}
          </div>

          {/* Tag Color */}
          <div className="space-y-2">
            <Label htmlFor="tag-color">
              Color <span className="text-destructive">*</span>
            </Label>
            <div className="flex items-center space-x-2">
              <input
                id="tag-color"
                type="color"
                value={formData.selectedColor}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    selectedColor: e.target.value,
                  }))
                }
                className="w-12 h-10 rounded border cursor-pointer disabled:cursor-not-allowed disabled:opacity-50"
                disabled={isLoading}
              />
              <Input
                value={formData.selectedColor}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    selectedColor: e.target.value,
                  }))
                }
                placeholder="#3b82f6"
                className={
                  validationErrors.selectedColor ? 'border-destructive' : ''
                }
                disabled={isLoading}
              />
            </div>
            {validationErrors.selectedColor && (
              <p className="text-sm text-destructive">
                {validationErrors.selectedColor}
              </p>
            )}
          </div>

          {editingTag && (
            <div className="space-y-2">
              <Label htmlFor="tag-status">Status</Label>
              <select
                id="tag-status"
                value={formData.status}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    status: e.target.value as 'active' | 'inactive',
                  }))
                }
                className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground disabled:cursor-not-allowed disabled:opacity-50"
                disabled={isLoading}
              >
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
              </select>
            </div>
          )}

          {/* Preview */}
          <div className="space-y-2">
            <Label>Preview</Label>
            <div className="flex items-center space-x-2 p-3 bg-muted rounded-md">
              <div
                className="w-4 h-4 rounded-full"
                style={{ backgroundColor: formData.selectedColor }}
              />
              <span className="text-sm font-medium">
                {formData.name || 'Tag Name'}
              </span>
              {formData.status === 'inactive' && (
                <span className="text-xs text-muted-foreground">
                  (Inactive)
                </span>
              )}
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose} disabled={isLoading}>
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            disabled={isLoading || !formData.name.trim()}
          >
            {isLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2" />
                {editingTag ? 'Updating...' : 'Creating...'}
              </>
            ) : editingTag ? (
              'Save Changes'
            ) : (
              'Create Tag'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
