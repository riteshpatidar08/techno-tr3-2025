export interface BusinessProfile {
  id: string;
  name: string;
  profilePicture: string;
  phoneNumber: string;
  businessAddress: string;
  emailForBusinessContact: string;
  businessWebsite1: string;
  businessWebsite2: string;
  about: string;
  businessDescription: string;
  businessIndustry: string;
}

export interface GeneralSettings {
  customerTimeZone: string;
  language: string;
  supportButtonEnabled: boolean;
  contentDirection: string;
  sendReportSchedule: string;
}

export interface ContactAttribute {
  id: string;
  name: string;
  type: 'text' | 'number' | 'date' | 'boolean';
  required: boolean;
  defaultValue?: string;
  createdAt: string;
}

export interface Tag {
  id: string;
  name: string;
  color: string;
  description?: string;
  usageCount: number;
  createdAt: string;
}

export const routes = {
  'business-profile': 'Business Profile',
  general: 'General Settings',
  'tags-attributes': 'Tags & Attributes',
  'import-export': 'Import/Export',
  'message-deletion': 'Message Deletion',
} as const;

export type RouteKey = keyof typeof routes;
