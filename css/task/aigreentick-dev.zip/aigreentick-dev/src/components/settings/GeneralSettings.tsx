import React from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Clock, Settings, Languages } from 'lucide-react';
import { GeneralSettings as GeneralSettingsType } from './types';
import { ProfilePictureSection } from './ProfilePictureSection';

interface GeneralSettingsProps {
  generalSettings: GeneralSettingsType;
  isLoading: boolean;
  onUpdate: (updates: Partial<GeneralSettingsType>) => void;
  onSave: () => void;
}

export const GeneralSettings: React.FC<GeneralSettingsProps> = ({
  generalSettings,
  isLoading,
  onUpdate,
  onSave,
}) => {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 mb-2">
          General Settings
        </h1>
        <p className="text-muted-foreground">
          Configure your account preferences and system settings.
        </p>
      </div>

      <ProfilePictureSection />

      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Reports & Scheduling
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <p className="font-medium">Send Report Schedule</p>
              <p className="text-sm text-muted-foreground">
                Configure automated report delivery
              </p>
            </div>
            <Button className="bg-green-600 hover:bg-green-700">
              Create Schedule
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            System Preferences
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="timezone">Customer TimeZone</Label>
            <Select
              value={generalSettings.customerTimeZone}
              onValueChange={(value) => onUpdate({ customerTimeZone: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="(GMT+08:00) Beijing, Chongqing, Hong Kong, Urumqi, Kuala Lumpur, Singapore, Taipei, Perth, Irkutsk, Ulaanbaatar">
                  (GMT+08:00) Asia/Singapore
                </SelectItem>
                <SelectItem value="(GMT+00:00) Greenwich Mean Time">
                  (GMT+00:00) UTC
                </SelectItem>
                <SelectItem value="(GMT-05:00) Eastern Standard Time">
                  (GMT-05:00) America/New_York
                </SelectItem>
                <SelectItem value="(GMT+05:30) India Standard Time">
                  (GMT+05:30) Asia/Kolkata
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="language">
                Language <span className="text-red-500">*</span>
              </Label>
              <div className="relative">
                <Languages className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Select
                  value={generalSettings.language}
                  onValueChange={(value) => onUpdate({ language: value })}
                >
                  <SelectTrigger className="pl-10">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="English">English</SelectItem>
                    <SelectItem value="Spanish">Español</SelectItem>
                    <SelectItem value="French">Français</SelectItem>
                    <SelectItem value="German">Deutsch</SelectItem>
                    <SelectItem value="Chinese">中文</SelectItem>
                    <SelectItem value="Japanese">日本語</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="support-button">
                Support Button <span className="text-red-500">*</span>
              </Label>
              <Select
                value={generalSettings.supportButtonEnabled ? 'Yes' : 'No'}
                onValueChange={(value) =>
                  onUpdate({ supportButtonEnabled: value === 'Yes' })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Yes">Enabled</SelectItem>
                  <SelectItem value="No">Disabled</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="content-direction">
                Content Direction <span className="text-red-500">*</span>
              </Label>
              <Select
                value={generalSettings.contentDirection}
                onValueChange={(value) => onUpdate({ contentDirection: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Initial">Auto-detect</SelectItem>
                  <SelectItem value="LTR">Left to Right</SelectItem>
                  <SelectItem value="RTL">Right to Left</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button disabled={isLoading} onClick={onSave}>
          {isLoading ? 'Saving...' : 'Save Settings'}
        </Button>
      </div>
    </div>
  );
};
