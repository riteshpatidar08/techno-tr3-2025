import React from 'react';
import { Button } from '@/components/ui/button';
import { Settings } from 'lucide-react';
import { RouteKey } from './types';
import { sidebarItems } from './constants';

interface SidebarProps {
  currentRoute: RouteKey;
  onRouteChange: (route: RouteKey) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentRoute,
  onRouteChange,
}) => {
  return (
    <div className="w-64 bg-white border-r border-gray-200 min-h-screen">
      <div className="p-4">
        <div className="flex flex-col items-center space-y-3">
          <div className="w-full overflow-hidden flex items-center justify-center">
            <div className="w-24 h-24 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center shadow-lg">
              <Settings className="w-8 h-8 text-white" />
            </div>
          </div>
          <div className="text-center">
            <h2 className="text-lg font-semibold text-gray-900">
              Settings Manager
            </h2>
            <p className="text-sm text-gray-600">Manage your settings</p>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-1">
        {sidebarItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentRoute === item.id;

          return (
            <Button
              key={item.id}
              variant={isActive ? 'secondary' : 'ghost'}
              className={`w-full justify-start transition-all duration-200 ${
                isActive
                  ? 'bg-green-50 text-green-600 border-r-2 border-green-500'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
              }`}
              onClick={() => onRouteChange(item.id as RouteKey)}
            >
              <Icon className="w-4 h-4 mr-2" />
              <span className="flex-1 text-left">{item.label}</span>
            </Button>
          );
        })}
      </div>
    </div>
  );
};
