import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { RefreshCw, Calendar, User, Loader2, BarChart3 } from 'lucide-react';

interface DashboardHeaderProps {
  userName?: string;
  loading: boolean;
  lastUpdated: number | null;
  onRefresh: () => void;
}

const DashboardHeader: React.FC<DashboardHeaderProps> = ({
  userName,
  loading,
  lastUpdated,
  onRefresh,
}) => {
  const formatLastUpdated = (timestamp: number | null) => {
    if (!timestamp) return 'Never';
    return new Date(timestamp).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-4">
          {/* Enhanced Icon Container */}
          <div className="relative">
            <div className="flex items-center justify-center w-14 h-14 bg-primary rounded-xl shadow-lg">
              <BarChart3 className="w-7 h-7 text-primary-foreground" />
            </div>
            {/* Online Status Indicator */}
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-chart-2 border-2 border-card rounded-full"></div>
          </div>

          <div>
            <h1 className="text-2xl font-bold text-foreground">
              Welcome back, {loading ? 'Loading...' : userName || 'User'}
            </h1>
            <div className="flex items-center space-x-2 mt-1">
              <p className="text-sm text-muted-foreground">
                Last updated: {formatLastUpdated(lastUpdated)}
              </p>
              {!loading && lastUpdated && (
                <Badge
                  variant="outline"
                  className="bg-chart-2/10 text-chart-2 border-chart-2/20 text-xs px-2 py-0.5"
                >
                  Live
                </Badge>
              )}
            </div>
          </div>
        </div>

        <Button
          variant="outline"
          size="sm"
          className="bg-card/80 backdrop-blur-sm hover:bg-card border-border hover:border-primary/50 transition-all duration-200"
          onClick={onRefresh}
          disabled={loading}
        >
          {loading ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <RefreshCw className="w-4 h-4 mr-2" />
          )}
          {loading ? 'Loading...' : 'Refresh'}
        </Button>
      </div>

      {/* Time Period Badges */}
      <div className="flex items-center space-x-3">
        <Badge className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-sm px-3 py-1.5 font-medium">
          <Calendar className="w-3 h-3 mr-1.5" />7 Days
        </Badge>
        <Badge
          variant="outline"
          className="bg-card/80 backdrop-blur-sm hover:bg-accent border-border px-3 py-1.5 font-medium transition-colors"
        >
          <Calendar className="w-3 h-3 mr-1.5" />
          30 Days
        </Badge>
        <Badge
          variant="outline"
          className="bg-muted/50 hover:bg-muted text-muted-foreground border-border px-3 py-1.5 font-medium transition-colors"
        >
          <Calendar className="w-3 h-3 mr-1.5" />
          90 Days
        </Badge>
      </div>
    </div>
  );
};

export default DashboardHeader;
