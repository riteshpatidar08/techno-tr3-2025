import React from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { User, Shield, Calendar, MapPin, Phone, Mail } from 'lucide-react';

interface UserData {
  name: string;
  email: string;
  mobile: string;
  country: {
    name: string;
    mobile_code: string;
  };
  is_demo: string;
  demo_end?: string;
  created_at: string;
}

interface UserProfileCardProps {
  user: UserData | null;
}

const UserProfileCard: React.FC<UserProfileCardProps> = ({ user }) => {
  if (!user) return null;

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const calculateDaysRemaining = (demoEndDate: string) => {
    const endDate = new Date(demoEndDate);
    const currentDate = new Date();

    const timeDifference = endDate.getTime() - currentDate.getTime();

    const daysRemaining = Math.ceil(timeDifference / (1000 * 60 * 60 * 24));

    return daysRemaining;
  };

  const formatDaysRemaining = (days: number) => {
    if (days <= 0) {
      return 'Expired';
    } else if (days === 1) {
      return '1 day remaining';
    } else {
      return `${days} days remaining`;
    }
  };

  const daysRemaining = user.demo_end
    ? calculateDaysRemaining(user.demo_end)
    : 0;
  const isDemoExpiringSoon =
    user.is_demo === 'on' && daysRemaining <= 7 && daysRemaining > 0;
  const isDemoExpired = user.is_demo === 'on' && daysRemaining <= 0;
  const isActiveExpiringSoon =
    user.is_demo === 'off' && daysRemaining <= 30 && daysRemaining > 0;
  const isActiveExpired = user.is_demo === 'off' && daysRemaining <= 0;

  return (
    <Card className="bg-card border-border transition-all duration-300 hover:border-primary/20 mb-6">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center justify-center w-12 h-12 bg-primary rounded-xl">
              <User className="w-6 h-6 text-primary-foreground" />
            </div>
            <div>
              <CardTitle className="text-xl font-semibold text-card-foreground">
                Account Information
              </CardTitle>
              <CardDescription className="text-muted-foreground mt-1">
                Your account details and current status
              </CardDescription>
            </div>
          </div>

          {/* Account Status Badge */}
          <div className="flex items-center space-x-2">
            <Badge
              variant={user.is_demo === 'on' ? 'outline' : 'default'}
              className={`${
                user.is_demo === 'on'
                  ? isDemoExpired
                    ? 'bg-destructive/10 text-destructive border-destructive/20'
                    : 'bg-chart-4/10 text-chart-4 border-chart-4/20'
                  : isActiveExpired
                  ? 'bg-destructive/10 text-destructive border-destructive/20'
                  : isActiveExpiringSoon
                  ? 'bg-yellow-100 text-yellow-800 border-yellow-300'
                  : 'bg-green-600 text-white border-0 shadow-sm'
              } font-medium`}
            >
              <Shield className="w-3 h-3 mr-1" />
              {isDemoExpired
                ? 'Demo Expired'
                : isActiveExpired
                ? 'Account Expired'
                : user.is_demo === 'on'
                ? 'Demo Account'
                : 'Active Account'}
            </Badge>

            {(isDemoExpiringSoon || isActiveExpiringSoon) && (
              <Badge
                variant="outline"
                className={`${
                  isDemoExpiringSoon
                    ? 'bg-destructive/10 text-destructive border-destructive/20'
                    : 'bg-yellow-100 text-yellow-800 border-yellow-300'
                }`}
              >
                {isDemoExpiringSoon ? 'Expiring Soon' : 'Renewal Due Soon'}
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent className="pt-0">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Email */}
          <div className="space-y-3 p-4 bg-muted/30 rounded-lg border border-border/50">
            <div className="flex items-center space-x-2">
              <Mail className="w-4 h-4 text-chart-1" />
              <p className="text-sm font-medium text-muted-foreground">
                Email Address
              </p>
            </div>
            <p className="font-medium text-card-foreground break-all">
              {user.email}
            </p>
          </div>

          {/* Mobile */}
          <div className="space-y-3 p-4 bg-muted/30 rounded-lg border border-border/50">
            <div className="flex items-center space-x-2">
              <Phone className="w-4 h-4 text-chart-2" />
              <p className="text-sm font-medium text-muted-foreground">
                Mobile Number
              </p>
            </div>
            <p className="font-medium text-card-foreground">
              +{user.country.mobile_code} {user.mobile}
            </p>
          </div>

          {/* Country */}
          <div className="space-y-3 p-4 bg-muted/30 rounded-lg border border-border/50">
            <div className="flex items-center space-x-2">
              <MapPin className="w-4 h-4 text-chart-3" />
              <p className="text-sm font-medium text-muted-foreground">
                Country
              </p>
            </div>
            <p className="font-medium text-card-foreground">
              {user.country.name}
            </p>
          </div>

          {/* Account End Date */}
          {user.demo_end && (
            <div
              className={`space-y-3 p-4 rounded-lg border ${
                isDemoExpired || isActiveExpired
                  ? 'bg-destructive/5 border-destructive/20'
                  : isDemoExpiringSoon || isActiveExpiringSoon
                  ? 'bg-yellow-50 border-yellow-200'
                  : user.is_demo === 'on'
                  ? 'bg-chart-4/5 border-chart-4/20'
                  : 'bg-green-50/50 border-green-200/50'
              }`}
            >
              <div className="flex items-center space-x-2">
                <Calendar
                  className={`w-4 h-4 ${
                    isDemoExpired || isActiveExpired
                      ? 'text-destructive'
                      : isDemoExpiringSoon || isActiveExpiringSoon
                      ? 'text-yellow-600'
                      : user.is_demo === 'on'
                      ? 'text-chart-4'
                      : 'text-green-600'
                  }`}
                />
                <p className="text-sm font-medium text-muted-foreground">
                  {user.is_demo === 'on' ? 'Demo Expires' : 'Account Expires'}
                </p>
              </div>
              <div className="space-y-1">
                <p className="font-medium text-card-foreground">
                  {formatDate(user.demo_end)}
                </p>
                <p
                  className={`text-xs font-medium ${
                    isDemoExpired || isActiveExpired
                      ? 'text-destructive'
                      : isDemoExpiringSoon || isActiveExpiringSoon
                      ? 'text-yellow-600'
                      : user.is_demo === 'on'
                      ? 'text-chart-4'
                      : 'text-green-600'
                  }`}
                >
                  {formatDaysRemaining(daysRemaining)}
                </p>
              </div>
            </div>
          )}

          {/* Member Since */}
          <div className="space-y-3 p-4 bg-muted/30 rounded-lg border border-border/50">
            <div className="flex items-center space-x-2">
              <Calendar className="w-4 h-4 text-chart-5" />
              <p className="text-sm font-medium text-muted-foreground">
                Member Since
              </p>
            </div>
            <p className="font-medium text-card-foreground">
              {formatDate(user.created_at)}
            </p>
          </div>

          {/* Account Name */}
          <div className="space-y-3 p-4 bg-muted/30 rounded-lg border border-border/50">
            <div className="flex items-center space-x-2">
              <User className="w-4 h-4 text-primary" />
              <p className="text-sm font-medium text-muted-foreground">
                Full Name
              </p>
            </div>
            <p className="font-medium text-card-foreground">{user.name}</p>
          </div>
        </div>

        {/* Demo Account Warning */}
        {user.is_demo === 'on' && (
          <div
            className={`mt-6 p-4 rounded-lg border ${
              isDemoExpired
                ? 'bg-destructive/5 border-destructive/20'
                : isDemoExpiringSoon
                ? 'bg-yellow-50 border-yellow-200'
                : 'bg-chart-4/5 border-chart-4/20'
            }`}
          >
            <div className="flex items-start space-x-3">
              <Shield
                className={`w-5 h-5 mt-0.5 flex-shrink-0 ${
                  isDemoExpired
                    ? 'text-destructive'
                    : isDemoExpiringSoon
                    ? 'text-yellow-600'
                    : 'text-chart-4'
                }`}
              />
              <div className="flex-1">
                <h4 className="font-medium text-card-foreground mb-1">
                  {isDemoExpired
                    ? 'Demo Account Expired'
                    : 'Demo Account Notice'}
                </h4>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {isDemoExpired ? (
                    <>
                      Your demo account has expired. Please upgrade to a full
                      account to continue using all features.
                    </>
                  ) : (
                    <>
                      You're currently using a demo account with limited
                      features.
                      {user.demo_end && (
                        <>
                          {' '}
                          Your demo access will expire on{' '}
                          <span className="font-medium">
                            {formatDate(user.demo_end)}
                          </span>{' '}
                          ({formatDaysRemaining(daysRemaining)}).
                        </>
                      )}{' '}
                      Upgrade to a full account to unlock all features and
                      remove limitations.
                    </>
                  )}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Active Account Status */}
        {user.is_demo === 'off' && (
          <div
            className={`mt-6 p-4 rounded-lg border ${
              isActiveExpired
                ? 'bg-destructive/5 border-destructive/20'
                : isActiveExpiringSoon
                ? 'bg-yellow-50 border-yellow-200'
                : 'bg-green-50/50 border-green-200/50'
            }`}
          >
            <div className="flex items-start space-x-3">
              <Shield
                className={`w-5 h-5 mt-0.5 flex-shrink-0 ${
                  isActiveExpired
                    ? 'text-destructive'
                    : isActiveExpiringSoon
                    ? 'text-yellow-600'
                    : 'text-green-600'
                }`}
              />
              <div className="flex-1">
                <h4 className="font-medium text-card-foreground mb-1">
                  {isActiveExpired
                    ? 'Account Expired'
                    : isActiveExpiringSoon
                    ? 'Account Renewal Due Soon'
                    : 'Full Account Access'}
                </h4>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {isActiveExpired ? (
                    <>
                      Your account has expired. Please renew your subscription
                      to continue using all features.
                    </>
                  ) : isActiveExpiringSoon ? (
                    <>
                      Your account will expire soon. Please renew your
                      subscription to avoid service interruption.
                      {user.demo_end && (
                        <>
                          {' '}
                          Your account expires on{' '}
                          <span className="font-medium">
                            {formatDate(user.demo_end)}
                          </span>{' '}
                          ({formatDaysRemaining(daysRemaining)}).
                        </>
                      )}
                    </>
                  ) : (
                    <>
                      You have full access to all features and unlimited usage.
                      Your account is active and in good standing.
                      {user.demo_end && (
                        <>
                          {' '}
                          Your account is valid until{' '}
                          <span className="font-medium">
                            {formatDate(user.demo_end)}
                          </span>{' '}
                          ({formatDaysRemaining(daysRemaining)}).
                        </>
                      )}
                    </>
                  )}
                </p>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default UserProfileCard;
