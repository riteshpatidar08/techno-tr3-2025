import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MessageSquare, CheckCircle2 } from 'lucide-react';

interface UnreadMessage {
  id: string;
  from: string;
  message: string;
  timestamp: string;
}

interface UnreadMessagesCardProps {
  unreadMessages?: UnreadMessage[];
  unreadCount?: number;
}

const UnreadMessagesCard: React.FC<UnreadMessagesCardProps> = ({
  unreadMessages = [],
  unreadCount = 0,
}) => {
  const hasUnreadMessages = unreadCount > 0 || unreadMessages.length > 0;

  return (
    <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-lg rounded-xl">
      <CardHeader className="pb-4">
        <div className="flex items-center space-x-3">
          <div className="flex items-center justify-center w-8 h-8 bg-gradient-to-br from-green-400 to-green-600 rounded-lg">
            <MessageSquare className="w-4 h-4 text-white" />
          </div>
          <CardTitle className="text-lg font-semibold text-gray-900">
            Unread Messages
          </CardTitle>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        {hasUnreadMessages ? (
          <div className="space-y-3">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm text-gray-600">
                {unreadCount || unreadMessages.length} unread messages
              </span>
            </div>
            {unreadMessages.slice(0, 3).map((message) => (
              <div
                key={message.id}
                className="flex items-start space-x-3 p-3 rounded-lg bg-blue-50 border border-blue-100"
              >
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-white text-xs font-medium">
                    {message.from?.charAt(0) || 'U'}
                  </span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900">
                    {message.from || 'Unknown Contact'}
                  </p>
                  <p className="text-sm text-gray-600 truncate">
                    {message.message}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    {message.timestamp}
                  </p>
                </div>
              </div>
            ))}
            {unreadMessages.length > 3 && (
              <p className="text-xs text-gray-500 text-center">
                +{unreadMessages.length - 3} more messages
              </p>
            )}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center text-center py-6">
            <div className="flex items-center justify-center w-14 h-14 bg-gradient-to-br from-green-400 to-green-600 rounded-2xl mb-4 shadow-lg">
              <CheckCircle2 className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-1">
              All caught up!
            </h3>
            <p className="text-sm text-gray-500">No unread messages</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default UnreadMessagesCard;
