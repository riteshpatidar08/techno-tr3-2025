import React from 'react';
import { MessageCircle, TrendingUp, Shield, AlertCircle } from 'lucide-react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export default function MessageChargesCard({ user }) {
  if (!user) {
    return (
      <Card className="bg-card border-border">
        <CardContent className="p-6">
          <div className="animate-pulse">
            <div className="h-6 bg-muted rounded w-1/2 mb-4"></div>
            <div className="space-y-3">
              <div className="h-4 bg-muted rounded"></div>
              <div className="h-4 bg-muted rounded"></div>
              <div className="h-4 bg-muted rounded"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const charges = [
    {
      category: 'Marketing Messages',
      charge: user.market_msg_charge,
      icon: TrendingUp,
      color: 'text-chart-1',
      bgColor: 'bg-chart-1/10',
      borderColor: 'border-chart-1/20',
      description: 'Promotional and marketing campaigns',
    },
    {
      category: 'Utility Messages',
      charge: user.utilty_msg_charge,
      icon: MessageCircle,
      color: 'text-chart-2',
      bgColor: 'bg-chart-2/10',
      borderColor: 'border-chart-2/20',
      description: 'Service updates and notifications',
    },
    {
      category: 'Authentication Messages',
      charge: user.auth_msg_charge,
      icon: Shield,
      color: 'text-chart-3',
      bgColor: 'bg-chart-3/10',
      borderColor: 'border-chart-3/20',
      description: 'OTP and verification messages',
    },
  ];

  const totalCharges = charges.reduce((sum, item) => sum + item.charge, 0);

  return (
    <Card className="bg-card border-border transition-all duration-300 hover:border-primary/20">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center justify-center w-12 h-12 bg-primary rounded-xl">
              <MessageCircle className="w-6 h-6 text-primary-foreground" />
            </div>
            <div>
              <CardTitle className="text-xl font-semibold text-card-foreground">
                Message Charges by Category
              </CardTitle>
              <CardDescription className="text-muted-foreground mt-1">
                Per message cost breakdown by template type
              </CardDescription>
            </div>
          </div>
          <Badge
            variant="outline"
            className="bg-muted/30 text-muted-foreground border-border/50"
          >
            <AlertCircle className="w-3 h-3 mr-1" />
            Per message
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="pt-0">
        <div className="space-y-4">
          {charges.map((item, index) => {
            const Icon = item.icon;
            const percentage =
              totalCharges > 0 ? (item.charge / totalCharges) * 100 : 0;

            return (
              <div
                key={index}
                className="space-y-3 p-4 bg-muted/30 rounded-lg border border-border/50 hover:border-primary/20 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div
                      className={`p-2 rounded-lg ${item.bgColor} border ${item.borderColor}`}
                    >
                      <Icon className={`w-4 h-4 ${item.color}`} />
                    </div>
                    <div>
                      <h4 className="font-semibold text-card-foreground">
                        {item.category}
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        {item.description}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold text-card-foreground">
                      ₹{item.charge.toFixed(4)}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {percentage.toFixed(1)}% of total
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-6 pt-4 border-t border-border">
          <div className="flex items-center justify-between">
            <div className="text-sm font-medium text-muted-foreground">
              Current Balance
            </div>
            <div className="text-lg font-bold text-chart-2">
              ₹{user.balance.toFixed(2)}
            </div>
          </div>

          <div className="mt-3 grid grid-cols-2 gap-4 text-sm">
            <div className="text-center p-2 bg-chart-2/10 rounded-lg border border-chart-2/20">
              <div className="font-medium text-card-foreground">
                Total Credit
              </div>
              <div className="text-chart-2">₹{user.credit}</div>
            </div>
            <div className="text-center p-2 bg-destructive/10 rounded-lg border border-destructive/20">
              <div className="font-medium text-card-foreground">
                Total Debit
              </div>
              <div className="text-destructive">₹{user.debit}</div>
            </div>
          </div>
        </div>

        <div className="mt-4 p-4 bg-chart-4/5 rounded-lg border border-chart-4/20">
          <div className="flex items-start space-x-3">
            <AlertCircle className="w-4 h-4 text-chart-4 mt-0.5 flex-shrink-0" />
            <div className="flex-1">
              <h4 className="font-medium text-card-foreground mb-1">
                Pricing Information
              </h4>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Charges vary by message category. Marketing messages have the
                highest cost due to promotional nature, while utility and
                authentication messages are optimized for essential
                communications.
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
