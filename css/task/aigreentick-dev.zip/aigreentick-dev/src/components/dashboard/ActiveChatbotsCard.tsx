import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Bot, Plus, Settings, Play, Pause } from 'lucide-react';

interface Chatbot {
  id: string;
  name: string;
  status: 'active' | 'inactive' | 'paused';
  conversations: number;
  lastActive: string;
}

interface ActiveChatbotsCardProps {
  chatbots?: Chatbot[];
  chatbotCount?: number;
  onCreateChatbot?: () => void;
  onManageChatbot?: (chatbotId: string) => void;
}

const ActiveChatbotsCard: React.FC<ActiveChatbotsCardProps> = ({
  chatbots = [],
  chatbotCount = 0,
  onCreateChatbot,
  onManageChatbot,
}) => {
  const activeChatbots = chatbots.filter((bot) => bot.status === 'active');
  const totalCount = chatbotCount || chatbots.length;

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active':
        return <Play className="w-3 h-3 text-green-600" />;
      case 'paused':
        return <Pause className="w-3 h-3 text-yellow-600" />;
      default:
        return <div className="w-3 h-3 bg-gray-400 rounded-full" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'text-green-600';
      case 'paused':
        return 'text-yellow-600';
      default:
        return 'text-gray-600';
    }
  };

  return (
    <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-lg rounded-xl">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="flex items-center justify-center w-8 h-8 bg-gradient-to-br from-green-400 to-green-600 rounded-lg">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <CardTitle className="text-lg font-semibold text-gray-900">
              Active Chatbots
            </CardTitle>
          </div>
          {totalCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              className="text-green-600 hover:text-green-700 hover:bg-green-50"
            >
              <Settings className="w-4 h-4" />
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        {totalCount > 0 ? (
          <div className="space-y-4">
            <div className="flex flex-col items-center justify-center text-center py-4">
              <div className="flex items-center justify-center w-14 h-14 bg-gradient-to-br from-green-400 to-green-600 rounded-2xl mb-4 shadow-lg">
                <Bot className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-1">
                {totalCount} Chatbot{totalCount !== 1 ? 's' : ''}
              </h3>
              <p className="text-sm text-gray-500 mb-4">
                Ready to serve your customers
              </p>
            </div>

            {chatbots.length > 0 && (
              <div className="space-y-3">
                <h4 className="text-sm font-medium text-gray-700 border-b border-gray-200 pb-2">
                  Recent Activity
                </h4>
                {chatbots.slice(0, 3).map((chatbot) => (
                  <div
                    key={chatbot.id}
                    className="flex items-center justify-between p-3 rounded-lg border border-gray-100 hover:bg-gray-50 transition-colors cursor-pointer"
                    onClick={() => onManageChatbot?.(chatbot.id)}
                  >
                    <div className="flex items-center space-x-3">
                      <div className="flex items-center space-x-1">
                        {getStatusIcon(chatbot.status)}
                        <span
                          className={`text-xs font-medium ${getStatusColor(
                            chatbot.status
                          )}`}
                        >
                          {chatbot.status}
                        </span>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          {chatbot.name}
                        </p>
                        <p className="text-xs text-gray-500">
                          {chatbot.conversations} conversations
                        </p>
                      </div>
                    </div>
                    <div className="text-xs text-gray-400">
                      {chatbot.lastActive}
                    </div>
                  </div>
                ))}
              </div>
            )}

            <Button
              variant="outline"
              size="sm"
              className="w-full"
              onClick={onCreateChatbot}
            >
              <Plus className="w-4 h-4 mr-2" />
              Create New Chatbot
            </Button>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center text-center py-6">
            <div className="flex items-center justify-center w-14 h-14 bg-gradient-to-br from-green-400 to-green-600 rounded-2xl mb-4 shadow-lg">
              <Bot className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-1">
              No Chatbots Yet
            </h3>
            <p className="text-sm text-gray-500 mb-4">
              Create your first chatbot to get started
            </p>
            <Button
              size="sm"
              className="bg-green-600 hover:bg-green-700"
              onClick={onCreateChatbot}
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Chatbot
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ActiveChatbotsCard;
