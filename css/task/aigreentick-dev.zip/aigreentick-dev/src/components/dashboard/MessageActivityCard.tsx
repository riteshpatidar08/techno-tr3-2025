import React from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { BarChart3, TrendingUp } from 'lucide-react';

interface ActivityData {
  date: string;
  messages: number;
  conversations: number;
}

interface MessageActivityCardProps {
  activityData?: ActivityData[];
  loading?: boolean;
}

const MessageActivityCard: React.FC<MessageActivityCardProps> = ({
  activityData = [],
  loading = false,
}) => {
  return (
    <Card className="lg:col-span-2 bg-white/90 backdrop-blur-sm border-0 shadow-lg rounded-xl">
      <CardHeader className="pb-4">
        <div className="flex items-center space-x-3">
          <div className="flex items-center justify-center w-8 h-8 bg-gradient-to-br from-gray-400 to-gray-600 rounded-lg">
            <BarChart3 className="w-4 h-4 text-white" />
          </div>
          <div>
            <CardTitle className="text-lg font-semibold text-gray-900">
              Message Activity
            </CardTitle>
            <CardDescription className="text-gray-600 mt-1">
              Track your conversation patterns over time
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-600"></div>
          </div>
        ) : activityData.length > 0 ? (
          <div className="h-64">
            <div className="flex items-center justify-center h-full">
              <p className="text-gray-500">Chart component would go here</p>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-64 text-center">
            <div className="flex items-center justify-center w-16 h-16 bg-gradient-to-br from-gray-200 to-gray-300 rounded-2xl mb-6 shadow-inner">
              <TrendingUp className="w-8 h-8 text-gray-500" />
            </div>
            <h3 className="text-lg font-medium text-gray-700 mb-2">
              No activity data available
            </h3>
            <p className="text-sm text-gray-500">
              Start conversations to see your activity patterns
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default MessageActivityCard;
