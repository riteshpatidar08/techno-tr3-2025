import { useEffect } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import {
  selectIsAuthenticated,
  selectIsLoading,
  initializeAuth,
} from '@/redux/authSlice';

interface ProtectedRoutesProps {
  children: React.ReactNode;
  redirectTo?: string;
  requireAuth?: boolean;
}

const ProtectedRoutes: React.FC<ProtectedRoutesProps> = ({
  children,
  redirectTo = '/login',
  requireAuth = true,
}) => {
  const dispatch = useDispatch();
  const location = useLocation();
  const isAuthenticated = useSelector(selectIsAuthenticated);
  const isLoading = useSelector(selectIsLoading);

  console.log('Auth Status:', {
    isAuthenticated,
    isLoading,
    location: location.pathname,
  });

  // Optional: Initialize auth on mount (if you need this)
  useEffect(() => {
    // Uncomment if you need to initialize auth state
    // dispatch(initializeAuth());
  }, [dispatch]);

  // Show loading spinner while checking authentication
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="flex flex-col items-center space-y-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
          <p className="text-sm text-gray-600">Checking authentication...</p>
        </div>
      </div>
    );
  }

  // Protected route: redirect to login if not authenticated
  if (requireAuth && !isAuthenticated) {
    console.log('Redirecting to login - user not authenticated');
    return <Navigate to={redirectTo} state={{ from: location }} replace />;
  }

  // Public route: redirect to dashboard if already authenticated
  if (!requireAuth && isAuthenticated) {
    console.log('Redirecting to dashboard - user already authenticated');
    return <Navigate to="/dashboard" replace />;
  }

  // All checks passed, render children
  return <>{children}</>;
};

export default ProtectedRoutes;

export const PublicRoutes: React.FC<{
  children: React.ReactNode;
  redirectTo?: string;
}> = ({ children, redirectTo = '/dashboard' }) => {
  return (
    <ProtectedRoutes requireAuth={false} redirectTo={redirectTo}>
      {children}
    </ProtectedRoutes>
  );
};

export const withProtectedRoute = <P extends object>(
  Component: React.ComponentType<P>,
  options?: { redirectTo?: string; requireAuth?: boolean }
) => {
  const WrappedComponent: React.FC<P> = (props) => (
    <ProtectedRoutes {...options}>
      <Component {...props} />
    </ProtectedRoutes>
  );

  WrappedComponent.displayName = `withProtectedRoute(${
    Component.displayName || Component.name
  })`;

  return WrappedComponent;
};


export const AdminRoute: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
 
  return <ProtectedRoutes requireAuth={true}>{children}</ProtectedRoutes>;
};

export const GuestOnlyRoute: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  
  return <PublicRoutes>{children}</PublicRoutes>;
};
