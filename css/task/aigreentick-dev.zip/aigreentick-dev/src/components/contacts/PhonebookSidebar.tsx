import React from 'react';
import { Dialog, DialogTrigger } from '@/components/ui/dialog';
import { Users, Phone, Plus, Trash2 } from 'lucide-react';
import { Phonebook } from './types';

interface PhonebookSidebarProps {
  phonebooks: Phonebook[];
  onAddContact: () => void;
  onDeletePhonebook: (phonebook: Phonebook) => void;
}

export const PhonebookSidebar: React.FC<PhonebookSidebarProps> = ({
  phonebooks,
  onAddContact,
  onDeletePhonebook,
}) => {
  return (
    <div className="w-72 h-screen sticky top-0 bg-white border-r border-gray-200 shadow-sm overflow-y-auto">
      <div className="p-6">
        <div className="text-center mb-8">
          <div className="relative mx-auto w-24 h-24 mb-4">
            <div className="w-full h-full bg-gradient-to-br from-green-100 to-green-200 rounded-full flex items-center justify-center shadow-inner">
              <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-sm">
                <Users className="w-8 h-8 text-green-600" />
              </div>
            </div>
            <div className="absolute -top-1 -right-1 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
              <Plus className="w-3 h-3 text-white" />
            </div>
          </div>
          <h2 className="text-lg font-semibold text-gray-900 mb-1">
            Your phonebooks
          </h2>
        </div>

        <div className="space-y-2">
          {phonebooks.map((phonebook, index) => (
            <div key={index} className="group relative">
              <div className="flex items-center p-3 bg-green-50 border border-green-100 rounded-lg hover:bg-green-100 transition-colors cursor-pointer">
                <div className="flex items-center flex-1 min-w-0">
                  <div className="w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center shadow-sm">
                    <Phone className="w-4 h-4 text-white" />
                  </div>
                  <div className="ml-3 flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">
                      {phonebook.name}
                    </p>
                    <p className="text-xs text-gray-500">
                      {phonebook.daysAgo} days ago
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-1 ml-2">
                  <button
                    onClick={onAddContact}
                    className="w-6 h-6 text-green-500 hover:text-green-600 transition-colors flex items-center justify-center"
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                  <button
                    onClick={() => onDeletePhonebook(phonebook)}
                    className="w-6 h-6 text-red-400 hover:text-red-600 transition-colors flex items-center justify-center"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
