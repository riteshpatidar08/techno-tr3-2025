import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  X,
  UserPlus,
  Phone,
  CheckCircle,
  Upload,
  Download,
  Plus,
} from 'lucide-react';
import { ContactFormData, TabValue } from './types';

interface AddContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveContact: (contact: ContactFormData) => void;
  onImportCSV: (file: File) => void;
  phonebookName: string;
}

export const AddContactModal: React.FC<AddContactModalProps> = ({
  isOpen,
  onClose,
  onSaveContact,
  onImportCSV,
  phonebookName,
}) => {
  const [activeTab, setActiveTab] = useState<TabValue>('paste');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [contactForm, setContactForm] = useState<ContactFormData>({
    name: '',
    mobile: '',
    var1: '',
    var2: '',
    var3: '',
    var4: '',
    var5: '',
  });

  const handleContactFormChange = (
    field: keyof ContactFormData,
    value: string
  ) => {
    setContactForm((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleFileSelect = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type === 'text/csv') {
      setSelectedFile(file);
    }
  };

  const handleSaveContact = () => {
    onSaveContact(contactForm);
    setContactForm({
      name: '',
      mobile: '',
      var1: '',
      var2: '',
      var3: '',
      var4: '',
      var5: '',
    });
    onClose();
  };

  const handleImportCSV = () => {
    if (selectedFile) {
      onImportCSV(selectedFile);
      setSelectedFile(null);
      onClose();
    }
  };

  const downloadSampleCSV = () => {
    const csvContent =
      'name,mobile,var1,var2,var3,var4,var5\nJohn Doe,1234567890,value1,value2,value3,value4,value5';
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'sample_contacts.csv';
    link.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <>
      <input
        ref={fileInputRef}
        type="file"
        accept=".csv"
        onChange={handleFileChange}
        className="hidden"
      />

      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-lg mx-auto bg-white border-0 shadow-2xl rounded-2xl p-0 overflow-hidden">
          <div className="flex items-center justify-between p-6 border-b border-gray-100">
            <div className="flex items-center space-x-3">
              <div className="w-6 h-6 bg-green-500 rounded-lg flex items-center justify-center">
                <UserPlus className="w-4 h-4 text-white" />
              </div>
              <DialogTitle className="text-xl font-semibold text-gray-900">
                Add Contacts{' '}
                <span className="text-green-500 font-medium">
                  ({phonebookName})
                </span>
              </DialogTitle>
            </div>
          
          </div>

          <div className="p-6">
            <Tabs
              value={activeTab}
              onValueChange={(value) => setActiveTab(value as TabValue)}
            >
              <TabsList className="grid w-full grid-cols-2 h-12 p-1 bg-gray-50 rounded-xl">
                <TabsTrigger
                  value="paste"
                  className="rounded-lg font-medium data-[state=active]:bg-green-500 data-[state=active]:text-white data-[state=active]:shadow-sm transition-all"
                >
                  Upload by pasting
                </TabsTrigger>
                <TabsTrigger
                  value="csv"
                  className="rounded-lg font-medium data-[state=active]:bg-green-500 data-[state=active]:text-white data-[state=active]:shadow-sm transition-all"
                >
                  Upload by CSV
                </TabsTrigger>
              </TabsList>

              <TabsContent value="paste" className="mt-8 space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-2 block">
                      Contact name
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <UserPlus className="w-4 h-4 text-gray-400" />
                      </div>
                      <Input
                        value={contactForm.name}
                        onChange={(e) =>
                          handleContactFormChange('name', e.target.value)
                        }
                        className="pl-10 h-11 border-gray-200 focus:border-green-500 focus:ring-2 focus:ring-green-500/20 rounded-lg"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-2 block">
                      Mobile with country code
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Phone className="w-4 h-4 text-gray-400" />
                      </div>
                      <Input
                        value={contactForm.mobile}
                        onChange={(e) =>
                          handleContactFormChange('mobile', e.target.value)
                        }
                        className="pl-10 h-11 border-gray-200 focus:border-green-500 focus:ring-2 focus:ring-green-500/20 rounded-lg"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-5 h-5 bg-blue-500 rounded-lg flex items-center justify-center">
                      <Plus className="w-3 h-3 text-white" />
                    </div>
                    <span className="text-sm font-semibold text-gray-800">
                      Additional Fields
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    {['var1', 'var2', 'var3', 'var4'].map((field) => (
                      <div key={field}>
                        <label className="text-xs font-medium text-gray-500 mb-1 block uppercase tracking-wide">
                          {field}
                        </label>
                        <Input
                          value={contactForm[field as keyof ContactFormData]}
                          onChange={(e) =>
                            handleContactFormChange(
                              field as keyof ContactFormData,
                              e.target.value
                            )
                          }
                          className="h-10 border-gray-200 focus:border-green-500 focus:ring-2 focus:ring-green-500/20 rounded-lg"
                        />
                      </div>
                    ))}
                  </div>

                  <div>
                    <label className="text-xs font-medium text-gray-500 mb-1 block uppercase tracking-wide">
                      var5
                    </label>
                    <Input
                      value={contactForm.var5}
                      onChange={(e) =>
                        handleContactFormChange('var5', e.target.value)
                      }
                      className="h-10 border-gray-200 focus:border-green-500 focus:ring-2 focus:ring-green-500/20 rounded-lg"
                    />
                  </div>
                </div>

                <div className="flex justify-center pt-4">
                  <Button
                    onClick={handleSaveContact}
                    className="bg-green-500 hover:bg-green-600 text-white px-8 py-3 rounded-xl font-medium shadow-lg hover:shadow-xl transition-all"
                  >
                    <CheckCircle className="w-5 h-5 mr-2" />
                    Save contact
                  </Button>
                </div>
              </TabsContent>

              <TabsContent value="csv" className="mt-8">
                <div className="space-y-6">
                  <div className="text-center">
                    <button
                      onClick={downloadSampleCSV}
                      className="inline-flex items-center text-green-500 hover:text-green-600 text-sm font-medium hover:bg-green-50 px-4 py-2 rounded-lg transition-colors"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Download sample CSV
                    </button>
                  </div>

                  <div
                    className="border-2 border-dashed border-gray-200 rounded-xl p-12 text-center hover:border-green-300 transition-colors cursor-pointer"
                    onClick={handleFileSelect}
                  >
                    <div className="flex flex-col items-center space-y-4">
                      <div className="w-16 h-16 bg-green-50 rounded-2xl flex items-center justify-center">
                        <Upload className="w-8 h-8 text-green-500" />
                      </div>
                      <div>
                        <p className="text-gray-700 font-medium mb-1">
                          {selectedFile ? selectedFile.name : 'Select CSV file'}
                        </p>
                        {selectedFile ? (
                          <p className="text-sm text-green-600">
                            File selected successfully
                          </p>
                        ) : (
                          <p className="text-sm text-gray-500">
                            Click to browse or drag and drop
                          </p>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-center pt-2">
                    <Button
                      onClick={handleImportCSV}
                      disabled={!selectedFile}
                      className="bg-green-500 hover:bg-green-600 text-white px-8 py-3 rounded-xl font-medium shadow-lg hover:shadow-xl transition-all disabled:bg-gray-200 disabled:text-gray-400 disabled:cursor-not-allowed disabled:shadow-none"
                    >
                      <Upload className="w-5 h-5 mr-2" />
                      Import CSV
                    </Button>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};
