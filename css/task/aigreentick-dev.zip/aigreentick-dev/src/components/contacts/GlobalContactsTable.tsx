import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from '@/components/ui/pagination';
import { Label } from '@/components/ui/label';
import {
  Users,
  Plus,
  Search,
  Upload,
  Download,
  Trash2,
  Edit3,
  MoreHorizontal,
  Loader2,
  CheckCircle,
  XCircle,
  MessageSquare,
  Radio,
  AlertTriangle,
  X,
  Save,
  Phone,
  UserPlus,
} from 'lucide-react';
import {
  fetchContacts,
  deleteContact,
  updateContact,
  selectContacts,
  selectContactsPagination,
  selectContactsLoading,
  selectContactsError,
  selectContactsDeleting,
  selectContactsUpdating,
  clearError,
  setSearchTerm,
  selectContactsSearchTerm,
} from '@/redux/contactSlice';
import WarningComponent from '@/components/ui/warning';
import type { ContactData, UpdateContactData } from '@/services/api';
import 'react-phone-number-input/style.css';
import PhoneInput from 'react-phone-number-input';

interface GlobalContactsTableProps {
  onAddContact: () => void;
  onEditContact?: (contact: ContactData) => void;
  onExportContacts: () => void;
  onImportContacts: () => void;
  onOpenWhatsAppModal?: (contact: ContactData) => void;
}

type SortOption = 'Last Updated' | 'Name' | 'Phone Number';

interface EditContactForm {
  name: string;
  phone_number: string;
  allowed_broadcast: boolean;
  allowed_sms: boolean;
  attributes: Array<{ key: string; value: string }>;
}

export const GlobalContactsTable: React.FC<GlobalContactsTableProps> = ({
  onAddContact,
  onEditContact,
  onExportContacts,
  onImportContacts,
  onOpenWhatsAppModal,
}) => {
  const dispatch = useDispatch();

  // Redux selectors
  const contacts = useSelector(selectContacts);
  const pagination = useSelector(selectContactsPagination);
  const isLoading = useSelector(selectContactsLoading);
  const isDeleting = useSelector(selectContactsDeleting);
  const isUpdating = useSelector(selectContactsUpdating);
  const error = useSelector(selectContactsError);
  const searchTerm = useSelector(selectContactsSearchTerm);

  const [selectedContacts, setSelectedContacts] = useState<Set<number>>(
    new Set()
  );
  const [sortBy, setSortBy] = useState<SortOption>('Last Updated');
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [searchInput, setSearchInput] = useState('');
  const [searchDebounce, setSearchDebounce] = useState<NodeJS.Timeout | null>(
    null
  );

  // Delete confirmation dialog state
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [contactToDelete, setContactToDelete] = useState<ContactData | null>(
    null
  );

  // Edit dialog state
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [contactToEdit, setContactToEdit] = useState<ContactData | null>(null);
  const [editForm, setEditForm] = useState<EditContactForm>({
    name: '',
    phone_number: '',
    allowed_broadcast: true,
    allowed_sms: false,
    attributes: [],
  });
  const [showSuccess, setShowSuccess] = useState(false);

  // Load contacts on component mount
  useEffect(() => {
    dispatch(fetchContacts({ page: 1, per_page: rowsPerPage }) as any);
  }, [dispatch, rowsPerPage]);

  // Handle search with debounce
  useEffect(() => {
    if (searchDebounce) {
      clearTimeout(searchDebounce);
    }

    const timeout = setTimeout(() => {
      // Updated: Use fetchContacts with search parameter instead of separate searchContacts
      if (searchInput.trim()) {
        dispatch(
          fetchContacts({
            page: 1,
            per_page: rowsPerPage,
            search: searchInput.trim(),
          }) as any
        );
      } else {
        dispatch(fetchContacts({ page: 1, per_page: rowsPerPage }) as any);
      }
      dispatch(setSearchTerm(searchInput));
    }, 500);

    setSearchDebounce(timeout);

    return () => {
      if (timeout) clearTimeout(timeout);
    };
  }, [searchInput, dispatch, rowsPerPage]);

  // Auto-hide success message
  useEffect(() => {
    if (showSuccess) {
      const timer = setTimeout(() => {
        setShowSuccess(false);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [showSuccess]);

  // Clear error when component unmounts
  useEffect(() => {
    return () => {
      dispatch(clearError());
    };
  }, [dispatch]);

  const handleContactSelect = (contactId: number) => {
    const newSelected = new Set(selectedContacts);
    if (newSelected.has(contactId)) {
      newSelected.delete(contactId);
    } else {
      newSelected.add(contactId);
    }
    setSelectedContacts(newSelected);
  };

  const handleSelectAll = () => {
    if (selectedContacts.size === contacts.length && contacts.length > 0) {
      setSelectedContacts(new Set());
    } else {
      setSelectedContacts(new Set(contacts.map((contact) => contact.id)));
    }
  };

  // Fixed: Updated handlePageChange to include search parameters
  const handlePageChange = (page: number) => {
    const params: { page: number; per_page: number; search?: string } = {
      page,
      per_page: rowsPerPage,
    };

    // Include search term if it exists
    if (searchTerm.trim()) {
      params.search = searchTerm.trim();
    }

    dispatch(fetchContacts(params) as any);
    setSelectedContacts(new Set());
  };

  const handleRowsPerPageChange = (rows: number) => {
    setRowsPerPage(rows);
    setSelectedContacts(new Set());

    // Updated: Include search term when changing rows per page
    const params: { page: number; per_page: number; search?: string } = {
      page: 1,
      per_page: rows,
    };

    if (searchTerm.trim()) {
      params.search = searchTerm.trim();
    }

    dispatch(fetchContacts(params) as any);
  };

  // Delete handlers
  const handleDeleteClick = (contact: ContactData) => {
    setContactToDelete(contact);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!contactToDelete) return;

    try {
      await dispatch(deleteContact(contactToDelete.id) as any);
      setDeleteDialogOpen(false);
      setContactToDelete(null);

      // Remove from selected if it was selected
      const newSelected = new Set(selectedContacts);
      newSelected.delete(contactToDelete.id);
      setSelectedContacts(newSelected);

      console.log(`Contact "${contactToDelete.name}" deleted successfully`);
    } catch (error) {
      console.error('Failed to delete contact:', error);
    }
  };

  const handleDeleteCancel = () => {
    setDeleteDialogOpen(false);
    setContactToDelete(null);
  };

  const handleDeleteSelected = async () => {
    if (selectedContacts.size === 0) return;

    if (
      window.confirm(
        `Are you sure you want to delete ${selectedContacts.size} contact(s)?`
      )
    ) {
      const deletePromises = Array.from(selectedContacts).map((contactId) =>
        dispatch(deleteContact(contactId) as any)
      );

      await Promise.all(deletePromises);
      setSelectedContacts(new Set());
    }
  };

  // Edit handlers
  const handleEditClick = (contact: ContactData) => {
    setContactToEdit(contact);

    // Convert contact attributes to form format
    const attributesArray = contact.attributes.map((attr) => ({
      key: attr.attribute,
      value: attr.attribute_value,
    }));

    setEditForm({
      name: contact.name,
      phone_number: contact.mobile,
      allowed_broadcast: true, // Default values since API doesn't return these
      allowed_sms: false,
      attributes: attributesArray,
    });
    setEditDialogOpen(true);
    dispatch(clearError());
    setShowSuccess(false);
  };

  const handleEditFormChange = (
    field: keyof Omit<EditContactForm, 'attributes'>,
    value: string | boolean
  ) => {
    setEditForm((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleAttributeChange = (
    index: number,
    field: 'key' | 'value',
    value: string
  ) => {
    setEditForm((prev) => ({
      ...prev,
      attributes: prev.attributes.map((attr, i) =>
        i === index ? { ...attr, [field]: value } : attr
      ),
    }));
  };

  const addAttribute = () => {
    setEditForm((prev) => ({
      ...prev,
      attributes: [...prev.attributes, { key: '', value: '' }],
    }));
  };

  const removeAttribute = (index: number) => {
    setEditForm((prev) => ({
      ...prev,
      attributes: prev.attributes.filter((_, i) => i !== index),
    }));
  };

  const handleEditSave = async () => {
    if (!contactToEdit) return;

    dispatch(clearError());
    setShowSuccess(false);

    // Prepare attributes object (only include non-empty key-value pairs)
    const attributes: Record<string, string> = {};
    editForm.attributes.forEach((attr) => {
      if (attr.key.trim() && attr.value.trim()) {
        attributes[attr.key.trim()] = attr.value.trim();
      }
    });

    const updateData: UpdateContactData = {
      name: editForm.name.trim(),
      phone_number: editForm.phone_number.trim(),
      allowed_broadcast: editForm.allowed_broadcast,
      allowed_sms: editForm.allowed_sms,
      ...(Object.keys(attributes).length > 0 && { attributes }),
    };

    try {
      await dispatch(
        updateContact({ id: contactToEdit.id, data: updateData }) as any
      ).unwrap();

      setShowSuccess(true);
      setTimeout(() => {
        setEditDialogOpen(false);
        setContactToEdit(null);
        setShowSuccess(false);
      }, 1500);

      if (onEditContact) {
        onEditContact(contactToEdit);
      }
    } catch (error) {
      console.error('Failed to update contact:', error);
    }
  };

  const handleEditCancel = () => {
    if (!isUpdating) {
      setEditDialogOpen(false);
      setContactToEdit(null);
      dispatch(clearError());
      setShowSuccess(false);
    }
  };

  const handleSortChange = (sort: SortOption) => {
    setSortBy(sort);
  };

  const hasWhatsApp = (contact: ContactData) => {
    return contact.mobile && contact.mobile.length > 0;
  };

  // Enhanced pagination logic - Fixed to work with search
  const generatePaginationItems = () => {
    const currentPage = pagination?.current_page || 1;
    const totalPages = pagination?.last_page || 1;
    const items = [];

    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) {
        items.push(
          <PaginationItem key={i}>
            <PaginationLink
              onClick={() => handlePageChange(i)}
              isActive={currentPage === i}
              className="cursor-pointer"
            >
              {i}
            </PaginationLink>
          </PaginationItem>
        );
      }
    } else {
      items.push(
        <PaginationItem key={1}>
          <PaginationLink
            onClick={() => handlePageChange(1)}
            isActive={currentPage === 1}
            className="cursor-pointer"
          >
            1
          </PaginationLink>
        </PaginationItem>
      );

      if (currentPage > 4) {
        items.push(
          <PaginationItem key="start-ellipsis">
            <PaginationEllipsis />
          </PaginationItem>
        );
      }

      const start = Math.max(2, currentPage - 1);
      const end = Math.min(totalPages - 1, currentPage + 1);

      for (let i = start; i <= end; i++) {
        items.push(
          <PaginationItem key={i}>
            <PaginationLink
              onClick={() => handlePageChange(i)}
              isActive={currentPage === i}
              className="cursor-pointer"
            >
              {i}
            </PaginationLink>
          </PaginationItem>
        );
      }

      if (currentPage < totalPages - 3) {
        items.push(
          <PaginationItem key="end-ellipsis">
            <PaginationEllipsis />
          </PaginationItem>
        );
      }

      if (totalPages > 1) {
        items.push(
          <PaginationItem key={totalPages}>
            <PaginationLink
              onClick={() => handlePageChange(totalPages)}
              isActive={currentPage === totalPages}
              className="cursor-pointer"
            >
              {totalPages}
            </PaginationLink>
          </PaginationItem>
        );
      }
    }

    return items;
  };

  const currentPage = pagination?.current_page || 1;
  const totalPages = pagination?.last_page || 1;
  const totalContacts = pagination?.total || 0;

  const isEditFormValid = editForm.name.trim() && editForm.phone_number.trim();

  if (error && !editDialogOpen) {
    return (
      <Card className="border-0 bg-card shadow-none">
        <CardContent className="pt-6">
          <div className="text-center py-8">
            <div className="text-destructive mb-2">Error loading contacts</div>
            <div className="text-sm text-muted-foreground mb-4">{error}</div>
            <Button
              onClick={() =>
                dispatch(
                  fetchContacts({ page: 1, per_page: rowsPerPage }) as any
                )
              }
              variant="outline"
            >
              Try Again
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className="border-0 bg-card shadow-none">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center text-3xl font-semibold text-card-foreground">
              <div className="w-5 text-3xl h-5 bg-primary rounded flex items-center justify-center mr-3">
                <Users className="w-3   h-3 text-primary-foreground" />
              </div>
              Contacts
              <span className="ml-2 text-sm text-muted-foreground">
                ({totalContacts} in total)
              </span>
            </CardTitle>
            <div className="flex items-center space-x-2">
              <Button
                onClick={onAddContact}
                className="bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Contact
              </Button>
            </div>
          </div>
          <p className="text-sm text-muted-foreground mt-2">
            Contact list stores the list of numbers that you've interacted with.
            You can even manually export or import contacts.
          </p>
        </CardHeader>

        <CardContent className="pt-0">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <label className="text-sm font-medium text-card-foreground">
                  Sorted by:
                </label>
                <Select value={sortBy} onValueChange={handleSortChange}>
                  <SelectTrigger className="w-40 border-input bg-background">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border-border">
                    <SelectItem value="Last Updated">Last Updated</SelectItem>
                    <SelectItem value="Name">Name</SelectItem>
                    <SelectItem value="Phone Number">Phone Number</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="w-4 h-4 text-muted-foreground" />
                </div>
                <Input
                  placeholder="Search contacts..."
                  value={searchInput}
                  onChange={(e) => setSearchInput(e.target.value)}
                  className="pl-10 w-64 border-input bg-background"
                />
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" onClick={onExportContacts}>
                <Upload className="w-4 h-4 mr-2" />
                Export
              </Button>
              <Button variant="outline" size="sm" onClick={onImportContacts}>
                <Download className="w-4 h-4 mr-2" />
                Import
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="text-destructive border-destructive/30 hover:bg-destructive hover:text-destructive-foreground"
                onClick={handleDeleteSelected}
                disabled={selectedContacts.size === 0 || isDeleting}
              >
                {isDeleting ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Trash2 className="w-4 h-4" />
                )}
                {selectedContacts.size > 0 && ` (${selectedContacts.size})`}
              </Button>
            </div>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin mr-2" />
              <span className="text-muted-foreground">Loading contacts...</span>
            </div>
          ) : (
            <>
              <div className="rounded-lg overflow-hidden border border-border">
                <Table>
                  <TableHeader>
                    <TableRow className="border-b border-border bg-muted/50">
                      <TableHead className="w-12">
                        <Checkbox
                          checked={
                            selectedContacts.size === contacts.length &&
                            contacts.length > 0
                          }
                          onCheckedChange={handleSelectAll}
                        />
                      </TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Phone Number</TableHead>
                      <TableHead>Permissions</TableHead>
                      <TableHead>Attributes</TableHead>
                      <TableHead className="w-12">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {contacts.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8">
                          <div className="text-muted-foreground">
                            {searchTerm
                              ? 'No contacts found matching your search.'
                              : 'No contacts found. Click "Add Contact" to get started.'}
                          </div>
                        </TableCell>
                      </TableRow>
                    ) : (
                      contacts.map((contact) => (
                        <TableRow
                          key={contact.id}
                          className="hover:bg-muted/50 border-b border-border"
                        >
                          <TableCell>
                            <Checkbox
                              checked={selectedContacts.has(contact.id)}
                              onCheckedChange={() =>
                                handleContactSelect(contact.id)
                              }
                            />
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center space-x-3">
                              <div className="text-sm font-medium text-foreground">
                                {contact.name}
                              </div>
                              {hasWhatsApp(contact) && (
                                <button
                                  onClick={() => onOpenWhatsAppModal?.(contact)}
                                  className="hover:scale-110 transition-transform cursor-pointer"
                                  title="Send WhatsApp message"
                                >
                                  <svg
                                    xmlns="http://www.w3.org/2000/svg"
                                    width="16"
                                    height="16"
                                    viewBox="0 0 16 16"
                                    fill="none"
                                  >
                                    <g clipPath="url(#clip0_1092_5761)">
                                      <path
                                        d="M8.00018 0.640015C3.94194 0.640015 0.640184 3.94177 0.640184 8.00001C0.640184 9.26721 0.967544 10.5133 1.58834 11.6128L0.652024 14.9536C0.621304 15.0634 0.651064 15.1811 0.730424 15.2627C0.791544 15.3258 0.874744 15.36 0.960184 15.36C0.985784 15.36 1.0117 15.3568 1.03698 15.3507L4.5237 14.4871C5.58834 15.0586 6.78738 15.36 8.00018 15.36C12.0584 15.36 15.3602 12.0583 15.3602 8.00001C15.3602 3.94177 12.0584 0.640015 8.00018 0.640015ZM11.7026 10.5971C11.5451 11.033 10.7899 11.4307 10.4271 11.4842C10.1013 11.5319 9.68914 11.5523 9.23666 11.4103C8.96242 11.3239 8.61042 11.2093 8.15954 11.017C6.26418 10.2087 5.02642 8.32417 4.9317 8.19969C4.8373 8.07521 4.16018 7.18817 4.16018 6.27009C4.16018 5.35201 4.64818 4.90049 4.82162 4.71361C4.99506 4.52673 5.19954 4.48001 5.32562 4.48001C5.4517 4.48001 5.57746 4.48161 5.68786 4.48673C5.80402 4.49249 5.95986 4.44289 6.11314 4.80705C6.27058 5.18081 6.6485 6.09889 6.69522 6.19265C6.74258 6.28609 6.77394 6.39521 6.71122 6.51969C6.6485 6.64417 6.61714 6.72193 6.52242 6.83105C6.4277 6.94017 6.32402 7.07425 6.2389 7.15809C6.14418 7.25121 6.04594 7.35201 6.15602 7.53889C6.2661 7.72577 6.6453 8.33665 7.20722 8.83137C7.92882 9.46689 8.53778 9.66401 8.72658 9.75745C8.91538 9.85089 9.02578 9.83521 9.13586 9.71073C9.24594 9.58593 9.60818 9.16577 9.73394 8.97921C9.8597 8.79265 9.98578 8.82337 10.1592 8.88577C10.3327 8.94785 11.2616 9.39905 11.4504 9.49249C11.6392 9.58593 11.7653 9.63265 11.8127 9.71041C11.86 9.78785 11.86 10.1616 11.7026 10.5971Z"
                                        fill="#2CB742"
                                      ></path>
                                    </g>
                                    <defs>
                                      <clipPath id="clip0_1092_5761">
                                        <rect
                                          width="16"
                                          height="16"
                                          fill="white"
                                        ></rect>
                                      </clipPath>
                                    </defs>
                                  </svg>
                                </button>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center space-x-2">
                              <span className="text-sm text-foreground">
                                {contact.mobile}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center space-x-2">
                              <div
                                className="flex items-center space-x-1"
                                title="Broadcast allowed"
                              >
                                <Radio className="w-3 h-3 text-primary" />
                                <CheckCircle className="w-3 h-3 text-green-500" />
                              </div>
                              <div
                                className="flex items-center space-x-1"
                                title="SMS allowed"
                              >
                                <MessageSquare className="w-3 h-3 text-secondary" />
                                <XCircle className="w-3 h-3 text-red-500" />
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            {contact.attributes.length > 0 ? (
                              <div className="flex flex-wrap gap-1">
                                {contact.attributes.map((attr) => (
                                  <Badge
                                    key={attr.id}
                                    variant="outline"
                                    className="text-xs bg-muted border-border"
                                  >
                                    {attr.attribute}: {attr.attribute_value}
                                  </Badge>
                                ))}
                              </div>
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )}
                          </TableCell>
                          <TableCell>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-8 w-8 p-0"
                                >
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent
                                align="end"
                                className="bg-popover border-border"
                              >
                                <DropdownMenuItem
                                  onClick={() => handleEditClick(contact)}
                                >
                                  <Edit3 className="w-4 h-4 mr-2" />
                                  Edit
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  onClick={() => handleDeleteClick(contact)}
                                  className="text-destructive focus:text-destructive"
                                  disabled={isDeleting}
                                >
                                  {isDeleting &&
                                  contactToDelete?.id === contact.id ? (
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                  ) : (
                                    <Trash2 className="w-4 h-4 mr-2" />
                                  )}
                                  Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>

              {/* Enhanced Pagination */}
              {pagination && pagination.total > 0 && (
                <div className="flex items-center justify-between mt-6">
                  <div className="flex items-center space-x-4">
                    <span className="text-sm text-muted-foreground">
                      Rows per page:
                    </span>
                    <Select
                      value={rowsPerPage.toString()}
                      onValueChange={(value) => {
                        handleRowsPerPageChange(Number(value));
                      }}
                    >
                      <SelectTrigger className="w-20 border-input bg-background">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-popover border-border">
                        <SelectItem value="5">5</SelectItem>
                        <SelectItem value="10">10</SelectItem>
                        <SelectItem value="20">20</SelectItem>
                        <SelectItem value="50">50</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center space-x-4">
                    <span className="text-sm text-muted-foreground">
                      Page {currentPage} of {totalPages} ({pagination.from}-
                      {pagination.to} of {pagination.total})
                    </span>
                    <Pagination>
                      <PaginationContent>
                        <PaginationItem>
                          <PaginationPrevious
                            onClick={() =>
                              handlePageChange(Math.max(1, currentPage - 1))
                            }
                            className={
                              currentPage === 1
                                ? 'pointer-events-none opacity-50'
                                : 'cursor-pointer'
                            }
                          />
                        </PaginationItem>

                        {generatePaginationItems()}

                        <PaginationItem>
                          <PaginationNext
                            onClick={() =>
                              handlePageChange(
                                Math.min(totalPages, currentPage + 1)
                              )
                            }
                            className={
                              currentPage === totalPages
                                ? 'pointer-events-none opacity-50'
                                : 'cursor-pointer'
                            }
                          />
                        </PaginationItem>
                      </PaginationContent>
                    </Pagination>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent className="bg-card border-border">
          <AlertDialogHeader>
            <div className="flex items-center space-x-2">
              <div className="w-12 h-12 rounded-full bg-red-100 dark:bg-red-900/20 flex items-center justify-center">
                <AlertTriangle className="w-6 h-6 text-red-600 dark:text-red-400" />
              </div>
              <div>
                <AlertDialogTitle className="text-foreground">
                  Delete Contact
                </AlertDialogTitle>
                <AlertDialogDescription className="text-muted-foreground">
                  This action cannot be undone.
                </AlertDialogDescription>
              </div>
            </div>
          </AlertDialogHeader>

          {contactToDelete && (
            <div className="my-4 p-4 bg-muted/50 rounded-lg border border-border">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground">
                    Contact Name:
                  </span>
                  <span className="text-sm text-muted-foreground font-mono">
                    {contactToDelete.name}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground">
                    Phone Number:
                  </span>
                  <span className="text-sm text-muted-foreground font-mono">
                    {contactToDelete.mobile}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground">
                    Contact ID:
                  </span>
                  <span className="text-sm text-muted-foreground font-mono">
                    {contactToDelete.id}
                  </span>
                </div>
                {contactToDelete.attributes.length > 0 && (
                  <div className="flex items-start justify-between">
                    <span className="text-sm font-medium text-foreground">
                      Attributes:
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {contactToDelete.attributes.slice(0, 3).map((attr) => (
                        <Badge
                          key={attr.id}
                          variant="outline"
                          className="text-xs bg-muted border-border"
                        >
                          {attr.attribute}: {attr.attribute_value}
                        </Badge>
                      ))}
                      {contactToDelete.attributes.length > 3 && (
                        <Badge
                          variant="outline"
                          className="text-xs bg-muted border-border"
                        >
                          +{contactToDelete.attributes.length - 3} more
                        </Badge>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          <AlertDialogDescription className="text-muted-foreground">
            Are you sure you want to delete this contact? This will permanently
            remove the contact from your account and it cannot be recovered. Any
            campaign history with this contact will remain but the contact
            information will be lost.
          </AlertDialogDescription>

          <AlertDialogFooter className="flex items-center space-x-2">
            <AlertDialogCancel
              onClick={handleDeleteCancel}
              disabled={isDeleting}
              className="border-border hover:bg-accent"
            >
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteConfirm}
              disabled={isDeleting}
              className="bg-red-600 hover:bg-red-700 text-white border-red-600 hover:border-red-700"
            >
              {isDeleting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Deleting...
                </>
              ) : (
                <>
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete Contact
                </>
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Edit Contact Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={handleEditCancel}>
        <DialogContent className="max-w-md mx-auto bg-card border-border shadow-none rounded-xl p-0 overflow-hidden">
          <DialogHeader className="p-6 border-b border-border">
            <div className="flex items-center space-x-3">
              <div className="w-6 h-6 bg-primary rounded-lg flex items-center justify-center">
                <Edit3 className="w-4 h-4 text-primary-foreground" />
              </div>
              <div>
                <DialogTitle className="text-lg font-semibold text-card-foreground">
                  Edit Contact
                </DialogTitle>
                <DialogDescription className="text-muted-foreground">
                  Update contact information and attributes
                </DialogDescription>
              </div>
            </div>
          </DialogHeader>

          {/* Success Warning */}
          {showSuccess && (
            <div className="mx-6 mt-4">
              <WarningComponent
                type="success"
                title="Contact Updated Successfully!"
                message="The contact information has been updated."
                size="sm"
                rounded={true}
                bordered={true}
                showIcon={true}
              />
            </div>
          )}

          {/* Error Warning */}
          {error && editDialogOpen && (
            <div className="mx-6 mt-4">
              <WarningComponent
                type="error"
                title="Failed to Update Contact"
                message={error}
                size="sm"
                rounded={true}
                bordered={true}
                showIcon={true}
                dismissible={true}
                onClose={() => dispatch(clearError())}
                actions={[
                  {
                    label: 'Retry',
                    onClick: handleEditSave,
                    variant: 'default',
                    loading: isUpdating,
                    disabled: !isEditFormValid,
                  },
                  {
                    label: 'Cancel',
                    onClick: () => dispatch(clearError()),
                    variant: 'outline',
                  },
                ]}
              />
            </div>
          )}

          <div className="p-6 space-y-4">
            {/* Basic Information */}
            <div className="space-y-4">
              <div>
                <Label className="text-sm font-medium text-card-foreground mb-2 block">
                  Contact Name *
                </Label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <UserPlus className="w-4 h-4 text-muted-foreground" />
                  </div>
                  <Input
                    value={editForm.name}
                    onChange={(e) =>
                      handleEditFormChange('name', e.target.value)
                    }
                    className="pl-10 h-11 border-input bg-background focus:border-primary focus:ring-2 focus:ring-primary/20 rounded-lg"
                    placeholder="Enter contact name"
                    disabled={isUpdating}
                  />
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium text-card-foreground mb-2 block">
                  Phone Number *
                </Label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Phone className="w-4 h-4 text-muted-foreground" />
                  </div>
                  <Input
                    value={editForm.phone_number}
                    onChange={(e) =>
                      handleEditFormChange('phone_number', e.target.value)
                    }
                    className="pl-10 h-11 border-input bg-background focus:border-primary focus:ring-2 focus:ring-primary/20 rounded-lg"
                    placeholder="e.g., 9876543217"
                    disabled={isUpdating}
                  />
                </div>
              </div>

              {/* Communication Preferences */}
              <div className="space-y-3">
                <Label className="text-sm font-medium text-card-foreground">
                  Communication Preferences
                </Label>
                <div className="flex items-center space-x-6">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="edit-broadcast"
                      checked={editForm.allowed_broadcast}
                      onCheckedChange={(checked) =>
                        handleEditFormChange(
                          'allowed_broadcast',
                          checked as boolean
                        )
                      }
                      disabled={isUpdating}
                    />
                    <Label
                      htmlFor="edit-broadcast"
                      className="text-sm text-card-foreground"
                    >
                      Allow Broadcast
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="edit-sms"
                      checked={editForm.allowed_sms}
                      onCheckedChange={(checked) =>
                        handleEditFormChange('allowed_sms', checked as boolean)
                      }
                      disabled={isUpdating}
                    />
                    <Label
                      htmlFor="edit-sms"
                      className="text-sm text-card-foreground"
                    >
                      Allow SMS
                    </Label>
                  </div>
                </div>
              </div>
            </div>

            {/* Custom Attributes */}
            <div className="space-y-4">
              <Label className="text-sm font-medium text-card-foreground">
                Custom Attributes (Optional)
              </Label>

              {editForm.attributes.map((attr, index) => (
                <div key={index} className="flex gap-2">
                  <Input
                    placeholder="Key (e.g., city)"
                    value={attr.key}
                    onChange={(e) =>
                      handleAttributeChange(index, 'key', e.target.value)
                    }
                    className="border-input bg-background"
                    disabled={isUpdating}
                  />
                  <Input
                    placeholder="Value (e.g., Delhi)"
                    value={attr.value}
                    onChange={(e) =>
                      handleAttributeChange(index, 'value', e.target.value)
                    }
                    className="border-input bg-background"
                    disabled={isUpdating}
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => removeAttribute(index)}
                    className="text-destructive hover:text-destructive border-destructive/30 hover:bg-destructive/10"
                    disabled={isUpdating}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              ))}

              <Button
                variant="outline"
                size="sm"
                onClick={addAttribute}
                className="text-primary hover:text-primary border-primary/30 hover:bg-primary/10"
                disabled={isUpdating}
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Attribute
              </Button>
            </div>
          </div>

          <DialogFooter className="p-6 border-t border-border flex items-center space-x-2">
            <Button
              variant="outline"
              onClick={handleEditCancel}
              disabled={isUpdating}
              className="border-border hover:bg-accent"
            >
              Cancel
            </Button>
            <Button
              onClick={handleEditSave}
              disabled={!isEditFormValid || isUpdating}
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              {isUpdating ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Updating...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  Update Contact
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};
