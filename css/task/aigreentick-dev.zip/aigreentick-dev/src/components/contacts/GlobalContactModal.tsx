import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { X, Plus, Loader2, CheckCircle, RefreshCw } from 'lucide-react';
import {
  createContact,
  selectContactsCreating,
  selectContactsError,
  clearError,
} from '@/redux/contactSlice';
import WarningComponent from '@/components/ui/warning';
import type { CreateContactData } from '@/services/api';
import 'react-phone-number-input/style.css';
import PhoneInput from 'react-phone-number-input';

interface GlobalContactFormData {
  name: string;
  mobile: string;
  attributes: Array<{ key: string; value: string }>;
}

interface GlobalContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave?: (contact: GlobalContactFormData) => void; // Optional callback for additional handling
}

export const GlobalContactModal: React.FC<GlobalContactModalProps> = ({
  isOpen,
  onClose,
  onSave,
}) => {
  const dispatch = useDispatch();
  const isCreating = useSelector(selectContactsCreating);
  const error = useSelector(selectContactsError);

  const [globalContactForm, setGlobalContactForm] =
    useState<GlobalContactFormData>({
      name: '',
      mobile: '',
      attributes: [],
    });

  const [preferences, setPreferences] = useState({
    allowed_broadcast: true,
    allowed_sms: false,
  });

  const [showSuccess, setShowSuccess] = useState(false);

  // Clear error and success when modal opens
  useEffect(() => {
    if (isOpen) {
      dispatch(clearError());
      setShowSuccess(false);
    }
  }, [isOpen, dispatch]);

  // Auto-hide success message after 3 seconds
  useEffect(() => {
    if (showSuccess) {
      const timer = setTimeout(() => {
        setShowSuccess(false);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [showSuccess]);

  const handleGlobalContactFormChange = (
    field: keyof Omit<GlobalContactFormData, 'attributes'>,
    value: string
  ) => {
    setGlobalContactForm((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handlePreferenceChange = (
    field: keyof typeof preferences,
    value: boolean
  ) => {
    setPreferences((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const addCustomAttribute = () => {
    setGlobalContactForm((prev) => ({
      ...prev,
      attributes: [...prev.attributes, { key: '', value: '' }],
    }));
  };

  const updateCustomAttribute = (
    index: number,
    field: 'key' | 'value',
    value: string
  ) => {
    setGlobalContactForm((prev) => ({
      ...prev,
      attributes: prev.attributes.map((attr, i) =>
        i === index ? { ...attr, [field]: value } : attr
      ),
    }));
  };

  const removeCustomAttribute = (index: number) => {
    setGlobalContactForm((prev) => ({
      ...prev,
      attributes: prev.attributes.filter((_, i) => i !== index),
    }));
  };

  const resetForm = () => {
    setGlobalContactForm({
      name: '',
      mobile: '',
      attributes: [],
    });
    setPreferences({
      allowed_broadcast: true,
      allowed_sms: false,
    });
  };

  const handleSaveGlobalContact = async () => {
    // Clear any existing errors/success
    dispatch(clearError());
    setShowSuccess(false);

    // Prepare attributes object (only include non-empty key-value pairs)
    const attributes: Record<string, string> = {};
    globalContactForm.attributes.forEach((attr) => {
      if (attr.key.trim() && attr.value.trim()) {
        attributes[attr.key.trim()] = attr.value.trim();
      }
    });

    // Prepare contact data for API
    const contactData: CreateContactData = {
      name: globalContactForm.name.trim(),
      phone_number: globalContactForm.mobile.trim(),
      allowed_broadcast: preferences.allowed_broadcast,
      allowed_sms: preferences.allowed_sms,
      ...(Object.keys(attributes).length > 0 && { attributes }),
    };

    try {
      console.log('Creating contact with data:', contactData);
      const result = await dispatch(createContact(contactData) as any).unwrap();

      console.log('Contact created successfully:', result);

      // Call optional callback
      if (onSave) {
        onSave(globalContactForm);
      }

      // Success - show success message briefly, then reset form and close modal
      setShowSuccess(true);

      // Delay the form reset and modal close to show success message
      setTimeout(() => {
        resetForm();
        onClose();
        setShowSuccess(false);
      }, 1500);
    } catch (error: any) {
      console.error('Failed to create contact:', error);
      // Error will be handled by Redux state and displayed in warning component
    }
  };

  const handleRetryCreate = () => {
    dispatch(clearError());
    handleSaveGlobalContact();
  };

  const handleClose = () => {
    if (!isCreating) {
      resetForm();
      dispatch(clearError());
      setShowSuccess(false);
      onClose();
    }
  };

  const isFormValid =
    globalContactForm.name.trim() && globalContactForm.mobile.trim();

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-md mx-auto bg-card border-0 shadow-none rounded-xl p-0 overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b border-border">
          <DialogTitle className="text-lg font-semibold text-card-foreground">
            Add Contact
          </DialogTitle>
         
        </div>

        {/* Success Warning */}
        {showSuccess && (
          <div className="mx-6 mt-4">
            <WarningComponent
              type="success"
              title="Contact Created Successfully!"
              message="The contact has been added to your contact list."
              size="sm"
              rounded={true}
              bordered={true}
              showIcon={true}
            />
          </div>
        )}

        {/* Error Warning */}
        {error && (
          <div className="mx-6 mt-4">
            <WarningComponent
              type="error"
              title="Failed to Create Contact"
              message={error}
              size="sm"
              rounded={true}
              bordered={true}
              showIcon={true}
              dismissible={true}
              onClose={() => dispatch(clearError())}
              actions={[
                {
                  label: 'Retry',
                  onClick: handleRetryCreate,
                  icon: RefreshCw,
                  variant: 'default',
                  loading: isCreating,
                  disabled: !isFormValid,
                },
                {
                  label: 'Cancel',
                  onClick: () => dispatch(clearError()),
                  variant: 'outline',
                },
              ]}
            />
          </div>
        )}

        <div className="p-6 space-y-4">
          {/* Basic Information */}
          <div>
            <Label className="text-sm font-medium text-card-foreground mb-2 block">
              Name *
            </Label>
            <Input
              placeholder="Enter contact name"
              value={globalContactForm.name}
              onChange={(e) =>
                handleGlobalContactFormChange('name', e.target.value)
              }
              className="border-input bg-background focus:border-primary focus:ring-2 focus:ring-primary/20"
              disabled={isCreating}
            />
          </div>

          <div>
            <Label className="text-sm font-medium text-card-foreground mb-2 block">
              Phone Number *
            </Label>
            <PhoneInput
              international
              defaultCountry="IN"
              value={globalContactForm.mobile}
              onChange={(value) =>
                handleGlobalContactFormChange('mobile', value || '')
              }
              className="w-full px-3 py-2 phone-input border border-input rounded-md text-sm bg-background disabled:opacity-50"
              disabled={isCreating}
            />
          </div>

          {/* Communication Preferences */}
          <div className="space-y-3">
            <Label className="text-sm font-medium text-card-foreground">
              Communication Preferences
            </Label>
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="broadcast"
                  checked={preferences.allowed_broadcast}
                  onCheckedChange={(checked) =>
                    handlePreferenceChange(
                      'allowed_broadcast',
                      checked as boolean
                    )
                  }
                  disabled={isCreating}
                />
                <Label
                  htmlFor="broadcast"
                  className="text-sm text-card-foreground"
                >
                  Allow Broadcast
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="sms"
                  checked={preferences.allowed_sms}
                  onCheckedChange={(checked) =>
                    handlePreferenceChange('allowed_sms', checked as boolean)
                  }
                  disabled={isCreating}
                />
                <Label htmlFor="sms" className="text-sm text-card-foreground">
                  Allow SMS
                </Label>
              </div>
            </div>
          </div>

          {/* Custom Attributes */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <Label className="text-sm font-medium text-card-foreground">
                Custom Attributes (Optional)
              </Label>
            </div>

            {globalContactForm.attributes.map((attr, index) => (
              <div key={index} className="flex gap-2 mb-2">
                <Input
                  placeholder="Key (e.g., city)"
                  value={attr.key}
                  onChange={(e) =>
                    updateCustomAttribute(index, 'key', e.target.value)
                  }
                  className="border-input bg-background"
                  disabled={isCreating}
                />
                <Input
                  placeholder="Value (e.g., Delhi)"
                  value={attr.value}
                  onChange={(e) =>
                    updateCustomAttribute(index, 'value', e.target.value)
                  }
                  className="border-input bg-background"
                  disabled={isCreating}
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => removeCustomAttribute(index)}
                  className="text-destructive hover:text-destructive border-destructive/30 hover:bg-destructive/10"
                  disabled={isCreating}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            ))}

            <Button
              variant="outline"
              size="sm"
              onClick={addCustomAttribute}
              className="text-primary hover:text-primary border-primary/30 hover:bg-primary/10"
              disabled={isCreating}
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Attribute
            </Button>
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end space-x-3 pt-4">
            <Button
              variant="outline"
              onClick={handleClose}
              disabled={isCreating}
            >
              Cancel
            </Button>
            <Button
              onClick={handleSaveGlobalContact}
              disabled={!isFormValid || isCreating}
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              {isCreating ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Creating...
                </>
              ) : (
                <>
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Save Contact
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
