import React, { useState, useEffect } from 'react';
import {
  Contact,
  GlobalContact,
  ContactFormData,
  GlobalContactFormData,
  SortOption,
} from './types';
import { contacts, globalContacts, phonebooks } from './constants';
import { PhonebookSidebar } from './PhonebookSidebar';
import { AddContactModal } from './AddContactModal';
import { GlobalContactModal } from './GlobalContactModal';
import { AddPhonebookCard } from './AddPhonebookCard';
import { PhonebookContactsTable } from './PhonebookContactsTable';
import { GlobalContactsTable } from './GlobalContactsTable';
import {
  filterContacts,
  sortContacts,
  paginateContacts,
  getTotalPages,
  getStartIndex,
  exportContactsToCSV,
} from './utils';

const PhonebookContacts: React.FC = () => {
  const [phonebookContacts, setPhonebookContacts] =
    useState<Contact[]>(contacts);
  const [allGlobalContacts, setAllGlobalContacts] =
    useState<GlobalContact[]>(globalContacts);
  const [phonebookList, setPhonebookList] = useState(phonebooks);
  const [selectedContacts, setSelectedContacts] = useState<Set<number>>(
    new Set()
  );
  const [selectedGlobalContacts, setSelectedGlobalContacts] = useState<
    Set<number>
  >(new Set());
  const [showAddContactModal, setShowAddContactModal] = useState(false);
  const [showGlobalAddContactModal, setShowGlobalAddContactModal] =
    useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<SortOption>('Last Updated');
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const filteredGlobalContacts = filterContacts(allGlobalContacts, searchTerm);
  const sortedContacts = sortContacts(filteredGlobalContacts, sortBy);
  const totalPages = getTotalPages(sortedContacts.length, rowsPerPage);
  const startIndex = getStartIndex(currentPage, rowsPerPage);
  const paginatedContacts = paginateContacts(
    sortedContacts,
    currentPage,
    rowsPerPage
  );
  const handleContactSelect = (contactId: number) => {
    const newSelected = new Set(selectedContacts);
    if (newSelected.has(contactId)) {
      newSelected.delete(contactId);
    } else {
      newSelected.add(contactId);
    }
    setSelectedContacts(newSelected);
  };

  const handleGlobalContactSelect = (contactId: number) => {
    const newSelected = new Set(selectedGlobalContacts);
    if (newSelected.has(contactId)) {
      newSelected.delete(contactId);
    } else {
      newSelected.add(contactId);
    }
    setSelectedGlobalContacts(newSelected);
  };

  const handleSelectAll = () => {
    if (selectedContacts.size === phonebookContacts.length) {
      setSelectedContacts(new Set());
    } else {
      setSelectedContacts(new Set(phonebookContacts.map((c) => c.id)));
    }
  };

  const handleSelectAllGlobal = () => {
    if (
      selectedGlobalContacts.size === paginatedContacts.length &&
      paginatedContacts.length > 0
    ) {
      setSelectedGlobalContacts(new Set());
    } else {
      setSelectedGlobalContacts(new Set(paginatedContacts.map((c) => c.id)));
    }
  };
  const handleSaveContact = (contactData: ContactFormData) => {
    const newContact: Contact = {
      id: Date.now(),
      name: contactData.name,
      phonebook: 'Codeyon',
      mobile: contactData.mobile,
      var1: contactData.var1,
      var2: contactData.var2,
      var3: contactData.var3,
      var4: contactData.var4,
      added: new Date().toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      }),
    };

    setPhonebookContacts((prev) => [...prev, newContact]);
    console.log('Saving contact:', contactData);
  };

  const handleSaveGlobalContact = (contactData: GlobalContactFormData) => {
    const attributes: Record<string, string> = {};
    contactData.attributes.forEach((attr) => {
      if (attr.key && attr.value) {
        attributes[attr.key] = attr.value;
      }
    });

    const newContact: GlobalContact = {
      id: Date.now(),
      name: contactData.name,
      phone: contactData.mobile,
      source: 'Manual',
      attributes,
      hasWhatsApp: false,
    };

    setAllGlobalContacts((prev) => [...prev, newContact]);
    console.log('Saving global contact:', contactData);
  };

  const handleImportCSV = (file: File) => {
    console.log('Importing CSV:', file);
  };

  const handleAddPhonebook = (name: string) => {
    const newPhonebook = {
      name,
      daysAgo: 0,
      status: 'active',
    };
    setPhonebookList((prev) => [...prev, newPhonebook]);
    console.log('Adding phonebook:', name);
  };

  const handleDeletePhonebook = (phonebook: any) => {
    setPhonebookList((prev) => prev.filter((p) => p.name !== phonebook.name));
    console.log('Deleting phonebook:', phonebook);
  };

  const handleEditContact = (contact: Contact) => {
    console.log('Editing contact:', contact);
  };

  const handleEditGlobalContact = (contact: GlobalContact) => {
    console.log('Editing global contact:', contact);
  };

  const handleDeleteGlobalContact = (contactId: number) => {
    setAllGlobalContacts((prev) => prev.filter((c) => c.id !== contactId));
    console.log('Deleting contact:', contactId);
  };

  const handleExportContacts = () => {
    exportContactsToCSV(filteredGlobalContacts);
  };

  const handleImportContacts = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.csv';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        handleImportCSV(file);
      }
    };
    input.click();
  };

  const handleDeleteSelected = () => {
    if (selectedGlobalContacts.size > 0) {
      setAllGlobalContacts((prev) =>
        prev.filter((contact) => !selectedGlobalContacts.has(contact.id))
      );
      setSelectedGlobalContacts(new Set());
      console.log('Deleting contacts:', Array.from(selectedGlobalContacts));
    }
  };
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, sortBy]);

  return (
    <div className="flex min-h-screen bg-gray-50/50">
      {/* <PhonebookSidebar
        phonebooks={phonebookList}
        onAddContact={() => setShowAddContactModal(true)}
        onDeletePhonebook={handleDeletePhonebook}
      /> */}

      <AddContactModal
        isOpen={showAddContactModal}
        onClose={() => setShowAddContactModal(false)}
        onSaveContact={handleSaveContact}
        onImportCSV={handleImportCSV}
        phonebookName="Codeyon"
      />

      <GlobalContactModal
        isOpen={showGlobalAddContactModal}
        onClose={() => setShowGlobalAddContactModal(false)}
        onSave={handleSaveGlobalContact}
      />

      <div className="flex-1 overflow-hidden">
        <div className="h-full overflow-y-auto">
          <div className="p-6 space-y-6">
            {/* <AddPhonebookCard onAddPhonebook={handleAddPhonebook} /> */}

            {/* <PhonebookContactsTable
              contacts={phonebookContacts}
              selectedContacts={selectedContacts}
              onContactSelect={handleContactSelect}
              onSelectAll={handleSelectAll}
              onAddContact={() => setShowAddContactModal(true)}
              onEditContact={handleEditContact}
            /> */}

            <GlobalContactsTable
              contacts={allGlobalContacts}
              filteredContacts={filteredGlobalContacts}
              paginatedContacts={paginatedContacts}
              selectedContacts={selectedGlobalContacts}
              searchTerm={searchTerm}
              sortBy={sortBy}
              currentPage={currentPage}
              totalPages={totalPages}
              rowsPerPage={rowsPerPage}
              startIndex={startIndex}
              onContactSelect={handleGlobalContactSelect}
              onSelectAll={handleSelectAllGlobal}
              onSearchChange={setSearchTerm}
              onSortChange={setSortBy}
              onPageChange={setCurrentPage}
              onRowsPerPageChange={setRowsPerPage}
              onAddContact={() => setShowGlobalAddContactModal(true)}
              onEditContact={handleEditGlobalContact}
              onDeleteContact={handleDeleteGlobalContact}
              onExportContacts={handleExportContacts}
              onImportContacts={handleImportContacts}
              onDeleteSelected={handleDeleteSelected}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default PhonebookContacts;
