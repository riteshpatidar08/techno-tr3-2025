import { Contact, GlobalContact, Phonebook } from './types';

export const contacts: Contact[] = [
  {
    id: 1,
    name: 'codeyon',
    phonebook: 'Codeyon',
    mobile: '918430088300',
    var1: '',
    var2: '',
    var3: '',
    var4: '',
    added: '10 June 2025',
  },
  {
    id: 2,
    name: 'codeyon',
    phonebook: 'Codeyon',
    mobile: '918430088300',
    var1: '',
    var2: '',
    var3: '',
    var4: '',
    added: '10 June 2025',
  },
  {
    id: 3,
    name: 'codeyon',
    phonebook: 'Codeyon',
    mobile: '918430088300',
    var1: '',
    var2: '',
    var3: '',
    var4: '',
    added: '10 June 2025',
  },
  {
    id: 4,
    name: 'Codeyon Number',
    phonebook: 'Codeyon',
    mobile: '918430088300',
    var1: '',
    var2: '',
    var3: '',
    var4: '',
    added: '10 June 2025',
  },
];

export const globalContacts: GlobalContact[] = [
  {
    id: 1,
    name: 'KRUSHNA 👑 ♨️',
    phone: '+918432482806',
    source: 'WhatsApp',
    attributes: {},
    hasWhatsApp: true,
  },
  {
    id: 2,
    name: 'Piyush Agrawal',
    phone: '+918357950987',
    source: 'WhatsApp',
    attributes: {},
    hasWhatsApp: true,
  },
  {
    id: 3,
    name: 'Rajat Goyal',
    phone: '+919772165018',
    source: 'Wati',
    attributes: { type: 'test' },
    hasWhatsApp: true,
  },
  {
    id: 4,
    name: 'sonu',
    phone: '+918379081309',
    source: 'WhatsApp',
    attributes: {},
    hasWhatsApp: true,
  },
  {
    id: 5,
    name: 'Shri Balaji Message',
    phone: '+919784690987',
    source: 'WhatsApp',
    attributes: {},
    hasWhatsApp: true,
  },
  {
    id: 6,
    name: 'John Doe',
    phone: '+911234567890',
    source: 'Manual',
    attributes: { category: 'business', priority: 'high' },
    hasWhatsApp: true,
  },
  {
    id: 7,
    name: 'Jane Smith',
    phone: '+919876543210',
    source: 'WhatsApp',
    attributes: { department: 'sales' },
    hasWhatsApp: true,
  },
  {
    id: 8,
    name: 'Mike Johnson',
    phone: '+918765432109',
    source: 'Wati',
    attributes: {},
    hasWhatsApp: true
  },
];

export const phonebooks: Phonebook[] = [
  {
    name: 'Codeyon',
    daysAgo: 18,
    status: 'active',
  },
];

export const sortOptions = ['Last Updated', 'Name', 'Phone Number'] as const;
