import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import metaIcon from '@/assets/icons8-meta.svg';
import { fetchWhatsAppNumbers, clearError } from '@/redux/whatsappSlice';
import type { RootState, AppDispatch } from '@/redux/store/index';

const MetaIcon = () => <img src={metaIcon} alt="Meta" className="w-4 h-4" />;

interface WhatsAppNumber {
  id: number;
  whatsapp_no: string;
  whatsapp_no_id: string;
  whatsapp_biz_id: string;
  parmenent_token: string;
  token: string;
  status: string;
}

interface MetaConnectionButtonProps {
  mounted?: boolean;
  className?: string;
}

export const MetaConnectionButton: React.FC<MetaConnectionButtonProps> = ({
  mounted = true,
  className = '',
}) => {
  const dispatch = useDispatch<AppDispatch>();
  const whatsappState = useSelector((state: RootState) => state.whatsapp);

  const {
    numbers = [],
    loading: whatsappLoading = false,
    error = null,
  } = whatsappState || {};

  useEffect(() => {
    dispatch(fetchWhatsAppNumbers(1));
  }, [dispatch]);

  const getDisplayNumber = () => {
    if (numbers.data && numbers.data.length > 0) {
      const activeNumber = numbers.data.find(
        (num: WhatsAppNumber) => num.status === '1'
      );
      if (activeNumber) {
        return `+${activeNumber.whatsapp_no}`;
      }
      return `+${numbers.data[0].whatsapp_no}`;
    }
    return '';
  };

  if (whatsappLoading) {
    return (
      <div
        className={`flex items-center gap-2 px-3 py-2 bg-muted/50 rounded-md animate-pulse ${className}`}
      >
        <div className="w-4 h-4 bg-muted-foreground/20 rounded"></div>
        <div className="w-16 h-3 bg-muted-foreground/20 rounded"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div
        className={`
          flex items-center gap-2.5 px-3 py-2 
          bg-destructive/10 border border-destructive/20
          rounded-md transition-all duration-300
          ${mounted ? 'opacity-100' : 'opacity-0'}
          ${className}
        `}
        style={{ transitionDelay: mounted ? '200ms' : '0ms' }}
      >
        <div className="flex items-center justify-center w-6 h-6 rounded bg-destructive/10">
          <MetaIcon />
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium text-destructive">
            CONNECTION ERROR
          </span>
          <div className="w-1.5 h-1.5 bg-destructive rounded-full" />
        </div>
      </div>
    );
  }

  return (
    <div
      className={`
        flex items-center gap-2.5 px-3 py-2 
        bg-muted/30 border border-border/40
        rounded-md transition-all duration-300
        ${mounted ? 'opacity-100' : 'opacity-0'}
        ${className}
      `}
      style={{ transitionDelay: mounted ? '200ms' : '0ms' }}
    >
      {/* Meta Icon */}
      <div className="flex items-center justify-center w-6 h-6 rounded bg-primary/5">
        <MetaIcon />
      </div>

      {/* Connection Info */}
      <div className="flex items-center gap-2">
        <span className="text-xs font-medium text-muted-foreground">
          CONNECTED
        </span>
        <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full" />
      </div>

      {getDisplayNumber() && (
        <span className="text-xs font-mono text-foreground/80 ml-auto">
          {getDisplayNumber()}
        </span>
      )}
    </div>
  );
};

// Professional compact version for navbar
export const MetaConnectionCompact: React.FC<MetaConnectionButtonProps> = ({
  mounted = true,
  className = '',
}) => {
  const dispatch = useDispatch<AppDispatch>();
  const whatsappState = useSelector((state: RootState) => state.whatsapp);

  const {
    numbers = [],
    loading: whatsappLoading = false,
    error = null,
  } = whatsappState || {};

  useEffect(() => {
    if (!numbers.data || numbers.data.length === 0) {
      dispatch(fetchWhatsAppNumbers(1));
    }
  }, [dispatch, numbers.data]);

  const getDisplayNumber = () => {
    if (numbers.data && numbers.data.length > 0) {
      const activeNumber = numbers.data.find(
        (num: WhatsAppNumber) => num.status === '1'
      );
      if (activeNumber) {
        return `+${activeNumber.whatsapp_no}`;
      }
      return `+${numbers.data[0].whatsapp_no}`;
    }
    return '';
  };

  // Show loading state
  if (whatsappLoading) {
    return (
      <div
        className={`
          w-8 h-8 bg-muted/20 border border-border/30
          rounded animate-pulse
          ${mounted ? 'opacity-100' : 'opacity-0'}
          ${className}
        `}
        style={{ transitionDelay: mounted ? '300ms' : '0ms' }}
      />
    );
  }

  return (
    <div
      className={`
        group relative flex items-center justify-center w-8 h-8 
        bg-muted/20 hover:bg-muted/40 border border-border/30
        rounded transition-all duration-200
        ${mounted ? 'opacity-100' : 'opacity-0'}
        ${className}
      `}
      style={{ transitionDelay: mounted ? '300ms' : '0ms' }}
    >
      <MetaIcon />

      {/* Status indicator - red if error, green if connected */}
      <div
        className={`absolute -top-0.5 -right-0.5 w-2.5 h-2.5 border border-background rounded-full ${
          error ? 'bg-destructive' : 'bg-emerald-500'
        }`}
      />

      {/* Clean tooltip */}
      <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2.5 py-1.5 bg-popover border border-border text-popover-foreground text-xs rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none whitespace-nowrap z-50 shadow-sm">
        <div className="space-y-0.5">
          <div
            className={`font-medium ${
              error ? 'text-destructive' : 'text-emerald-600'
            }`}
          >
            {error ? 'Connection Error' : 'Meta Connected'}
          </div>
          {!error && getDisplayNumber() && (
            <div className="font-mono text-xs opacity-80">
              {getDisplayNumber()}
            </div>
          )}
          {error && (
            <div className="text-xs text-destructive opacity-80">
              Failed to load WhatsApp numbers
            </div>
          )}
          {!error && numbers.data && numbers.data.length > 0 && (
            <div className="text-xs opacity-60">
              {numbers.data.length} number{numbers.data.length > 1 ? 's' : ''}{' '}
              available
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
