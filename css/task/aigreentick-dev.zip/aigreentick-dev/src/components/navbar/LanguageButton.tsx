import React from 'react';
import { Languages } from 'lucide-react';

interface LanguageButtonProps {
  mounted: boolean;
  onLanguageToggle: () => void;
}

export const LanguageButton: React.FC<LanguageButtonProps> = ({
  mounted,
  onLanguageToggle,
}) => {
  return (
  <div></div>
  );
};
