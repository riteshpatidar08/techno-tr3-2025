import React from 'react';
import { Link } from 'react-router-dom';
import { MoreHorizontal } from 'lucide-react';
import { DropdownItem } from './types';

interface OptionsDropdownProps {
  mounted: boolean;
  dropdownOpen: string | null;
  userManagementItems: DropdownItem[];
  generalOptionsItems: DropdownItem[];
  onDropdownToggle: (dropdown: string | null) => void;
  onDropdownItemClick: (action: string) => void;
}

export const OptionsDropdown: React.FC<OptionsDropdownProps> = ({
  mounted,
  dropdownOpen,
  userManagementItems,
  generalOptionsItems,
  onDropdownToggle,
  onDropdownItemClick,
}) => {
  return (
    <div className="relative">
      <button
        className={`p-2 rounded-lg text-gray-600 hover:text-gray-900 transition-all duration-300 ease-out hover:scale-105 hover:bg-gray-100 hover:shadow-lg group transform hover:-translate-y-0.5 ${
          mounted ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'
        }`}
        onClick={() =>
          onDropdownToggle(dropdownOpen === 'more' ? null : 'more')
        }
        type="button"
        style={{ transitionDelay: mounted ? '450ms' : '0ms' }}
      >
        <MoreHorizontal
          className={`w-4 h-4 cursor-pointer transition-all duration-300 ease-out ${
            dropdownOpen === 'more'
              ? 'rotate-90 scale-110'
              : 'group-hover:rotate-90 group-hover:scale-110'
          }`}
        />
      </button>

      <div
        className={`absolute cursor-pointer right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-gray-200 z-50 transition-all duration-300 ease-out transform origin-top-right ${
          dropdownOpen === 'more'
            ? 'opacity-100 scale-100 translate-y-0'
            : 'opacity-0 scale-95 -translate-y-2 pointer-events-none'
        }`}
      >
        <div className="px-3 py-2 border-b border-gray-100">
          <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
            User Management
          </h3>
        </div>

        {userManagementItems.map((item, index) => (
          <Link
            key={item.action}
            to={item.href}
            onClick={() => onDropdownItemClick(item.action)}
            className={`w-full flex items-center px-4 py-3 text-sm text-gray-700 hover:bg-gradient-to-r hover:from-green-50 hover:to-green-100 hover:text-green-600 transition-all duration-200 ease-out group ${
              dropdownOpen === 'more'
                ? 'opacity-100 translate-x-0'
                : 'opacity-0 -translate-x-4'
            }`}
            style={{
              transitionDelay:
                dropdownOpen === 'more' ? `${index * 50}ms` : '0ms',
            }}
          >
            <item.icon className="w-4 h-4 mr-3 transition-all duration-200 ease-out group-hover:scale-110 group-hover:rotate-12" />
            <div className="flex-1">
              <div className="font-medium transition-transform duration-200 ease-out group-hover:translate-x-1">
                {item.label}
              </div>
              {item.description && (
                <div className="text-xs text-gray-500 mt-0.5">
                  {item.description}
                </div>
              )}
            </div>
          </Link>
        ))}

        <div className="border-t border-gray-100 my-2"></div>

        <div className="px-3 py-2 border-b border-gray-100">
          <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
            General
          </h3>
        </div>

        {generalOptionsItems.map((item, index) => (
          <Link
            key={item.action}
            to={item.href}
            onClick={() => onDropdownItemClick(item.action)}
            className={`w-full flex items-center px-4 py-3 text-sm text-gray-700 hover:bg-gradient-to-r hover:from-green-50 hover:to-green-100 hover:text-green-600 transition-all duration-200 ease-out group last:rounded-b-xl ${
              dropdownOpen === 'more'
                ? 'opacity-100 translate-x-0'
                : 'opacity-0 -translate-x-4'
            }`}
            style={{
              transitionDelay:
                dropdownOpen === 'more' ? `${(index + 4) * 50}ms` : '0ms',
            }}
          >
            <item.icon className="w-4 h-4 mr-3 transition-all duration-200 ease-out group-hover:scale-110 group-hover:rotate-12" />
            <span className="transition-transform duration-200 ease-out group-hover:translate-x-1">
              {item.label}
            </span>
          </Link>
        ))}
      </div>
    </div>
  );
};
