import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { X, LogOut } from 'lucide-react';
import { Badge, Avatar, AvatarFallback } from './UIComponents';
import { NavigationItem, PopoverItem, DropdownItem } from './types';

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
  logoText: string;
  navigationItems: NavigationItem[];
  userManagementItems: DropdownItem[];
  popoverItems: PopoverItem[];
  userImage?: string;
  userInitials: string;
  onNavigate: (itemName: string) => void;
  onDropdownItemClick: (action: string) => void;
}

export const MobileMenu: React.FC<MobileMenuProps> = ({
  isOpen,
  onClose,
  logoText,
  navigationItems,
  userManagementItems,
  popoverItems,
  userImage,
  userInitials,
  onNavigate,
  onDropdownItemClick,
}) => {
  const location = useLocation();

  return (
    <>
      <div
        className={`fixed inset-0 bg-black bg-opacity-50 z-50 lg:hidden transition-opacity duration-300 ${
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={onClose}
      />

      <div
        className={`fixed left-0 top-0 h-full w-80 bg-white shadow-xl z-50 lg:hidden transform transition-transform duration-300 ease-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-green-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xs">{logoText}</span>
            </div>
            <span className="font-semibold text-gray-900">Menu</span>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-gray-100 transition-colors duration-200"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          <div className="space-y-2">
            {navigationItems.map((item, index) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.href;

              return (
                <Link
                  key={item.name}
                  to={item.href}
                  onClick={() => {
                    onNavigate(item.name);
                    onClose();
                  }}
                  className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                    isActive
                      ? 'bg-green-50 text-green-600 border-l-4 border-green-500'
                      : 'text-gray-700 hover:bg-gray-50'
                  } ${
                    isOpen
                      ? 'opacity-100 translate-x-0'
                      : 'opacity-0 -translate-x-4'
                  }`}
                  style={{
                    transitionDelay: isOpen ? `${index * 50}ms` : '0ms',
                  }}
                >
                  <Icon
                    className={`w-5 h-5 ${
                      isActive ? 'text-green-600' : 'text-gray-400'
                    }`}
                  />
                  <span className="font-medium">{item.name}</span>
                  {item.badge && (
                    <Badge
                      variant={item.badgeVariant || 'secondary'}
                      className="ml-auto"
                    >
                      {item.badge}
                    </Badge>
                  )}
                </Link>
              );
            })}
          </div>

          <div className="mt-8">
            <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3">
              User Management
            </h3>
            <div className="space-y-2">
              {userManagementItems.map((item, index) => (
                <Link
                  key={item.action}
                  to={item.href}
                  onClick={onClose}
                  className={`flex items-start space-x-3 px-4 py-3 rounded-lg hover:bg-gray-50 transition-all duration-200 ${
                    isOpen
                      ? 'opacity-100 translate-x-0'
                      : 'opacity-0 -translate-x-4'
                  }`}
                  style={{
                    transitionDelay: isOpen
                      ? `${(navigationItems.length + index) * 50}ms`
                      : '0ms',
                  }}
                >
                  <item.icon className="w-5 h-5 text-gray-400 mt-0.5" />
                  <div className="flex-1">
                    <div className="flex items-center space-x-2">
                      <span className="text-sm font-medium text-gray-700">
                        {item.label}
                      </span>
                    </div>
                    {item.description && (
                      <p className="text-xs text-gray-500 mt-1">
                        {item.description}
                      </p>
                    )}
                  </div>
                </Link>
              ))}
            </div>
          </div>

          <div className="mt-8">
            <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3">
              More Features
            </h3>
            <div className="space-y-2">
              {popoverItems.map((item, index) => (
                <Link
                  key={item.name}
                  to={item.href}
                  onClick={onClose}
                  className={`flex items-start space-x-3 px-4 py-3 rounded-lg hover:bg-gray-50 transition-all duration-200 ${
                    isOpen
                      ? 'opacity-100 translate-x-0'
                      : 'opacity-0 -translate-x-4'
                  }`}
                  style={{
                    transitionDelay: isOpen
                      ? `${(navigationItems.length + 4 + index) * 50}ms`
                      : '0ms',
                  }}
                >
                  <item.icon className="w-5 h-5 text-gray-400 mt-0.5" />
                  <div className="flex-1">
                    <div className="flex items-center space-x-2">
                      <span className="text-sm font-medium text-gray-700">
                        {item.name}
                      </span>
                      {item.deprecated && (
                        <Badge variant="destructive" className="text-xs">
                          Deprecated
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {item.description}
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>

        <div className="border-t border-gray-200 p-4">
          <div className="flex items-center space-x-3">
            <Avatar className="h-10 w-10 rounded-full">
              {userImage ? (
                <img
                  src={userImage}
                  alt="Profile"
                  className="w-full h-full object-cover"
                />
              ) : (
                <AvatarFallback className="bg-gradient-to-br from-green-500 to-green-600 text-white w-full h-full">
                  {userInitials}
                </AvatarFallback>
              )}
            </Avatar>
            <div className="flex-1">
              <div className="text-sm font-medium text-gray-900">John Doe</div>
              <div className="text-xs text-gray-500">john@example.com</div>
            </div>
            <button
              onClick={() => onDropdownItemClick('Sign Out')}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors duration-200"
            >
              <LogOut className="w-4 h-4 text-gray-400" />
            </button>
          </div>
        </div>
      </div>
    </>
  );
};
