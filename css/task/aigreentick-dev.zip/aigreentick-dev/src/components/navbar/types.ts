import { LucideIcon } from 'lucide-react';

export interface NavigationItem {
  name: string;
  icon: LucideIcon;
  active?: boolean;
  href: string;
  badge?: string;
  badgeVariant?: 'default' | 'secondary' | 'destructive' | 'outline';
}

export interface PopoverItem {
  name: string;
  icon: LucideIcon;
  href: string;
  description: string;
  deprecated?: boolean;
}

export interface DropdownItem {
  icon: LucideIcon;
  label: string;
  action: string;
  href: string;
  description?: string;
  color?: 'green' | 'red';
}

export interface NavbarProps {
  className?: string;
  logoText?: string;
  userInitials?: string;
  userImage?: string;
  onNavigate?: (itemName: string) => void;
}
