import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { ProfileDrawer } from '../ProfileDrawer';
import { DropdownItem } from './types';
import { logout } from '@/redux/authSlice';

interface UserDropdownProps {
  userImage?: string;
  userInitials: string;
  mounted: boolean;
  dropdownOpen: string | null;
  profileMenuItems: DropdownItem[];
  onDropdownToggle: (dropdown: string | null) => void;
  onDropdownItemClick: (action: string) => void;
  showDrawer?: boolean; // New prop to control whether to show drawer or dropdown
}

export const UserDropdown: React.FC<UserDropdownProps> = ({
  userImage,
  userInitials,
  mounted,
  dropdownOpen,
  profileMenuItems,
  onDropdownToggle,
  onDropdownItemClick,
  showDrawer = true, // Default to showing drawer
}) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const handleSignOut = () => {
    try {
      onDropdownToggle(null);
      dispatch(logout());
      console.log('Successfully signed out');
      navigate('/login', { replace: true });
    } catch (error) {
      console.error('Error during sign out:', error);
      navigate('/login', { replace: true });
    }
  };

  const handleItemClick = (item: DropdownItem) => {
    if (
      item.action === 'signout' ||
      item.action === 'logout' ||
      item.label.toLowerCase().includes('sign out') ||
      item.label.toLowerCase().includes('logout')
    ) {
      handleSignOut();
    } else {
      onDropdownItemClick(item.action);
    }
  };

  // If showDrawer is true, render the ProfileDrawer
  if (showDrawer) {
    return (
      <ProfileDrawer
        userImage={userImage}
        userInitials={userInitials}
        mounted={mounted}
      />
    );
  }

  // Otherwise, render the traditional dropdown menu using shadcn DropdownMenu
  return (
    <DropdownMenu
      open={dropdownOpen === 'profile'}
      onOpenChange={(open) => onDropdownToggle(open ? 'profile' : null)}
    >
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          className={`relative h-10 w-10 rounded-full transition-all duration-300 ease-out hover:scale-110 hover:shadow-xl group transform hover:-translate-y-0.5 p-0 ${
            mounted ? 'opacity-100 scale-100' : 'opacity-0 scale-75'
          }`}
          style={{ transitionDelay: mounted ? '500ms' : '0ms' }}
        >
          <Avatar className="cursor-pointer h-10 w-10 rounded-full transition-all duration-300 ease-out group-hover:ring-2 group-hover:ring-primary group-hover:ring-offset-2 overflow-hidden">
            {userImage ? (
              <img
                src={userImage}
                alt="Profile"
                className="w-full h-full object-cover transition-transform duration-300 ease-out group-hover:scale-110"
              />
            ) : (
              <AvatarFallback className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground transition-all duration-300 ease-out group-hover:from-primary/80 group-hover:to-primary w-full h-full">
                {userInitials}
              </AvatarFallback>
            )}
          </Avatar>

          <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-400 border-2 border-white rounded-full shadow-sm">
            <div className="absolute inset-0 bg-green-400 rounded-full animate-ping opacity-75"></div>
            <div className="absolute inset-0 bg-green-400 rounded-full animate-ping animation-delay-200 opacity-50"></div>
          </div>
        </Button>
      </DropdownMenuTrigger>

      <DropdownMenuContent
        className="w-56"
        align="end"
        forceMount
        sideOffset={4}
      >
        <DropdownMenuLabel className="font-normal">
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-medium leading-none">Account</p>
            <p className="text-xs leading-none text-muted-foreground">
              Manage your profile and settings
            </p>
          </div>
        </DropdownMenuLabel>

        <DropdownMenuSeparator />

        {profileMenuItems.map((item) => {
          const isSignOutItem =
            item.action === 'signout' ||
            item.action === 'logout' ||
            item.label.toLowerCase().includes('sign out') ||
            item.label.toLowerCase().includes('logout');

          if (isSignOutItem) {
            return (
              <DropdownMenuItem
                key={item.action}
                onClick={() => handleItemClick(item)}
                className={`cursor-pointer ${
                  item.color === 'red'
                    ? 'text-red-600 focus:text-red-600 focus:bg-red-50'
                    : 'focus:bg-accent'
                }`}
              >
                <item.icon className="mr-2 h-4 w-4" />
                <span>{item.label}</span>
              </DropdownMenuItem>
            );
          }

          return (
            <DropdownMenuItem key={item.action} asChild>
              <Link
                to={item.href}
                onClick={() => handleItemClick(item)}
                className={`cursor-pointer flex items-center ${
                  item.color === 'red'
                    ? 'text-red-600 focus:text-red-600 focus:bg-red-50'
                    : 'focus:bg-accent'
                }`}
              >
                <item.icon className="mr-2 h-4 w-4" />
                <span>{item.label}</span>
              </Link>
            </DropdownMenuItem>
          );
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

// Example usage component showing how to integrate both versions
export const ProfileSection: React.FC = () => {
  const [dropdownOpen, setDropdownOpen] = React.useState<string | null>(null);
  const [useDrawer, setUseDrawer] = React.useState(true);

  const profileMenuItems: DropdownItem[] = [
    {
      label: 'Profile',
      action: 'profile',
      icon: User,
      href: '/profile',
    },
    {
      label: 'Settings',
      action: 'settings',
      icon: Settings,
      href: '/settings',
    },
    {
      label: 'Billing',
      action: 'billing',
      icon: CreditCard,
      href: '/billing',
    },
    {
      label: 'Sign Out',
      action: 'signout',
      icon: LogOut,
      href: '#',
      color: 'red',
    },
  ];

  const handleDropdownToggle = (dropdown: string | null) => {
    setDropdownOpen(dropdown);
  };

  const handleDropdownItemClick = (action: string) => {
    console.log('Dropdown item clicked:', action);
    setDropdownOpen(null);
  };

  return (
    <div className="flex items-center space-x-4">
      {/* Toggle between drawer and dropdown */}
      <Button
        variant="outline"
        size="sm"
        onClick={() => setUseDrawer(!useDrawer)}
      >
        Use {useDrawer ? 'Dropdown' : 'Drawer'}
      </Button>

      <UserDropdown
        userInitials="JD"
        mounted={true}
        dropdownOpen={dropdownOpen}
        profileMenuItems={profileMenuItems}
        onDropdownToggle={handleDropdownToggle}
        onDropdownItemClick={handleDropdownItemClick}
        showDrawer={useDrawer}
      />
    </div>
  );
};
