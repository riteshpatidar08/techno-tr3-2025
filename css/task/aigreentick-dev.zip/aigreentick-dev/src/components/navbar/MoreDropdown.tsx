import React from 'react';
import { Link } from 'react-router-dom';
import { MoreHorizontal, ChevronDown } from 'lucide-react';
import { Badge } from './UIComponents';
import { PopoverItem } from './types';

interface MoreDropdownProps {
  items: PopoverItem[];
  mounted: boolean;
  navigationItemsLength: number;
  dropdownOpen: string | null;
  onDropdownToggle: (dropdown: string | null) => void;
}

export const MoreDropdown: React.FC<MoreDropdownProps> = ({
  items,
  mounted,
  navigationItemsLength,
  dropdownOpen,
  onDropdownToggle,
}) => {
  return (
    <div className="relative">
      <button
        className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium text-gray-600 hover:text-gray-900 hover:bg-gray-50 transition-all duration-300 ease-out transform hover:scale-105 hover:-translate-y-0.5 ${
          mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
        }`}
        onClick={() =>
          onDropdownToggle(dropdownOpen === 'features' ? null : 'features')
        }
        type="button"
        style={{
          transitionDelay: mounted ? `${navigationItemsLength * 50}ms` : '0ms',
        }}
      >
        <MoreHorizontal className="w-4 h-4" />
        <span className='text-md  cursor-pointer font-semibold text-muted-foreground'>More</span>
        <ChevronDown
          className={`w-3 h-3 transition-transform duration-200 ${
            dropdownOpen === 'features' ? 'rotate-180' : ''
          }`}
        />
      </button>

      <div
        className={`absolute left-0 mt-2 w-80 bg-white rounded-xl shadow-xl border border-gray-200 z-50 transition-all duration-300 ease-out transform origin-top-left ${
          dropdownOpen === 'features'
            ? 'opacity-100 scale-100 translate-y-0'
            : 'opacity-0 scale-95 -translate-y-2 pointer-events-none'
        }`}
      >
        <div className="p-3">
          {items.map((item, index) => (
            <Link
              key={item.name}
              to={item.href}
              onClick={() => onDropdownToggle(null)}
              className={`flex items-start p-3 rounded-lg hover:bg-gray-50 transition-all duration-200 group ${
                dropdownOpen === 'features'
                  ? 'opacity-100 translate-x-0'
                  : 'opacity-0 -translate-x-4'
              }`}
              style={{
                transitionDelay:
                  dropdownOpen === 'features' ? `${index * 50}ms` : '0ms',
              }}
            >
              <div className="flex-shrink-0 mr-3 mt-0.5">
                <item.icon className="w-5 h-5 text-gray-400 group-hover:text-green-500 transition-colors duration-200" />
              </div>
              <div className="flex-1">
                <div className="flex items-center space-x-2">
                  <h4 className="text-sm font-medium text-gray-900 group-hover:text-green-600 transition-colors duration-200">
                    {item.name}
                  </h4>
                  {item.deprecated && (
                    <Badge variant="destructive" className="text-xs">
                      Deprecated
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-gray-500 mt-1">{item.description}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};
