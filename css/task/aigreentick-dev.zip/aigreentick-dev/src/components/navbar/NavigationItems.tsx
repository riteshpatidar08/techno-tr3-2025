import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Badge } from './UIComponents';
import { NavigationItem } from './types';

interface NavigationItemsProps {
  items: NavigationItem[];
  mounted: boolean;
  hoveredItem: string | null;
  onHover: (item: string | null) => void;
  onNavigate: (itemName: string) => void;
}

export const NavigationItems: React.FC<NavigationItemsProps> = ({
  items,
  mounted,
  hoveredItem,
  onHover,
  onNavigate,
}) => {
  const location = useLocation();

  return (
    <div className="hidden lg:flex items-center space-x-1">
      <div className="h-6 w-px bg-border mr-4"></div>
      {items.map((item: NavigationItem, index: number) => {
        const Icon = item.icon;
        const isActive = location.pathname === item.href;
        const isHovered = hoveredItem === item.name;

        return (
          <Link
            key={item.name}
            to={item.href}
            className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-semibold transition-colors duration-200 ease-out ${
              isActive
                ? 'text-primary'
                : 'text-muted-foreground hover:text-foreground'
            } ${mounted ? 'opacity-100' : 'opacity-0'}`}
            onClick={() => onNavigate(item.name)}
            onMouseEnter={() => onHover(item.name)}
            onMouseLeave={() => onHover(null)}
            style={{
              transitionDelay: mounted ? `${index * 50}ms` : '0ms',
            }}
          >
            <Icon className="w-4 h-4" />

            <span>{item.name}</span>

            {item.badge && (
              <Badge
                variant={item.badgeVariant || 'secondary'}
                className="ml-1 text-xs px-1.5 py-0.5"
              >
                {item.badge}
              </Badge>
            )}
          </Link>
        );
      })}
    </div>
  );
};
