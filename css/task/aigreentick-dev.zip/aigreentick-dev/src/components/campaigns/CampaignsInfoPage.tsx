import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  FileStack,
  FileText,
  Radio,
  Megaphone,
  Tags,
  FileSpreadsheet,
  RadioTower,
  Calendar,
  LayoutDashboard,
  ArrowRight,
  Zap,
  Target,
  Users,
  TrendingUp,
} from 'lucide-react';

const CampaignsInfoPage = () => {
  const navigate = useNavigate();

  const templateFeatures = [
    {
      icon: FileText,
      title: 'Template Library',
      description:
        'Access pre-built, professional templates for various campaign types',
      path: '/campaigns/template-library',
    },
    {
      icon: Radio,
      title: 'Your Templates',
      description: 'Create, customize, and manage your own reusable templates',
      path: '/campaigns/your-templates',
    },
  ];

  const campaignFeatures = [
    {
      icon: Tags,
      title: 'Send By Tags',
      description: 'Target specific audience segments using custom tags',
      path: '/campaigns/send-by-tags',
    },
    {
      icon: FileSpreadsheet,
      title: 'CSV Campaign',
      description: 'Upload CSV files to run bulk campaigns efficiently',
      path: '/campaigns/csv-campaign',
    },
    {
      icon: Radio,
      title: 'Broadcast',
      description: 'Send messages to your entire audience instantly',
      path: '/campaigns/broadcast',
    },
    {
      icon: RadioTower,
      title: 'Campaign History',
      description: 'Track and analyze your past campaign performance',
      path: '/campaigns/campaigns-history',
    },
    {
      icon: Calendar,
      title: 'Scheduled Campaign',
      description: 'Plan and schedule campaigns for optimal timing',
      path: '/campaigns/scheduled-campaigns',
    },
    {
      icon: LayoutDashboard,
      title: 'Campaign Dashboard',
      description: 'Monitor real-time metrics and campaign analytics',
      path: '/campaigns/campaign-dashboard',
    },
  ];

  const benefits = [
    {
      icon: Zap,
      title: 'Lightning Fast',
      description: 'Deploy campaigns in minutes with our streamlined workflow',
    },
    {
      icon: Target,
      title: 'Precision Targeting',
      description: 'Reach the right audience with advanced segmentation tools',
    },
    {
      icon: Users,
      title: 'Scale Effortlessly',
      description:
        'From small groups to millions - we handle any audience size',
    },
    {
      icon: TrendingUp,
      title: 'Data-Driven Results',
      description: 'Make informed decisions with comprehensive analytics',
    },
  ];

  const handleNavigate = (path: string) => {
    navigate(path);
  };

  return (
    <div className="min-h-screen p-6 ">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header Section */}
        <div className="space-y-2">
          <div className="flex gap-3 items-center">
            <div className="bg-primary p-3 rounded-xl">
              <Megaphone className="h-8 w-8 text-primary-foreground" />
            </div>
            <div className="flex flex-col gap-1">
              <h1 className="text-3xl font-bold text-foreground">
                Campaign Manager
              </h1>
              <p className="text-muted-foreground">
                Create powerful campaigns with professional templates and
                advanced targeting
              </p>
            </div>
          </div>
        </div>

        {/* Benefits Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {benefits.map((benefit, index) => (
            <Card key={index} className="border-0 bg-card">
              <CardContent className="pt-6 text-center">
                <div className="bg-accent p-3 rounded-xl w-fit mx-auto mb-4">
                  <benefit.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold text-card-foreground mb-2">
                  {benefit.title}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {benefit.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Templates Section */}
        <Card className="border-0 bg-card">
          <CardHeader>
            <div className="flex items-center space-x-3">
              <div className="bg-primary p-2 rounded-lg">
                <FileStack className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <CardTitle className="text-2xl text-card-foreground">
                  Templates
                </CardTitle>
                <p className="text-muted-foreground">
                  Professional templates to jumpstart your campaigns
                </p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {templateFeatures.map((feature, index) => (
                <Card
                  key={index}
                  className="border-border hover:bg-accent/50 transition-all cursor-pointer group "
                  onClick={() => handleNavigate(feature.path)}
                >
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div className="bg-accent p-2 rounded-lg group-hover:bg-primary/10 transition-colors">
                        <feature.icon className="w-5 h-5 text-primary" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-foreground mb-2 group-hover:text-primary transition-colors">
                          {feature.title}
                        </h3>
                        <p className="text-muted-foreground text-sm mb-3">
                          {feature.description}
                        </p>
                        <div className="flex items-center text-primary text-sm font-medium">
                          Get Started{' '}
                          <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Campaigns Section */}
        <Card className="border-0 bg-card">
          <CardHeader>
            <div className="flex items-center space-x-3">
              <div className="bg-primary p-2 rounded-lg">
                <Megaphone className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <CardTitle className="text-2xl text-card-foreground">
                  Campaigns
                </CardTitle>
                <p className="text-muted-foreground">
                  Powerful tools to create, manage, and analyze your campaigns
                </p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {campaignFeatures.map((feature, index) => (
                <Card
                  key={index}
                  className="border-border hover:bg-accent/50 transition-all cursor-pointer group "
                  onClick={() => handleNavigate(feature.path)}
                >
                  <CardContent className="p-6">
                    <div className="flex flex-col space-y-4">
                      <div className="bg-accent p-3 rounded-lg w-fit group-hover:bg-primary/10 transition-colors">
                        <feature.icon className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground mb-2 group-hover:text-primary transition-colors">
                          {feature.title}
                        </h3>
                        <p className="text-muted-foreground text-sm mb-3">
                          {feature.description}
                        </p>
                        <div className="flex items-center text-primary text-sm font-medium">
                          Launch{' '}
                          <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quick Start Section */}
        <Card className="bg-primary border-0">
          <CardContent className="p-8 text-center">
            <h2 className="text-2xl font-bold mb-4 text-primary-foreground">
              Ready to Get Started?
            </h2>
            <p className="text-primary-foreground/80 mb-6 text-lg">
              Choose your starting point and create your first campaign in
              minutes
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                variant="secondary"
                className="bg-background text-foreground hover:bg-accent"
                onClick={() => handleNavigate('/campaigns/template-library')}
              >
                <FileText className="w-5 h-5 mr-2" />
                Browse Templates
              </Button>
              <Button
                size="lg"
                variant="secondary"
                className="bg-background text-foreground hover:bg-accent"
                onClick={() => handleNavigate('/campaigns/broadcast')}
              >
                <Radio className="w-5 h-5 mr-2" />
                Create Campaign
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Stats Preview */}
        <Card className="bg-accent border-border">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-accent-foreground">
                  Campaign Overview
                </h3>
                <p className="text-muted-foreground text-sm">
                  Start building powerful campaigns with our comprehensive tools
                </p>
              </div>
              <div className="flex gap-2">
                <Badge
                  variant="outline"
                  className="bg-primary text-primary-foreground border-border"
                >
                  8 Tools Available
                </Badge>
                <Badge
                  variant="outline"
                  className="bg-secondary text-secondary-foreground border-border"
                >
                  Ready to Use
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CampaignsInfoPage;
