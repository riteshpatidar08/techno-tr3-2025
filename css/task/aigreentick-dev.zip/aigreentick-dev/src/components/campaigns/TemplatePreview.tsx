import React from 'react';
import {
  Eye,
  Phone,
  ExternalLink,
  MessageSquare,
  Info,
  Image,
  Copy,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

const TemplatePreview = ({ template, variables = {}, loading = false }) => {
  if (loading) {
    return (
      <div className="w-80 flex-shrink-0 p-4">
        <Card className="border-0 bg-gradient-to-br from-card to-card/50 shadow-lg sticky top-6">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-3 text-lg text-card-foreground">
              <div className="p-2 bg-primary/10 rounded-lg">
                <Eye className="h-5 w-5 text-primary" />
              </div>
              Template Preview
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="animate-pulse space-y-6">
              <div className="space-y-3">
                <div className="h-4 bg-gradient-to-r from-muted to-muted/50 rounded-lg w-3/4"></div>
                <div className="h-32 bg-gradient-to-br from-muted to-muted/30 rounded-xl"></div>
                <div className="h-4 bg-gradient-to-r from-muted to-muted/50 rounded-lg w-1/2"></div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const renderComponent = (component) => {
    switch (component.type) {
      case 'HEADER':
        if (
          component.format === 'IMAGE' &&
          (component.previewUrl || component.example?.header_handle)
        ) {
          return (
            <div className="mb-3">
              <div className="relative rounded-lg overflow-hidden bg-gradient-to-br from-muted/30 to-muted/10">
                <img
                  src={
                    component.previewUrl ||
                    'https://via.placeholder.com/300x120/e5e7eb/6b7280?text=Uploaded+Image'
                  }
                  alt="Template Header"
                  className="w-full h-32 object-cover"
                  onError={(e) => {
                    e.target.style.display = 'none';
                    e.target.nextSibling.style.display = 'flex';
                  }}
                />
                <div className="hidden w-full h-32 bg-gradient-to-br from-muted/50 to-muted/20 items-center justify-center">
                  <div className="p-3 bg-background/50 rounded-full">
                    <Image className="h-6 w-6 text-muted-foreground" />
                  </div>
                </div>
              </div>
            </div>
          );
        } else if (component.format === 'VIDEO' && component.previewUrl) {
          return (
            <div className="mb-3">
              <div className="relative rounded-lg overflow-hidden bg-gradient-to-br from-muted/30 to-muted/10">
                <video
                  src={component.previewUrl}
                  className="w-full h-32 object-cover"
                  controls
                />
              </div>
            </div>
          );
        } else if (component.format === 'DOCUMENT' && component.previewUrl) {
          return (
            <div className="mb-3">
              <div className="w-full h-32 bg-gradient-to-br from-muted/50 to-muted/20 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <div className="text-2xl mb-2">📄</div>
                  <span className="text-sm text-muted-foreground">
                    Document
                  </span>
                </div>
              </div>
            </div>
          );
        } else if (component.text) {
          return (
            <div className="mb-3">
              <div className="p-3 bg-gradient-to-r from-primary/10 to-primary/5 border border-primary/20 rounded-lg">
                <h3 className="font-semibold text-primary text-sm leading-tight break-words">
                  {component.text}
                </h3>
              </div>
            </div>
          );
        }
        return null;

      case 'BODY':
        const processedText = component.text.replace(
          /\{\{(\d+|\w+)\}\}/g,
          (match, varName) => {
            const varContent = variables[varName];
            return varContent || match;
          }
        );

        return (
          <div className="mb-3">
            <div className="p-3 bg-background/50 rounded-lg border border-border/30">
              <div className="text-foreground whitespace-pre-wrap leading-relaxed text-sm break-words">
                {processedText}
              </div>
            </div>
          </div>
        );

      case 'FOOTER':
        return (
          <div className="mb-3">
            <div className="p-2 bg-muted/20 rounded-md border-t border-border/50">
              <p className="text-xs text-muted-foreground font-medium text-center break-words">
                {component.text}
              </p>
            </div>
          </div>
        );

      case 'BUTTONS':
        if (component.buttons && component.buttons.length > 0) {
          const urlButtons = component.buttons.filter(
            (btn) => btn.type === 'URL'
          );
          const phoneButtons = component.buttons.filter(
            (btn) => btn.type === 'PHONE_NUMBER'
          );
          const quickReplyButtons = component.buttons.filter(
            (btn) => btn.type === 'QUICK_REPLY'
          );
          const otpButtons = component.buttons.filter(
            (btn) => btn.type === 'otp'
          );

          return (
            <div className="space-y-3">
              {/* URL and Phone buttons */}
              {(urlButtons.length > 0 || phoneButtons.length > 0) && (
                <div className="space-y-1.5">
                  {phoneButtons.map((button, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      className="w-full justify-center gap-2 text-xs h-8 bg-gradient-to-r from-green-50 to-green-50/50 border-green-200 text-green-700 truncate"
                      disabled
                    >
                      <Phone className="h-3 w-3 flex-shrink-0" />
                      <span className="truncate">{button.text}</span>
                    </Button>
                  ))}
                  {urlButtons.map((button, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      className="w-full justify-center gap-2 text-xs h-8 bg-gradient-to-r from-blue-50 to-blue-50/50 border-blue-200 text-blue-700 truncate"
                      disabled
                    >
                      <ExternalLink className="h-3 w-3 flex-shrink-0" />
                      <span className="truncate">{button.text}</span>
                    </Button>
                  ))}
                </div>
              )}

              {/* OTP Copy Code buttons for Authentication */}
              {otpButtons.length > 0 && (
                <div className="space-y-1.5">
                  {otpButtons.map((button, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      className="w-full justify-center gap-2 text-xs h-8 bg-gradient-to-r from-orange-50 to-orange-50/50 border-orange-200 text-orange-700 truncate"
                      disabled
                    >
                      <Copy className="h-3 w-3 flex-shrink-0" />
                      <span className="truncate">{button.text}</span>
                    </Button>
                  ))}
                </div>
              )}

              {/* Quick Reply buttons */}
              {quickReplyButtons.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground font-medium">
                    <div className="w-1 h-1 bg-muted-foreground/50 rounded-full"></div>
                    Quick Replies
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {quickReplyButtons.map((button, index) => (
                      <Badge
                        key={index}
                        variant="secondary"
                        className="px-2 py-1 text-xs font-medium bg-gradient-to-r from-secondary to-secondary/70 max-w-full truncate"
                      >
                        {button.text}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        }
        return null;

      default:
        return null;
    }
  };

  return (
    <div className="w-84 flex-shrink-0 p-4">
      <Card className="border-0 bg-gradient-to-br from-card via-card/95 to-card/90  sticky top-6 w-full">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-md text-card-foreground">
              <div className="p-1.5 bg-primary/10 rounded-lg">
                <Eye className="h-4 w-4 text-primary" />
              </div>
              Live Preview
            </CardTitle>
            {/* FIXED: Proper flex container for badges */}
            <div className="flex items-center gap-1.5 flex-shrink-0">
              <Badge
                variant="outline"
                className="text-xs bg-background/50 border-border/50 whitespace-nowrap"
              >
                {template.category || 'MARKETING'}
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          {/* Phone Mockup Container - FIXED: Added proper constraints */}
          <div className="relative mx-auto w-full max-w-[280px]">
            {/* Phone Frame */}
            <div className="relative bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 rounded-[1.5rem] p-1.5 shadow-2xl w-full">
              {/* Screen */}
              <div className="bg-gradient-to-b from-gray-50 to-white rounded-[1.25rem] overflow-hidden w-full">
                {/* Status Bar */}
                <div className="bg-white px-3 py-1.5 flex justify-between items-center text-xs font-medium text-black">
                  <span>9:41</span>
                  <div className="flex items-center gap-1">
                    <div className="flex gap-0.5">
                      <div className="w-0.5 h-0.5 bg-black rounded-full"></div>
                      <div className="w-0.5 h-0.5 bg-black rounded-full"></div>
                      <div className="w-0.5 h-0.5 bg-black/30 rounded-full"></div>
                    </div>
                    <div className="ml-1 w-5 h-2.5 border border-black/30 rounded-sm">
                      <div className="w-3 h-1 bg-green-500 rounded-sm m-0.5"></div>
                    </div>
                  </div>
                </div>

                {/* WhatsApp Header */}
                <div className="bg-[#075E54] px-3 py-2 flex items-center gap-2">
                  <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0">
                    <MessageSquare className="h-3 w-3 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-white font-medium text-xs truncate">
                      Business Account
                    </h4>
                    <p className="text-white/70 text-xs truncate">
                      Template Message
                    </p>
                  </div>
                </div>

                {/* Message Content - FIXED: Added proper constraints */}
                <div className="p-2 bg-[#E5DDD5] h-[280px] overflow-y-auto scrollbar-hide">
                  <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden w-full">
                    <div className="p-2 space-y-2">
                      {template.components && template.components.length > 0 ? (
                        [...template.components]
                          .sort((a, b) => {
                            const order = {
                              HEADER: 1,
                              BODY: 2,
                              FOOTER: 3,
                              BUTTONS: 4,
                            };
                            return (order[a.type] || 5) - (order[b.type] || 5);
                          })
                          .map((component, index) => (
                            <div key={component.id || index} className="w-full">
                              {renderComponent(component)}
                            </div>
                          ))
                      ) : (
                        <div className="text-center py-8 text-muted-foreground">
                          <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-50" />
                          <p className="text-sm">
                            Start building your template
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Template Metadata - FIXED: Added proper constraints */}
          <div className="mt-4 p-3 bg-gradient-to-r from-muted/30 to-muted/10 rounded-lg border border-border/50 w-full">
            <h4 className="font-semibold text-sm text-foreground mb-2 flex items-center gap-2">
              <Info className="h-3 w-3 flex-shrink-0" />
              Template Info
            </h4>
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground flex-shrink-0">
                  Name:
                </span>
                <span className="font-medium truncate ml-2">
                  {template.name || 'Untitled'}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground flex-shrink-0">
                  Language:
                </span>
                <span className="font-medium truncate ml-2">
                  {template.language || 'en'}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground flex-shrink-0">
                  Components:
                </span>
                <Badge variant="outline" className="text-xs h-5 flex-shrink-0">
                  {template.components?.length || 0}
                </Badge>
              </div>
            </div>
          </div>

          {/* Variables - FIXED: Added proper constraints */}
          {Object.keys(variables).length > 0 && (
            <div className="mt-4 p-3 bg-gradient-to-r from-blue/10 to-blue/5 rounded-lg border border-blue/20 w-full">
              <h4 className="font-semibold text-sm text-foreground mb-2">
                Variables Used
              </h4>
              <div className="flex flex-wrap gap-1.5">
                {Object.entries(variables).map(([key, value]) => (
                  <div key={key} className="text-xs max-w-full">
                    <Badge
                      variant="outline"
                      className="bg-blue-50 text-blue-700 border-blue-200 truncate max-w-full"
                      title={`{{${key}}} → ${value}`}
                    >
                      <span className="truncate">
                        {`{{${key}}}`} → {value}
                      </span>
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default TemplatePreview;
