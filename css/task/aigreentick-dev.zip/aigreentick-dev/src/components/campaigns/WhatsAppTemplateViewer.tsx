import React from 'react';
import {
  Phone,
  ExternalLink,
  MapPin,
  MessageSquare,
  User,
  Clock,
  CheckCircle2,
  Play,
  FileText,
  Image,
  TrendingUp,
  Send,
  Eye,
  AlertCircle,
  Loader,
  Info,
  BarChart3,
  Activity,
} from 'lucide-react';

// Mock UI Components (replace with your actual imports)
const Card = ({ children, className = '' }) => (
  <div
    className={`bg-white border border-gray-200 rounded-lg shadow-sm ${className}`}
  >
    {children}
  </div>
);

const CardHeader = ({ children, className = '' }) => (
  <div className={`p-6 pb-4 ${className}`}>{children}</div>
);

const CardTitle = ({ children, className = '' }) => (
  <h3 className={`text-lg font-semibold ${className}`}>{children}</h3>
);

const CardContent = ({ children, className = '' }) => (
  <div className={`p-6 pt-0 ${className}`}>{children}</div>
);

const Badge = ({ children, variant = 'default', className = '' }) => {
  const variants = {
    default: 'bg-blue-100 text-blue-800 border-blue-200',
    outline: 'bg-transparent border border-gray-300 text-gray-700',
    secondary: 'bg-gray-100 text-gray-800 border-gray-200',
  };

  return (
    <span
      className={`inline-flex items-center px-2 py-1 rounded-md text-xs font-medium border ${variants[variant]} ${className}`}
    >
      {children}
    </span>
  );
};

const Button = ({
  children,
  variant = 'default',
  className = '',
  disabled = false,
  onClick,
}) => {
  const variants = {
    default: 'bg-blue-600 text-white hover:bg-blue-700',
    outline:
      'bg-transparent border border-gray-300 text-gray-700 hover:bg-gray-50',
    secondary: 'bg-gray-100 text-gray-800 hover:bg-gray-200',
  };

  return (
    <button
      className={`inline-flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
        variants[variant]
      } ${disabled ? 'opacity-50 cursor-not-allowed' : ''} ${className}`}
      disabled={disabled}
      onClick={onClick}
    >
      {children}
    </button>
  );
};

interface Template {
  name: string;
  wa_id: string;
  category: string;
  status: string;
  language: string;
  components?: Array<{
    type: string;
    format?: string;
    text?: string;
    image_url?: string;
    buttons?: Array<{
      id: string;
      type: string;
      text: string;
      url?: string;
      number?: string;
      phone_number?: string;
    }>;
  }>;
}

interface WhatsAppTemplateViewerProps {
  template: Template;
  showStats?: boolean;
  showExpandedView?: boolean;
  className?: string;
  reportData?: {
    total?: number;
    sent_count?: number;
    dlvd_count?: number;
    read_count?: number;
    failed_count?: number;
    other_count?: number;
    created_at?: string;
    updated_at?: string;
    status?: string;
    user?: { name?: string };
    country?: { name?: string };
  };
  variables?: { [key: string]: string };
}

const WhatsAppTemplateViewer: React.FC<WhatsAppTemplateViewerProps> = ({
  template,
  showStats = false,
  showExpandedView = false,
  className = '',
  reportData,
  variables = {},
}) => {
  const renderComponent = (component: any) => {
    switch (component.type) {
      case 'HEADER':
        if (component.format === 'IMAGE' && component.image_url) {
          return (
            <div className="mb-3">
              <div className="relative rounded-lg overflow-hidden bg-gradient-to-br from-gray-100 to-gray-50">
                <img
                  src={component.image_url}
                  alt="Template Header"
                  className="w-full h-32 object-cover"
                  onError={(e) => {
                    e.target.style.display = 'none';
                    e.target.nextSibling.style.display = 'flex';
                  }}
                />
                <div className="hidden w-full h-32 bg-gradient-to-br from-gray-200 to-gray-100 items-center justify-center">
                  <div className="p-3 bg-white/50 rounded-full">
                    <Image className="h-6 w-6 text-gray-500" />
                  </div>
                </div>
              </div>
            </div>
          );
        } else if (component.format === 'VIDEO' && component.image_url) {
          return (
            <div className="mb-3">
              <div className="relative rounded-lg overflow-hidden bg-gradient-to-br from-gray-100 to-gray-50">
                <video
                  src={component.image_url}
                  className="w-full h-32 object-cover"
                  controls
                />
              </div>
            </div>
          );
        } else if (component.format === 'DOCUMENT') {
          return (
            <div className="mb-3">
              <div className="w-full h-32 bg-gradient-to-br from-gray-200 to-gray-100 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <div className="text-2xl mb-2">📄</div>
                  <span className="text-sm text-gray-600">Document</span>
                </div>
              </div>
            </div>
          );
        } else if (component.text) {
          return (
            <div className="mb-3">
              <div className="p-3 bg-gradient-to-r from-blue-50 to-blue-25 border border-blue-200 rounded-lg">
                <h3 className="font-semibold text-blue-700 text-sm leading-tight break-words">
                  {component.text}
                </h3>
              </div>
            </div>
          );
        }
        return null;

      case 'BODY':
        const processedText = component.text?.replace(
          /\{\{(\d+|\w+)\}\}/g,
          (match, varName) => {
            const varContent = variables[varName];
            return varContent || match;
          }
        );

        return (
          <div className="mb-3">
            <div className="p-3 bg-white rounded-lg border border-gray-200">
              <div className="text-gray-900 whitespace-pre-wrap leading-relaxed text-sm break-words">
                {processedText || 'No message content'}
              </div>
            </div>
          </div>
        );

      case 'FOOTER':
        return (
          <div className="mb-3">
            <div className="p-2 bg-gray-100 rounded-md border-t border-gray-200">
              <p className="text-xs text-gray-600 font-medium text-center break-words">
                {component.text}
              </p>
            </div>
          </div>
        );

      case 'BUTTONS':
        if (component.buttons && component.buttons.length > 0) {
          const urlButtons = component.buttons.filter(
            (btn) => btn.type === 'URL'
          );
          const phoneButtons = component.buttons.filter(
            (btn) => btn.type === 'PHONE_NUMBER'
          );
          const quickReplyButtons = component.buttons.filter(
            (btn) => btn.type === 'QUICK_REPLY'
          );

          return (
            <div className="space-y-3">
              {/* URL and Phone buttons */}
              {(urlButtons.length > 0 || phoneButtons.length > 0) && (
                <div className="space-y-1.5">
                  {phoneButtons.map((button, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      className="w-full justify-center gap-2 text-xs h-8 bg-gradient-to-r from-green-50 to-green-25 border-green-200 text-green-700 truncate"
                      disabled
                    >
                      <Phone className="h-3 w-3 flex-shrink-0" />
                      <span className="truncate">{button.text}</span>
                    </Button>
                  ))}
                  {urlButtons.map((button, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      className="w-full justify-center gap-2 text-xs h-8 bg-gradient-to-r from-blue-50 to-blue-25 border-blue-200 text-blue-700 truncate"
                      disabled
                    >
                      <ExternalLink className="h-3 w-3 flex-shrink-0" />
                      <span className="truncate">{button.text}</span>
                    </Button>
                  ))}
                </div>
              )}

              {/* Quick Reply buttons */}
              {quickReplyButtons.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-xs text-gray-600 font-medium">
                    <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
                    Quick Replies
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {quickReplyButtons.map((button, index) => (
                      <Badge
                        key={index}
                        variant="secondary"
                        className="px-2 py-1 text-xs font-medium bg-gradient-to-r from-gray-100 to-gray-50 max-w-full truncate"
                      >
                        {button.text}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        }
        return null;

      default:
        return null;
    }
  };

  const getCategoryStyles = (category: string) => {
    switch (category) {
      case 'MARKETING':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'UTILITY':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'AUTHENTICATION':
        return 'bg-indigo-50 text-indigo-700 border-indigo-200';
      default:
        return 'bg-gray-50 text-gray-700 border-gray-200';
    }
  };

  const getStatusStyles = (status: string) => {
    switch (status) {
      case 'APPROVED':
        return 'bg-green-50 text-green-700 border-green-200';
      case 'PENDING':
        return 'bg-yellow-50 text-yellow-700 border-yellow-200';
      case 'REJECTED':
        return 'bg-red-50 text-red-700 border-red-200';
      default:
        return 'bg-gray-50 text-gray-700 border-gray-200';
    }
  };

  const formatDate = (dateString: string) =>
    new Date(dateString).toLocaleDateString('en-GB');

  const getDeliveryRate = (data: any) => {
    const total = data?.total || 0;
    const delivered = data?.dlvd_count || 0;
    return total > 0 ? ((delivered / total) * 100).toFixed(1) : '0';
  };

  const getReadRate = (data: any) => {
    const delivered = data?.dlvd_count || 0;
    const read = data?.read_count || 0;
    return delivered > 0 ? ((read / delivered) * 100).toFixed(1) : '0';
  };

  return (
    <div className={`space-y-6 ${className}`}>
      {/* WhatsApp Template Preview */}
      <div className="flex flex-col lg:flex-row gap-6">
        {/* Phone Mockup */}
        <div className="flex-shrink-0">
          <Card className="border-0 bg-gradient-to-br from-white via-gray-50 to-white shadow-lg sticky top-6 w-full max-w-[320px]">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2 text-base text-gray-900">
                  <div className="p-1.5 bg-blue-100 rounded-lg">
                    <Eye className="h-4 w-4 text-blue-600" />
                  </div>
                  Template Preview
                </CardTitle>
                <div className="flex items-center gap-1.5 flex-shrink-0">
                  <Badge
                    variant="outline"
                    className={`text-xs whitespace-nowrap ${getCategoryStyles(
                      template.category
                    )}`}
                  >
                    {template.category}
                  </Badge>
                  <Badge
                    variant="outline"
                    className={`text-xs whitespace-nowrap ${getStatusStyles(
                      template.status
                    )}`}
                  >
                    {template.status}
                  </Badge>
                </div>
              </div>
            </CardHeader>

            <CardContent className="pt-0">
              {/* Phone Mockup Container */}
              <div className="relative mx-auto w-full max-w-[280px]">
                {/* Phone Frame */}
                <div className="relative bg-gradient-to-b from-gray-900 via-gray-800 to-gray-900 rounded-[1.5rem] p-1.5 shadow-2xl w-full">
                  {/* Screen */}
                  <div className="bg-gradient-to-b from-gray-50 to-white rounded-[1.25rem] overflow-hidden w-full">
                    {/* Status Bar */}
                    <div className="bg-white px-3 py-1.5 flex justify-between items-center text-xs font-medium text-black">
                      <span>9:41</span>
                      <div className="flex items-center gap-1">
                        <div className="flex gap-0.5">
                          <div className="w-0.5 h-0.5 bg-black rounded-full"></div>
                          <div className="w-0.5 h-0.5 bg-black rounded-full"></div>
                          <div className="w-0.5 h-0.5 bg-black/30 rounded-full"></div>
                        </div>
                        <div className="ml-1 w-5 h-2.5 border border-black/30 rounded-sm">
                          <div className="w-3 h-1 bg-green-500 rounded-sm m-0.5"></div>
                        </div>
                      </div>
                    </div>

                    {/* WhatsApp Header */}
                    <div className="bg-green-600 px-3 py-2 flex items-center gap-2">
                      <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0">
                        <MessageSquare className="h-3 w-3 text-white" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-white font-medium text-xs truncate">
                          {template.name}
                        </h4>
                        <p className="text-white/70 text-xs truncate">
                          WhatsApp Business
                        </p>
                      </div>
                    </div>

                    {/* Message Content */}
                    <div className="p-2 bg-gray-100 h-[280px] overflow-y-auto">
                      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden w-full">
                        <div className="p-2 space-y-2">
                          {template.components &&
                          template.components.length > 0 ? (
                            [...template.components]
                              .sort((a, b) => {
                                const order = {
                                  HEADER: 1,
                                  BODY: 2,
                                  FOOTER: 3,
                                  BUTTONS: 4,
                                };
                                return (
                                  (order[a.type] || 5) - (order[b.type] || 5)
                                );
                              })
                              .map((component, index) => (
                                <div
                                  key={component.id || index}
                                  className="w-full"
                                >
                                  {renderComponent(component)}
                                </div>
                              ))
                          ) : (
                            <div className="text-center py-8 text-gray-500">
                              <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-50" />
                              <p className="text-sm">No content available</p>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Template Metadata */}
              <div className="mt-4 p-3 bg-gradient-to-r from-gray-50 to-gray-25 rounded-lg border border-gray-200 w-full">
                <h4 className="font-semibold text-sm text-gray-900 mb-2 flex items-center gap-2">
                  <Info className="h-3 w-3 flex-shrink-0" />
                  Template Details
                </h4>
                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600 flex-shrink-0">ID:</span>
                    <span className="font-mono text-xs truncate ml-2">
                      {template.wa_id}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600 flex-shrink-0">
                      Language:
                    </span>
                    <span className="font-medium truncate ml-2">
                      {template.language}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600 flex-shrink-0">
                      Components:
                    </span>
                    <Badge
                      variant="outline"
                      className="text-xs h-5 flex-shrink-0"
                    >
                      {template.components?.length || 0}
                    </Badge>
                  </div>
                </div>
              </div>

              {/* Variables */}
              {Object.keys(variables).length > 0 && (
                <div className="mt-4 p-3 bg-gradient-to-r from-blue-50 to-blue-25 rounded-lg border border-blue-200 w-full">
                  <h4 className="font-semibold text-sm text-gray-900 mb-2">
                    Variables Used
                  </h4>
                  <div className="flex flex-wrap gap-1.5">
                    {Object.entries(variables).map(([key, value]) => (
                      <div key={key} className="text-xs max-w-full">
                        <Badge
                          variant="outline"
                          className="bg-blue-50 text-blue-700 border-blue-200 truncate max-w-full"
                          title={`{{${key}}} → ${value}`}
                        >
                          <span className="truncate">
                            {`{{${key}}}`} → {value}
                          </span>
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Stats Section */}
        {showStats && reportData && (
          <div className="flex-1 space-y-6">
            {/* Performance Metrics Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-green-600">
                        Delivery Rate
                      </p>
                      <p className="text-2xl font-bold text-green-700">
                        {getDeliveryRate(reportData)}%
                      </p>
                    </div>
                    <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center">
                      <TrendingUp className="h-5 w-5 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-blue-600">
                        Read Rate
                      </p>
                      <p className="text-2xl font-bold text-blue-700">
                        {getReadRate(reportData)}%
                      </p>
                    </div>
                    <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                      <Eye className="h-5 w-5 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-purple-600">
                        Total Sent
                      </p>
                      <p className="text-2xl font-bold text-purple-700">
                        {reportData.total || 0}
                      </p>
                    </div>
                    <div className="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center">
                      <Send className="h-5 w-5 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Detailed Analytics */}
            {showExpandedView && (
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <Card className="bg-white border-gray-200">
                  <CardContent className="p-4 text-center">
                    <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center mx-auto mb-2">
                      <Send className="w-5 h-5 text-white" />
                    </div>
                    <div className="text-xl font-bold text-gray-900">
                      {reportData.sent_count || 0}
                    </div>
                    <div className="text-sm text-gray-600">Sent</div>
                  </CardContent>
                </Card>

                <Card className="bg-white border-gray-200">
                  <CardContent className="p-4 text-center">
                    <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center mx-auto mb-2">
                      <CheckCircle2 className="w-5 h-5 text-white" />
                    </div>
                    <div className="text-xl font-bold text-gray-900">
                      {reportData.dlvd_count || 0}
                    </div>
                    <div className="text-sm text-gray-600">Delivered</div>
                  </CardContent>
                </Card>

                <Card className="bg-white border-gray-200">
                  <CardContent className="p-4 text-center">
                    <div className="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center mx-auto mb-2">
                      <Eye className="w-5 h-5 text-white" />
                    </div>
                    <div className="text-xl font-bold text-gray-900">
                      {reportData.read_count || 0}
                    </div>
                    <div className="text-sm text-gray-600">Read</div>
                  </CardContent>
                </Card>

                <Card className="bg-white border-gray-200">
                  <CardContent className="p-4 text-center">
                    <div className="w-10 h-10 bg-red-600 rounded-lg flex items-center justify-center mx-auto mb-2">
                      <AlertCircle className="w-5 h-5 text-white" />
                    </div>
                    <div className="text-xl font-bold text-gray-900">
                      {reportData.failed_count || 0}
                    </div>
                    <div className="text-sm text-gray-600">Failed</div>
                  </CardContent>
                </Card>

                <Card className="bg-white border-gray-200">
                  <CardContent className="p-4 text-center">
                    <div className="w-10 h-10 bg-yellow-600 rounded-lg flex items-center justify-center mx-auto mb-2">
                      <Loader className="w-5 h-5 text-white" />
                    </div>
                    <div className="text-xl font-bold text-gray-900">
                      {reportData.other_count || 0}
                    </div>
                    <div className="text-sm text-gray-600">Pending</div>
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Campaign Info */}
            <Card className="bg-white border-gray-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <BarChart3 className="h-5 w-5 text-blue-600" />
                  Campaign Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Template:</span>
                      <span className="font-medium">{template.name}</span>
                    </div>
                    {reportData.user?.name && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">User:</span>
                        <span className="font-medium">
                          {reportData.user.name}
                        </span>
                      </div>
                    )}
                    {reportData.country?.name && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Country:</span>
                        <span className="font-medium flex items-center">
                          <MapPin className="h-3 w-3 mr-1" />
                          {reportData.country.name}
                        </span>
                      </div>
                    )}
                  </div>
                  <div className="space-y-2">
                    {reportData.status && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Status:</span>
                        <Badge
                          variant="outline"
                          className={
                            reportData.status === '1'
                              ? 'bg-green-50 text-green-700 border-green-200'
                              : 'bg-yellow-50 text-yellow-700 border-yellow-200'
                          }
                        >
                          {reportData.status === '1' ? 'Completed' : 'Pending'}
                        </Badge>
                      </div>
                    )}
                    {reportData.created_at && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Created:</span>
                        <span className="font-medium">
                          {formatDate(reportData.created_at)}
                        </span>
                      </div>
                    )}
                    {reportData.updated_at && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Updated:</span>
                        <span className="font-medium">
                          {formatDate(reportData.updated_at)}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default WhatsAppTemplateViewer;
