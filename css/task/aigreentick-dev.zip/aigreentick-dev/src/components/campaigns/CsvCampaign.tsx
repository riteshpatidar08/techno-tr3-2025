import React, { useState, useRef, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  sendCSVBroadcast,
  selectCSVBroadcastLoading,
  selectCSVBroadcastError,
  selectCSVBroadcastSuccess,
  selectLastCSVCampaign,
  clearCSVError,
  clearCSVSuccess,
} from '@/redux/broadcastSlice';
import {
  fetchTemplates,
  fetchTemplateById,
  selectTemplates,
  selectSelectedTemplate,
  selectSelectedTemplateLoading,
} from '@/redux/templateSlice';
import {
  fetchCountries,
  selectCountriesSorted,
  selectCountriesLoading,
} from '@/redux/countrySlice';
import WarningComponent from '@/components/ui/warning';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import {
  Upload,
  FileSpreadsheet,
  Calendar,
  Send,
  X,
  Settings,
  MessageSquare,
  Database,
  RefreshCw,
  Eye,
  Phone,
  Users,
  ExternalLink,
  Info,
  Variable,
  Globe,
  Image as ImageIcon,
  AlertCircle,
  CheckCircle,
} from 'lucide-react';
import * as XLSX from 'exceljs';

// Professional Template Preview Component
const TemplatePreview = ({
  template,
  loading,
  variables,
  columnMappings,
  csvData,
  csvHeaders,
}) => {
  if (loading) {
    return (
      <Card className="border-0 bg-gradient-to-br from-card to-card/50 sticky top-6 z-10">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-3 text-lg text-card-foreground">
            <div className="p-2 bg-primary/10 rounded-lg">
              <Eye className="h-5 w-5 text-primary" />
            </div>
            Template Preview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-6">
            <div className="space-y-3">
              <div className="h-4 bg-gradient-to-r from-muted to-muted/50 rounded-lg w-3/4"></div>
              <div className="h-32 bg-gradient-to-br from-muted to-muted/30 rounded-xl"></div>
              <div className="h-4 bg-gradient-to-r from-muted to-muted/50 rounded-lg w-1/2"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!template) {
    return (
      <Card className="border-0 bg-gradient-to-br from-card to-card/50 sticky top-6 z-10">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-3 text-lg text-card-foreground">
            <div className="p-2 bg-primary/10 rounded-lg">
              <Eye className="h-5 w-5 text-primary" />
            </div>
            Template Preview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <div className="relative mb-6">
              <div className="absolute inset-0 bg-primary/5 rounded-full blur-xl"></div>
              <div className="relative p-6 bg-muted/30 rounded-full w-20 h-20 mx-auto flex items-center justify-center">
                <Eye className="h-8 w-8 text-muted-foreground/70" />
              </div>
            </div>
            <h3 className="font-semibold text-foreground mb-2">
              No Template Selected
            </h3>
            <p className="text-sm">
              Choose a template to see the WhatsApp preview
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const replaceVariables = (
    text,
    variables,
    columnMappings,
    sampleRow = null
  ) => {
    if (!text) return '';
    let replacedText = text;

    Object.keys(variables || {}).forEach((index) => {
      const placeholder = `{{${index}}}`;
      let value;

      if (
        columnMappings &&
        columnMappings[index] &&
        columnMappings[index] !== '__no_mapping__' &&
        sampleRow
      ) {
        // Use sample data from CSV for preview
        value =
          sampleRow[columnMappings[index]] || `[${columnMappings[index]}]`;
      } else {
        // Use static value or placeholder
        value = variables[index] || `{{${index}}}`;
      }

      // Use split and join instead of regex for safer replacement
      replacedText = replacedText.split(placeholder).join(value);
    });
    return replacedText;
  };

  // Get sample row for preview
  const sampleRow = csvData && csvData.length > 0 ? csvData[0] : null;

  const renderComponent = (component) => {
    switch (component.type) {
      case 'HEADER':
        if (component.format === 'IMAGE' && component.image_url) {
          return (
            <div className="mb-3" key={component.id}>
              <div className="relative rounded-lg overflow-hidden bg-gradient-to-br from-muted/30 to-muted/10">
                <img
                  src={component.image_url}
                  alt="Template Header"
                  className="w-full h-32 object-cover"
                  onError={(e) => {
                    e.target.style.display = 'none';
                    e.target.nextSibling.style.display = 'flex';
                  }}
                />
                <div className="hidden w-full h-32 bg-gradient-to-br from-muted/50 to-muted/20 items-center justify-center">
                  <div className="p-3 bg-background/50 rounded-full">
                    <ImageIcon className="h-6 w-6 text-muted-foreground" />
                  </div>
                </div>
              </div>
            </div>
          );
        } else if (component.text) {
          return (
            <div className="mb-3" key={component.id}>
              <div className="p-3 bg-gradient-to-r from-primary/10 to-primary/5 border border-primary/20 rounded-lg">
                <h3 className="font-semibold text-primary text-xs leading-tight">
                  {replaceVariables(
                    component.text,
                    variables,
                    columnMappings,
                    sampleRow
                  )}
                </h3>
              </div>
            </div>
          );
        }
        return null;

      case 'BODY':
        return (
          <div className="mb-3" key={component.id}>
            <div className="p-3 bg-background/50 rounded-lg border border-border/30">
              <p className="text-foreground whitespace-pre-wrap leading-relaxed text-xs">
                {replaceVariables(
                  component.text,
                  variables,
                  columnMappings,
                  sampleRow
                )}
              </p>
            </div>
          </div>
        );

      case 'FOOTER':
        return (
          <div className="mb-3" key={component.id}>
            <div className="p-2 bg-muted/20 rounded-md border-t border-border/50">
              <p className="text-xs text-muted-foreground font-medium text-center">
                {replaceVariables(
                  component.text,
                  variables,
                  columnMappings,
                  sampleRow
                )}
              </p>
            </div>
          </div>
        );

      case 'BUTTONS':
        if (component.buttons && component.buttons.length > 0) {
          const urlButtons = component.buttons.filter(
            (btn) => btn.type === 'URL'
          );
          const phoneButtons = component.buttons.filter(
            (btn) => btn.type === 'PHONE_NUMBER'
          );
          const quickReplyButtons = component.buttons.filter(
            (btn) => btn.type === 'QUICK_REPLY'
          );

          return (
            <div className="space-y-3" key={component.id}>
              {/* URL and Phone buttons */}
              {(urlButtons.length > 0 || phoneButtons.length > 0) && (
                <div className="space-y-1.5">
                  {phoneButtons.map((button) => (
                    <Button
                      key={button.id}
                      variant="outline"
                      className="w-full justify-center gap-2 text-xs h-8 bg-gradient-to-r from-green-50 to-green-50/50 border-green-200 text-green-700 transition-all duration-200"
                      disabled
                    >
                      <Phone className="h-3 w-3" />
                      {button.text}
                    </Button>
                  ))}
                  {urlButtons.map((button) => (
                    <Button
                      key={button.id}
                      variant="outline"
                      className="w-full justify-center gap-2 text-xs h-8 bg-gradient-to-r from-blue-50 to-blue-50/50 border-blue-200 text-blue-700 transition-all duration-200"
                      disabled
                    >
                      <ExternalLink className="h-3 w-3" />
                      {button.text}
                    </Button>
                  ))}
                </div>
              )}

              {/* Quick Reply buttons */}
              {quickReplyButtons.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground font-medium">
                    <div className="w-1 h-1 bg-muted-foreground/50 rounded-full"></div>
                    Quick Replies
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {quickReplyButtons.map((button) => (
                      <Badge
                        key={button.id}
                        variant="secondary"
                        className="px-2 py-1 text-xs font-medium bg-gradient-to-r from-secondary to-secondary/70 transition-all duration-200 cursor-default border border-border/50"
                      >
                        {button.text}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        }
        return null;

      default:
        return null;
    }
  };

  return (
    <Card className="border-0 bg-gradient-to-br from-card via-card/95 to-card/90 sticky top-6 z-10">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-base text-card-foreground">
            <div className="p-1.5 bg-primary/10 rounded-lg">
              <Eye className="h-4 w-4 text-primary" />
            </div>
            Preview
          </CardTitle>
          <div className="flex items-center gap-1.5">
            <Badge
              variant="outline"
              className="text-xs bg-background/50 border-border/50"
            >
              {template.category}
            </Badge>
            <Badge
              variant={template.status === 'APPROVED' ? 'default' : 'secondary'}
              className={`text-xs ${
                template.status === 'APPROVED'
                  ? 'bg-green-100 text-green-700 border-green-200'
                  : 'bg-yellow-100 text-yellow-700 border-yellow-200'
              }`}
            >
              {template.status}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="relative scrollbar-hide mx-auto max-w-[280px]">
          {/* Phone Frame */}
          <div className="relative bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 rounded-[1.5rem] p-1.5 shadow-2xl">
            {/* Screen */}
            <div className="bg-gradient-to-b from-gray-50 to-white rounded-[1.25rem] overflow-hidden">
              {/* Status Bar */}
              <div className="bg-white px-4 py-1.5 flex justify-between items-center text-xs font-medium text-black">
                <span>9:41</span>
                <div className="flex items-center gap-1">
                  <div className="flex gap-0.5">
                    <div className="w-0.5 h-0.5 bg-black rounded-full"></div>
                    <div className="w-0.5 h-0.5 bg-black rounded-full"></div>
                    <div className="w-0.5 h-0.5 bg-black/30 rounded-full"></div>
                  </div>
                  <div className="ml-1 w-5 h-2.5 border border-black/30 rounded-sm">
                    <div className="w-3 h-1 bg-green-500 rounded-sm m-0.5"></div>
                  </div>
                </div>
              </div>

              {/* WhatsApp Header */}
              <div className="bg-[#075E54] px-3 py-2 flex items-center gap-2">
                <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center">
                  <MessageSquare className="h-3 w-3 text-white" />
                </div>
                <div className="flex-1">
                  <h4 className="text-white font-medium text-xs">
                    Business Account
                  </h4>
                  <p className="text-white/70 text-xs">Template Message</p>
                </div>
              </div>

              {/* Message Content - Scrollable for long content */}
              <div className="p-3 bg-[#E5DDD5] max-h-[350px] overflow-y-auto scrollbar-hide">
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
                  <div className="p-3 space-y-2">
                    {[...template.components]
                      .sort((a, b) => {
                        const order = {
                          HEADER: 1,
                          BODY: 2,
                          FOOTER: 3,
                          BUTTONS: 4,
                        };
                        return (order[a.type] || 5) - (order[b.type] || 5);
                      })
                      .map((component) => renderComponent(component))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Preview Note */}
        {sampleRow && Object.keys(columnMappings).length > 0 && (
          <div className="mt-4 p-3 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-200">
            <div className="flex items-center gap-2 mb-2">
              <Info className="h-3 w-3 text-blue-600" />
              <span className="text-xs font-medium text-blue-900">
                Preview shows data from first CSV row
              </span>
            </div>
          </div>
        )}

        {/* Template Metadata - Compact Version */}
        <div className="mt-4 p-3 bg-gradient-to-r from-muted/30 to-muted/10 rounded-lg border border-border/50">
          <h4 className="font-semibold text-sm text-foreground mb-2 flex items-center gap-2">
            <Info className="h-3 w-3" />
            Template Info
          </h4>
          <div className="space-y-1.5 text-xs">
            <div className="flex justify-between">
              <span className="text-muted-foreground">ID:</span>
              <code className="font-mono text-xs bg-background/50 px-1.5 py-0.5 rounded">
                {template.wa_id}
              </code>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Language:</span>
              <span className="uppercase font-medium">{template.language}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Components:</span>
              <Badge variant="outline" className="text-xs h-5">
                {template.components.length}
              </Badge>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

// Import your existing Redux logic

// Enhanced file parsing with ExcelJS
class FileParser {
  static async parseFile(file) {
    const result = {
      headers: [],
      data: [],
      errors: [],
      warnings: [],
      metadata: {
        fileName: file.name,
        fileSize: file.size,
        fileType: file.type,
        totalRows: 0,
        totalColumns: 0,
      },
    };

    try {
      if (file.name.toLowerCase().endsWith('.csv')) {
        return await this.parseCSV(file, result);
      } else if (file.name.toLowerCase().match(/\.(xlsx|xls)$/)) {
        return await this.parseExcel(file, result);
      } else {
        result.errors.push(
          'Unsupported file format. Please use .csv, .xlsx, or .xls files.'
        );
        return result;
      }
    } catch (error) {
      result.errors.push(`Failed to parse file: ${error.message}`);
      return result;
    }
  }

  static async parseExcel(file, result) {
    const workbook = new XLSX.Workbook();
    const buffer = await file.arrayBuffer();

    try {
      await workbook.xlsx.load(buffer);
    } catch (error) {
      // Try as XLS format
      try {
        // Note: ExcelJS doesn't support XLS directly, but we can provide a fallback
        result.errors.push(
          'XLS format detected. Please convert to XLSX or CSV format for better compatibility.'
        );
        return result;
      } catch (xlsError) {
        result.errors.push(
          "Unable to read Excel file. Please ensure it's not corrupted."
        );
        return result;
      }
    }

    // Get the first worksheet
    const worksheet = workbook.worksheets[0];

    if (!worksheet) {
      result.errors.push('No worksheets found in the Excel file.');
      return result;
    }

    // Extract headers from first row
    const headerRow = worksheet.getRow(1);
    const headers = [];

    headerRow.eachCell((cell, colNumber) => {
      const value =
        cell.value?.toString()?.trim() ||
        `Column_${String.fromCharCode(64 + colNumber)}`;
      headers.push(value);
    });

    if (headers.length === 0) {
      result.errors.push('No headers found in the first row.');
      return result;
    }

    result.headers = headers;
    result.metadata.totalColumns = headers.length;

    // Extract data rows
    const data = [];
    let rowCount = 0;

    worksheet.eachRow((row, rowNumber) => {
      if (rowNumber === 1) return; // Skip header row

      const rowData = { rowIndex: rowCount };
      let hasData = false;

      headers.forEach((header, colIndex) => {
        const cell = row.getCell(colIndex + 1);
        let value = '';

        if (cell.value !== null && cell.value !== undefined) {
          // Handle different cell types
          if (cell.value instanceof Date) {
            value = cell.value.toISOString().split('T')[0]; // Format as YYYY-MM-DD
          } else if (typeof cell.value === 'object' && cell.value.text) {
            value = cell.value.text; // Rich text
          } else {
            value = cell.value.toString().trim();
          }

          if (value) hasData = true;
        }

        rowData[header] = value;
      });

      if (hasData) {
        data.push(rowData);
        rowCount++;
      }
    });

    result.data = data;
    result.metadata.totalRows = data.length;

    // Add warnings for large files
    if (data.length > 10000) {
      result.warnings.push(
        `Large file detected with ${data.length} rows. Consider breaking into smaller batches.`
      );
    }

    if (data.length === 0) {
      result.warnings.push('No data rows found in the file.');
    }

    return result;
  }

  static async parseCSV(file, result) {
    const text = await file.text();

    try {
      // Auto-detect delimiter
      const delimiters = [',', ';', '\t', '|'];
      let bestDelimiter = ',';
      let maxColumns = 0;

      for (const delimiter of delimiters) {
        const firstLine = text.split('\n')[0];
        const columns = firstLine.split(delimiter).length;
        if (columns > maxColumns) {
          maxColumns = columns;
          bestDelimiter = delimiter;
        }
      }

      const lines = text.split('\n').filter((line) => line.trim());

      if (lines.length === 0) {
        result.errors.push('Empty CSV file.');
        return result;
      }

      // Parse CSV manually to handle quotes and escape characters
      const parseCSVLine = (line) => {
        const result = [];
        let current = '';
        let inQuotes = false;

        for (let i = 0; i < line.length; i++) {
          const char = line[i];

          if (char === '"') {
            if (inQuotes && line[i + 1] === '"') {
              current += '"';
              i++; // Skip next quote
            } else {
              inQuotes = !inQuotes;
            }
          } else if (char === bestDelimiter && !inQuotes) {
            result.push(current.trim());
            current = '';
          } else {
            current += char;
          }
        }

        result.push(current.trim());
        return result;
      };

      // Extract headers
      const headers = parseCSVLine(lines[0]).map((header, index) => {
        const cleanHeader = header.replace(/["\r\n]/g, '').trim();
        return cleanHeader || `Column_${String.fromCharCode(65 + index)}`;
      });

      result.headers = headers;
      result.metadata.totalColumns = headers.length;

      // Extract data
      const data = [];
      for (let i = 1; i < lines.length; i++) {
        const values = parseCSVLine(lines[i]);
        const rowData = { rowIndex: i - 1 };
        let hasData = false;

        headers.forEach((header, index) => {
          const value = values[index]?.replace(/["\r\n]/g, '')?.trim() || '';
          rowData[header] = value;
          if (value) hasData = true;
        });

        if (hasData) {
          data.push(rowData);
        }
      }

      result.data = data;
      result.metadata.totalRows = data.length;

      if (data.length === 0) {
        result.warnings.push('No data rows found in the CSV file.');
      }

      return result;
    } catch (error) {
      result.errors.push(`CSV parsing error: ${error.message}`);
      return result;
    }
  }

  static validatePhoneNumbers(data, columnName) {
    if (!data || !columnName) return [];

    const phoneRegex = /^\d{10,15}$/; // 10-15 digits
    const validNumbers = [];
    const invalidNumbers = [];

    data.forEach((row, index) => {
      const phoneValue = row[columnName]?.toString()?.replace(/\D/g, '') || '';

      if (phoneRegex.test(phoneValue)) {
        validNumbers.push({
          number: parseInt(phoneValue),
          rowIndex: index,
          originalValue: row[columnName],
        });
      } else if (phoneValue) {
        invalidNumbers.push({
          rowIndex: index,
          originalValue: row[columnName],
          reason:
            phoneValue.length < 10
              ? 'Too short'
              : phoneValue.length > 15
              ? 'Too long'
              : 'Invalid format',
        });
      }
    });

    return { validNumbers, invalidNumbers };
  }

  static detectPhoneColumn(headers, data) {
    // Priority keywords for phone columns
    const phoneKeywords = [
      { keywords: ['mobile', 'phone'], priority: 10 },
      { keywords: ['contact', 'number'], priority: 8 },
      { keywords: ['cell', 'telephone'], priority: 6 },
      { keywords: ['tel', 'mob'], priority: 4 },
    ];

    let bestColumn = null;
    let bestScore = 0;

    for (const header of headers) {
      const lowerHeader = header.toLowerCase();
      let score = 0;

      // Check keyword matches
      for (const { keywords, priority } of phoneKeywords) {
        if (keywords.some((keyword) => lowerHeader.includes(keyword))) {
          score += priority;
          break;
        }
      }

      // Check data pattern (sample first 10 rows)
      const sampleData = data.slice(0, 10);
      const phonePattern = /^\d{10,15}$/;
      const validPhoneCount = sampleData.filter((row) => {
        const value = row[header]?.toString()?.replace(/\D/g, '') || '';
        return phonePattern.test(value);
      }).length;

      const phoneDataScore = (validPhoneCount / sampleData.length) * 20;
      score += phoneDataScore;

      if (score > bestScore) {
        bestScore = score;
        bestColumn = header;
      }
    }

    return bestScore > 5 ? bestColumn : null;
  }
}

// Enhanced File Upload Component with ExcelJS integration
const EnhancedFileUpload = ({
  uploadedFile,
  onFileSelect,
  onFileRemove,
  parseResult,
  onShowCSVInfo,
  isDragOver,
  onDragHandlers,
}) => {
  const fileInputRef = useRef(null);

  return (
    <Card className="border-0 bg-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Database className="h-5 w-5 text-primary" />
            <CardTitle className="text-xl font-semibold text-card-foreground">
              Data Source
            </CardTitle>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onShowCSVInfo}
            className="text-muted-foreground hover:text-primary"
          >
            <Info className="h-4 w-4 mr-1" />
            File Guide
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div
          className={`border-2 border-dashed rounded-xl p-12 text-center transition-all duration-300 ${
            isDragOver
              ? 'border-primary bg-accent scale-105'
              : uploadedFile
              ? 'border-primary bg-accent'
              : 'border-border bg-muted hover:border-muted-foreground'
          }`}
          onDragOver={onDragHandlers.onDragOver}
          onDragLeave={onDragHandlers.onDragLeave}
          onDrop={onDragHandlers.onDrop}
        >
          {uploadedFile ? (
            <div className="space-y-4">
              <div className="bg-accent p-4 rounded-full w-fit mx-auto">
                <FileSpreadsheet className="h-12 w-12 text-primary" />
              </div>
              <div>
                <div className="flex items-center justify-center gap-3 mb-2">
                  <Badge
                    variant="outline"
                    className="bg-accent text-accent-foreground border-border px-4 py-2"
                  >
                    {uploadedFile.name}
                  </Badge>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onFileRemove}
                    className="h-8 w-8 p-0 text-destructive hover:text-destructive hover:bg-accent"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>

                {parseResult?.errors?.length > 0 ? (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-red-600">
                      <AlertCircle className="h-4 w-4" />
                      <span className="font-medium">Parsing Failed</span>
                    </div>
                    {parseResult.errors.map((error, index) => (
                      <p key={index} className="text-sm text-red-600">
                        {error}
                      </p>
                    ))}
                  </div>
                ) : parseResult ? (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-green-600">
                      <CheckCircle className="h-4 w-4" />
                      <span className="font-medium">
                        File parsed successfully!
                      </span>
                    </div>
                    <div className="flex items-center justify-center gap-4 text-sm">
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4 text-muted-foreground" />
                        <span className="text-muted-foreground">
                          {parseResult.metadata.totalRows} rows
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Database className="h-4 w-4 text-muted-foreground" />
                        <span className="text-muted-foreground">
                          {parseResult.metadata.totalColumns} columns
                        </span>
                      </div>
                    </div>

                    {parseResult.warnings?.length > 0 && (
                      <div className="mt-3 space-y-1">
                        {parseResult.warnings.map((warning, index) => (
                          <div
                            key={index}
                            className="flex items-center gap-2 text-amber-600 text-xs"
                          >
                            <Info className="h-3 w-3" />
                            <span>{warning}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="flex items-center gap-2 text-blue-600">
                    <RefreshCw className="h-4 w-4 animate-spin" />
                    <span className="font-medium">Processing file...</span>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="bg-muted p-4 rounded-full w-fit mx-auto">
                <Upload className="h-12 w-12 text-muted-foreground" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  Upload Your File
                </h3>
                <p className="text-muted-foreground mb-4">
                  Drag and drop your file here, or click to browse
                </p>
                <Button
                  variant="outline"
                  onClick={() => fileInputRef.current?.click()}
                  className="h-12 px-8 text-primary border-primary hover:bg-accent"
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Choose File
                </Button>
                <p className="text-xs text-muted-foreground mt-2">
                  Supports: .xlsx, .xls, .csv files •
                </p>
              </div>
            </div>
          )}
          <input
            ref={fileInputRef}
            type="file"
            accept=".xlsx,.xls,.csv"
            onChange={(e) => {
              const files = e.target.files;
              if (files && files[0]) {
                onFileSelect(files[0]);
              }
            }}
            className="hidden"
          />
        </div>
      </CardContent>
    </Card>
  );
};

// Enhanced Phone Column Selector with validation results
const EnhancedPhoneColumnSelector = ({
  headers,
  selectedColumn,
  onColumnChange,
  phoneValidation,
  parseResult,
}) => {
  return (
    <div className="space-y-3">
      <Label className="text-sm font-medium text-card-foreground flex items-center gap-2">
        <Phone className="h-4 w-4" />
        Mobile Number Column *
      </Label>

      <Select value={selectedColumn} onValueChange={onColumnChange}>
        <SelectTrigger className="h-12 bg-card border-input text-card-foreground">
          <SelectValue placeholder="Select mobile number column...">
            {selectedColumn && (
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-primary" />
                <Badge variant="outline" className="text-xs">
                  {String.fromCharCode(65 + headers.indexOf(selectedColumn))}
                </Badge>
                {selectedColumn}
              </div>
            )}
          </SelectValue>
        </SelectTrigger>
        <SelectContent>
          {headers.map((header, index) => (
            <SelectItem key={header} value={header}>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-xs">
                  {String.fromCharCode(65 + index)}
                </Badge>
                <Phone className="h-4 w-4" />
                {header}
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      {/* Phone Validation Results */}
      {phoneValidation && (
        <div className="space-y-2">
          {phoneValidation.validNumbers.length > 0 && (
            <div className="flex items-center gap-2 text-xs text-green-600">
              <CheckCircle className="h-3 w-3" />
              <span>
                Found {phoneValidation.validNumbers.length} valid phone numbers
              </span>
            </div>
          )}

          {phoneValidation.invalidNumbers.length > 0 && (
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-xs text-amber-600">
                <AlertCircle className="h-3 w-3" />
                <span>
                  {phoneValidation.invalidNumbers.length} rows with invalid
                  phone numbers
                </span>
              </div>
              <div className="max-h-20 overflow-y-auto space-y-1">
                {phoneValidation.invalidNumbers
                  .slice(0, 3)
                  .map((invalid, index) => (
                    <div
                      key={index}
                      className="text-xs text-muted-foreground pl-5"
                    >
                      Row {invalid.rowIndex + 2}: "{invalid.originalValue}" -{' '}
                      {invalid.reason}
                    </div>
                  ))}
                {phoneValidation.invalidNumbers.length > 3 && (
                  <div className="text-xs text-muted-foreground pl-5">
                    ...and {phoneValidation.invalidNumbers.length - 3} more
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

// Main Component with ExcelJS Integration
function CsvCampaign() {
  // State management
  const [template, setTemplate] = useState('');
  const [campaignName, setCampaignName] = useState('');
  const [selectedCountry, setSelectedCountry] = useState('');
  const [message, setMessage] = useState('');
  const [mobileColumn, setMobileColumn] = useState('');
  const [uploadedFile, setUploadedFile] = useState(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const [parseResult, setParseResult] = useState(null);
  const [phoneValidation, setPhoneValidation] = useState(null);
  const [templateVariables, setTemplateVariables] = useState({});
  const [columnMappings, setColumnMappings] = useState({});
  const [showCSVInfo, setShowCSVInfo] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  const dispatch = useDispatch();

  // Selectors
  const templates = useSelector(selectTemplates) || [];
  const selectedTemplateData = useSelector(selectSelectedTemplate);
  const templateLoading = useSelector(selectSelectedTemplateLoading);
  const countries = useSelector(selectCountriesSorted) || [];
  const countriesLoading = useSelector(selectCountriesLoading);
  const csvLoading = useSelector(selectCSVBroadcastLoading);
  const csvError = useSelector(selectCSVBroadcastError);
  const csvSuccess = useSelector(selectCSVBroadcastSuccess);
  const lastCSVCampaign = useSelector(selectLastCSVCampaign);

  // Initialize data
  useEffect(() => {
    dispatch(fetchTemplates());
    dispatch(fetchCountries());
  }, [dispatch]);

  // Set default country to India
  useEffect(() => {
    if (countries.length > 0 && !selectedCountry) {
      const indiaCountry = countries.find(
        (country) => country.mobile_code === '91'
      );
      if (indiaCountry) {
        setSelectedCountry(indiaCountry.id.toString());
      }
    }
  }, [countries, selectedCountry]);

  // Handle file selection and parsing with ExcelJS
  const handleFileSelect = async (file) => {
    setUploadedFile(file);
    setIsProcessing(true);
    setParseResult(null);
    setPhoneValidation(null);
    setMobileColumn('');
    setColumnMappings({});

    try {
      const result = await FileParser.parseFile(file);
      setParseResult(result);

      if (result.errors.length === 0 && result.data.length > 0) {
        // Auto-detect phone column
        const detectedColumn = FileParser.detectPhoneColumn(
          result.headers,
          result.data
        );
        if (detectedColumn) {
          setMobileColumn(detectedColumn);
          const validation = FileParser.validatePhoneNumbers(
            result.data,
            detectedColumn
          );
          setPhoneValidation(validation);
        }
      }
    } catch (error) {
      setParseResult({
        headers: [],
        data: [],
        errors: [`Unexpected error: ${error.message}`],
        warnings: [],
        metadata: {},
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle mobile column change
  const handleMobileColumnChange = (columnName) => {
    setMobileColumn(columnName);
    if (columnName && parseResult?.data) {
      const validation = FileParser.validatePhoneNumbers(
        parseResult.data,
        columnName
      );
      setPhoneValidation(validation);
    }
  };

  // Drag and drop handlers
  const dragHandlers = {
    onDragOver: (e) => {
      e.preventDefault();
      setIsDragOver(true);
    },
    onDragLeave: (e) => {
      e.preventDefault();
      setIsDragOver(false);
    },
    onDrop: (e) => {
      e.preventDefault();
      setIsDragOver(false);
      const files = e.dataTransfer.files;
      if (files && files[0]) {
        handleFileSelect(files[0]);
      }
    },
  };

  // Handle file removal
  const handleRemoveFile = () => {
    setUploadedFile(null);
    setParseResult(null);
    setPhoneValidation(null);
    setMobileColumn('');
    setColumnMappings({});
    setTemplateVariables({});
  };

  // Template handling
  const handleTemplateChange = (templateId) => {
    setTemplate(templateId);
    setTemplateVariables({});
    setColumnMappings({});
    if (templateId) {
      dispatch(fetchTemplateById(Number(templateId)));
    }
  };

  // Update message when template changes
  useEffect(() => {
    if (selectedTemplateData) {
      const bodyComponent = selectedTemplateData.components.find(
        (comp) => comp.type === 'BODY'
      );
      if (bodyComponent && bodyComponent.text) {
        setMessage(bodyComponent.text);
      }
    } else {
      setMessage('');
    }
  }, [selectedTemplateData]);

  // Variable and column mapping handlers
  const handleVariableChange = (index, value) => {
    setTemplateVariables((prev) => ({
      ...prev,
      [index]: value,
    }));
  };

  const handleColumnMapping = (variableIndex, columnName) => {
    setColumnMappings((prev) => ({
      ...prev,
      [variableIndex]: columnName === '__no_mapping__' ? '' : columnName,
    }));

    if (columnName && columnName !== '__no_mapping__') {
      setTemplateVariables((prev) => ({
        ...prev,
        [variableIndex]: '',
      }));
    }
  };

  // Form validation
  const areVariablesConfigured = () => {
    if (!selectedTemplateData) return true;

    const allVariables = [];
    selectedTemplateData.components.forEach((comp) => {
      if (comp.body_text && comp.body_text.length > 0) {
        comp.body_text.forEach((variable) => {
          allVariables.push(variable.text_index);
        });
      }
    });

    return allVariables.every(
      (varIndex) =>
        (columnMappings[varIndex] &&
          columnMappings[varIndex] !== '__no_mapping__') ||
        templateVariables[varIndex]
    );
  };

  const isFormValid =
    template &&
    campaignName &&
    message &&
    uploadedFile &&
    parseResult &&
    parseResult.errors.length === 0 &&
    mobileColumn &&
    phoneValidation?.validNumbers?.length > 0 &&
    areVariablesConfigured();

  // Get valid phone numbers for campaign
  const getValidPhoneNumbers = () => {
    return phoneValidation?.validNumbers?.map((item) => item.number) || [];
  };

  // Prepare CSV variables for API call
  const prepareCSVVariables = () => {
    if (
      !selectedTemplateData ||
      !parseResult?.data?.length ||
      !phoneValidation?.validNumbers?.length
    ) {
      return [];
    }

    const variables = [];

    // Extract template variables
    const templateVars = [];
    selectedTemplateData.components.forEach((comp) => {
      if (comp.body_text && comp.body_text.length > 0) {
        comp.body_text.forEach((variable) => {
          templateVars.push(variable.text_index);
        });
      }
    });

    // Map phone numbers to variables with dynamic column mapping
    phoneValidation.validNumbers.forEach(({ number, rowIndex }) => {
      const row = parseResult.data[rowIndex];
      const mobileVariables = {
        mobile: number,
        variable: templateVars.map((varIndex) => {
          let value;

          if (
            columnMappings[varIndex] &&
            columnMappings[varIndex] !== '__no_mapping__'
          ) {
            // Use dynamic value from CSV column
            value = row[columnMappings[varIndex]] || '';
          } else {
            // Use static value
            value = templateVariables[varIndex] || '';
          }

          return {
            variable: varIndex,
            value: value,
          };
        }),
      };
      variables.push(mobileVariables);
    });

    // Add the extra variable object as shown in your example payload
    if (templateVars.length > 0) {
      variables.push({
        variable: templateVars.map((varIndex) => ({
          variable: varIndex,
        })),
      });
    }

    return variables;
  };

  // Handle campaign send
  const handleSendCampaign = async () => {
    if (!isFormValid) return;

    const countryData = countries.find(
      (c) => c.id.toString() === selectedCountry
    );
    const phoneNumbers = getValidPhoneNumbers();
    const csvVariables = prepareCSVVariables();

    console.log('Debug - phoneNumbers:', phoneNumbers);
    console.log('Debug - phoneValidation:', phoneValidation);
    console.log('Debug - csvVariables:', csvVariables);

    // Prepare payload matching your required format
    const campaignData = {
      template_id: template,
      col_name: parseResult?.headers?.indexOf(mobileColumn)?.toString() || '0',
      country_id: countryData?.id || 98,
      camp_name: campaignName,
      is_media:
        selectedTemplateData?.components?.some(
          (c) => c.type === 'HEADER' && c.format === 'IMAGE'
        ) || false,
      media_type:
        selectedTemplateData?.components?.find(
          (c) => c.type === 'HEADER' && c.format === 'IMAGE'
        )?.format || '',
      media_url:
        selectedTemplateData?.components?.find(
          (c) => c.type === 'HEADER' && c.format === 'IMAGE'
        )?.image_url || '',
      mobile_numbers: phoneNumbers,
      schedule_date: '',
      variables: csvVariables,
    };

    console.log('Sending CSV campaign with payload:', campaignData);
    dispatch(sendCSVBroadcast(campaignData));
  };

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        {/* Success/Error Messages */}
        {csvSuccess && lastCSVCampaign && (
          <WarningComponent
            type="success"
            title="CSV Campaign Sent Successfully!"
            message={lastCSVCampaign.success}
            description={`Campaign "${campaignName}" has been sent to ${
              phoneValidation?.validNumbers?.length || 0
            } recipients.`}
            actions={[
              {
                label: 'Create New Campaign',
                onClick: () => {
                  dispatch(clearCSVSuccess());
                  setTemplate('');
                  setCampaignName('');
                  setMessage('');
                  setColumnMappings({});
                  setTemplateVariables({});
                  handleRemoveFile();
                },
                variant: 'default',
                icon: RefreshCw,
              },
            ]}
            dismissible
            onClose={() => dispatch(clearCSVSuccess())}
          />
        )}

        {csvError && (
          <WarningComponent
            type="error"
            title="CSV Campaign Failed"
            message="Failed to send CSV broadcast campaign"
            description={csvError}
            actions={[
              {
                label: 'Retry',
                onClick: handleSendCampaign,
                variant: 'default',
                icon: RefreshCw,
                loading: csvLoading,
              },
            ]}
            dismissible
            onClose={() => dispatch(clearCSVError())}
          />
        )}

        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="bg-primary p-3 rounded-xl">
              <FileSpreadsheet className="h-8 w-8 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-foreground">
                WhatsApp CSV Campaign
              </h1>
              <p className="text-lg text-muted-foreground mt-1">
                Enhanced with ExcelJS for better file handling
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-4 gap-8">
          {/* Left Column - Configuration */}
          <div className="xl:col-span-3 space-y-6">
            {/* Campaign Settings */}
            <Card className="border-0 bg-card">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Settings className="h-5 w-5 text-primary" />
                  <CardTitle className="text-xl font-semibold text-card-foreground">
                    Campaign Configuration
                  </CardTitle>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Template Selection */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-card-foreground">
                      Message Template *
                    </Label>
                    <Select
                      value={template}
                      onValueChange={handleTemplateChange}
                    >
                      <SelectTrigger className="h-12 bg-card border-input text-card-foreground">
                        <SelectValue placeholder="Choose your template..." />
                      </SelectTrigger>
                      <SelectContent>
                        {templates.map((temp) => (
                          <SelectItem key={temp.id} value={temp.id.toString()}>
                            <div className="flex flex-col">
                              <span>{temp.name}</span>
                              <span className="text-xs text-muted-foreground">
                                {temp.category} • {temp.status}
                              </span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Campaign Name */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-card-foreground">
                      Campaign Name *
                    </Label>
                    <Input
                      value={campaignName}
                      onChange={(e) => setCampaignName(e.target.value)}
                      placeholder="Enter campaign name..."
                      className="h-12 bg-card border-input text-card-foreground"
                    />
                  </div>

                  {/* Country Selection */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-card-foreground flex items-center gap-2">
                      <Globe className="h-4 w-4" />
                      Target Country *
                    </Label>
                    <Select
                      value={selectedCountry}
                      onValueChange={setSelectedCountry}
                      disabled={csvLoading || countriesLoading}
                    >
                      <SelectTrigger className="bg-card text-card-foreground max-w-xs border-none">
                        <SelectValue>
                          {countriesLoading ? (
                            <div className="flex items-center gap-1">
                              <RefreshCw className="h-4 w-4 animate-spin" />
                              Loading countries...
                            </div>
                          ) : selectedCountry ? (
                            <div className="flex items-center w-full">
                              <div className="w-16 flex-shrink-0">
                                <Badge
                                  variant="outline"
                                  className="text-xs border-none w-full flex justify-center"
                                >
                                  +
                                  {
                                    countries.find(
                                      (c) => c.id.toString() === selectedCountry
                                    )?.mobile_code
                                  }
                                </Badge>
                              </div>
                              <span className="flex-1 text-left truncate ml-2">
                                {
                                  countries.find(
                                    (c) => c.id.toString() === selectedCountry
                                  )?.name
                                }
                              </span>
                            </div>
                          ) : (
                            'Select a country'
                          )}
                        </SelectValue>
                      </SelectTrigger>
                      <SelectContent>
                        {countries.map((country) => (
                          <SelectItem
                            key={country.id}
                            value={country.id.toString()}
                          >
                            <div className="flex items-center w-full">
                              <div className="w-16 flex-shrink-0">
                                <Badge
                                  variant="outline"
                                  className="text-xs border-none w-full flex justify-center"
                                >
                                  +{country.mobile_code}
                                </Badge>
                              </div>
                              <span className="flex-1 text-left truncate ml-2">
                                {country.name}
                              </span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Phone Column Selector */}
                  {parseResult && parseResult.headers.length > 0 && (
                    <EnhancedPhoneColumnSelector
                      headers={parseResult.headers}
                      selectedColumn={mobileColumn}
                      onColumnChange={handleMobileColumnChange}
                      phoneValidation={phoneValidation}
                      parseResult={parseResult}
                    />
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Enhanced File Upload */}
            <EnhancedFileUpload
              uploadedFile={uploadedFile}
              onFileSelect={handleFileSelect}
              onFileRemove={handleRemoveFile}
              parseResult={parseResult}
              onShowCSVInfo={() => setShowCSVInfo(true)}
              isDragOver={isDragOver}
              onDragHandlers={dragHandlers}
            />

            {/* Template Variables - Enhanced */}
            {selectedTemplateData && parseResult && (
              <Card className="border-0 bg-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg text-card-foreground">
                    <Variable className="h-5 w-5" />
                    Template Variables & Column Mapping
                  </CardTitle>
                  <p className="text-sm text-muted-foreground">
                    Map template variables to your file columns for dynamic
                    content
                  </p>
                </CardHeader>
                <CardContent>
                  {(() => {
                    const allVariables = [];
                    selectedTemplateData.components.forEach((component) => {
                      if (
                        component.body_text &&
                        component.body_text.length > 0
                      ) {
                        component.body_text.forEach((variable) => {
                          allVariables.push({
                            ...variable,
                            componentType: component.type,
                          });
                        });
                      }
                    });

                    if (allVariables.length === 0) {
                      return (
                        <div className="text-center py-8 text-muted-foreground">
                          <Variable className="h-12 w-12 mx-auto mb-4 opacity-50" />
                          <p>
                            This template doesn't have any variables to
                            configure.
                          </p>
                        </div>
                      );
                    }

                    return (
                      <div className="space-y-6">
                        {allVariables.map((variable) => (
                          <div
                            key={variable.id}
                            className="space-y-4 p-4 bg-muted/20 rounded-lg border border-border/50"
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <Badge
                                  variant="outline"
                                  className="text-xs font-mono"
                                >
                                  {`{{${variable.text_index}}}`}
                                </Badge>
                                <span className="font-medium text-card-foreground">
                                  {variable.text}
                                </span>
                                <Badge variant="secondary" className="text-xs">
                                  {variable.componentType}
                                </Badge>
                              </div>
                            </div>

                            {/* Column Mapping */}
                            <div className="space-y-2">
                              <Label className="text-sm font-medium text-card-foreground flex items-center gap-2">
                                <Database className="h-4 w-4" />
                                Map to File Column
                              </Label>
                              <Select
                                value={
                                  columnMappings?.[variable.text_index] ||
                                  '__no_mapping__'
                                }
                                onValueChange={(value) =>
                                  handleColumnMapping(
                                    variable.text_index,
                                    value
                                  )
                                }
                              >
                                <SelectTrigger className="bg-card border-input text-card-foreground">
                                  <SelectValue placeholder="Select column to map...">
                                    {columnMappings?.[variable.text_index] && (
                                      <div className="flex items-center gap-2">
                                        <Badge
                                          variant="outline"
                                          className="text-xs"
                                        >
                                          {String.fromCharCode(
                                            65 +
                                              parseResult.headers.indexOf(
                                                columnMappings[
                                                  variable.text_index
                                                ]
                                              )
                                          )}
                                        </Badge>
                                        <Database className="h-4 w-4 text-primary" />
                                        {columnMappings[variable.text_index]}
                                      </div>
                                    )}
                                  </SelectValue>
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="__no_mapping__">
                                    <span className="text-muted-foreground">
                                      No mapping (use static value)
                                    </span>
                                  </SelectItem>
                                  {parseResult.headers.map((header, index) => (
                                    <SelectItem key={header} value={header}>
                                      <div className="flex items-center gap-2">
                                        <Badge
                                          variant="outline"
                                          className="text-xs"
                                        >
                                          {String.fromCharCode(65 + index)}
                                        </Badge>
                                        <Database className="h-4 w-4" />
                                        {header}
                                      </div>
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>

                            {/* Static Value Input */}
                            {(!columnMappings?.[variable.text_index] ||
                              columnMappings?.[variable.text_index] ===
                                '__no_mapping__') && (
                              <div className="space-y-2">
                                <Label className="text-sm font-medium text-card-foreground flex items-center gap-2">
                                  <Variable className="h-4 w-4" />
                                  Static Value
                                </Label>
                                <Input
                                  placeholder={`Enter static value for ${variable.text}`}
                                  value={
                                    templateVariables[variable.text_index] || ''
                                  }
                                  onChange={(e) =>
                                    handleVariableChange(
                                      variable.text_index,
                                      e.target.value
                                    )
                                  }
                                  className="bg-card border-input text-card-foreground"
                                />
                              </div>
                            )}

                            {/* Preview */}
                            {columnMappings?.[variable.text_index] &&
                              columnMappings?.[variable.text_index] !==
                                '__no_mapping__' && (
                                <div className="p-3 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-md border border-blue-200">
                                  <div className="flex items-center gap-2 mb-2">
                                    <Eye className="h-4 w-4 text-blue-600" />
                                    <span className="text-sm font-medium text-blue-900">
                                      Dynamic Mapping Preview
                                    </span>
                                  </div>
                                  <div className="text-xs text-blue-700">
                                    <span className="font-mono bg-white px-1.5 py-0.5 rounded border">
                                      {`{{${variable.text_index}}}`}
                                    </span>
                                    <span className="mx-2">→</span>
                                    <span className="font-mono bg-white px-1.5 py-0.5 rounded border">
                                      Column{' '}
                                      {String.fromCharCode(
                                        65 +
                                          parseResult.headers.indexOf(
                                            columnMappings[variable.text_index]
                                          )
                                      )}{' '}
                                      ({columnMappings[variable.text_index]})
                                    </span>
                                  </div>
                                  {parseResult.data.length > 0 && (
                                    <div className="mt-2 text-xs text-blue-600">
                                      Sample: "
                                      {parseResult.data[0][
                                        columnMappings[variable.text_index]
                                      ] || '[empty]'}
                                      "
                                    </div>
                                  )}
                                </div>
                              )}
                          </div>
                        ))}
                      </div>
                    );
                  })()}
                </CardContent>
              </Card>
            )}

          
            {parseResult && parseResult.data.length > 0 && (
              <Card className="border-0 bg-card">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Eye className="h-5 w-5 text-primary" />
                      <CardTitle className="text-xl font-semibold text-card-foreground">
                        Data Preview
                      </CardTitle>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">
                        {parseResult.metadata.totalRows} rows
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {parseResult.metadata.totalColumns} columns
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="overflow-x-auto">
                    <table className="w-full border-none text-sm">
                      <thead>
                        <tr className="borber-none">
                          {parseResult.headers.map((header, index) => (
                            <th
                              key={header}
                              className="text-left p-2 font-medium"
                            >
                              <div className="flex items-center gap-2">
                                <Badge variant="outline" className="text-xs">
                                  {String.fromCharCode(65 + index)}
                                </Badge>
                                {header === mobileColumn && (
                                  <Phone className="h-3 w-3 text-primary" />
                                )}
                                {Object.values(columnMappings).includes(
                                  header
                                ) && (
                                  <Variable className="h-3 w-3 text-green-600" />
                                )}
                                {header}
                              </div>
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {parseResult.data.slice(0, 5).map((row, index) => (
                          <tr key={index} className="border-b">
                            {parseResult.headers.map((header) => (
                              <td
                                key={header}
                                className="p-2 text-muted-foreground"
                              >
                                <div className="max-w-[200px] truncate">
                                  {row[header] || '-'}
                                </div>
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {parseResult.data.length > 5 && (
                      <p className="text-xs text-muted-foreground mt-2 text-center">
                        ... and {parseResult.data.length - 5} more rows
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

    
          <div className="xl:col-span-1 space-y-6">
            {/* Message Content */}
            <Card className="border-0 bg-card">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5 text-primary" />
                  <CardTitle className="text-xl font-semibold text-card-foreground">
                    Message Content
                  </CardTitle>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-2">
                  <Label className="text-sm font-medium text-card-foreground">
                    Template Message
                  </Label>
                  <Textarea
                    value={message}
                    placeholder="Template message will appear here after selection..."
                    className="min-h-[120px] resize-none bg-muted/50 border-input text-card-foreground text-sm"
                    readOnly
                  />
                  {selectedTemplateData && (
                    <p className="text-xs text-muted-foreground">
                      Template variables will be automatically filled from your
                      file data
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

         
            <div className="relative z-10">
              <TemplatePreview
                template={selectedTemplateData}
                loading={templateLoading}
                variables={templateVariables}
                columnMappings={columnMappings}
                csvData={parseResult?.data || []}
                csvHeaders={parseResult?.headers || []}
              />
            </div>

            {/* Campaign Actions */}
            <Card className="border-0 bg-card">
              <CardContent className="p-6">
                <div className="space-y-4">
                  <Button
                    className="w-full bg-primary hover:bg-primary/90 text-primary-foreground h-12 text-base font-medium"
                    disabled={!isFormValid || csvLoading || isProcessing}
                    onClick={handleSendCampaign}
                  >
                    {csvLoading || isProcessing ? (
                      <>
                        <RefreshCw className="h-5 w-5 mr-2 animate-spin" />
                        {isProcessing
                          ? 'Processing File...'
                          : 'Sending Campaign...'}
                      </>
                    ) : (
                      <>
                        <Send className="h-5 w-5 mr-2" />
                        Send CSV Campaign
                      </>
                    )}
                  </Button>

                  {/* Form Validation Messages */}
                  {!isFormValid && (
                    <div className="bg-secondary border border-border rounded-lg p-3">
                      <p className="text-sm text-secondary-foreground font-medium">
                        ⚠️ Please complete all required fields to proceed
                      </p>
                      <ul className="text-xs text-muted-foreground mt-1 space-y-1">
                        {!template && <li>• Select a template</li>}
                        {!campaignName && <li>• Enter campaign name</li>}
                        {!uploadedFile && <li>• Upload a file</li>}
                        {parseResult?.errors?.length > 0 && (
                          <li>• Fix file parsing errors</li>
                        )}
                        {!mobileColumn && (
                          <li>• Select mobile number column</li>
                        )}
                        {(!phoneValidation?.validNumbers?.length ||
                          phoneValidation?.validNumbers?.length === 0) && (
                          <li>• Ensure file has valid phone numbers</li>
                        )}
                        {!areVariablesConfigured() && (
                          <li>• Configure all template variables</li>
                        )}
                      </ul>
                    </div>
                  )}

                  {/* Processing Status */}
                  {isProcessing && (
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                      <div className="flex items-center gap-2 text-blue-700">
                        <RefreshCw className="h-4 w-4 animate-spin" />
                        <span className="text-sm font-medium">
                          Processing your file...
                        </span>
                      </div>
                      <p className="text-xs text-blue-600 mt-1">
                        Parsing and Validating your data
                      </p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Campaign Summary */}
            {parseResult &&
              campaignName &&
              phoneValidation?.validNumbers?.length > 0 && (
                <Card className="border-0 bg-accent">
                  <CardContent className="p-6">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <h3 className="font-semibold text-accent-foreground text-lg">
                          Campaign Summary
                        </h3>
                        <Badge
                          className={`${
                            isFormValid
                              ? 'bg-primary text-primary-foreground'
                              : 'bg-yellow-500 text-yellow-50'
                          }`}
                        >
                          {isFormValid
                            ? 'Ready to Deploy'
                            : 'Configuration Needed'}
                        </Badge>
                      </div>
                      <div className="h-px bg-border my-2"></div>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground font-medium">
                            Campaign:
                          </span>
                          <span className="text-accent-foreground">
                            {campaignName}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground font-medium">
                            File:
                          </span>
                          <span className="text-accent-foreground">
                            {uploadedFile?.name}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground font-medium">
                            Valid Recipients:
                          </span>
                          <span className="text-accent-foreground font-semibold">
                            {phoneValidation?.validNumbers?.length || 0}
                          </span>
                        </div>
                        {phoneValidation?.invalidNumbers?.length > 0 && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground font-medium">
                              Invalid Numbers:
                            </span>
                            <span className="text-amber-600 font-semibold">
                              {phoneValidation.invalidNumbers.length}
                            </span>
                          </div>
                        )}
                        <div className="flex justify-between">
                          <span className="text-muted-foreground font-medium">
                            Mobile Column:
                          </span>
                          <div className="flex items-center gap-1">
                            <Badge variant="outline" className="text-xs">
                              {mobileColumn
                                ? String.fromCharCode(
                                    65 +
                                      parseResult.headers.indexOf(mobileColumn)
                                  )
                                : ''}
                            </Badge>
                            <span className="text-accent-foreground">
                              {mobileColumn}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
          </div>
        </div>

        {/* CSV Info Modal placeholder */}
      {/* CSV Info Modal */}
      {showCSVInfo && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-card rounded-xl shadow-2xl max-w-3xl w-full max-h-[70vh] overflow-y-auto">
              <div className="p-6 border-b border-border">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold text-card-foreground flex items-center gap-2">
                    <FileSpreadsheet className="h-5 w-5 text-primary" />
                    File Format Guide
                  </h2>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowCSVInfo(false)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div className="p-6 space-y-6">
                {/* File Requirements */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-primary">
                    <CheckCircle className="h-5 w-5" />
                    <span className="font-semibold text-lg">File Requirements</span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <FileSpreadsheet className="h-4 w-4 text-green-600" />
                        <span className="font-medium text-green-800">Supported Formats</span>
                      </div>
                      <ul className="text-sm text-green-700 space-y-1">
                        <li>• Excel (.xlsx, .xls)</li>
                        <li>• CSV (.csv)</li>
                        <li>• UTF-8 encoding recommended</li>
                      </ul>
                    </div>
                    
                    <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Phone className="h-4 w-4 text-blue-600" />
                        <span className="font-medium text-blue-800">Phone Numbers</span>
                      </div>
                      <ul className="text-sm text-blue-700 space-y-1">
                        <li>• 10-15 digits only</li>
                        <li>• No country code prefix</li>
                        <li>• No special characters</li>
                      </ul>
                    </div>
                    
                    <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Database className="h-4 w-4 text-purple-600" />
                        <span className="font-medium text-purple-800">File Structure</span>
                      </div>
                      <ul className="text-sm text-purple-700 space-y-1">
                        <li>• First row = Headers</li>
                        <li>• No empty columns</li>
                        <li>• Max 10,000 rows</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Sample File Structure */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-primary">
                    <Eye className="h-5 w-5" />
                    <span className="font-semibold text-lg">Correct File Example</span>
                  </div>
                  
                  <div className="bg-muted p-4 rounded-lg overflow-x-auto">
                    <table className="w-full text-sm border-collapse">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left p-2 font-semibold bg-green-100 text-green-800">mobile</th>
                          <th className="text-left p-2 font-semibold bg-blue-100 text-blue-800">name</th>
                          <th className="text-left p-2 font-semibold bg-purple-100 text-purple-800">company</th>
                          <th className="text-left p-2 font-semibold bg-orange-100 text-orange-800">city</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="border-b border-border">
                          <td className="p-2 font-mono">8815227632</td>
                          <td className="p-2">Ritesh</td>
                          <td className="p-2">Grras Solutions</td>
                          <td className="p-2">Jaipur</td>
                        </tr>
                        <tr className="border-b border-border">
                          <td className="p-2 font-mono">8765432109</td>
                          <td className="p-2">Jane Smith</td>
                          <td className="p-2">XYZ Ltd</td>
                          <td className="p-2">Delhi</td>
                        </tr>
                        <tr className="border-b border-border">
                          <td className="p-2 font-mono">7654321098</td>
                          <td className="p-2">Mike Johnson</td>
                          <td className="p-2">Tech Solutions</td>
                          <td className="p-2">Bangalore</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

               
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-primary">
                    <Phone className="h-5 w-5" />
                    <span className="font-semibold text-lg">Phone Number Guidelines</span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-3">
                      <div className="flex items-center gap-2 text-green-600">
                        <CheckCircle className="h-4 w-4" />
                        <span className="font-medium">Correct Examples</span>
                      </div>
                      <div className="bg-green-50 p-3 rounded border border-green-200">
                        <ul className="text-sm space-y-1 font-mono">
                          <li className="text-green-700">• 9876543210</li>
                          <li className="text-green-700">• 8765432109</li>
                          <li className="text-green-700">• 7654321098</li>
                        </ul>
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <div className="flex items-center gap-2 text-red-600">
                        <AlertCircle className="h-4 w-4" />
                        <span className="font-medium">Incorrect Examples</span>
                      </div>
                      <div className="bg-red-50 p-3 rounded border border-red-200">
                        <ul className="text-sm space-y-1 font-mono">
                          <li className="text-red-700">• +91-9876543210</li>
                          <li className="text-red-700">• 91 9876543210</li>
                          <li className="text-red-700">• (987) 654-3210</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Common Issues */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-amber-600">
                    <AlertCircle className="h-5 w-5" />
                    <span className="font-semibold text-lg">Common Issues to Avoid</span>
                  </div>
                  
                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                    <ul className="space-y-2 text-sm text-amber-800">
                      <li className="flex items-start gap-2">
                        <X className="h-4 w-4 text-red-500 mt-0.5 flex-shrink-0" />
                        <span><strong>Empty headers:</strong> Make sure first row has column names</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <X className="h-4 w-4 text-red-500 mt-0.5 flex-shrink-0" />
                        <span><strong>Phone format:</strong> Remove country codes, spaces, and special characters</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <X className="h-4 w-4 text-red-500 mt-0.5 flex-shrink-0" />
                        <span><strong>Mixed data:</strong> Keep phone numbers in separate column from other data</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <X className="h-4 w-4 text-red-500 mt-0.5 flex-shrink-0" />
                        <span><strong>Large files:</strong> Break files larger than 10,000 rows into smaller batches</span>
                      </li>
                    </ul>
                  </div>
                </div>

                {/* Template Variables Info */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-primary">
                    <Variable className="h-5 w-5" />
                    <span className="font-semibold text-lg">Using Template Variables</span>
                  </div>
                  
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <p className="text-sm text-blue-800 mb-3">
                      Column names in your file can be mapped to template variables for personalized messages:
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="font-medium text-blue-900">Template Variable:</span>
                        <div className="font-mono bg-white px-2 py-1 rounded mt-1 border">
                          Hi {'{{1}}'}, welcome to {'{{2}}'}!
                        </div>
                      </div>
                      <div>
                        <span className="font-medium text-blue-900">File Columns:</span>
                        <div className="space-y-1 mt-1">
                          <div className="font-mono bg-white px-2 py-1 rounded border">{'{1}'} → name column</div>
                          <div className="font-mono bg-white px-2 py-1 rounded border">{'{2}'} → company column</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="p-6 border-t border-border bg-muted/30">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Info className="h-4 w-4" />
                    <span>Need help? Contact support for file preparation assistance</span>
                  </div>
                  <Button
                    onClick={() => setShowCSVInfo(false)}
                    className="px-6"
                  >
                    Got it!
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default CsvCampaign;
