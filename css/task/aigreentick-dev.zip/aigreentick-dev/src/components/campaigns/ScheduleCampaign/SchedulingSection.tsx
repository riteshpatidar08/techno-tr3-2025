import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface SchedulingSectionProps {
  sendOption: string;
  onSendOptionChange: (option: string) => void;
}

export const SchedulingSection: React.FC<SchedulingSectionProps> = ({
  sendOption,
  onSendOptionChange,
}) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>When do you want to send it?</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center space-x-3">
            <div className="flex items-center">
              <div className="w-4 h-4 rounded-full border-2 border-green-500 bg-green-500 flex items-center justify-center mr-3">
                <div className="w-2 h-2 rounded-full bg-white"></div>
              </div>
              <label className="text-sm font-medium text-gray-900">
                Send now
              </label>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <div className="flex items-center">
              <div className="w-4 h-4 rounded-full border-2 border-gray-300 mr-3"></div>
              <label className="text-sm font-medium text-gray-500">
                Schedule for a specific time
              </label>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
