import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { AvailableTemplate } from './types';

interface BroadcastFormProps {
  broadcastName: string;
  selectedTemplate: string;
  availableTemplates: AvailableTemplate[];
  onBroadcastNameChange: (name: string) => void;
  onTemplateChange: (template: string) => void;
}

export const BroadcastForm: React.FC<BroadcastFormProps> = ({
  broadcastName,
  selectedTemplate,
  availableTemplates,
  onBroadcastNameChange,
  onTemplateChange,
}) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>What message do you want to send?</CardTitle>
        <p className="text-sm text-gray-500">
          Add broadcast name and template below
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <label className="text-sm font-medium text-gray-700 block mb-2">
            Broadcast name
          </label>
          <Input
            value={broadcastName}
            onChange={(e) => onBroadcastNameChange(e.target.value)}
            className="max-w-md"
          />
        </div>
        <div>
          <label className="text-sm font-medium text-gray-700 block mb-2">
            Select template message
          </label>
          <div className="flex items-center space-x-3">
            <Select value={selectedTemplate} onValueChange={onTemplateChange}>
              <SelectTrigger className="max-w-md">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {availableTemplates.map((template) => (
                  <SelectItem key={template.id} value={template.name}>
                    {template.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="link" className="text-green-500">
              +Add New Template
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
