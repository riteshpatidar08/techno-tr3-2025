export interface Contact {
  id: number;
  name: string;
  phone: string;
  allowBroadcast: boolean;
  attributes: {
    channel: string;
    source: string;
    type: string;
    priority: string;
    leadScore: string;
  };
}

export interface TemplateComponent {
  type: 'HEADER' | 'BODY' | 'FOOTER' | 'BUTTONS';
  format?: 'TEXT' | 'IMAGE';
  text?: string;
  image_url?: string;
  buttons?: Array<{
    type: string;
    text: string;
  }>;
}

export interface Template {
  name: string;
  components: TemplateComponent[];
}

export interface AvailableTemplate {
  id: number;
  name: string;
  category: string;
  template: Template;
}

export interface ScheduledBroadcast {
  id: number;
  name: string;
  template: string;
  contacts: number;
  scheduled: string;
  status: 'scheduled' | 'paused';
  createdAt: string;
}

export interface FilterCondition {
  id: string;
  attribute: string;
  operation: string;
  value: string;
}

export interface VariableValues {
  [key: string]: string;
}
