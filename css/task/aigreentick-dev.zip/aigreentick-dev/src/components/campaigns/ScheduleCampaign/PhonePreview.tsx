import React from 'react';
import { Eye } from 'lucide-react';
import { TemplatePreview } from './TemplatePreview';
import { TemplateVariables } from './TemplateVariables';
import { Template, VariableValues } from './types';

interface PhonePreviewProps {
  template: Template;
  variableValues: VariableValues;
  templateVariables: string[];
  onVariableChange: (variable: string, value: string) => void;
}

export const PhonePreview: React.FC<PhonePreviewProps> = ({
  template,
  variableValues,
  templateVariables,
  onVariableChange,
}) => {
  return (
    <div className="w-96 bg-gray-50 border-l border-gray-200 overflow-y-auto scrollbar-hide">
      <div className="p-6 pb-20">
        <div className="flex items-center space-x-2 mb-6">
          <Eye className="w-5 h-5 text-gray-600" />
          <h3 className="text-lg font-semibold text-gray-900">Preview</h3>
        </div>

        <div className="bg-black rounded-[2.5rem] p-2 shadow-2xl">
          <div className="bg-white rounded-[2rem] overflow-hidden">
            <div className="bg-gray-900 h-6 flex items-center justify-center rounded-t-[2rem]">
              <div className="w-16 h-1 bg-gray-600 rounded-full"></div>
            </div>

            <div
              className="bg-[#e5ddd5] min-h-[500px] relative"
              style={{
                backgroundImage: `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23ffffff' fill-opacity='0.03'%3E%3Cpath d='m0 40l40-40h-40v40zm10-10l30-30h-30v30z'/%3E%3C/g%3E%3C/svg%3E")`,
              }}
            >
              <TemplatePreview
                template={template}
                variableValues={variableValues}
              />
            </div>

            <div className="bg-white h-6 rounded-b-[2rem]"></div>
          </div>
        </div>

        <TemplateVariables
          variables={templateVariables}
          variableValues={variableValues}
          onVariableChange={onVariableChange}
        />
      </div>
    </div>
  );
};
