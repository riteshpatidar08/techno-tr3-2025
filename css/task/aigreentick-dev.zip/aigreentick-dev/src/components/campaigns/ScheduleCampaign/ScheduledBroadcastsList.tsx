import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  flexRender,
  getCoreRowModel,
  useReactTable,
  createColumnHelper,
  getSortedRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  SortingState,
  ColumnFiltersState,
  PaginationState,
  ColumnDef,
} from '@tanstack/react-table';
import {
  Search,
  Info,
  Calendar,
  Edit,
  Trash2,
  Play,
  Pause,
  MoreHorizontal,
  ArrowUpDown,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
} from 'lucide-react';
import { ScheduledBroadcast } from './types';

interface ScheduledBroadcastsListProps {
  broadcasts: ScheduledBroadcast[];
  onCreateNew: () => void;
  onEdit?: (broadcast: ScheduledBroadcast) => void;
  onDelete?: (broadcast: ScheduledBroadcast) => void;
  onTogglePause?: (broadcast: ScheduledBroadcast) => void;
}

export const ScheduledBroadcastsList: React.FC<
  ScheduledBroadcastsListProps
> = ({ broadcasts, onCreateNew, onEdit, onDelete, onTogglePause }) => {
  const [sorting, setSorting] = useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
  const [globalFilter, setGlobalFilter] = useState('');
  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
  });
  const columnHelper = createColumnHelper<ScheduledBroadcast>();
  const columns: ColumnDef<ScheduledBroadcast>[] = [
    columnHelper.accessor('name', {
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')}
          className="h-auto p-0 font-medium text-left justify-start"
        >
          Broadcast name
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => {
        const broadcast = row.original;
        return (
          <div>
            <div className="font-medium text-gray-900">{broadcast.name}</div>
            <div className="text-sm text-gray-500">
              Template: {broadcast.template} • {broadcast.contacts} contacts
            </div>
          </div>
        );
      },
    }),
    columnHelper.accessor('scheduled', {
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')}
          className="h-auto p-0 font-medium text-left justify-start"
        >
          Scheduled
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => {
        const broadcast = row.original;
        return (
          <div>
            <div className="flex items-center space-x-2">
              <Calendar className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-700">
                {broadcast.scheduled}
              </span>
            </div>
            <div className="flex items-center space-x-2 mt-1">
              <Badge
                variant={
                  broadcast.status === 'scheduled' ? 'default' : 'secondary'
                }
                className={
                  broadcast.status === 'scheduled'
                    ? 'bg-green-100 text-green-800'
                    : 'bg-yellow-100 text-yellow-800'
                }
              >
                {broadcast.status.charAt(0).toUpperCase() +
                  broadcast.status.slice(1)}
              </Badge>
            </div>
          </div>
        );
      },
    }),
    columnHelper.display({
      id: 'actions',
      header: 'Actions',
      cell: ({ row }) => {
        const broadcast = row.original;
        return (
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onEdit?.(broadcast)}
              className="h-8 w-8 p-0"
              title="Edit broadcast"
            >
              <Edit className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onTogglePause?.(broadcast)}
              className="h-8 w-8 p-0"
              title={
                broadcast.status === 'scheduled'
                  ? 'Pause broadcast'
                  : 'Resume broadcast'
              }
            >
              {broadcast.status === 'scheduled' ? (
                <Pause className="w-4 h-4" />
              ) : (
                <Play className="w-4 h-4" />
              )}
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                  <MoreHorizontal className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem
                  onClick={() => onEdit?.(broadcast)}
                  className="cursor-pointer"
                >
                  <Edit className="w-4 h-4 mr-2" />
                  Edit broadcast
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => onTogglePause?.(broadcast)}
                  className="cursor-pointer"
                >
                  {broadcast.status === 'scheduled' ? (
                    <>
                      <Pause className="w-4 h-4 mr-2" />
                      Pause broadcast
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 mr-2" />
                      Resume broadcast
                    </>
                  )}
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => {
                    if (
                      window.confirm(
                        'Are you sure you want to delete this broadcast?'
                      )
                    ) {
                      onDelete?.(broadcast);
                    }
                  }}
                  className="text-red-600 focus:text-red-600 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete broadcast
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        );
      },
    }),
  ];
  const table = useReactTable({
    data: broadcasts,
    columns,
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    onPaginationChange: setPagination,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    onGlobalFilterChange: setGlobalFilter,
    state: {
      sorting,
      columnFilters,
      globalFilter,
      pagination,
    },
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h1 className="text-2xl font-bold text-gray-900">
              Scheduled Broadcast
            </h1>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search broadcasts..."
                value={globalFilter ?? ''}
                onChange={(event) =>
                  setGlobalFilter(String(event.target.value))
                }
                className="pl-10 w-64"
              />
            </div>
          </div>
          <div className="flex items-center space-x-3">
           
            <Button
              onClick={onCreateNew}
              className="bg-green-500 hover:bg-green-600 text-white"
            >
              New Broadcast
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6">
        <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
          {broadcasts.length === 0 ? (
            /* Empty State */
            <div className="text-center py-12">
              <div className="flex flex-col items-center space-y-3">
                <Calendar className="w-12 h-12 text-gray-300" />
                <div>
                  <h3 className="text-lg font-medium text-gray-500">
                    No scheduled broadcasts
                  </h3>
                  <p className="text-sm text-gray-400 mt-1">
                    Create your first broadcast to get started
                  </p>
                </div>
                <Button
                  onClick={onCreateNew}
                  className="bg-green-500 hover:bg-green-600 text-white"
                >
                  Create Broadcast
                </Button>
              </div>
            </div>
          ) : (
          
            <Table>
              <TableHeader>
                {table.getHeaderGroups().map((headerGroup) => (
                  <TableRow key={headerGroup.id}>
                    {headerGroup.headers.map((header) => (
                      <TableHead key={header.id} className="px-6 py-4">
                        {header.isPlaceholder
                          ? null
                          : flexRender(
                              header.column.columnDef.header,
                              header.getContext()
                            )}
                      </TableHead>
                    ))}
                  </TableRow>
                ))}
              </TableHeader>
              <TableBody>
                {table.getRowModel().rows?.length ? (
                  table.getRowModel().rows.map((row) => (
                    <TableRow
                      key={row.id}
                      data-state={row.getIsSelected() && 'selected'}
                      className="hover:bg-gray-50"
                    >
                      {row.getVisibleCells().map((cell) => (
                        <TableCell key={cell.id} className="px-6 py-4">
                          {flexRender(
                            cell.column.columnDef.cell,
                            cell.getContext()
                          )}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell
                      colSpan={columns.length}
                      className="h-24 text-center"
                    >
                      <div className="flex flex-col items-center space-y-2">
                        <Search className="w-8 h-8 text-gray-300" />
                        <span className="text-gray-500">No results found.</span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setGlobalFilter('')}
                        >
                          Clear search
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </div>

        {broadcasts.length > 0 && (
          <div className="flex items-center justify-between space-x-2 py-4 px-6">
            <div className="flex items-center space-x-4">
              <div className="text-sm text-gray-500">
                {table.getFilteredRowModel().rows.length === broadcasts.length
                  ? `${broadcasts.length} broadcast${
                      broadcasts.length === 1 ? '' : 's'
                    } total`
                  : `${table.getFilteredRowModel().rows.length} of ${
                      broadcasts.length
                    } broadcast${broadcasts.length === 1 ? '' : 's'}`}
              </div>
              {table.getState().sorting.length > 0 && (
                <Badge variant="outline" className="text-xs">
                  Sorted by:{' '}
                  {table
                    .getState()
                    .sorting.map(
                      (sort) => `${sort.id} (${sort.desc ? 'desc' : 'asc'})`
                    )
                    .join(', ')}
                </Badge>
              )}
            </div>

            <div className="flex items-center space-x-2">
              <p className="text-sm font-medium">Rows per page</p>
              <Select
                value={`${table.getState().pagination.pageSize}`}
                onValueChange={(value) => {
                  table.setPageSize(Number(value));
                }}
              >
                <SelectTrigger className="h-8 w-[70px]">
                  <SelectValue
                    placeholder={table.getState().pagination.pageSize}
                  />
                </SelectTrigger>
                <SelectContent side="top">
                  {[5, 10, 20, 30, 40, 50].map((pageSize) => (
                    <SelectItem key={pageSize} value={`${pageSize}`}>
                      {pageSize}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center space-x-6 lg:space-x-8">
              <div className="flex items-center space-x-2">
                <p className="text-sm font-medium">
                  Page {table.getState().pagination.pageIndex + 1} of{' '}
                  {table.getPageCount()}
                </p>
                <span className="text-sm text-gray-500">
                  ({table.getPrePaginationRowModel().rows.length} total rows)
                </span>
              </div>

              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  className="hidden h-8 w-8 p-0 lg:flex"
                  onClick={() => table.setPageIndex(0)}
                  disabled={!table.getCanPreviousPage()}
                >
                  <span className="sr-only">Go to first page</span>
                  <ChevronsLeft className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  className="h-8 w-8 p-0"
                  onClick={() => table.previousPage()}
                  disabled={!table.getCanPreviousPage()}
                >
                  <span className="sr-only">Go to previous page</span>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  className="h-8 w-8 p-0"
                  onClick={() => table.nextPage()}
                  disabled={!table.getCanNextPage()}
                >
                  <span className="sr-only">Go to next page</span>
                  <ChevronRight className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  className="hidden h-8 w-8 p-0 lg:flex"
                  onClick={() => table.setPageIndex(table.getPageCount() - 1)}
                  disabled={!table.getCanNextPage()}
                >
                  <span className="sr-only">Go to last page</span>
                  <ChevronsRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
