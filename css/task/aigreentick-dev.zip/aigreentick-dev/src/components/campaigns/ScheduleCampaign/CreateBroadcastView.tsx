import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { BroadcastForm } from './BroadcastForm';
import { ContactSelector } from './ContactSelector';
import { SchedulingSection } from './SchedulingSection';
import { PhonePreview } from './PhonePreview';
import { ContactFilterModal } from '@/components/contacts/ContactFilterModal';
import {
  Contact,
  AvailableTemplate,
  FilterCondition,
  Template,
  VariableValues,
} from './types';

interface CreateBroadcastViewProps {
  broadcastName: string;
  selectedTemplate: string;
  sendOption: string;
  filteredContacts: Contact[];
  selectedContacts: Set<number>;
  searchTerm: string;
  activeFilters: FilterCondition[];
  availableTemplates: AvailableTemplate[];
  currentTemplate: Template;
  templateVariables: string[];
  variableValues: VariableValues;
  showFilterModal: boolean;
  onBack: () => void;
  onDiscard: () => void;
  onAddBroadcast: () => void;
  onBroadcastNameChange: (name: string) => void;
  onTemplateChange: (template: string) => void;
  onSendOptionChange: (option: string) => void;
  onContactSelect: (contactId: number) => void;
  onSelectAll: () => void;
  onSearchChange: (term: string) => void;
  onShowFilter: () => void;
  onCloseFilter: () => void;
  onApplyFilters: (conditions: FilterCondition[]) => void;
  onClearFilters: () => void;
  onVariableChange: (variable: string, value: string) => void;
}

export const CreateBroadcastView: React.FC<CreateBroadcastViewProps> = ({
  broadcastName,
  selectedTemplate,
  sendOption,
  filteredContacts,
  selectedContacts,
  searchTerm,
  activeFilters,
  availableTemplates,
  currentTemplate,
  templateVariables,
  variableValues,
  showFilterModal,
  onBack,
  onDiscard,
  onAddBroadcast,
  onBroadcastNameChange,
  onTemplateChange,
  onSendOptionChange,
  onContactSelect,
  onSelectAll,
  onSearchChange,
  onShowFilter,
  onCloseFilter,
  onApplyFilters,
  onClearFilters,
  onVariableChange,
}) => {
  return (
    <div className="min-h-screen bg-gray-50 flex">
      <div className="flex-1 overflow-y-auto scrollbar-hide">
        <div className="p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Button variant="ghost" size="sm" onClick={onBack}>
                <ArrowLeft className="w-5 h-5 text-gray-600" />
              </Button>
              <h1 className="text-2xl font-bold text-gray-900">
                New Broadcast
              </h1>
            </div>
            <div className="flex space-x-3">
              <Button
                variant="outline"
                className="text-red-500 border-red-200 hover:bg-red-50"
                onClick={onDiscard}
              >
                Discard
              </Button>
              <Button
                className="bg-green-500 hover:bg-green-600 text-white"
                onClick={onAddBroadcast}
              >
                Add Broadcast
              </Button>
            </div>
          </div>

          <div className="space-y-6 pb-20">
            <BroadcastForm
              broadcastName={broadcastName}
              selectedTemplate={selectedTemplate}
              availableTemplates={availableTemplates}
              onBroadcastNameChange={onBroadcastNameChange}
              onTemplateChange={onTemplateChange}
            />

            <ContactSelector
              contacts={filteredContacts}
              selectedContacts={selectedContacts}
              searchTerm={searchTerm}
              activeFilters={activeFilters}
              onContactSelect={onContactSelect}
              onSelectAll={onSelectAll}
              onSearchChange={onSearchChange}
              onShowFilter={onShowFilter}
              onClearFilters={onClearFilters}
            />

            <SchedulingSection
              sendOption={sendOption}
              onSendOptionChange={onSendOptionChange}
            />
          </div>
        </div>
      </div>

      <PhonePreview
        template={currentTemplate}
        variableValues={variableValues}
        templateVariables={templateVariables}
        onVariableChange={onVariableChange}
      />

      <ContactFilterModal
        isOpen={showFilterModal}
        onClose={onCloseFilter}
        onApplyFilter={onApplyFilters}
        existingConditions={activeFilters}
      />
    </div>
  );
};
