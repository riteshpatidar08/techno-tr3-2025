import { Contact, FilterCondition, Template, AvailableTemplate } from './types';

export const filterContacts = (
  contacts: Contact[],
  searchTerm: string,
  conditions: FilterCondition[]
): Contact[] => {
  let filtered = [...contacts];
  if (searchTerm) {
    filtered = filtered.filter(
      (contact) =>
        contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        contact.phone.includes(searchTerm)
    );
  }
  conditions.forEach((condition) => {
    filtered = filtered.filter((contact) => {
      const value = contact.attributes[condition.attribute] || '';

      switch (condition.operation) {
        case 'equals':
          return value.toLowerCase() === condition.value.toLowerCase();
        case 'contains':
          return value.toLowerCase().includes(condition.value.toLowerCase());
        case 'notEquals':
          return value.toLowerCase() !== condition.value.toLowerCase();
        case 'greaterThan':
          return parseFloat(value) > parseFloat(condition.value);
        case 'lessThan':
          return parseFloat(value) < parseFloat(condition.value);
        case 'greaterThanOrEqual':
          return parseFloat(value) >= parseFloat(condition.value);
        case 'lessThanOrEqual':
          return parseFloat(value) <= parseFloat(condition.value);
        default:
          return true;
      }
    });
  });

  return filtered;
};

export const getCurrentTemplate = (
  templateName: string,
  availableTemplates: AvailableTemplate[]
): Template => {
  const templateData = availableTemplates.find((t) => t.name === templateName);

  if (templateData) {
    return templateData.template;
  }
  return {
    name: 'welcome_wati_v1',
    components: [
      {
        type: 'HEADER',
        format: 'TEXT',
        text: 'Welcome to WATI! 👋',
      },
      {
        type: 'BODY',
        text: 'Hi {{name}},\n\nThank you for your message.\n\nHow can I help you today?',
      },
      {
        type: 'FOOTER',
        text: "WATI's Chatbot",
      },
      {
        type: 'BUTTONS',
        buttons: [
          { type: 'QUICK_REPLY', text: 'Know the Pricing' },
          { type: 'QUICK_REPLY', text: 'Know how WATI works?' },
          { type: 'QUICK_REPLY', text: 'Get Started' },
        ],
      },
    ],
  };
};

export const getTemplateVariables = (template: Template): string[] => {
  const variables = new Set<string>();

  template.components?.forEach((component) => {
    if (component.text) {
      const matches = component.text.match(/{{(\w+)}}/g);
      if (matches) {
        matches.forEach((match) => {
          const variable = match.replace(/[{}]/g, '');
          variables.add(variable);
        });
      }
    }
  });

  return Array.from(variables);
};

export const replaceVariables = (
  text: string,
  variableValues: Record<string, string>
): string => {
  if (!text) return '';
  let replacedText = text;
  Object.entries(variableValues).forEach(([key, value]) => {
    replacedText = replacedText.replace(
      new RegExp(`{{${key}}}`, 'g'),
      value || `{{${key}}}`
    );
  });
  return replacedText;
};
