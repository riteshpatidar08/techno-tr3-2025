import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { VariableValues } from './types';

interface TemplateVariablesProps {
  variables: string[];
  variableValues: VariableValues;
  onVariableChange: (variable: string, value: string) => void;
}

export const TemplateVariables: React.FC<TemplateVariablesProps> = ({
  variables,
  variableValues,
  onVariableChange,
}) => {
  if (variables.length === 0) {
    return null;
  }

  return (
    <Card className="mt-6">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-medium">
          Template Variables
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-3">
          {variables.map((variable) => (
            <div key={variable} className="space-y-1">
              <label className="text-xs font-medium text-gray-700 flex items-center">
                <Badge variant="outline" className="text-xs mr-2">
                  {variable}
                </Badge>
                Sample Value
              </label>
              <Input
                placeholder={`Enter ${variable} value`}
                value={variableValues[variable] || ''}
                onChange={(e) => onVariableChange(variable, e.target.value)}
                className="text-xs h-8"
              />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
