import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { useDispatch, useSelector } from 'react-redux';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Send,
  Calendar,
  Radio,
  Users,
  MessageSquare,
  Settings,
  Info,
  Clock,
  CheckCircle,
  Eye,
  Phone,
  ExternalLink,
  Image as ImageIcon,
  RefreshCw,
  Variable,
  Globe,
} from 'lucide-react';
import {
  fetchTemplates,
  fetchTemplateById,
  selectTemplates,
  selectSelectedTemplate,
  selectSelectedTemplateLoading,
  clearError,
  clearSelectedTemplate,
} from '@/redux/templateSlice';
import {
  sendBroadcast,
  selectBroadcastLoading,
  selectBroadcastError,
  selectBroadcastSuccess,
  selectLastCampaign,
  clearError as clearBroadcastError,
  clearSuccess as clearBroadcastSuccess,
} from '@/redux/broadcastSlice';
import {
  fetchCountries,
  selectCountries,
  selectCountriesLoading,
  selectCountriesError,
  selectCountriesSorted,
} from '@/redux/countrySlice';
import WarningComponent from '@/components/ui/warning';

// Professional Template Preview Component
const TemplatePreview = ({ template, loading, variables }) => {
  if (loading) {
    return (
      <Card className="border-0 bg-gradient-to-br from-card to-card/50  sticky top-6">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-3 text-lg text-card-foreground">
            <div className="p-2 bg-primary/10 rounded-lg">
              <Eye className="h-5 w-5 text-primary" />
            </div>
            Template Preview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-6">
            <div className="space-y-3">
              <div className="h-4 bg-gradient-to-r from-muted to-muted/50 rounded-lg w-3/4"></div>
              <div className="h-32 bg-gradient-to-br from-muted to-muted/30 rounded-xl"></div>
              <div className="h-4 bg-gradient-to-r from-muted to-muted/50 rounded-lg w-1/2"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!template) {
    return (
      <Card className="border-0 bg-gradient-to-br from-card to-card/50  sticky top-6">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-3 text-lg text-card-foreground">
            <div className="p-2 bg-primary/10 rounded-lg">
              <Eye className="h-5 w-5 text-primary" />
            </div>
            Template Preview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <div className="relative mb-6">
              <div className="absolute inset-0 bg-primary/5 rounded-full blur-xl"></div>
              <div className="relative p-6 bg-muted/30 rounded-full w-20 h-20 mx-auto flex items-center justify-center">
                <Eye className="h-8 w-8 text-muted-foreground/70" />
              </div>
            </div>
            <h3 className="font-semibold text-foreground mb-2">
              No Template Selected
            </h3>
            <p className="text-sm">
              Choose a template to see the WhatsApp preview
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const replaceVariables = (text, variables) => {
    if (!text) return '';
    let replacedText = text;
    Object.keys(variables).forEach((index) => {
      const placeholder = `{{${index}}}`;
      const value = variables[index] || `{{${index}}}`;
      replacedText = replacedText.replace(
        new RegExp(placeholder.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'),
        value
      );
    });
    return replacedText;
  };

  const renderComponent = (component) => {
    switch (component.type) {
      case 'HEADER':
        if (component.format === 'IMAGE' && component.image_url) {
          return (
            <div className="mb-3">
              <div className="relative rounded-lg overflow-hidden bg-gradient-to-br from-muted/30 to-muted/10">
                <img
                  src={component.image_url}
                  alt="Template Header"
                  className="w-full h-32 object-cover"
                  onError={(e) => {
                    e.target.style.display = 'none';
                    e.target.nextSibling.style.display = 'flex';
                  }}
                />
                <div className="hidden w-full h-32 bg-gradient-to-br from-muted/50 to-muted/20 items-center justify-center">
                  <div className="p-3 bg-background/50 rounded-full">
                    <ImageIcon className="h-6 w-6 text-muted-foreground" />
                  </div>
                </div>
              </div>
            </div>
          );
        } else if (component.text) {
          return (
            <div className="mb-3">
              <div className="p-3 bg-gradient-to-r from-primary/10 to-primary/5 border border-primary/20 rounded-lg">
                <h3 className="font-semibold text-primary text-xs leading-tight">
                  {replaceVariables(component.text, variables)}
                </h3>
              </div>
            </div>
          );
        }
        return null;

      case 'BODY':
        return (
          <div className="mb-3">
            <div className="p-3 bg-background/50 rounded-lg border border-border/30">
              <p className="text-foreground whitespace-pre-wrap leading-relaxed text-xs">
                {replaceVariables(component.text, variables)}
              </p>
            </div>
          </div>
        );

      case 'FOOTER':
        return (
          <div className="mb-3">
            <div className="p-2 bg-muted/20 rounded-md border-t border-border/50">
              <p className="text-xs text-muted-foreground font-medium text-center">
                {replaceVariables(component.text, variables)}
              </p>
            </div>
          </div>
        );

      case 'BUTTONS':
        if (component.buttons && component.buttons.length > 0) {
          const urlButtons = component.buttons.filter(
            (btn) => btn.type === 'URL'
          );
          const phoneButtons = component.buttons.filter(
            (btn) => btn.type === 'PHONE_NUMBER'
          );
          const quickReplyButtons = component.buttons.filter(
            (btn) => btn.type === 'QUICK_REPLY'
          );

          return (
            <div className="space-y-3">
              {/* URL and Phone buttons */}
              {(urlButtons.length > 0 || phoneButtons.length > 0) && (
                <div className="space-y-1.5">
                  {phoneButtons.map((button) => (
                    <Button
                      key={button.id}
                      variant="outline"
                      className="w-full justify-center gap-2 text-xs h-8 bg-gradient-to-r from-green-50 to-green-50/50 border-green-200 text-green-700 transition-all duration-200"
                      disabled
                    >
                      <Phone className="h-3 w-3" />
                      {button.text}
                    </Button>
                  ))}
                  {urlButtons.map((button) => (
                    <Button
                      key={button.id}
                      variant="outline"
                      className="w-full justify-center gap-2 text-xs h-8 bg-gradient-to-r from-blue-50 to-blue-50/50 border-blue-200 text-blue-700 transition-all duration-200"
                      disabled
                    >
                      <ExternalLink className="h-3 w-3" />
                      {button.text}
                    </Button>
                  ))}
                </div>
              )}

              {/* Quick Reply buttons */}
              {quickReplyButtons.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground font-medium">
                    <div className="w-1 h-1 bg-muted-foreground/50 rounded-full"></div>
                    Quick Replies
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {quickReplyButtons.map((button) => (
                      <Badge
                        key={button.id}
                        variant="secondary"
                        className="px-2 py-1 text-xs font-medium bg-gradient-to-r from-secondary to-secondary/70 transition-all duration-200 cursor-default border border-border/50"
                      >
                        {button.text}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        }
        return null;

      default:
        return null;
    }
  };

  return (
    <Card className="border-0 bg-gradient-to-br from-card via-card/95 to-card/90  sticky top-6">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-base text-card-foreground">
            <div className="p-1.5 bg-primary/10 rounded-lg">
              <Eye className="h-4 w-4 text-primary" />
            </div>
            Preview
          </CardTitle>
          <div className="flex items-center gap-1.5">
            <Badge
              variant="outline"
              className="text-xs bg-background/50 border-border/50"
            >
              {template.category}
            </Badge>
            <Badge
              variant={template.status === 'APPROVED' ? 'default' : 'secondary'}
              className={`text-xs ${
                template.status === 'APPROVED'
                  ? 'bg-green-100 text-green-700 border-green-200'
                  : 'bg-yellow-100 text-yellow-700 border-yellow-200'
              }`}
            >
              {template.status}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="relative scrollbar-hide mx-auto max-w-[300px]">
          {/* Phone Frame */}
          <div className="relative bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 rounded-[1.5rem] p-1.5 shadow-2xl">
            {/* Screen */}
            <div className="bg-gradient-to-b from-gray-50 to-white rounded-[1.25rem] overflow-hidden">
              {/* Status Bar */}
              <div className="bg-white px-4 py-1.5 flex justify-between items-center text-xs font-medium text-black">
                <span>9:41</span>
                <div className="flex items-center gap-1">
                  <div className="flex gap-0.5">
                    <div className="w-0.5 h-0.5 bg-black rounded-full"></div>
                    <div className="w-0.5 h-0.5 bg-black rounded-full"></div>
                    <div className="w-0.5 h-0.5 bg-black/30 rounded-full"></div>
                  </div>
                  <div className="ml-1 w-5 h-2.5 border border-black/30 rounded-sm">
                    <div className="w-3 h-1 bg-green-500 rounded-sm m-0.5"></div>
                  </div>
                </div>
              </div>

              {/* WhatsApp Header */}
              <div className="bg-[#075E54] px-3 py-2 flex items-center gap-2">
                <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center">
                  <MessageSquare className="h-3 w-3 text-white" />
                </div>
                <div className="flex-1">
                  <h4 className="text-white font-medium text-xs">
                    Business Account
                  </h4>
                  <p className="text-white/70 text-xs">Template Message</p>
                </div>
              </div>

              {/* Message Content - Scrollable for long content */}
              <div className="p-3 bg-[#E5DDD5] max-h-[400px] overflow-y-auto scrollbar-hide">
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
                  <div className="p-3 space-y-2">
                    {[...template.components]
                      .sort((a, b) => {
                        const order = {
                          HEADER: 1,
                          BODY: 2,
                          FOOTER: 3,
                          BUTTONS: 4,
                        };
                        return (order[a.type] || 5) - (order[b.type] || 5);
                      })
                      .map((component) => (
                        <div key={component.id}>
                          {renderComponent(component)}
                        </div>
                      ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Template Metadata - Compact Version */}
        <div className="mt-4 p-3 bg-gradient-to-r from-muted/30 to-muted/10 rounded-lg border border-border/50">
          <h4 className="font-semibold text-sm text-foreground mb-2 flex items-center gap-2">
            <Info className="h-3 w-3" />
            Template Info
          </h4>
          <div className="space-y-1.5 text-xs">
            <div className="flex justify-between">
              <span className="text-muted-foreground">ID:</span>
              <code className="font-mono text-xs bg-background/50 px-1.5 py-0.5 rounded">
                {template.wa_id}
              </code>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Language:</span>
              <span className="uppercase font-medium">{template.language}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Components:</span>
              <Badge variant="outline" className="text-xs h-5">
                {template.components.length}
              </Badge>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

// Template Variables Component
const TemplateVariables = ({ template, variables, onVariableChange }) => {
  if (!template) return null;

  const allVariables = [];

  template.components.forEach((component) => {
    if (component.body_text && component.body_text.length > 0) {
      component.body_text.forEach((variable) => {
        allVariables.push({
          ...variable,
          componentType: component.type,
        });
      });
    }
  });

  if (allVariables.length === 0) return null;

  return (
    <Card className="border-0 bg-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg text-card-foreground">
          <Variable className="h-5 w-5" />
          Template Variables
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          This template contains variables that need to be filled in
        </p>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {allVariables.map((variable) => (
            <div key={variable.id} className="space-y-2">
              <Label className="text-sm font-medium text-card-foreground flex items-center gap-2">
                <Badge variant="outline" className="text-xs">
                  {`{{${variable.text_index}}}`}
                </Badge>
                {variable.text}
                <span className="text-xs text-muted-foreground">
                  ({variable.componentType})
                </span>
              </Label>
              <Input
                placeholder={`Enter value for ${variable.text}`}
                value={variables[variable.text_index] || ''}
                onChange={(e) =>
                  onVariableChange(variable.text_index, e.target.value)
                }
                className="bg-card border-input text-card-foreground"
              />
              <p className="text-xs text-muted-foreground">
                This will replace {`{{${variable.text_index}}}`} in the template
              </p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

function Broadcast() {
  const [selectedTemplate, setSelectedTemplate] = useState('');
  const [campaignName, setCampaignName] = useState('');
  const [selectedCountry, setSelectedCountry] = useState('');
  const [numbers, setNumbers] = useState('');
  const [message, setMessage] = useState('');
  const [templateVariables, setTemplateVariables] = useState({});

  const dispatch = useDispatch();

  // Template selectors
  const templates = useSelector(selectTemplates) || [];
  const selectedTemplateData = useSelector(selectSelectedTemplate);
  const templateLoading = useSelector(selectSelectedTemplateLoading);

  // Countries selectors
  const countries = useSelector(selectCountriesSorted) || [];
  const countriesLoading = useSelector(selectCountriesLoading);
  const countriesError = useSelector(selectCountriesError);

  // Broadcast selectors
  const broadcastLoading = useSelector(selectBroadcastLoading);
  const broadcastError = useSelector(selectBroadcastError);
  const broadcastSuccess = useSelector(selectBroadcastSuccess);
  const lastCampaign = useSelector(selectLastCampaign);

  useEffect(() => {
    console.log('Broadcast: Fetching templates and countries...');
    dispatch(fetchTemplates() as any);
    dispatch(fetchCountries() as any);

    return () => {
      dispatch(clearError());
      dispatch(clearSelectedTemplate());
      dispatch(clearBroadcastError());
      dispatch(clearBroadcastSuccess());
    };
  }, [dispatch]);

  // Set default country to India when countries are loaded
  useEffect(() => {
    if (countries.length > 0 && !selectedCountry) {
      const indiaCountry = countries.find(country => country.mobile_code === '91');
      if (indiaCountry) {
        setSelectedCountry(indiaCountry.id.toString());
      } else {
        // Fallback to first country if India not found
        setSelectedCountry(countries[0].id.toString());
      }
    }
  }, [countries, selectedCountry]);

  const handleTemplateChange = (templateId) => {
    setSelectedTemplate(templateId);
    setTemplateVariables({});

    if (templateId) {
      dispatch(fetchTemplateById(Number(templateId)) as any);
    } else {
      dispatch(clearSelectedTemplate());
    }
  };

  const handleVariableChange = (index, value) => {
    setTemplateVariables((prev) => ({
      ...prev,
      [index]: value,
    }));
  };

  useEffect(() => {
    if (selectedTemplateData) {
      const bodyComponent = selectedTemplateData.components.find(
        (comp) => comp.type === 'BODY'
      );
      if (bodyComponent && bodyComponent.text) {
        setMessage(bodyComponent.text);
      }
    } else {
      // Clear message when no template is selected
      setMessage('');
    }
  }, [selectedTemplateData]);

  const recipientCount = numbers.split(/[\n,]/).filter((n) => n.trim()).length;

  const hasVariables =
    selectedTemplateData &&
    selectedTemplateData.components.some(
      (comp) => comp.body_text && comp.body_text.length > 0
    );

  const allVariablesFilled =
    !hasVariables ||
    (selectedTemplateData &&
      selectedTemplateData.components.every((comp) => {
        if (!comp.body_text) return true;
        return comp.body_text.every(
          (variable) =>
            templateVariables[variable.text_index] &&
            templateVariables[variable.text_index].trim() !== ''
        );
      }));

  const isFormValid =
    selectedTemplate &&
    campaignName &&
    selectedCountry &&
    numbers &&
    message &&
    allVariablesFilled;

  const getSelectedCountryData = () => {
    if (!selectedCountry) return null;
    return countries.find(country => country.id.toString() === selectedCountry);
  };

  const getCountryId = () => {
    const country = getSelectedCountryData();
    return country ? country.id : 98; // Default to India's ID if not found
  };

  const handleSendCampaign = async () => {
    if (!isFormValid) return;

    dispatch(clearBroadcastError());
    dispatch(clearBroadcastSuccess());

    const mobileNumbers = numbers
      .split(/[\n,]/)
      .map((n) => n.trim().replace(/^\+\d+/, ''))
      .filter((n) => n);

    console.log(mobileNumbers);

    const headerComponent = selectedTemplateData?.components.find(
      (c) => c.type === 'HEADER' && c.format === 'IMAGE'
    );

    const campaignData = {
      template_id: selectedTemplate,
      country_id: getCountryId(),
      camp_name: campaignName,
      mobile_numbers: mobileNumbers,
      is_media: !!headerComponent?.image_url,
      media_type: headerComponent?.format || '',
      media_url: headerComponent?.image_url || '',
      schedule_date: '',
      variables: JSON.stringify(templateVariables),
    };

    console.log('Sending campaign with data:', campaignData);
    dispatch(sendBroadcast(campaignData) as any);
  };

  const handleRetry = () => {
    handleSendCampaign();
  };

  const handleNewCampaign = () => {
    setSelectedTemplate('');
    setCampaignName('');
    setNumbers('');
    setMessage('');
    setTemplateVariables({});
    dispatch(clearSelectedTemplate());
    dispatch(clearBroadcastSuccess());
    dispatch(clearBroadcastError());
  };

  const selectedCountryData = getSelectedCountryData();

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header Section */}
        <div className="space-y-2">
          <div className="flex gap-3 items-center">
            <div className="bg-primary p-3 rounded-xl">
              <Radio className="h-8 w-8 text-primary-foreground" />
            </div>
            <div className="flex flex-col gap-1">
              <h1 className="text-3xl font-bold text-foreground">
                WhatsApp Broadcast Campaign
              </h1>
              <p className="text-muted-foreground">
                Send official template messages to multiple recipients
              </p>
            </div>
          </div>
        </div>

        {/* Success/Error Messages */}
        {broadcastSuccess && lastCampaign && (
          <WarningComponent
            type="success"
            title="Campaign Sent Successfully!"
            message={`Your campaign "${campaignName}" has been sent to ${recipientCount} recipients.`}
            description={
              lastCampaign.message ||
              'Campaign is being processed and will be delivered shortly.'
            }
            actions={[
              {
                label: 'Create New Campaign',
                onClick: handleNewCampaign,
                variant: 'default',
                icon: RefreshCw,
              },
            ]}
            dismissible
            onClose={() => dispatch(clearBroadcastSuccess())}
          />
        )}

        {broadcastError && (
          <WarningComponent
            type="error"
            title="Campaign Failed"
            message="Failed to send broadcast campaign"
            description={broadcastError}
            actions={[
              {
                label: 'Retry',
                onClick: handleRetry,
                variant: 'default',
                icon: RefreshCw,
                loading: broadcastLoading,
              },
            ]}
            dismissible
            onClose={() => dispatch(clearBroadcastError())}
          />
        )}

        {/* Countries Error */}
        {countriesError && (
          <WarningComponent
            type="error"
            title="Failed to Load Countries"
            message="Could not fetch country list"
            description={countriesError}
            actions={[
              {
                label: 'Retry',
                onClick: () => dispatch(fetchCountries() as any),
                variant: 'default',
                icon: RefreshCw,
                loading: countriesLoading,
              },
            ]}
            dismissible
          />
        )}

        {/* New Layout: Form on left, Preview on right */}
        <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
          {/* Main Form Content - Takes 3 columns */}
          <div className="xl:col-span-3 space-y-6">
            {/* Campaign Setup */}
            <Card className="border-0 bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg text-card-foreground">
                  <Settings className="h-5 w-5" />
                  Campaign Configuration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-card-foreground">
                      Template Selection *
                    </Label>
                    <Select
                      value={selectedTemplate}
                      onValueChange={handleTemplateChange}
                      disabled={broadcastLoading}
                    >
                      <SelectTrigger className="bg-card border-input text-card-foreground">
                        <SelectValue placeholder="Choose an approved template" />
                      </SelectTrigger>
                      <SelectContent className="bg-popover border-border">
                        {templates.map((template) => (
                          <SelectItem
                            key={template.id}
                            value={template.id.toString()}
                            className="text-popover-foreground"
                          >
                            <div className="flex flex-col">
                              <span>{template.name}</span>
                              <span className="text-xs text-muted-foreground">
                                {template.category} • {template.status}
                              </span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">
                      Only pre-approved templates can be used for official
                      messages
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-card-foreground">
                      Campaign Name *
                    </Label>
                    <Input
                      placeholder="e.g., New Year Promotion 2025"
                      value={campaignName}
                      onChange={(e) => setCampaignName(e.target.value)}
                      className="bg-card border-input text-card-foreground"
                      disabled={broadcastLoading}
                    />
                    <p className="text-xs text-muted-foreground">
                      Internal name for tracking and analytics
                    </p>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-sm font-medium text-card-foreground flex items-center gap-2">
                    <Globe className="h-4 w-4" />
                    Target Country *
                  </Label>
                  <Select
                    value={selectedCountry}
                    onValueChange={setSelectedCountry}
                    disabled={broadcastLoading || countriesLoading}
                  >
                    <SelectTrigger className="bg-card text-card-foreground max-w-xs border-none">
                      <SelectValue>
                        {countriesLoading ? (
                          <div className="flex items-center gap-1">
                            <RefreshCw className="h-4 w-4 animate-spin" />
                            Loading countries...
                          </div>
                        ) : selectedCountryData ? (
                          <div className="flex items-center w-full">
                            <div className="w-16 flex-shrink-0">
                              <Badge
                                variant="outline"
                                className="text-xs border-none w-full flex justify-center"
                              >
                                +{selectedCountryData.mobile_code}
                              </Badge>
                            </div>
                            <span className="flex-1 text-left truncate ml-2">
                              {selectedCountryData.name}
                            </span>
                          </div>
                        ) : (
                          'Select a country'
                        )}
                      </SelectValue>
                    </SelectTrigger>
                    <SelectContent>
                      {countries.map((country) => (
                        <SelectItem
                          key={country.id}
                          value={country.id.toString()}
                        >
                          <div className="flex items-center w-full">
                            <div className="w-16 flex-shrink-0">
                              <Badge
                                variant="outline"
                                className="text-xs border-none w-full flex justify-center"
                              >
                                +{country.mobile_code}
                              </Badge>
                            </div>
                            <span className="flex-1 text-left truncate ml-2">
                              {country.name}
                            </span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    {selectedCountryData && (
                      <>
                        Country code +{selectedCountryData.mobile_code} will be
                        automatically added to phone numbers
                      </>
                    )}
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Template Variables - Only show if template has variables */}
            <TemplateVariables
              template={selectedTemplateData}
              variables={templateVariables}
              onVariableChange={handleVariableChange}
            />

            {/* Recipients */}
            <Card className="border-0 bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg text-card-foreground">
                  <Users className="h-5 w-5" />
                  Recipient List
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-card-foreground">
                      Phone Numbers *
                    </Label>
                    <Textarea
                      placeholder={`Enter phone numbers (without country code):${
                        selectedCountryData
                          ? `\nExample for ${selectedCountryData.name}:`
                          : ''
                      }\n9876543210\n8765432109\n• One number per line\n• No country codes needed\n• Maximum 1000 recipients`}
                      value={numbers}
                      onChange={(e) => setNumbers(e.target.value)}
                      className="min-h-[140px] placeholder:text-xs bg-card border-input text-card-foreground"
                      disabled={broadcastLoading}
                    />
                    <div className="flex flex-wrap gap-4 text-xs text-muted-foreground">
                      <span>• One number per line or comma-separated</span>
                      {selectedCountryData && (
                        <span>
                          • Country code +{selectedCountryData.mobile_code} will
                          be auto-added
                        </span>
                      )}
                      <span>• Maximum 1000 recipients per campaign</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Message Content */}
            <Card className="border-0 bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg text-card-foreground">
                  <MessageSquare className="h-5 w-5" />
                  Message Content
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-card-foreground">
                      Message Body *
                    </Label>
                    <Textarea
               
                      placeholder="Message content will be auto-populated from selected template...&#10;&#10;You can customize the message as needed.&#10;&#10;Keep it concise and engaging!"
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      className="min-h-[200px] bg-card border-input text-card-foreground"
                      disabled
                    />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>Template-based message content</span>
                      <span>{message.length}/1024 characters</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Campaign Summary */}
            <Card className="border-0 bg-card">
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-3 text-xl text-card-foreground">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <Send className="h-5 w-5 text-primary" />
                  </div>
                  Campaign Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Summary Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg border border-border/50">
                      <span className="text-sm font-medium text-muted-foreground">
                        Template:
                      </span>
                      <Badge
                        variant="secondary"
                        className="max-w-[140px] truncate"
                      >
                        {selectedTemplate
                          ? templates.find(
                              (t) => t.id.toString() === selectedTemplate
                            )?.name || 'Selected'
                          : 'Not selected'}
                      </Badge>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg border border-border/50">
                      <span className="text-sm font-medium text-muted-foreground">
                        Campaign:
                      </span>
                      <span className="text-sm font-semibold text-foreground max-w-[140px] truncate">
                        {campaignName || 'Unnamed'}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg border border-border/50">
                      <span className="text-sm font-medium text-muted-foreground">
                        Country:
                      </span>
                      <div className="flex items-center gap-2">
                        {selectedCountryData ? (
                          <>
                            <Badge variant="outline" className="text-xs">
                              +{selectedCountryData.mobile_code}
                            </Badge>
                            <span className="text-sm font-semibold text-foreground">
                              {selectedCountryData.name}
                            </span>
                          </>
                        ) : (
                          <span className="text-sm text-muted-foreground">
                            Not selected
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg border border-border/50">
                      <span className="text-sm font-medium text-muted-foreground">
                        Recipients:
                      </span>
                      <Badge variant="outline" className="font-semibold">
                        {recipientCount > 0 ? recipientCount : 0}
                      </Badge>
                    </div>
                  </div>
                </div>

                {/* Variables Summary */}
                {hasVariables && (
                  <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-200">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <Variable className="h-4 w-4 text-blue-600" />
                        <span className="text-sm font-medium text-blue-900">
                          Template Variables
                        </span>
                      </div>
                      <Badge
                        variant={allVariablesFilled ? 'default' : 'destructive'}
                        className="text-xs"
                      >
                        {allVariablesFilled ? 'Complete' : 'Incomplete'}
                      </Badge>
                    </div>
                    <div className="space-y-2">
                      {selectedTemplateData?.components.map((comp) =>
                        comp.body_text?.map((variable) => (
                          <div
                            key={variable.id}
                            className="flex items-center justify-between text-xs"
                          >
                            <span className="text-blue-700">
                              {`{{${variable.text_index}}}`} - {variable.text}:
                            </span>
                            <span className="font-mono bg-white px-2 py-1 rounded border max-w-[120px] truncate">
                              {templateVariables[variable.text_index] ||
                                'Not set'}
                            </span>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}

                {/* Estimated Reach */}
                {recipientCount > 0 && (
                  <div className="p-4 bg-gradient-to-r from-primary/10 to-primary/5 rounded-xl border border-primary/20">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-2xl font-bold text-primary">
                          {recipientCount}
                        </div>
                        <div className="text-sm text-primary/80">
                          Recipients Ready
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-xs text-muted-foreground">
                          Estimated delivery
                        </div>
                        <div className="text-sm font-medium text-foreground">
                          2-5 minutes
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="space-y-4 pt-2">
                  <Button
                    className="w-full h-14 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold text-base shadow-lg hover:shadow-xl transition-all duration-200"
                    disabled={!isFormValid || broadcastLoading}
                    onClick={handleSendCampaign}
                  >
                    {broadcastLoading ? (
                      <>
                        <RefreshCw className="h-5 w-5 mr-3 animate-spin" />
                        Sending Campaign...
                      </>
                    ) : (
                      <>
                        <Send className="h-5 w-5 mr-3" />
                        Send Campaign Now
                      </>
                    )}
                  </Button>

                  <div className="grid grid-cols-2 gap-3">
                    <Button
                      variant="outline"
                      className="h-11 bg-background hover:bg-muted text-foreground border-border hover:border-border/80 transition-all duration-200"
                      disabled={!isFormValid || broadcastLoading}
                    >
                      <Clock className="h-4 w-4 mr-2" />
                      Schedule
                    </Button>
                    <Button
                      variant="ghost"
                      className="h-11 text-muted-foreground hover:bg-muted hover:text-foreground transition-all duration-200"
                      disabled={broadcastLoading}
                    >
                      Save Draft
                    </Button>
                  </div>

                  {!isFormValid && !broadcastLoading && (
                    <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                      <p className="text-sm text-amber-800 flex items-center gap-2">
                        <Info className="h-4 w-4 text-amber-600" />
                        {!allVariablesFilled
                          ? 'Please fill in all template variables to proceed'
                          : 'Complete all required fields to proceed'}
                      </p>
                      {!allVariablesFilled && (
                        <div className="mt-2 text-xs text-amber-700">
                          Missing variables:{' '}
                          {selectedTemplateData?.components
                            .flatMap((comp) => comp.body_text || [])
                            .filter(
                              (variable) =>
                                !templateVariables[variable.text_index]
                            )
                            .map((variable) => `{{${variable.text_index}}}`)
                            .join(', ')}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Template Preview - Takes 1 column, sticky */}
          <div className="xl:col-span-1">
            <TemplatePreview
              template={selectedTemplateData}
              loading={templateLoading}
              variables={templateVariables}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default Broadcast