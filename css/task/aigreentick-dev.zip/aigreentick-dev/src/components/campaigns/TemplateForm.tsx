import React, { useState, useRef, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import {
  ArrowLeft,
  Save,
  Upload,
  Plus,
  X,
  Bold,
  Italic,
  Code,
  Eye,
  EyeOff,
  Strikethrough,
  Smile,
  Loader2,
  Edit,
  Trash2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';

// Redux imports
import {
  fetchAllLanguages,
  selectLanguages,
  selectLanguagesLoading,
  Language,
} from '@/redux/languageSlice';
import { uploadMedia, clearMedia, selectMediaData } from '@/redux/mediaSlice';
import {
  createTemplate,
  selectCreateLoading,
  selectLastError,
  selectUserFriendlyError,
  selectIsValidationError,
  clearError,
} from '@/redux/templateSlice';

// Import the separate preview component
import TemplatePreview from './TemplatePreview';
import WarningComponent, {
  WarningType,
  WarningAction,
} from '@/components/ui/warning';

// Types
interface TemplateButton {
  id: string;
  type: 'QUICK_REPLY' | 'PHONE_NUMBER' | 'URL' | 'otp';
  text: string;
  url?: string;
  phone_number?: string;
  otp_type?: 'copy_code';
}

interface Template {
  name: string;
  category: string;
  language: string;
  components: any[];
}

// Variable Content Modal Component
const VariableContentModal = ({
  isOpen,
  onClose,
  onSave,
  variableName,
  currentContent,
}: {
  isOpen: boolean;
  onClose: () => void;
  onSave: (variableName: string, content: string) => void;
  variableName: string;
  currentContent: string;
}) => {
  const [content, setContent] = useState(currentContent || '');

  const handleSave = () => {
    onSave(variableName, content);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Variable Content: {variableName}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label htmlFor="content">Content for variable {variableName}</Label>
            <Input
              id="content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder={`Enter content for ${variableName}`}
              className="mt-2"
            />
          </div>
          <p className="text-sm text-muted-foreground">
            This content will be used in API example: {`{{${variableName}}}`} →{' '}
            {content || 'content'}
          </p>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave}>Save Content</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default function TemplateForm({
  onBack = () => {},
}: {
  onBack?: () => void;
}) {
  const dispatch = useDispatch();

  const languages = useSelector(selectLanguages);
  const languagesLoading = useSelector(selectLanguagesLoading);
  const mediaData = useSelector(selectMediaData);
  const templatesLoading = useSelector(selectCreateLoading);
  const lastError = useSelector(selectLastError);
  const userFriendlyError = useSelector(selectUserFriendlyError);
  const isValidationError = useSelector(selectIsValidationError);

  const [template, setTemplate] = useState<Template>({
    name: '',
    category: 'MARKETING',
    language: 'en',
    components: [],
  });

  const [broadcastType, setBroadcastType] = useState('none');
  const [headerText, setHeaderText] = useState('');
  const [bodyText, setBodyText] = useState('');
  const [footerText, setFooterText] = useState('');
  const [buttons, setButtons] = useState<TemplateButton[]>([]);
  const [variables, setVariables] = useState<Record<string, string>>({});
  const [nextVariableNumber, setNextVariableNumber] = useState(1);

  // Authentication category specific states
  const [addSecurityRecommendation, setAddSecurityRecommendation] =
    useState(true);
  const [includeExpiryTime, setIncludeExpiryTime] = useState(false);
  const [codeExpirationMinutes, setCodeExpirationMinutes] = useState(10);
  const [copyButtonText, setCopyButtonText] = useState('');

  const [variableModal, setVariableModal] = useState({
    isOpen: false,
    variableName: '',
    currentContent: '',
  });

  const [showSuccess, setShowSuccess] = useState(false);
  const [warningState, setWarningState] = useState({
    show: false,
    type: 'error' as WarningType,
    title: '',
    message: '',
    description: '',
    actions: [] as WarningAction[],
  });

  const [showPreview, setShowPreview] = useState(false);

  // Check if current category is authentication
  const isAuthCategory = template.category === 'AUTHENTICATION';

  const bodyTextareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Set default body text for authentication category
  useEffect(() => {
    if (isAuthCategory && !bodyText) {
      setBodyText(
        '{{1}} is your verification code. For your security, do not share this code.'
      );
    } else if (
      !isAuthCategory &&
      bodyText ===
        '{{1}} is your verification code. For your security, do not share this code.'
    ) {
      setBodyText('');
    }
  }, [template.category, isAuthCategory, bodyText]);

  // Handle security recommendation text toggle
  useEffect(() => {
    if (isAuthCategory) {
      if (addSecurityRecommendation) {
        // Add security text if not present
        if (!bodyText.includes('For your security, do not share this code.')) {
          setBodyText(
            '{{1}} is your verification code. For your security, do not share this code.'
          );
        }
      } else {
        // Remove security text but keep "do not share this code" if present
        if (bodyText.includes('For your security, do not share this code.')) {
          setBodyText(
            '{{1}} is your verification code. Do not share this code.'
          );
        }
      }
    }
  }, [addSecurityRecommendation, isAuthCategory]);

  
  useEffect(() => {
    if (isAuthCategory && includeExpiryTime && !footerText) {
      setFooterText(`This code expires in ${codeExpirationMinutes} minutes.`);
    } else if (!isAuthCategory || !includeExpiryTime) {
      if (footerText.includes('This code expires in')) {
        setFooterText('');
      }
    }
  }, [isAuthCategory, includeExpiryTime, codeExpirationMinutes, footerText]);

  // Update footer text when expiration minutes change
  useEffect(() => {
    if (isAuthCategory && includeExpiryTime) {
      setFooterText(`This code expires in ${codeExpirationMinutes} minutes.`);
    }
  }, [codeExpirationMinutes, isAuthCategory, includeExpiryTime]);

  const applyWhatsAppFormatting = (symbol: string) => {
    const textarea = bodyTextareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = bodyText.substring(start, end);

    if (selectedText) {
      const beforeText = bodyText.substring(0, start);
      const afterText = bodyText.substring(end);
      const formattedText = `${symbol}${selectedText}${symbol}`;
      const newText = beforeText + formattedText + afterText;

      setBodyText(newText);

      setTimeout(() => {
        const newCursorPos =
          start + symbol.length + selectedText.length + symbol.length;
        textarea.setSelectionRange(newCursorPos, newCursorPos);
        textarea.focus();
      }, 0);
    } else {
      const beforeText = bodyText.substring(0, start);
      const afterText = bodyText.substring(start);
      const formattedText = `${symbol}text${symbol}`;
      const newText = beforeText + formattedText + afterText;

      setBodyText(newText);

      setTimeout(() => {
        const textStart = start + symbol.length;
        const textEnd = textStart + 4;
        textarea.setSelectionRange(textStart, textEnd);
        textarea.focus();
      }, 0);
    }
  };

  const insertRandomEmoji = () => {
    const emojis = ['😊', '👍', '❤️', '🎉', '🔥', '💯', '✨', '🚀', '💪', '🙌'];
    const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)];

    const textarea = bodyTextareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const beforeText = bodyText.substring(0, start);
    const afterText = bodyText.substring(start);
    const newText = beforeText + randomEmoji + afterText;

    setBodyText(newText);

    setTimeout(() => {
      const newCursorPos = start + randomEmoji.length;
      textarea.setSelectionRange(newCursorPos, newCursorPos);
      textarea.focus();
    }, 0);
  };

  const renderWhatsAppPreview = (text: string) => {
    if (!text)
      return (
        <span className="text-muted-foreground">
          Preview will appear here...
        </span>
      );

    let formattedText = text.replace(/\{\{(\d+)\}\}/g, (match, num) => {
      const content = variables[num] || num;
      return `<span style="background-color: hsl(var(--primary) / 0.1); color: hsl(var(--primary)); padding: 2px 4px; border-radius: 4px; font-family: monospace; font-size: 0.9em; border: 1px solid hsl(var(--primary) / 0.3);">${content}</span>`;
    });

    formattedText = formattedText.replace(
      /\*([^*]+)\*/g,
      '<strong>$1</strong>'
    );
    formattedText = formattedText.replace(/_([^_]+)_/g, '<em>$1</em>');
    formattedText = formattedText.replace(/~([^~]+)~/g, '<del>$1</del>');
    formattedText = formattedText.replace(
      /```([^`]+)```/g,
      '<code style="font-family: monospace; background-color: hsl(var(--muted)); padding: 2px 4px; border-radius: 3px; font-size: 0.9em;">$1</code>'
    );

    return <div dangerouslySetInnerHTML={{ __html: formattedText }} />;
  };

  useEffect(() => {
    if (showSuccess) {
      const timer = setTimeout(() => {
        setShowSuccess(false);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [showSuccess]);

  const showWarning = (
    type: WarningType,
    title: string,
    message: string,
    description = '',
    actions: WarningAction[] = []
  ) => {
    setWarningState({
      show: true,
      type,
      title,
      message,
      description,
      actions: [
        ...actions,
        {
          label: 'Dismiss',
          onClick: () => setWarningState((prev) => ({ ...prev, show: false })),
          variant: 'outline',
        },
      ],
    });
  };

  const showError = (title: string, message: string, description = '') => {
    showWarning('error', title, message, description);
  };

  const showInfo = (title: string, message: string, description = '') => {
    showWarning('info', title, message, description);
  };

  const categories = ['MARKETING', 'UTILITY', 'AUTHENTICATION'];

  useEffect(() => {
    dispatch(fetchAllLanguages());
  }, [dispatch]);

  const insertVariableAtCursor = () => {
    const textarea = bodyTextareaRef.current;
    if (!textarea) return;

    const variableNumber = nextVariableNumber.toString();
    const variableText = `{{${variableNumber}}}`;

    const cursorStart = textarea.selectionStart;
    const cursorEnd = textarea.selectionEnd;

    const textBefore = bodyText.substring(0, cursorStart);
    const textAfter = bodyText.substring(cursorEnd);

    const newText = textBefore + variableText + textAfter;
    setBodyText(newText);

    setTimeout(() => {
      const newCursorPosition = cursorStart + variableText.length;
      textarea.setSelectionRange(newCursorPosition, newCursorPosition);
      textarea.focus();
    }, 0);

    setVariableModal({
      isOpen: true,
      variableName: variableNumber,
      currentContent: variables[variableNumber] || variableNumber,
    });

    setNextVariableNumber((prev) => prev + 1);
  };

  const saveVariableContent = (variableName: string, content: string) => {
    setVariables((prev) => ({
      ...prev,
      [variableName]: content || variableName,
    }));
  };

  const removeVariable = (variableName: string) => {
    setVariables((prev) => {
      const newVariables = { ...prev };
      delete newVariables[variableName];
      return newVariables;
    });

    const variablePattern = new RegExp(`\\{\\{${variableName}\\}\\}`, 'g');
    setBodyText((prev) => prev.replace(variablePattern, ''));

    const variableNum = parseInt(variableName);
    if (!isNaN(variableNum)) {
      const existingNumbers = Object.keys(variables)
        .map((key) => parseInt(key))
        .filter((num) => !isNaN(num) && num !== variableNum)
        .concat(
          Array.from(bodyText.matchAll(/\{\{(\d+)\}\}/g))
            .map((match) => parseInt(match[1]))
            .filter((num) => !isNaN(num) && num !== variableNum)
        );

      const maxNumber =
        existingNumbers.length > 0 ? Math.max(...existingNumbers) : 0;
      setNextVariableNumber(maxNumber + 1);
    }
  };

  const editVariable = (variableName: string) => {
    setVariableModal({
      isOpen: true,
      variableName,
      currentContent: variables[variableName] || '',
    });
  };

  useEffect(() => {
    const variableMatches = bodyText.match(/\{\{(\d+)\}\}/g);
    if (variableMatches) {
      const numbers = variableMatches
        .map((match) => parseInt(match.replace(/[{}]/g, '')))
        .filter((num) => !isNaN(num));

      if (numbers.length > 0) {
        const maxNumber = Math.max(...numbers);
        setNextVariableNumber(maxNumber + 1);
      }
    } else {
      setNextVariableNumber(1);
    }
  }, [bodyText]);

  const handleFileUpload = async (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      await dispatch(uploadMedia(file)).unwrap();
    } catch (error) {
      console.error('Upload failed:', error);
      showError(
        'File Upload Failed',
        'Failed to upload the selected file',
        'Please check your file format and try again. Make sure your file meets the requirements.'
      );
    }
  };

  const addButton = (type: TemplateButton['type'] = 'QUICK_REPLY') => {
    const newButton: TemplateButton = {
      id: Date.now().toString(),
      type: type,
      text: '',
      url: type === 'URL' ? 'https://' : undefined,
      phone_number: type === 'PHONE_NUMBER' ? '+91' : undefined,
    };
    setButtons([...buttons, newButton]);
  };

  const cleanPhoneNumber = (phoneNumber: string) => {
    return phoneNumber
      .replace(/[\u200E\u200F\u202A-\u202E\u2066\u2067\u2068\u2069]/g, '')
      .replace(/\s+/g, '')
      .replace(/[^\d+\-()]/g, '')
      .trim();
  };

  const validatePhoneNumber = (
    phoneNumber: string
  ): { isValid: boolean; cleanedNumber: string; error?: string } => {
    const cleaned = cleanPhoneNumber(phoneNumber);

    if (!cleaned) {
      return {
        isValid: false,
        cleanedNumber: cleaned,
        error: 'Phone number is required',
      };
    }

    if (!cleaned.startsWith('+')) {
      return {
        isValid: false,
        cleanedNumber: cleaned,
        error: 'Phone number must start with +',
      };
    }

    const digitsOnly = cleaned.replace(/[^\d]/g, '');

    if (digitsOnly.length < 7 || digitsOnly.length > 15) {
      return {
        isValid: false,
        cleanedNumber: cleaned,
        error: 'Phone number must be 7-15 digits long',
      };
    }

    const phoneRegex = /^\+[1-9]\d{6,14}$/;
    if (!phoneRegex.test(cleaned)) {
      return {
        isValid: false,
        cleanedNumber: cleaned,
        error: 'Invalid phone number format',
      };
    }

    return { isValid: true, cleanedNumber: cleaned };
  };

  const updateButton = (
    buttonId: string,
    field: keyof TemplateButton,
    value: string
  ) => {
    let processedValue = value;

    if (field === 'phone_number') {
      const validation = validatePhoneNumber(value);
      processedValue = validation.cleanedNumber;

      if (!validation.isValid && value.length > 0) {
        console.warn('Phone validation:', validation.error);
      }
    }

    setButtons(
      buttons.map((button) =>
        button.id === buttonId ? { ...button, [field]: processedValue } : button
      )
    );
  };

  const removeButton = (buttonId: string) => {
    setButtons(buttons.filter((button) => button.id !== buttonId));
  };

  const buildTemplatePayload = () => {
    const components = [];

    if (!bodyText || !bodyText.trim()) {
      throw new Error('Body text is required');
    }

    if (isAuthCategory) {
      // Authentication category payload structure
      const bodyComponent = {
        type: 'BODY',
        add_security_recommendation: addSecurityRecommendation,
      };
      components.push(bodyComponent);

      // Footer component for authentication
      if (includeExpiryTime) {
        components.push({
          type: 'FOOTER',
          code_expiration_minutes: codeExpirationMinutes,
        });
      }

      // Buttons component for authentication
      if (copyButtonText && copyButtonText.trim()) {
        components.push({
          type: 'BUTTONS',
          buttons: [
            {
              type: 'otp',
              otp_type: 'copy_code',
              text: copyButtonText.trim(),
            },
          ],
        });
      }
    } else {
      // Regular template payload structure
      const bodyComponent = {
        type: 'BODY',
        text: bodyText.trim(),
      };

      const variableMatches = bodyText.match(/\{\{([^}]+)\}\}/g);
      if (variableMatches && variableMatches.length > 0) {
        const exampleValues = [];

        for (const match of variableMatches) {
          const varName = match.replace(/[{}]/g, '');
          const content = variables[varName];

          if (!content || content.trim() === '') {
            throw new Error(
              `Variable {{${varName}}} has no content. Please provide content for this variable.`
            );
          }

          exampleValues.push([content.trim()]);
        }

        bodyComponent.example = {
          body_text: exampleValues,
        };
      }

      components.push(bodyComponent);

      if (footerText && footerText.trim()) {
        components.push({
          type: 'FOOTER',
          text: footerText.trim(),
        });
      }

      if (broadcastType !== 'none') {
        const headerComponent = {
          type: 'HEADER',
          format: broadcastType.toUpperCase(),
        };

        if (['image', 'video', 'document'].includes(broadcastType)) {
          const whatsappHandle = mediaData.handle || mediaData.image;

          if (!whatsappHandle) {
            throw new Error(
              `No ${broadcastType} handle found. Please upload ${broadcastType} again.`
            );
          }

          headerComponent.example = {
            header_handle: [whatsappHandle],
          };

          components.push(headerComponent);
        } else if (broadcastType === 'text') {
          if (!headerText || !headerText.trim()) {
            throw new Error(
              'Header text is required when text header is selected'
            );
          }
          headerComponent.text = headerText.trim();
          components.push(headerComponent);
        }
      }

      if (buttons.length > 0) {
        const validButtons = buttons.filter(
          (button) => button.text && button.text.trim()
        );

        if (validButtons.length > 0) {
          validButtons.forEach((button, index) => {
            if (button.type === 'URL' && (!button.url || !button.url.trim())) {
              throw new Error(
                `Button ${index + 1} (${button.text}) is missing URL`
              );
            }
            if (
              button.type === 'PHONE_NUMBER' &&
              (!button.phone_number || !button.phone_number.trim())
            ) {
              throw new Error(
                `Button ${index + 1} (${button.text}) is missing phone number`
              );
            }

            if (button.type === 'PHONE_NUMBER' && button.phone_number) {
              const validation = validatePhoneNumber(button.phone_number);
              if (!validation.isValid) {
                throw new Error(
                  `Button ${index + 1} (${
                    button.text
                  }) has invalid phone number: ${validation.error}`
                );
              }
            }
          });

          const buttonsComponent = {
            type: 'BUTTONS',
            buttons: validButtons.map((button) => {
              const buttonData = {
                type: button.type,
                text: button.text.trim(),
              };

              if (button.type === 'URL') {
                buttonData.url = button.url.trim();
              } else if (button.type === 'PHONE_NUMBER') {
                const validation = validatePhoneNumber(button.phone_number);
                if (!validation.isValid) {
                  throw new Error(
                    `Invalid phone number for button "${button.text}": ${validation.error}`
                  );
                }
                buttonData.phone_number = validation.cleanedNumber;
              }

              return buttonData;
            }),
          };

          components.push(buttonsComponent);
        }
      }
    }

    const payload = {
      name: template.name.trim(),
      language: template.language,
      category: template.category,
      components,
    };

    return payload;
  };

  const handleSaveTemplate = async () => {
    try {
      dispatch(clearError());

      if (!template.name || !template.name.trim()) {
        showError(
          'Template Name Required',
          'Please enter a template name',
          'Template name is required to create a WhatsApp message template.'
        );
        return;
      }

      if (!bodyText || !bodyText.trim()) {
        showError(
          'Body Text Required',
          'Please enter body text for your template',
          'Body text is the main content of your WhatsApp message and is required.'
        );
        return;
      }

      if (!isAuthCategory) {
        if (['image', 'video', 'document'].includes(broadcastType)) {
          console.log('Validating media for:', broadcastType);

          if (mediaData.loading) {
            showInfo(
              'Upload In Progress',
              'Please wait for the file upload to complete',
              'Your file is still being uploaded. Please wait a moment before saving the template.'
            );
            return;
          }

          if (mediaData.error) {
            showError(
              'Media Upload Error',
              `Upload failed: ${mediaData.error}`,
              'Please try uploading your file again before saving the template.'
            );
            return;
          }

          const whatsappHandle = mediaData.handle || mediaData.image;
          if (!whatsappHandle || whatsappHandle.trim() === '') {
            showError(
              `${
                broadcastType.charAt(0).toUpperCase() + broadcastType.slice(1)
              } Required`,
              `No ${broadcastType} found for the header`,
              `Please upload a ${broadcastType} file for the header before saving the template.`
            );
            return;
          }

          console.log('✅ Media validation passed. Handle:', whatsappHandle);
        }

        if (broadcastType === 'text' && (!headerText || !headerText.trim())) {
          showError(
            'Header Text Required',
            'Please enter header text',
            'When text header is selected, header text is required for the template.'
          );
          return;
        }

        const variableMatches = bodyText.match(/\{\{([^}]+)\}\}/g);
        if (variableMatches) {
          console.log('🔍 Pre-save variable check:', variableMatches);
          console.log('🔍 Current variables:', variables);

          let hasUpdatedVariables = false;
          const updatedVariables = { ...variables };

          variableMatches.forEach((match) => {
            const varName = match.replace(/[{}]/g, '');
            if (
              !updatedVariables[varName] ||
              !updatedVariables[varName].trim()
            ) {
              console.log(
                `🔧 Auto-setting variable ${varName} to "${varName}"`
              );
              updatedVariables[varName] = varName;
              hasUpdatedVariables = true;
            }
          });

          if (hasUpdatedVariables) {
            setVariables(updatedVariables);
            await new Promise((resolve) => setTimeout(resolve, 100));
          }
        }
      }

      const payload = buildTemplatePayload();

      try {
        const result = await dispatch(createTemplate(payload)).unwrap();

        setShowSuccess(true);

        // Reset form
        setTemplate({
          name: '',
          category: 'MARKETING',
          language: 'en',
          components: [],
        });
        setBroadcastType('none');
        setHeaderText('');
        setBodyText('');
        setFooterText('');
        setButtons([]);
        setVariables({});
        setNextVariableNumber(1);
        setAddSecurityRecommendation(true);
        setIncludeExpiryTime(false);
        setCodeExpirationMinutes(10);
        setCopyButtonText('');
        dispatch(clearMedia());
      } catch (dispatchError) {
        throw dispatchError;
      }
    } catch (error) {
      console.error('Save failed:', error);
    }
  };

  const buildTemplateForPreview = () => {
    const components = [];

    if (!isAuthCategory && broadcastType !== 'none') {
      const headerComponent: any = {
        type: 'HEADER',
        format: broadcastType.toUpperCase(),
      };

      if (
        broadcastType === 'image' &&
        (mediaData.publicUrl || mediaData.handle)
      ) {
        headerComponent.previewUrl = mediaData.publicUrl;
        headerComponent.example = {
          header_handle: [mediaData.handle || mediaData.image],
        };
      } else if (
        broadcastType === 'video' &&
        (mediaData.publicUrl || mediaData.handle)
      ) {
        headerComponent.previewUrl = mediaData.publicUrl;
        headerComponent.example = {
          header_handle: [mediaData.handle || mediaData.image],
        };
      } else if (
        broadcastType === 'document' &&
        (mediaData.publicUrl || mediaData.handle)
      ) {
        headerComponent.previewUrl = mediaData.publicUrl;
        headerComponent.example = {
          header_handle: [mediaData.handle || mediaData.image],
        };
      } else if (broadcastType === 'text' && headerText) {
        headerComponent.text = headerText;
      }

      components.push(headerComponent);
    }

    if (bodyText && bodyText.trim()) {
      components.push({
        type: 'BODY',
        text: bodyText,
      });
    }

    if (footerText) {
      components.push({
        type: 'FOOTER',
        text: footerText,
      });
    }

    if (!isAuthCategory && buttons.length > 0) {
      const validButtons = buttons.filter((button) => button.text.trim());
      if (validButtons.length > 0) {
        components.push({
          type: 'BUTTONS',
          buttons: validButtons,
        });
      }
    }

    if (isAuthCategory && copyButtonText && copyButtonText.trim()) {
      components.push({
        type: 'BUTTONS',
        buttons: [
          {
            type: 'otp',
            otp_type: 'copy_code',
            text: copyButtonText.trim(),
          },
        ],
      });
    }

    return {
      ...template,
      components,
    };
  };

  const getSelectedLanguageName = () => {
    const selectedLang = languages.find(
      (lang) => lang.code === template.language
    );
    return selectedLang ? selectedLang.name : template.language;
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <VariableContentModal
        isOpen={variableModal.isOpen}
        onClose={() =>
          setVariableModal({
            isOpen: false,
            variableName: '',
            currentContent: '',
          })
        }
        onSave={saveVariableContent}
        variableName={variableModal.variableName}
        currentContent={variableModal.currentContent}
      />

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-6 py-4 flex-shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" onClick={onBack} size="sm">
                <ArrowLeft className="w-4 h-4" />
              </Button>
              <div>
                <h1 className="text-xl font-semibold text-gray-900">
                  New Template
                </h1>
              </div>
            </div>
            <Button
              className="bg-green-600 hover:bg-green-700"
              onClick={handleSaveTemplate}
              disabled={templatesLoading}
            >
              {templatesLoading ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Save className="w-4 h-4 mr-2" />
              )}
              {templatesLoading ? 'Saving...' : 'Save Template'}
            </Button>
          </div>
        </div>

        {/* Form and Preview Layout */}
        <div className="flex flex-1 min-h-0">
          {/* Warning and Success notifications */}
          {warningState.show && (
            <div className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 max-w-lg w-full mx-4">
              <WarningComponent
                type={warningState.type}
                title={warningState.title}
                message={warningState.message}
                description={warningState.description}
                actions={warningState.actions}
                dismissible
                onClose={() =>
                  setWarningState((prev) => ({ ...prev, show: false }))
                }
                size="md"
                className="shadow-lg"
              />
            </div>
          )}

          {lastError && (
            <div className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 max-w-lg w-full mx-4">
              <WarningComponent
                type="error"
                title={lastError.error_user_title || 'Template Creation Failed'}
                message={
                  userFriendlyError ||
                  'An error occurred while creating the template'
                }
                actions={[
                  {
                    label: 'Dismiss',
                    onClick: () => dispatch(clearError()),
                    variant: 'outline',
                  },
                ]}
                dismissible
                onClose={() => dispatch(clearError())}
                size="md"
                className="shadow-lg"
              />
            </div>
          )}

          {showSuccess && (
            <div className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 max-w-lg w-full mx-4">
              <WarningComponent
                type="success"
                title="Template Created Successfully!"
                message="Your WhatsApp template has been submitted for approval."
                description="You'll receive a notification once it's approved by WhatsApp."
                actions={[
                  {
                    label: 'Create Another',
                    onClick: () => setShowSuccess(false),
                    variant: 'outline',
                  },
                ]}
                dismissible
                onClose={() => setShowSuccess(false)}
                size="md"
                className="shadow-lg"
              />
            </div>
          )}

          {/* Form Content */}
          <div className="flex-1 overflow-y-auto scrollbar-hide">
            <div className="p-6">
              <div className="max-w-4xl mx-auto space-y-6 pb-8">
                <div className="bg-white rounded-lg p-6 space-y-8">
                  {/* Basic Template Info */}
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="templateName">Template Name *</Label>
                        <Input
                          id="templateName"
                          value={template.name}
                          onChange={(e) =>
                            setTemplate({ ...template, name: e.target.value })
                          }
                          placeholder="e.g., welcome_message"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Category</Label>
                        <Select
                          value={template.category}
                          onValueChange={(value) =>
                            setTemplate({ ...template, category: value })
                          }
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {categories.map((category) => (
                              <SelectItem key={category} value={category}>
                                {category}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Language</Label>
                        <Select
                          value={template.language}
                          onValueChange={(value) =>
                            setTemplate({ ...template, language: value })
                          }
                        >
                          <SelectTrigger>
                            <SelectValue>
                              {languagesLoading
                                ? 'Loading...'
                                : getSelectedLanguageName()}
                            </SelectValue>
                          </SelectTrigger>
                          <SelectContent>
                            {languages.map((language) => (
                              <SelectItem
                                key={language.id}
                                value={language.code}
                              >
                                {language.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>

                  {/* Header Section - Hidden for Authentication */}
                  {!isAuthCategory && (
                    <div className="space-y-4">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                          Header
                          <Badge variant="secondary" className="ml-2">
                            Optional
                          </Badge>
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          Add media or text to make your message stand out
                        </p>
                      </div>

                      <RadioGroup
                        value={broadcastType}
                        onValueChange={setBroadcastType}
                        className="flex flex-wrap gap-6"
                      >
                        {[
                          { value: 'none', label: 'None' },
                          { value: 'text', label: 'Text' },
                          { value: 'image', label: 'Image' },
                          { value: 'video', label: 'Video' },
                          { value: 'document', label: 'Document' },
                        ].map(({ value, label }) => (
                          <div
                            key={value}
                            className="flex items-center space-x-2"
                          >
                            <RadioGroupItem value={value} id={value} />
                            <Label htmlFor={value} className="cursor-pointer">
                              {label}
                            </Label>
                          </div>
                        ))}
                      </RadioGroup>

                      {broadcastType === 'text' && (
                        <div className="space-y-3">
                          <Input
                            placeholder="Enter header text"
                            value={headerText}
                            onChange={(e) => setHeaderText(e.target.value)}
                            maxLength={60}
                          />
                          <p className="text-xs text-muted-foreground">
                            Max 60 characters
                          </p>
                        </div>
                      )}

                      {(broadcastType === 'image' ||
                        broadcastType === 'video' ||
                        broadcastType === 'document') && (
                        <div className="space-y-3">
                          <p className="text-sm text-blue-600">
                            {broadcastType === 'image' &&
                              '(Supported: .jpeg, .png)'}
                            {broadcastType === 'video' &&
                              '(Supported: .mp4, .3gp)'}
                            {broadcastType === 'document' &&
                              '(Supported: .pdf, .doc, .docx)'}
                          </p>

                          <div className="border-2 border-dashed border-gray-300 rounded-lg p-4">
                            <div className="text-center">
                              <Button
                                variant="outline"
                                onClick={() => fileInputRef.current?.click()}
                                className="border-green-500 text-green-600 hover:bg-green-50"
                                disabled={mediaData.loading}
                              >
                                {mediaData.loading ? (
                                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                ) : (
                                  <Upload className="w-4 h-4 mr-2" />
                                )}
                                {mediaData.loading
                                  ? 'Uploading...'
                                  : `Upload ${broadcastType}`}
                              </Button>
                              <input
                                ref={fileInputRef}
                                type="file"
                                accept={
                                  broadcastType === 'image'
                                    ? 'image/*'
                                    : broadcastType === 'video'
                                    ? 'video/*'
                                    : broadcastType === 'document'
                                    ? '.pdf,.doc,.docx'
                                    : '*'
                                }
                                onChange={handleFileUpload}
                                className="hidden"
                              />
                            </div>

                            {mediaData.publicUrl && (
                              <div className="mt-4 p-2 bg-green-50 border border-green-200 rounded-md">
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center space-x-2">
                                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                                    <span className="text-sm text-green-700">
                                      File uploaded successfully
                                    </span>
                                  </div>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => dispatch(clearMedia())}
                                    className="text-red-500 hover:text-red-700"
                                  >
                                    <X className="w-4 h-4" />
                                  </Button>
                                </div>
                                {broadcastType === 'image' && (
                                  <img
                                    src={mediaData.publicUrl}
                                    alt="Preview"
                                    className="mt-2 max-h-32 rounded border"
                                  />
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Body Section */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-semibold text-gray-900">
                        Body *
                      </h3>
                      {!isAuthCategory && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-green-600 border-green-200 hover:bg-green-50"
                          onClick={insertVariableAtCursor}
                        >
                          <Plus className="w-4 h-4 mr-1" />
                          Add Variable {`{{${nextVariableNumber}}}`}
                        </Button>
                      )}
                    </div>

                    {isAuthCategory ? (
                      <div className="space-y-4">
                        <p className="text-sm text-muted-foreground">
                          Content for authentication message templates can't be
                          edited. You can add/remove additional content from the
                          option below
                        </p>

                        <div className="space-y-2">
                          <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg border border-border/50">
                            <div className="flex items-center space-x-1">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 w-8 p-0 hover:bg-accent"
                                onClick={() => applyWhatsAppFormatting('*')}
                                title="Bold (*text*)"
                              >
                                <Bold className="w-4 h-4" />
                              </Button>

                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 w-8 p-0 hover:bg-accent"
                                onClick={() => applyWhatsAppFormatting('_')}
                                title="Italic (_text_)"
                              >
                                <Italic className="w-4 h-4" />
                              </Button>

                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 w-8 p-0 hover:bg-accent"
                                onClick={() => applyWhatsAppFormatting('~')}
                                title="Strikethrough (~text~)"
                              >
                                <Strikethrough className="w-4 h-4" />
                              </Button>

                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 w-8 p-0 hover:bg-accent"
                                onClick={() => applyWhatsAppFormatting('```')}
                                title="Monospace (```text```)"
                              >
                                <Code className="w-4 h-4" />
                              </Button>
                            </div>

                            <Badge variant="outline" className="text-xs">
                              {bodyText.length || 0}/1024
                            </Badge>
                          </div>

                          <Textarea
                            ref={bodyTextareaRef}
                            value={bodyText}
                            onChange={(e) => setBodyText(e.target.value)}
                            className="min-h-[120px] resize-none font-mono bg-gray-50"
                            maxLength={1024}
                            required
                            disabled
                          />
                        </div>

                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id="addSecurityRecommendation"
                            checked={addSecurityRecommendation}
                            onCheckedChange={setAddSecurityRecommendation}
                          />
                          <Label
                            htmlFor="addSecurityRecommendation"
                            className="text-sm"
                          >
                            Add security recommendation
                          </Label>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <p className="text-sm text-muted-foreground">
                          Enter your message content with WhatsApp formatting.
                          Use{' '}
                          <code className="bg-muted px-1 rounded">*bold*</code>,{' '}
                          <code className="bg-muted px-1 rounded">
                            _italic_
                          </code>
                          ,{' '}
                          <code className="bg-muted px-1 rounded">
                            ~strikethrough~
                          </code>
                          , or{' '}
                          <code className="bg-muted px-1 rounded">
                            ```monospace```
                          </code>
                          .
                        </p>

                        <div className="space-y-2">
                          <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg border border-border/50">
                            <div className="flex items-center space-x-1">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 w-8 p-0 hover:bg-accent"
                                onClick={() => applyWhatsAppFormatting('*')}
                                title="Bold (*text*)"
                              >
                                <Bold className="w-4 h-4" />
                              </Button>

                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 w-8 p-0 hover:bg-accent"
                                onClick={() => applyWhatsAppFormatting('_')}
                                title="Italic (_text_)"
                              >
                                <Italic className="w-4 h-4" />
                              </Button>

                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 w-8 p-0 hover:bg-accent"
                                onClick={() => applyWhatsAppFormatting('~')}
                                title="Strikethrough (~text~)"
                              >
                                <Strikethrough className="w-4 h-4" />
                              </Button>

                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 w-8 p-0 hover:bg-accent"
                                onClick={() => applyWhatsAppFormatting('```')}
                                title="Monospace (```text```)"
                              >
                                <Code className="w-4 h-4" />
                              </Button>

                              <div className="w-px h-6 bg-border mx-2"></div>

                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 w-8 p-0 hover:bg-accent"
                                onClick={insertRandomEmoji}
                                title="Insert Emoji"
                              >
                                <Smile className="w-4 h-4" />
                              </Button>

                              <div className="w-px h-6 bg-border mx-2"></div>

                              <Button
                                variant="outline"
                                size="sm"
                                className="text-primary border-primary/20 hover:bg-primary/10 h-8"
                                onClick={insertVariableAtCursor}
                                title={`Insert Variable {{${nextVariableNumber}}}`}
                              >
                                <Plus className="w-3 h-3 mr-1" />
                                {`{{${nextVariableNumber}}}`}
                              </Button>
                            </div>

                            <div className="flex items-center space-x-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 px-2 hover:bg-accent"
                                onClick={() => setShowPreview(!showPreview)}
                                title={
                                  showPreview ? 'Hide Preview' : 'Show Preview'
                                }
                              >
                                {showPreview ? (
                                  <EyeOff className="w-4 h-4" />
                                ) : (
                                  <Eye className="w-4 h-4" />
                                )}
                              </Button>
                              <Badge variant="outline" className="text-xs">
                                {bodyText.length || 0}/1024
                              </Badge>
                            </div>
                          </div>

                          <Textarea
                            ref={bodyTextareaRef}
                            value={bodyText}
                            onChange={(e) => setBodyText(e.target.value)}
                            placeholder="Enter your message body... Use *bold*, _italic_, ~strikethrough~, or ```monospace``` formatting"
                            className="min-h-[120px] resize-none font-mono"
                            maxLength={1024}
                            required
                          />
                        </div>

                        <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
                          <span className="bg-muted/50 px-2 py-1 rounded">
                            <strong>*bold*</strong>
                          </span>
                          <span className="bg-muted/50 px-2 py-1 rounded">
                            <em>_italic_</em>
                          </span>
                          <span className="bg-muted/50 px-2 py-1 rounded">
                            <del>~strikethrough~</del>
                          </span>
                          <span className="bg-muted/50 px-2 py-1 rounded font-mono">
                            ```monospace```
                          </span>
                        </div>

                        {showPreview && (
                          <div className="space-y-2">
                            <h4 className="text-sm font-medium text-foreground flex items-center gap-2">
                              <Eye className="w-4 h-4" />
                              WhatsApp Preview
                            </h4>
                            <div className="p-4 bg-gradient-to-br from-green-50 to-green-100 border border-green-200 rounded-lg">
                              <div className="bg-white rounded-lg p-3 shadow-sm border border-green-200/50">
                                <div className="text-sm leading-relaxed whitespace-pre-wrap">
                                  {renderWhatsAppPreview(bodyText)}
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Footer Section */}
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                        Footer
                        <Badge variant="secondary" className="ml-2">
                          Optional
                        </Badge>
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {isAuthCategory
                          ? 'Footers are great to add any disclaimers or to add a thoughtful PS'
                          : 'Add a short line of text to the bottom of your message template.'}
                      </p>
                    </div>

                    {isAuthCategory ? (
                      <div className="space-y-4">
                        <Input
                          value={footerText}
                          disabled
                          onChange={(e) => setFooterText(e.target.value)}
                          placeholder="Footer text (optional)"
                          maxLength={60}
                        />
                        <p className="text-xs text-muted-foreground">
                          {footerText.length}/60
                        </p>

                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id="includeExpiryTime"
                            checked={includeExpiryTime}
                            onCheckedChange={setIncludeExpiryTime}
                          />
                          <Label
                            htmlFor="includeExpiryTime"
                            className="text-sm"
                          >
                            Include expiry time
                          </Label>
                        </div>

                        {includeExpiryTime && (
                          <div className="space-y-2">
                            <Label htmlFor="expirationTime">Expires in</Label>
                            <div className="flex items-center space-x-2">
                              <Input
                                id="expirationTime"
                                type="number"
                                value={codeExpirationMinutes}
                                onChange={(e) =>
                                  setCodeExpirationMinutes(
                                    parseInt(e.target.value) || 10
                                  )
                                }
                                className="w-20"
                                min={1}
                                max={90}
                              />
                              <span className="text-sm text-muted-foreground">
                                minutes
                              </span>
                            </div>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="space-y-3">
                        <Input
                          value={footerText}
                          onChange={(e) => setFooterText(e.target.value)}
                          placeholder="Footer text (optional)"
                          maxLength={60}
                        />
                        <p className="text-xs text-muted-foreground">
                          Max 60 characters
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Buttons Section */}
                  {isAuthCategory ? (
                    <div className="space-y-4">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900">
                          Buttons
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          Add text here for users to easily copy the code.
                        </p>
                      </div>

                      <div className="space-y-3">
                        <Input
                          value={copyButtonText}
                          onChange={(e) => setCopyButtonText(e.target.value)}
                          placeholder="Button Text"
                          maxLength={25}
                        />
                        <p className="text-xs text-muted-foreground">
                          {copyButtonText.length}/25
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4" data-section="buttons">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                          Buttons
                          <Badge variant="secondary" className="ml-2">
                            Optional
                          </Badge>
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          Add interactive buttons to your template. You can add
                          up to 10 buttons.
                        </p>
                      </div>

                      <div className="space-y-4">
                        {buttons.map((button) => (
                          <Card key={button.id} className="p-4">
                            <div className="flex items-start space-x-3">
                              <Select
                                value={button.type}
                                onValueChange={(
                                  value: TemplateButton['type']
                                ) => updateButton(button.id, 'type', value)}
                              >
                                <SelectTrigger className="w-40">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="QUICK_REPLY">
                                    Quick Reply
                                  </SelectItem>
                                  <SelectItem value="PHONE_NUMBER">
                                    Call Phone
                                  </SelectItem>
                                  <SelectItem value="URL">
                                    Visit Website
                                  </SelectItem>
                                </SelectContent>
                              </Select>

                              <div className="flex-1 space-y-2">
                                <Input
                                  placeholder="Button text"
                                  value={button.text}
                                  onChange={(e) =>
                                    updateButton(
                                      button.id,
                                      'text',
                                      e.target.value
                                    )
                                  }
                                  maxLength={20}
                                />

                                {button.type === 'URL' && (
                                  <Input
                                    placeholder="https://example.com"
                                    value={button.url || ''}
                                    onChange={(e) =>
                                      updateButton(
                                        button.id,
                                        'url',
                                        e.target.value
                                      )
                                    }
                                  />
                                )}

                                {button.type === 'PHONE_NUMBER' && (
                                  <div className="space-y-2">
                                    <Input
                                      placeholder="+917710955555"
                                      value={button.phone_number || ''}
                                      onChange={(e) =>
                                        updateButton(
                                          button.id,
                                          'phone_number',
                                          e.target.value
                                        )
                                      }
                                    />
                                    {button.phone_number &&
                                      (() => {
                                        const validation = validatePhoneNumber(
                                          button.phone_number
                                        );
                                        return !validation.isValid ? (
                                          <p className="text-xs text-red-500">
                                            {validation.error}
                                          </p>
                                        ) : (
                                          <p className="text-xs text-green-600">
                                            ✓ Valid phone number
                                          </p>
                                        );
                                      })()}
                                  </div>
                                )}
                              </div>

                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => removeButton(button.id)}
                                className="text-red-500 hover:text-red-700"
                              >
                                <X className="w-4 h-4" />
                              </Button>
                            </div>
                          </Card>
                        ))}

                        {buttons.length < 10 && (
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                            <Button
                              variant="outline"
                              className="border-dashed border-2 h-12"
                              onClick={() => addButton('QUICK_REPLY')}
                            >
                              <Plus className="w-4 h-4 mr-2" />
                              Quick Reply
                            </Button>
                            <Button
                              variant="outline"
                              className="border-dashed border-2 h-12"
                              onClick={() => addButton('PHONE_NUMBER')}
                            >
                              <Plus className="w-4 h-4 mr-2" />
                              Call Phone
                            </Button>
                            <Button
                              variant="outline"
                              className="border-dashed border-2 h-12"
                              onClick={() => addButton('URL')}
                            >
                              <Plus className="w-4 h-4 mr-2" />
                              Visit Website
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Template Preview - Right Sidebar */}
          <TemplatePreview
            template={buildTemplateForPreview()}
            variables={variables}
            loading={mediaData.loading}
            onRemoveVariable={removeVariable}
            onEditVariable={editVariable}
          />
        </div>
      </div>
    </div>
  );
}
