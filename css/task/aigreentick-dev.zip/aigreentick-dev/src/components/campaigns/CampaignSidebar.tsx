import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import sideImg from '@/assets/campaign.svg';
import {
  Radio,
  FileText,
  Calendar,
  LayoutDashboard,
  Tags,
  FileSpreadsheet,
  RadioTower,
  ChevronDown,
  ChevronRight,
  FileStack,
  Megaphone,
} from 'lucide-react';

interface SidebarItem {
  icon: React.ElementType;
  label: string;
  path: string;
}

interface SidebarCategory {
  icon: React.ElementType;
  label: string;
  items: SidebarItem[];
  defaultOpen?: boolean;
}

interface CampaignSidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const CampaignSidebar: React.FC<CampaignSidebarProps> = ({
  activeTab,
  setActiveTab,
}) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [openCategories, setOpenCategories] = useState<string[]>([]);

  // Add a ref to track if we've initialized the sidebar
  const [isInitialized, setIsInitialized] = useState(false);

  const sidebarCategories: SidebarCategory[] = [
    {
      icon: FileStack,
      label: 'Templates',
      defaultOpen: true,
      items: [
        {
          icon: FileText,
          label: 'Template Library',
          path: '/campaigns/template-library',
        },
        {
          icon: Radio,
          label: 'Your Templates',
          path: '/campaigns/your-templates',
        },
      ],
    },
    {
      icon: Megaphone,
      label: 'Campaigns',
      items: [
        {
          icon: Tags,
          label: 'Send By Tags',
          path: '/campaigns/send-by-tags',
        },
        {
          icon: FileSpreadsheet,
          label: 'CSV Campaign',
          path: '/campaigns/csv-campaign',
        },
        {
          icon: Radio,
          label: 'Broadcast',
          path: '/campaigns/broadcast',
        },
        {
          icon: RadioTower,
          label: 'Campaign History',
          path: '/campaigns/campaigns-history',
        },
        {
          icon: Calendar,
          label: 'Scheduled Campaign',
          path: '/campaigns/scheduled-campaigns',
        },
        {
          icon: LayoutDashboard,
          label: 'Campaign Dashboard',
          path: '/campaigns/campaign-dashboard',
        },
      ],
    },
  ];

  // Get all items from all categories for path matching
  const allItems = sidebarCategories.flatMap((category) => category.items);

  // Initialize sidebar state on first load only
  useEffect(() => {
    const currentPath = location.pathname;
    const initialOpenCategories: string[] = [];

    // Open categories that have defaultOpen: true
    sidebarCategories.forEach((category) => {
      if (category.defaultOpen) {
        initialOpenCategories.push(category.label);
      }
    });

    // Set active tab and determine which categories to open initially
    if (currentPath.startsWith('/campaigns/')) {
      const activeItem = allItems.find((item) => item.path === currentPath);
      if (activeItem) {
        setActiveTab(activeItem.label);

        // Only auto-open category if it's not already in initialOpenCategories
        const categoryWithActiveItem = sidebarCategories.find((category) =>
          category.items.some((item) => item.path === currentPath)
        );
        if (
          categoryWithActiveItem &&
          !initialOpenCategories.includes(categoryWithActiveItem.label)
        ) {
          initialOpenCategories.push(categoryWithActiveItem.label);
        }
      } else if (
        currentPath === '/campaigns' ||
        currentPath === '/campaigns/'
      ) {
        setActiveTab('Your Templates');
        if (!initialOpenCategories.includes('Templates')) {
          initialOpenCategories.push('Templates');
        }
      }
    }

    // Only set initial state if not already initialized
    if (!isInitialized) {
      setOpenCategories(initialOpenCategories);
      setIsInitialized(true);
    }
  }, []); // Empty dependency array - run only once on mount

  // Handle route changes - ONLY update active tab, never modify openCategories
  useEffect(() => {
    const currentPath = location.pathname;

    if (currentPath.startsWith('/campaigns/')) {
      const activeItem = allItems.find((item) => item.path === currentPath);
      if (activeItem) {
        setActiveTab(activeItem.label);
      } else if (
        currentPath === '/campaigns' ||
        currentPath === '/campaigns/'
      ) {
        setActiveTab('Your Templates');
      }
    }
  }, [location.pathname]); // Only depend on pathname

  const handleItemClick = (item: SidebarItem) => {
    navigate(item.path);
    setActiveTab(item.label);
  };

  const isItemActive = (item: SidebarItem) => {
    return location.pathname === item.path;
  };

  const toggleCategory = (categoryLabel: string) => {
    setOpenCategories((prev) =>
      prev.includes(categoryLabel)
        ? prev.filter((cat) => cat !== categoryLabel)
        : [...prev, categoryLabel]
    );
  };

  const isCategoryOpen = (categoryLabel: string) => {
    return openCategories.includes(categoryLabel);
  };

  const hasCategoryActiveItem = (category: SidebarCategory) => {
    return category.items.some((item) => isItemActive(item));
  };

  return (
    <div className="w-64 fixed top-16 left-0 bg-white border-r border-gray-200 h-screen overflow-y-auto z-40">
      <div className="p-4">
        <div className="flex flex-col items-center space-y-3">
          <div className="w-full overflow-hidden flex items-center justify-center">
            <img
              src={sideImg}
              alt="Campaign Logo"
              className="w-full h-full object-cover"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
                const nextElement = e.currentTarget
                  .nextElementSibling as HTMLElement;
                if (nextElement) {
                  nextElement.style.display = 'flex';
                }
              }}
            />
            <Radio
              className="w-24 h-24 text-gray-400"
              style={{ display: 'none' }}
            />
          </div>
          <div className="text-center">
            <h2 className="text-lg font-semibold text-gray-900">
              Campaign Manager
            </h2>
            <p className="text-sm text-gray-600">Manage your campaigns</p>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-2">
        {sidebarCategories.map((category) => {
          const CategoryIcon = category.icon;
          const isOpen = isCategoryOpen(category.label);
          const hasActiveItem = hasCategoryActiveItem(category);

          return (
            <Collapsible
              key={category.label}
              open={isOpen}
              onOpenChange={() => toggleCategory(category.label)}
            >
              <CollapsibleTrigger asChild>
                <Button
                  variant="ghost"
                  className={`w-full justify-between p-2 h-auto font-medium transition-all duration-200 ${
                    hasActiveItem
                      ? 'bg-green-50 text-green-700'
                      : 'text-gray-700 hover:text-gray-900 hover:bg-gray-50'
                  }`}
                >
                  <div className="flex items-center">
                    <CategoryIcon className="w-4 h-4 mr-2" />
                    <span>{category.label}</span>
                  </div>
                  {isOpen ? (
                    <ChevronDown className="w-4 h-4" />
                  ) : (
                    <ChevronRight className="w-4 h-4" />
                  )}
                </Button>
              </CollapsibleTrigger>

              <CollapsibleContent className="space-y-1">
                <div className="ml-4 mt-1 space-y-1">
                  {category.items.map((item) => {
                    const Icon = item.icon;
                    const isActive = isItemActive(item);

                    return (
                      <Button
                        key={item.label}
                        variant={isActive ? 'secondary' : 'ghost'}
                        size="sm"
                        className={`w-full justify-start transition-all duration-200 ${
                          isActive
                            ? 'bg-green-100 text-green-700 border-r-2 border-green-500 font-medium'
                            : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                        }`}
                        onClick={() => handleItemClick(item)}
                      >
                        <Icon className="w-4 h-4 mr-2" />
                        <span className="flex-1 text-left text-sm">
                          {item.label}
                        </span>
                      </Button>
                    );
                  })}
                </div>
              </CollapsibleContent>
            </Collapsible>
          );
        })}
      </div>
    </div>
  );
};

export default CampaignSidebar;
