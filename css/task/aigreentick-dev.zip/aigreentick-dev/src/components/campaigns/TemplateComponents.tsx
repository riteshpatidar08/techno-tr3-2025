import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Type,
  FileText,
  MousePointer,
  Plus,
  X,
  MessageSquare,
} from 'lucide-react';

interface TemplateComponent {
  id: string;
  type: 'HEADER' | 'BODY' | 'FOOTER' | 'BUTTONS';
  format?: 'TEXT' | 'IMAGE' | 'VIDEO' | 'DOCUMENT';
  text?: string;
  image_url?: string;
  buttons?: Array<{
    type: 'QUICK_REPLY' | 'URL' | 'PHONE_NUMBER';
    text: string;
    url?: string;
    phone_number?: string;
  }>;
}

interface TemplateComponentsProps {
  components: TemplateComponent[];
  onAddComponent: (type: 'HEADER' | 'BODY' | 'FOOTER' | 'BUTTONS') => void;
  onUpdateComponent: (id: string, updates: Partial<TemplateComponent>) => void;
  onRemoveComponent: (id: string) => void;
  onAddVariable: (componentId: string) => void;
}

const TemplateComponents: React.FC<TemplateComponentsProps> = ({
  components,
  onAddComponent,
  onUpdateComponent,
  onRemoveComponent,
  onAddVariable,
}) => {
  const renderButtonComponent = (component: TemplateComponent) => (
    <div className="space-y-3">
      <Label>Buttons</Label>
      {component.buttons?.map((button, index) => (
        <div key={index} className="flex items-center space-x-2">
          <Select
            value={button.type}
            onValueChange={(value) => {
              const newButtons = [...(component.buttons || [])];
              newButtons[index] = {
                ...button,
                type: value as any,
              };
              onUpdateComponent(component.id, {
                buttons: newButtons,
              });
            }}
          >
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="QUICK_REPLY">Quick Reply</SelectItem>
              <SelectItem value="URL">URL</SelectItem>
              <SelectItem value="PHONE_NUMBER">Phone</SelectItem>
            </SelectContent>
          </Select>
          <Input
            placeholder="Button text"
            value={button.text}
            onChange={(e) => {
              const newButtons = [...(component.buttons || [])];
              newButtons[index] = {
                ...button,
                text: e.target.value,
              };
              onUpdateComponent(component.id, {
                buttons: newButtons,
              });
            }}
          />
          {button.type === 'URL' && (
            <Input
              placeholder="https://example.com"
              value={button.url || ''}
              onChange={(e) => {
                const newButtons = [...(component.buttons || [])];
                newButtons[index] = {
                  ...button,
                  url: e.target.value,
                };
                onUpdateComponent(component.id, {
                  buttons: newButtons,
                });
              }}
            />
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              const newButtons =
                component.buttons?.filter((_, i) => i !== index) || [];
              onUpdateComponent(component.id, {
                buttons: newButtons,
              });
            }}
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      ))}
      <Button
        variant="outline"
        size="sm"
        onClick={() => {
          const newButtons = [
            ...(component.buttons || []),
            { type: 'QUICK_REPLY' as const, text: '' },
          ];
          onUpdateComponent(component.id, {
            buttons: newButtons,
          });
        }}
      >
        <Plus className="w-4 h-4 mr-2" />
        Add Button
      </Button>
    </div>
  );

  return (
    <Card className='border-0'>
      <CardHeader>
        <CardTitle className="text-lg">Template Components</CardTitle>
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onAddComponent('HEADER')}
            disabled={components.some((c) => c.type === 'HEADER')}
          >
            <Type className="w-4 h-4 mr-2" />
            Header
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onAddComponent('BODY')}
            disabled={components.some((c) => c.type === 'BODY')}
          >
            <FileText className="w-4 h-4 mr-2" />
            Body
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onAddComponent('FOOTER')}
            disabled={components.some((c) => c.type === 'FOOTER')}
          >
            <Type className="w-4 h-4 mr-2" />
            Footer
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onAddComponent('BUTTONS')}
            disabled={components.some((c) => c.type === 'BUTTONS')}
          >
            <MousePointer className="w-4 h-4 mr-2" />
            Buttons
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {components.map((component) => (
          <Card key={component.id} className="border-l-4 border-r-0 border-b-0 border-t-0 border-l-green-500">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <Badge variant="secondary">{component.type}</Badge>
                  {component.type === 'HEADER' && (
                    <Select
                      value={component.format}
                      onValueChange={(value) =>
                        onUpdateComponent(component.id, {
                          format: value as any,
                        })
                      }
                    >
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="TEXT">Text</SelectItem>
                        <SelectItem value="IMAGE">Image</SelectItem>
                        <SelectItem value="VIDEO">Video</SelectItem>
                        <SelectItem value="DOCUMENT">Document</SelectItem>
                      </SelectContent>
                    </Select>
                  )}
                </div>
                <div className="flex items-center space-x-2">
                  {component.type === 'BODY' && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onAddVariable(component.id)}
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      Variable
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onRemoveComponent(component.id)}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {component.format === 'IMAGE' && (
                <div className="mb-3">
                  <Label>Image URL</Label>
                  <Input
                    placeholder="https://example.com/image.jpg"
                    value={component.image_url || ''}
                    onChange={(e) =>
                      onUpdateComponent(component.id, {
                        image_url: e.target.value,
                      })
                    }
                    className="mt-1"
                  />
                </div>
              )}

              {(component.format === 'TEXT' ||
                component.type !== 'HEADER' ||
                !component.format) &&
                component.type !== 'BUTTONS' && (
                  <div>
                    <Label>Text Content</Label>
                    <Textarea
                      placeholder={`Enter ${component.type.toLowerCase()} text...`}
                      value={component.text || ''}
                      onChange={(e) =>
                        onUpdateComponent(component.id, {
                          text: e.target.value,
                        })
                      }
                      className="mt-1"
                      rows={component.type === 'BODY' ? 4 : 2}
                    />
                  </div>
                )}

              {component.type === 'BUTTONS' && renderButtonComponent(component)}
            </CardContent>
          </Card>
        ))}

        {components.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>
              No components added yet. Start by adding a header, body, or
              footer.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default TemplateComponents;
