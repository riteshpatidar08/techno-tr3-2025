import { useState, useEffect } from 'react';
import logo from '@/assets/images/logos/aiGreenTick.png'
const LoadingAnimation = () => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const duration = 2000; 
    const increment = 100 / (duration / 16); 

    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          return 100;
        }
        return Math.min(prev + increment, 100);
      });
    }, 16); 

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-100 flex items-center justify-center p-4">
   
      <style jsx>{`
        @keyframes shimmer {
          0% {
            transform: translateX(-100%);
          }
          100% {
            transform: translateX(100%);
          }
        }
        @keyframes float {
          0%,
          100% {
            transform: translateY(0px);
          }
          50% {
            transform: translateY(-12px);
          }
        }
        @keyframes glow {
          0%,
          100% {
            box-shadow: 0 0 20px rgba(34, 197, 94, 0.3),
              0 0 40px rgba(34, 197, 94, 0.1);
          }
          50% {
            box-shadow: 0 0 30px rgba(34, 197, 94, 0.5),
              0 0 60px rgba(34, 197, 94, 0.2);
          }
        }
        @keyframes pulse-ring {
          0% {
            transform: scale(0.8);
            opacity: 1;
          }
          100% {
            transform: scale(1.4);
            opacity: 0;
          }
        }
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-float {
          animation: float 4s ease-in-out infinite;
        }
        .animate-glow {
          animation: glow 2s ease-in-out infinite;
        }
        .animate-pulse-ring {
          animation: pulse-ring 2s ease-out infinite;
        }
        .animate-fadeInUp {
          animation: fadeInUp 0.8s ease-out forwards;
        }
      `}</style>

      <div className="text-center max-w-md mx-auto">
       
        <div className="relative mb-12 animate-float">
         
          <div className="relative">
        
            <div className="absolute inset-0 blur-xl bg-green-200 opacity-10 animate-pulse scale-125"></div>

           
            <div className="relative w-full  mx-auto">
              <img
                src={logo}
                alt="whatsCRM Logo"
                className="w-full h-full object-contain transition-all duration-300 drop-shadow-lg"
                onError={(e) => {
            
                  e.target.style.display = 'none';
                  e.target.nextSibling.style.display = 'flex';
                }}
              />
              <div className="hidden items-center justify-center w-full h-full">
                <div className="text-green-600 font-bold text-3xl drop-shadow-sm">
                  CRM
                </div>
              </div>
            </div>
          </div>
        </div>

       
        <div
          className="mb-10 animate-fadeInUp"
          style={{ animationDelay: '0.3s' }}
        >
        
          <p className="text-gray-500 text-sm font-medium">
            Powering Your Customer Relationships
          </p>
        </div>

        
        <div
          className="w-80 mx-auto mb-8 animate-fadeInUp"
          style={{ animationDelay: '0.6s' }}
        >
          <div className="bg-gray-200 rounded-full h-2 overflow-hidden shadow-inner backdrop-blur-sm">
            <div
              className="bg-gradient-to-r from-green-400 via-green-500 to-green-600 h-full rounded-full transition-all duration-100 ease-out relative"
              style={{
                width: `${progress}%`,
                boxShadow:
                  progress > 0
                    ? '0 0 20px rgba(34, 197, 94, 0.4), inset 0 1px 1px rgba(255, 255, 255, 0.3)'
                    : 'none',
              }}
            >
       
              <div
                className="absolute inset-0 rounded-full"
                style={{
                  background:
                    progress > 0
                      ? 'linear-gradient(90deg, transparent, rgba(255,255,255,0.6), transparent)'
                      : '',
                  animation: progress > 0 ? 'shimmer 1.5s infinite' : 'none',
                }}
              ></div>
            </div>
          </div>
        </div>

        
        <div
          className="space-y-3 animate-fadeInUp"
          style={{ animationDelay: '0.9s' }}
        >
          <div className="flex items-center justify-center space-x-2">
            <div className="flex space-x-1">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <div
                className="w-2 h-2 bg-green-500 rounded-full animate-pulse"
                style={{ animationDelay: '0.2s' }}
              ></div>
              <div
                className="w-2 h-2 bg-green-500 rounded-full animate-pulse"
                style={{ animationDelay: '0.4s' }}
              ></div>
            </div>
            <p className="text-gray-600 text-sm font-medium">
              Initializing your workspace
            </p>
          </div>

          <p className="text-green-600 text-lg font-semibold">
            {Math.round(progress)}%
          </p>

          {progress === 100 && (
            <div className="mt-4 animate-fadeInUp">
              <div className="inline-flex items-center px-4 py-2 bg-green-50 border border-green-200 rounded-full">
                <svg
                  className="w-4 h-4 text-green-500 mr-2"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
                <span className="text-green-700 text-sm font-medium">
                  Ready to go!
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default LoadingAnimation;
