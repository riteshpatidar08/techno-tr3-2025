import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Search,
  MessageCircle,
  Phone,
  MoreVertical,
  Send,
  Paperclip,
  Smile,
  Star,
  Trash2,
  Bell,
  Filter,
  Plus,
  Settings,
  User,
  CheckCircle2,
  Clock,
  X,
  Menu,
  Languages,
  Save,
  Download,
  Calendar,
  ChevronDown,
  Mic,
  ChevronUp,
  ArrowLeft,
  Globe,
} from 'lucide-react';

export default function WhatsAppCRM() {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const filterButtonRef = useRef<HTMLButtonElement>(null);
  const [isInitialLoad, setIsInitialLoad] = useState(true);
  const [sidebarExpanded, setSidebarExpanded] = useState(false);
  const [showContactModal, setShowContactModal] = useState(false);

  const [selectedConversation, setSelectedConversation] = useState({
    id: '1',
    name: 'Tilak Raj Upadhyay',
    phone: '+919928293009',
    avatar: 'T',
    isOnline: true,
    status: 'Available',
    messages: [
      {
        id: 'm1',
        text: 'Hi',
        sender: 'contact',
        timestamp: '11:37 AM',
        status: 'delivered',
      },
      {
        id: 'm2',
        text: 'Wait Test',
        sender: 'user',
        timestamp: '10:17 AM',
        status: 'delivered',
      },
      {
        id: 'm3',
        text: 'Hey please join our demo session today!',
        sender: 'user',
        timestamp: '10:17 AM',
        status: 'delivered',
      },
      {
        id: 'm4',
        text: 'Hi',
        sender: 'contact',
        timestamp: '10:17 AM',
        status: 'delivered',
      },
    ],
  });

  const [newMessage, setNewMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [chatNote, setChatNote] = useState('');
  const [rating, setRating] = useState(0);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [filterOrigin, setFilterOrigin] = useState('All');
  const [filterAgent, setFilterAgent] = useState('All');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('All chats');

  const conversations = [
    {
      id: '1',
      name: 'Tilak Raj Upadhyay',
      phone: '+919928293009',
      lastMessage: 'Hi',
      timestamp: '11:37 AM',
      avatar: 'T',
      isActive: true,
      status: 'Open',
      isBot: false,
    },
    {
      id: '2',
      name: 'John Vijay Solomon',
      phone: '+919845141335',
      lastMessage: 'Tell me more',
      timestamp: '10:17 AM',
      avatar: 'J',
      isActive: false,
      status: 'Open',
      isBot: true,
    },
  ];

  const contacts = [
    { name: 'Morgan, Frazier and Turner', phone: '(6283899366355)' },
    { name: 'John Vijay Solomon', phone: '(919845141335)' },
    { name: 'Abhinay', phone: '(919780140028)' },
    { name: 'Tilak Raj Upadhyay', phone: '(919928293009)' },
    { name: 'shubham', phone: '(917042645164)' },
    { name: 'Ritesh Pundir', phone: '(919930843432)' },
  ];

  const filterOptions = [
    'All chats',
    'Broadcasts',
    'Unassigned',
    'Unread',
    'Last 24 Hours',
    'Assigned to me',
    'Favorite only',
  ];
  const scrollToBottom = (behavior: ScrollBehavior = 'smooth') => {
    messagesEndRef.current?.scrollIntoView({ behavior });
  };
  useEffect(() => {
    if (isInitialLoad && messagesContainerRef.current) {
      messagesContainerRef.current.scrollTop = 0;
      setTimeout(() => {
        scrollToBottom('smooth');
        setIsInitialLoad(false);
      }, 500);
    }
  }, [isInitialLoad]);

  useEffect(() => {
    if (!isInitialLoad) {
      scrollToBottom('smooth');
    }
  }, [selectedConversation.messages.length, isInitialLoad]);

  useEffect(() => {
    if (!isInitialLoad) {
      setTimeout(() => {
        scrollToBottom('auto');
      }, 100);
    }
  }, [selectedConversation.id, isInitialLoad]);

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;

    const newMsg = {
      id: `m${Date.now()}`,
      text: newMessage,
      sender: 'user',
      timestamp: new Date().toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
      }),
      status: 'sent',
    };

    setSelectedConversation((prev) => ({
      ...prev,
      messages: [...prev.messages, newMsg],
    }));

    setNewMessage('');
  };

  const handleApplyFilters = () => {
    setShowFilterModal(false);
  };

  const handleResetFilters = () => {
    setFilterOrigin('All');
    setFilterAgent('All');
    setStartDate('');
    setEndDate('');
  };

  return (
    <div className="h-screen bg-green-400 flex flex-col">
      <div className="bg-green-500 text-white px-6 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-6">
          <div className="w-8 h-8 bg-white/20 rounded flex items-center justify-center">
            <MessageCircle className="w-4 h-4" />
          </div>
          <nav className="flex items-center space-x-6 text-sm">
            <span className="text-white/80">Team Inbox</span>
            <span className="text-white/80">Broadcast</span>
            <span className="text-white/80">Contacts</span>
            <span className="text-white/80">Automations</span>
            <span className="text-white/80">Analytics</span>
            <span className="text-white/80">More</span>
          </nav>
        </div>
        <div className="flex items-center space-x-4">
          <Badge className="bg-white/20 text-white">CONNECTED</Badge>
          <span className="text-sm">+917037356338</span>
          <Button
            variant="ghost"
            size="sm"
            className="text-white hover:bg-white/20"
          >
            <Settings className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="flex-1 flex bg-white">
        <div
          className={`${
            sidebarExpanded ? 'w-80' : 'w-16'
          } bg-white border-r border-gray-200 flex flex-col transition-all duration-300`}
        >
          {sidebarExpanded ? (
            <>
              <div className="p-4 border-b border-gray-100">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="font-semibold text-gray-900">Active Chats</h2>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setSidebarExpanded(false)}
                    >
                      <ChevronUp className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Filter className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="bg-green-500 text-white hover:bg-green-600 rounded-full"
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                <div className="text-sm text-gray-600 mb-4">
                  2 Chats • 0 Unread
                </div>
              </div>

              <div className="px-4 py-2 border-b border-gray-100">
                <div className="space-y-1">
                  {filterOptions.map((option) => (
                    <button
                      key={option}
                      onClick={() => setSelectedFilter(option)}
                      className={`w-full text-left px-3 py-2 text-sm rounded transition-colors ${
                        selectedFilter === option
                          ? 'bg-gray-100 text-gray-900 font-medium'
                          : 'text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      {option}
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-4">
                <h3 className="text-sm font-medium text-gray-500 mb-3">
                  Today
                </h3>
                <div className="space-y-2">
                  {conversations.map((conversation) => (
                    <div
                      key={conversation.id}
                      className={`p-3 rounded-lg cursor-pointer transition-colors ${
                        conversation.isActive
                          ? 'bg-green-50 border border-green-200'
                          : 'hover:bg-gray-50'
                      }`}
                      onClick={() => setSelectedConversation(conversation)}
                    >
                      <div className="flex items-start space-x-3">
                        <div className="relative">
                          <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center text-white font-semibold">
                            {conversation.avatar}
                          </div>
                          {conversation.isBot && (
                            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                              <span className="text-xs text-white">B</span>
                            </div>
                          )}
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-1">
                            <h4 className="font-medium text-gray-900 truncate">
                              {conversation.name}
                            </h4>
                            <span className="text-xs text-gray-500">
                              {conversation.timestamp}
                            </span>
                          </div>
                          <p className="text-sm text-gray-600 truncate">
                            {conversation.lastMessage}
                          </p>
                          <div className="flex items-center justify-between mt-1">
                            <Badge
                              className={`text-xs ${
                                conversation.status === 'Open'
                                  ? 'bg-green-100 text-green-700'
                                  : 'bg-gray-100 text-gray-600'
                              }`}
                            >
                              {conversation.status}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : (
            /* Collapsed Sidebar */
            <div className="p-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSidebarExpanded(true)}
                className="w-full h-12 mb-2"
              >
                <Menu className="w-5 h-5" />
              </Button>
              <div className="space-y-2">
                {conversations.slice(0, 2).map((conversation) => (
                  <div
                    key={conversation.id}
                    className={`w-12 h-12 rounded-full cursor-pointer ${
                      conversation.isActive ? 'ring-2 ring-green-500' : ''
                    }`}
                    onClick={() => setSelectedConversation(conversation)}
                  >
                    <div className="w-full h-full bg-green-500 rounded-full flex items-center justify-center text-white font-semibold">
                      {conversation.avatar}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="flex-1 flex flex-col">
          <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between bg-white">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center text-white font-semibold">
                  {selectedConversation.avatar}
                </div>
                <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-400 rounded-full border-2 border-white"></div>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">
                  {selectedConversation.name}
                </h3>
                <p className="text-sm text-green-500">
                  {selectedConversation.status}
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="sm">
                <Star className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Phone className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <MoreVertical className="w-4 h-4" />
              </Button>
              <div className="text-right">
                <p className="text-sm font-medium">Submit As</p>
                <p className="text-xs text-gray-500">Test</p>
              </div>
            </div>
          </div>

          <div
            ref={messagesContainerRef}
            className="flex-1 overflow-y-auto p-6 bg-gradient-to-b from-green-50 to-white"
          >
            <div className="space-y-4 max-w-4xl mx-auto">
              <div className="text-center my-6">
                <div className="inline-block bg-gray-100 rounded-lg px-4 py-3 text-sm text-gray-600">
                  <Clock className="w-4 h-4 inline mr-2" />
                  The chat has been expired (after 24 hours of last received
                  message)
                </div>
              </div>

              {selectedConversation.messages.map((message, index) => (
                <div
                  key={message.id}
                  className={`flex ${
                    message.sender === 'user' ? 'justify-end' : 'justify-start'
                  } animate-fadeIn`}
                  style={{
                    animationDelay: isInitialLoad ? `${index * 100}ms` : '0ms',
                  }}
                >
                  <div
                    className={`max-w-sm ${
                      message.sender === 'user'
                        ? 'bg-green-100 rounded-l-2xl rounded-tr-2xl rounded-br-md'
                        : 'bg-white shadow-sm rounded-r-2xl rounded-tl-2xl rounded-bl-md'
                    }`}
                  >
                    <div className="px-4 py-3">
                      <p className="text-sm text-gray-900">{message.text}</p>
                    </div>

                    <div className="flex items-center justify-end px-4 pb-2">
                      <span className="text-xs text-gray-500">
                        {message.timestamp}
                      </span>
                      {message.sender === 'user' && (
                        <CheckCircle2 className="w-3 h-3 text-blue-500 ml-1" />
                      )}
                    </div>
                  </div>
                </div>
              ))}

              <div className="text-center my-6">
                <div className="inline-block bg-gray-100 rounded-lg px-4 py-2 text-xs text-gray-600">
                  The chat has been initialised by contact Tilak Raj Upadhyay
                  (+919928293009)
                </div>
              </div>

              <div className="text-center my-6">
                <div className="inline-block bg-gray-100 rounded-lg px-4 py-2 text-xs text-gray-600">
                  The ticket status has been set as Open by agent Bot
                </div>
              </div>

              <div ref={messagesEndRef} />
            </div>
          </div>

          <div className="p-4 border-t border-gray-200 bg-white">
            <div className="flex items-center space-x-3 max-w-4xl mx-auto">
              <Button variant="ghost" size="sm">
                <Paperclip className="w-5 h-5 text-gray-500" />
              </Button>
              <Button variant="ghost" size="sm">
                <Smile className="w-5 h-5 text-gray-500" />
              </Button>
              <Button variant="ghost" size="sm">
                <Plus className="w-5 h-5 text-gray-500" />
              </Button>
              <Button variant="ghost" size="sm">
                <MessageCircle className="w-5 h-5 text-gray-500" />
              </Button>
              <Button variant="ghost" size="sm">
                <Download className="w-5 h-5 text-gray-500" />
              </Button>
              <div className="flex-1">
                <Input
                  placeholder="Type a message"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  className="border-gray-300 rounded-full"
                />
              </div>
              <Button
                onClick={handleSendMessage}
                disabled={!newMessage.trim()}
                className="bg-green-500 hover:bg-green-600 text-white rounded-lg px-6"
              >
                Send
              </Button>
            </div>
          </div>
        </div>

        <div className="w-80 bg-white border-l border-gray-200 flex flex-col">
          <div className="p-4 border-b border-gray-200">
            <div className="text-center">
              <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center text-white font-bold text-xl mx-auto mb-3">
                {selectedConversation.name
                  .split(' ')
                  .map((n) => n[0])
                  .join('')}
              </div>
              <h3 className="font-semibold text-gray-900">
                {selectedConversation.name}
              </h3>
              <p className="text-sm text-green-500 mb-1">
                {selectedConversation.status}
              </p>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowContactModal(true)}
                className="text-blue-500 border-blue-200 hover:bg-blue-50"
              >
                Select User
              </Button>
            </div>
          </div>

          <div className="p-4 border-b border-gray-200">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium text-gray-900">Basic Information</h4>
              <Button variant="ghost" size="sm" className="text-green-500">
                <Settings className="w-4 h-4" />
              </Button>
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-500">Phone Number</span>
                <span className="text-gray-900">
                  {selectedConversation.phone}
                </span>
              </div>
            </div>
          </div>

          <div className="p-4 border-b border-gray-200">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium text-gray-900">
                Contact custom parameters
              </h4>
              <Button variant="ghost" size="sm" className="text-green-500">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-500">Name</span>
                <span className="text-gray-900">
                  {selectedConversation.name}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">City</span>
                <span className="text-gray-900">Jaipur</span>
              </div>
            </div>
          </div>

          <div className="p-4 border-b border-gray-200">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium text-gray-900">Tags</h4>
              <Button variant="ghost" size="sm" className="text-green-500">
                <ChevronDown className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <div className="flex-1 p-4">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium text-gray-900">Notes</h4>
              <Button variant="ghost" size="sm" className="text-green-500">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-sm text-gray-600 mb-4">
              Notes help you to keep track of your conversation with your team
            </p>
            <textarea
              placeholder="Add your notes here..."
              value={chatNote}
              onChange={(e) => setChatNote(e.target.value)}
              className="w-full p-3 bg-gray-50 border border-gray-200 rounded-lg resize-none h-24 text-sm"
            />
          </div>
        </div>
      </div>

      {showContactModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-2xl w-96 max-h-[70vh] overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 flex items-center">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowContactModal(false)}
                className="mr-3"
              >
                <ArrowLeft className="w-4 h-4" />
              </Button>
              <h2 className="text-lg font-semibold text-gray-900">
                Choose Contact
              </h2>
            </div>

            <div className="p-6">
              <div className="flex items-center space-x-3 mb-4">
                <Globe className="w-5 h-5 text-gray-400" />
                <span className="text-gray-600">+1</span>
              </div>

              <div className="mb-4">
                <span className="text-sm text-gray-500">Or</span>
              </div>

              <div className="space-y-2 max-h-60 overflow-y-auto">
                {contacts.map((contact, index) => (
                  <div
                    key={index}
                    className="p-3 hover:bg-gray-50 rounded-lg cursor-pointer transition-colors"
                    onClick={() => {
                      setSelectedConversation((prev) => ({
                        ...prev,
                        name: contact.name,
                        phone: contact.phone,
                      }));
                      setShowContactModal(false);
                    }}
                  >
                    <div className="font-medium text-gray-900">
                      {contact.name}
                    </div>
                    <div className="text-sm text-gray-500">{contact.phone}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      <style jsx>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .animate-fadeIn {
          animation: fadeIn 0.3s ease-out forwards;
          opacity: 0;
        }

        .scroll-smooth {
          scroll-behavior: smooth;
        }

        .overflow-y-auto::-webkit-scrollbar {
          width: 6px;
        }

        .overflow-y-auto::-webkit-scrollbar-track {
          background: #f3f4f6;
        }

        .overflow-y-auto::-webkit-scrollbar-thumb {
          background: #d1d5db;
          border-radius: 3px;
        }

        .overflow-y-auto::-webkit-scrollbar-thumb:hover {
          background: #9ca3af;
        }
      `}</style>
    </div>
  );
}
