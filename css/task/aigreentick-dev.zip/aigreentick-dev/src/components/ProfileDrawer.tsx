import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { secureStorage } from '@/services/secure-storage'; // Import the secure storage
import {
  User,
  Mail,
  Phone,
  Building,
  MapPin,
  Globe,
  CreditCard,
  DollarSign,
  Shield,
  Calendar,
  Camera,
  Settings,
  Key,
  Download,
  Upload,
  Activity,
  Clock,
  CheckCircle,
  AlertCircle,
  Copy,
  Eye,
  EyeOff,
  LogOut,
  Wallet,
  ChevronRight,
  Check,
} from 'lucide-react';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { logout } from '@/redux/authSlice';

interface User {
  id: number;
  role_id: number;
  created_by: number | null;
  country_id: number;
  name: string;
  mobile: string;
  profile_photo: string | null;
  rememberToken: string | null;
  api_token: string;
  email: string;
  company_name: string | null;
  city: string | null;
  market_msg_charge: number | null;
  utilty_msg_charge: number;
  auth_msg_charge: number;
  balance: number;
  balance_enabled: number;
  online_status: string;
  agent_id: number | null;
  credit: number;
  debit: number;
  status: string;
  domain: string | null;
  logo: string | null;
  is_demo: string;
  demo_end: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  webhook_token: string | null;
  permission: any[];
}

interface ProfileDrawerProps {
  userImage?: string;
  userInitials: string;
  mounted: boolean;
  children?: React.ReactNode;
}

export const ProfileDrawer: React.FC<ProfileDrawerProps> = ({
  userImage,
  userInitials,
  mounted,
  children,
}) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [user, setUser] = useState<User | null>(null);
  const [showApiToken, setShowApiToken] = useState(false);
  const [showWebhookToken, setShowWebhookToken] = useState(false);
  const [open, setOpen] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  // Simple validation function
  const isValidAuth = () => {
    const token = secureStorage.getItem('auth_token');
    const user = secureStorage.getItem('ai_green_tick_user');
    const authFlag = localStorage.getItem('isAuthenticated') === 'true';
    return !!(token && user && user.id && authFlag);
  };

  useEffect(() => {
    try {
      // Validate authentication first
      if (!isValidAuth()) {
        console.warn('Invalid authentication state detected');
        // Clear invalid data
        secureStorage.removeItem('auth_token');
        secureStorage.removeItem('ai_green_tick_user');
        localStorage.removeItem('isAuthenticated');
        navigate('/login', { replace: true });
        return;
      }

      // Get user data from secure storage
      const userData = secureStorage.getItem('ai_green_tick_user');
      if (userData) {
        setUser(userData);
      } else {
        console.warn('No user data found despite valid auth');
        navigate('/login', { replace: true });
      }
    } catch (error) {
      console.error('Error loading user data:', error);
      navigate('/login', { replace: true });
    }
  }, [navigate]);

  const handleSignOut = () => {
    try {
      setOpen(false);
      
      // Clear secure storage
      secureStorage.removeItem('ai_green_tick_user');
      secureStorage.removeItem('auth_token');
      localStorage.removeItem('isAuthenticated');
      
      dispatch(logout());
      console.log('Successfully signed out');
      navigate('/login', { replace: true });
    } catch (error) {
      console.error('Error during sign out:', error);
      navigate('/login', { replace: true });
    }
  };

  const copyToClipboard = async (text: string, field: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedField(field);
      setTimeout(() => setCopiedField(null), 2000);
      console.log('Copied to clipboard');
    } catch (err) {
      console.error('Failed to copy: ', err);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case '1':
        return (
          <Badge
            variant="default"
            className="bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-50 font-medium"
          >
            <CheckCircle className="w-3 h-3 mr-1.5" />
            Active
          </Badge>
        );
      case '0':
        return (
          <Badge 
            variant="destructive" 
            className="bg-red-50 text-red-700 border-red-200 font-medium"
          >
            <AlertCircle className="w-3 h-3 mr-1.5" />
            Inactive
          </Badge>
        );
      default:
        return <Badge variant="secondary" className="font-medium">{status}</Badge>;
    }
  };

  const getOnlineStatusBadge = (status: string) => {
    return status === '1' ? (
      <Badge
        variant="default"
        className="bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-50 font-medium"
      >
        <div className="w-2 h-2 bg-emerald-500 rounded-full mr-1.5 animate-pulse"></div>
        Online
      </Badge>
    ) : (
      <Badge variant="secondary" className="font-medium">
        <div className="w-2 h-2 bg-slate-400 rounded-full mr-1.5"></div>
        Offline
      </Badge>
    );
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  if (!user) {
    // Validate authentication
    if (!isValidAuth()) {
      // Clear invalid data and redirect
      secureStorage.removeItem('auth_token');
      secureStorage.removeItem('ai_green_tick_user');
      localStorage.removeItem('isAuthenticated');
      navigate('/login', { replace: true });
      return null;
    }

    return (
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild>
          <button
            className={`relative h-10 w-10 rounded-full transition-all duration-300 ease-out hover:scale-110 hover:shadow-xl group transform hover:-translate-y-0.5 ${
              mounted ? 'opacity-100 scale-100' : 'opacity-0 scale-75'
            }`}
            type="button"
            style={{ transitionDelay: mounted ? '500ms' : '0ms' }}
          >
            <Avatar className="cursor-pointer h-10 w-10 rounded-full transition-all duration-300 ease-out group-hover:ring-2 group-hover:ring-primary group-hover:ring-offset-2 overflow-hidden">
              {userImage ? (
                <img
                  src={userImage}
                  alt="Profile"
                  className="w-full h-full object-cover transition-transform duration-300 ease-out group-hover:scale-110"
                />
              ) : (
                <AvatarFallback className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground transition-all duration-300 ease-out group-hover:from-primary/80 group-hover:to-primary w-full h-full">
                  {userInitials}
                </AvatarFallback>
              )}
            </Avatar>
            <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-400 border-2 border-white rounded-full shadow-sm">
              <div className="absolute inset-0 bg-emerald-400 rounded-full animate-ping opacity-75"></div>
            </div>
          </button>
        </SheetTrigger>
        <SheetContent
          side="right"
          className="w-[500px] sm:w-[650px] overflow-y-auto z-[100]"
        >
          <div className="flex items-center justify-center h-full">
            <div className="text-center space-y-4">
              <User className="w-16 h-16 text-slate-400 mx-auto" />
              <div className="space-y-2">
                <h3 className="text-lg font-semibold text-slate-900">Loading Profile</h3>
                <p className="text-sm text-slate-500 max-w-sm">
                  Please wait while we load your profile information...
                </p>
              </div>
            </div>
          </div>
        </SheetContent>
      </Sheet>
    );
  }

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <button
          className={`relative h-10 w-10 rounded-full transition-all duration-300 ease-out hover:scale-110 hover:shadow-xl group transform hover:-translate-y-0.5 ${
            mounted ? 'opacity-100 scale-100' : 'opacity-0 scale-75'
          }`}
          type="button"
          style={{ transitionDelay: mounted ? '500ms' : '0ms' }}
        >
          <Avatar className="cursor-pointer h-10 w-10 rounded-full transition-all duration-300 ease-out group-hover:ring-2 group-hover:ring-primary group-hover:ring-offset-2 overflow-hidden">
            {userImage ? (
              <img
                src={userImage}
                alt="Profile"
                className="w-full h-full object-cover transition-transform duration-300 ease-out group-hover:scale-110"
              />
            ) : (
              <AvatarFallback className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground transition-all duration-300 ease-out group-hover:from-primary/80 group-hover:to-primary w-full h-full">
                {userInitials}
              </AvatarFallback>
            )}
          </Avatar>
          <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-400 border-2 border-white rounded-full shadow-sm">
            <div className="absolute inset-0 bg-emerald-400 rounded-full animate-ping opacity-75"></div>
          </div>
        </button>
      </SheetTrigger>

      <SheetContent
        side="right"
        className="w-[500px] sm:w-[650px] overflow-y-auto z-[100]"
      >
        {/* Profile Header */}
        <SheetHeader className="space-y-6 pb-6">
          <div className="flex flex-col items-between gap-10 justify-between">
            <div className="flex items-start space-x-4">
              <div className="relative">
                <Avatar className="w-20 h-20 ring-4 ring-slate-100">
                  {user.profile_photo ? (
                    <img
                      src={user.profile_photo}
                      alt="Profile"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <AvatarFallback className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground text-2xl font-semibold">
                      {user.name
                        .split(' ')
                        .map((n) => n[0])
                        .join('')}
                    </AvatarFallback>
                  )}
                </Avatar>
                <button className="absolute -bottom-1 -right-1 w-8 h-8 bg-white border-2 border-slate-200 rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-shadow hover:bg-slate-50">
                  <Camera className="w-4 h-4 text-slate-600" />
                </button>
              </div>
              <div className="flex-1 min-w-0 space-y-3">
                <div className="space-y-1">
                  <SheetTitle className="text-2xl font-bold text-slate-900 leading-tight">
                    {user.name}
                  </SheetTitle>
                  <SheetDescription className="text-base font-medium text-slate-600">
                    {user.email}
                  </SheetDescription>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  {getStatusBadge(user.status)}
                  {getOnlineStatusBadge(user.online_status)}
                  {user.is_demo === 'on' && (
                    <Badge
                      variant="outline"
                      className="text-amber-700 border-amber-300 bg-amber-50 font-medium"
                    >
                      Demo Account
                    </Badge>
                  )}
                </div>
              </div>
            </div>
            <button
              onClick={handleSignOut}
              className="group flex items-center justify-center w-full px-4 py-3 text-sm font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 hover:text-red-600 hover:border-red-200 focus:outline-none focus:ring-2 focus:ring-slate-500  cursor-pointer focus:ring-offset-1 transition-all duration-200"
            >
              <LogOut className="w-4 h-4 mr-2 transition-colors duration-200 group-hover:text-red-500" />
              Sign Out
            </button>
          </div>
        </SheetHeader>

        <Separator className="my-6" />

        {/* Profile Content */}
        <div className="space-y-6">
          <Accordion
            type="multiple"
            defaultValue={['personal', 'billing']}
            className="w-full"
          >
            {/* Personal Information */}
            <AccordionItem value="personal" className="border-slate-200">
              <AccordionTrigger className="hover:no-underline py-4 px-1">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center">
                    <User className="w-5 h-5 text-blue-600" />
                  </div>
                  <div className="text-left">
                    <h3 className="text-base font-semibold text-slate-900">
                      Personal Information
                    </h3>
                    <p className="text-sm text-slate-500">
                      Contact details and basic info
                    </p>
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent className="px-1 pb-6">
                <div className="grid gap-6">
                  <div className="grid grid-cols-1 gap-4">
                    <div className="flex items-center space-x-3 p-4 bg-slate-50 rounded-lg">
                      <Mail className="w-5 h-5 text-slate-500" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-slate-600">
                          Email
                        </p>
                        <p className="text-base font-semibold text-slate-900 truncate">
                          {user.email}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3 p-4 bg-slate-50 rounded-lg">
                      <Phone className="w-5 h-5 text-slate-500" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-slate-600">
                          Mobile
                        </p>
                        <p className="text-base font-semibold text-slate-900">
                          {user.mobile}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3 p-4 bg-slate-50 rounded-lg">
                      <MapPin className="w-5 h-5 text-slate-500" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-slate-600">
                          City
                        </p>
                        <p className="text-base font-semibold text-slate-900">
                          {user.city || 'Not specified'}
                        </p>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-3">
                    <h4 className="text-sm font-semibold text-slate-900 flex items-center">
                      <Building className="w-4 h-4 mr-2 text-slate-500" />
                      Company Details
                    </h4>
                    <div className="grid grid-cols-1 gap-3">
                      <div className="flex justify-between items-center py-2">
                        <span className="text-sm font-medium text-slate-600">
                          Company Name
                        </span>
                        <span className="text-sm font-semibold text-slate-900">
                          {user.company_name || 'Not specified'}
                        </span>
                      </div>
                      <div className="flex justify-between items-center py-2">
                        <span className="text-sm font-medium text-slate-600">
                          Domain
                        </span>
                        <span className="text-sm font-semibold text-slate-900">
                          {user.domain || 'Not specified'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            {/* Billing Information */}
            <AccordionItem value="billing" className="border-slate-200">
              <AccordionTrigger className="hover:no-underline py-4 px-1">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-lg bg-emerald-50 flex items-center justify-center">
                    <Wallet className="w-5 h-5 text-emerald-600" />
                  </div>
                  <div className="text-left">
                    <h3 className="text-base font-semibold text-slate-900">
                      Billing & Balance
                    </h3>
                    <p className="text-sm text-slate-500">
                      Account balance and pricing
                    </p>
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent className="px-1 pb-6">
                <div className="space-y-6">
                  {/* Balance Overview */}
                  <div className="p-6 bg-gradient-to-r from-emerald-50 to-blue-50 rounded-xl border border-emerald-100">
                    <div className="text-center space-y-2">
                      <p className="text-sm font-semibold text-slate-700">
                        Current Balance
                      </p>
                      <p className="text-3xl font-bold text-emerald-600">
                        {formatCurrency(user.balance)}
                      </p>
                      <p className="text-xs text-slate-500">
                        Balance {user.balance_enabled ? 'Enabled' : 'Disabled'}
                      </p>
                    </div>
                  </div>

                  {/* Credit & Debit */}
                  <div className="grid grid-cols-2 gap-4">
                    <Card className="border-emerald-200">
                      <CardContent className="p-4 text-center">
                        <Upload className="w-6 h-6 text-emerald-500 mx-auto mb-2" />
                        <p className="text-sm font-medium text-slate-600 mb-1">
                          Total Credit
                        </p>
                        <p className="text-xl font-bold text-emerald-600">
                          {formatCurrency(user.credit)}
                        </p>
                      </CardContent>
                    </Card>

                    <Card className="border-red-200">
                      <CardContent className="p-4 text-center">
                        <Download className="w-6 h-6 text-red-500 mx-auto mb-2" />
                        <p className="text-sm font-medium text-slate-600 mb-1">
                          Total Debit
                        </p>
                        <p className="text-xl font-bold text-red-600">
                          {formatCurrency(user.debit)}
                        </p>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Message Charges */}
                  <div className="space-y-3">
                    <h4 className="text-sm font-semibold text-slate-900 flex items-center">
                      <CreditCard className="w-4 h-4 mr-2 text-slate-500" />
                      Message Pricing
                    </h4>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                        <span className="text-sm font-medium text-slate-700">
                          Marketing Messages
                        </span>
                        <span className="text-sm font-bold text-slate-900">
                          {user.market_msg_charge
                            ? formatCurrency(user.market_msg_charge)
                            : 'N/A'}
                        </span>
                      </div>
                      <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                        <span className="text-sm font-medium text-slate-700">
                          Utility Messages
                        </span>
                        <span className="text-sm font-bold text-slate-900">
                          {formatCurrency(user.utilty_msg_charge)}
                        </span>
                      </div>
                      <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                        <span className="text-sm font-medium text-slate-700">
                          Auth Messages
                        </span>
                        <span className="text-sm font-bold text-slate-900">
                          {formatCurrency(user.auth_msg_charge)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            {/* API Settings */}
            <AccordionItem value="api" className="border-slate-200">
              <AccordionTrigger className="hover:no-underline py-4 px-1">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-lg bg-purple-50 flex items-center justify-center">
                    <Key className="w-5 h-5 text-purple-600" />
                  </div>
                  <div className="text-left">
                    <h3 className="text-base font-semibold text-slate-900">
                      API Configuration
                    </h3>
                    <p className="text-sm text-slate-500">
                      Authentication tokens and keys
                    </p>
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent className="px-1 pb-6">
                <div className="space-y-4">
                  <div className="space-y-3">
                    <h4 className="text-sm font-semibold text-slate-900">
                      API Token
                    </h4>
                    <div className="flex items-center space-x-2">
                      <Input
                        type={showApiToken ? 'text' : 'password'}
                        value={user.api_token}
                        readOnly
                        className="font-mono text-sm flex-1 bg-slate-50"
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setShowApiToken(!showApiToken)}
                        className="px-3"
                      >
                        {showApiToken ? (
                          <EyeOff className="w-4 h-4" />
                        ) : (
                          <Eye className="w-4 h-4" />
                        )}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() =>
                          copyToClipboard(user.api_token, 'api_token')
                        }
                        className={`px-3 transition-colors ${
                          copiedField === 'api_token'
                            ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
                            : 'hover:bg-slate-50'
                        }`}
                      >
                        {copiedField === 'api_token' ? (
                          <Check className="w-4 h-4" />
                        ) : (
                          <Copy className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                    <p className="text-xs text-slate-500">
                      Use this token to authenticate API requests. Keep it
                      secure and never share it publicly.
                    </p>
                  </div>

                  <div className="space-y-3">
                    <h4 className="text-sm font-semibold text-slate-900">
                      Webhook Token
                    </h4>
                    <div className="flex items-center space-x-2">
                      <Input
                        type={showWebhookToken ? 'text' : 'password'}
                        value={user.webhook_token || 'Not configured'}
                        readOnly
                        className="font-mono text-sm flex-1 bg-slate-50"
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setShowWebhookToken(!showWebhookToken)}
                        className="px-3"
                        disabled={!user.webhook_token}
                      >
                        {showWebhookToken ? (
                          <EyeOff className="w-4 h-4" />
                        ) : (
                          <Eye className="w-4 h-4" />
                        )}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() =>
                          copyToClipboard(
                            user.webhook_token || '',
                            'webhook_token'
                          )
                        }
                        className={`px-3 transition-colors ${
                          copiedField === 'webhook_token'
                            ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
                            : 'hover:bg-slate-50'
                        }`}
                        disabled={!user.webhook_token}
                      >
                        {copiedField === 'webhook_token' ? (
                          <Check className="w-4 h-4" />
                        ) : (
                          <Copy className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                    <p className="text-xs text-slate-500">
                      {user.webhook_token
                        ? 'Token for webhook verification and security.'
                        : 'No webhook token configured. Contact support to set up webhooks.'}
                    </p>
                  </div>

                  <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <Key className="w-3 h-3 text-blue-600" />
                      </div>
                      <div className="space-y-1">
                        <h5 className="text-sm font-semibold text-blue-900">
                          Security Notice
                        </h5>
                        <p className="text-xs text-blue-700 leading-relaxed">
                          Keep your API tokens secure. If you suspect they've
                          been compromised, contact support immediately to
                          regenerate them.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            {/* Account Details */}
            <AccordionItem value="account" className="border-slate-200">
              <AccordionTrigger className="hover:no-underline py-4 px-1">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center">
                    <Shield className="w-5 h-5 text-slate-600" />
                  </div>
                  <div className="text-left">
                    <h3 className="text-base font-semibold text-slate-900">
                      Account Details
                    </h3>
                    <p className="text-sm text-slate-500">
                      System information and dates
                    </p>
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent className="px-1 pb-6">
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-slate-600">
                        Role ID
                      </p>
                      <p className="text-sm font-bold text-slate-900">
                        {user.role_id}
                      </p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-slate-600">
                        Country ID
                      </p>
                      <p className="text-sm font-bold text-slate-900">
                        {user.country_id}
                      </p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-slate-600">
                        Agent ID
                      </p>
                      <p className="text-sm font-bold text-slate-900">
                        {user.agent_id || 'Not assigned'}
                      </p>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-3">
                    <div className="flex items-center space-x-3 p-3 bg-slate-50 rounded-lg">
                      <Calendar className="w-5 h-5 text-slate-500" />
                      <div>
                        <p className="text-sm font-medium text-slate-600">
                          Account Created
                        </p>
                        <p className="text-sm font-semibold text-slate-900">
                          {formatDate(user.created_at)}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3 p-3 bg-slate-50 rounded-lg">
                      <Clock className="w-5 h-5 text-slate-500" />
                      <div>
                        <p className="text-sm font-medium text-slate-600">
                          Last Updated
                        </p>
                        <p className="text-sm font-semibold text-slate-900">
                          {formatDate(user.updated_at)}
                        </p>
                      </div>
                    </div>
                  </div>

                  {user.is_demo === 'on' && (
                    <>
                      <Separator />
                      <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                        <div className="flex items-center space-x-2 mb-2">
                          <AlertCircle className="w-5 h-5 text-amber-600" />
                          <h4 className="text-sm font-semibold text-amber-800">
                            Demo Account
                          </h4>
                        </div>
                        <p className="text-sm text-amber-700 mb-2">
                          This is a demo account with limited functionality.
                        </p>
                        <p className="text-xs text-amber-600">
                          Demo expires on: {formatDate(user.demo_end)}
                        </p>
                      </div>
                    </>
                  )}
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </SheetContent>
    </Sheet>
  );
}