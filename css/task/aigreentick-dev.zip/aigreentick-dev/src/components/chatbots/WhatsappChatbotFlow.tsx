import React, { useState, useCallback, useMemo } from 'react';
import ReactFlow, {
  Node,
  Edge,
  addEdge,
  Connection,
  useNodesState,
  useEdgesState,
  Controls,
  MiniMap,
  Background,
  BackgroundVariant,
  Panel,
  NodeChange,
  EdgeChange,
} from 'reactflow';
import 'reactflow/dist/style.css';

import {
  MessageSquare,
  User,
  Bot,
  Plus,
  Settings,
  Play,
  Save,
  Download,
  Upload,
  Trash2,
  Copy,
  Eye,
  Zap,
  Database,
  BarChart3,
} from 'lucide-react';
import NodePropertiesPanel from './NodePropertiesPanel';
const MessageNode = ({ data, selected }) => {
  const getMessageTypeIcon = () => {
    switch (data.messageType) {
      case 'image':
        return <Image className="w-3 h-3" />;
      case 'document':
        return <FileText className="w-3 h-3" />;
      case 'template':
        return <Zap className="w-3 h-3" />;
      default:
        return <MessageSquare className="w-3 h-3" />;
    }
  };

  return (
    <div
      className={`bg-white rounded-lg shadow-lg border-2 min-w-[200px] max-w-[250px] ${
        selected ? 'border-green-500 shadow-green-200' : 'border-gray-200'
      } transition-all duration-200`}
    >
      <div className="bg-gradient-to-r from-green-500 to-green-600 text-white p-3 rounded-t-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {getMessageTypeIcon()}
            <span className="text-sm font-medium">Message</span>
          </div>
          {data.delay > 0 && (
            <div className="bg-white/20 px-2 py-1 rounded text-xs">
              {data.delay}s
            </div>
          )}
        </div>
      </div>
      <div className="p-3">
        <div className="text-xs text-gray-500 mb-2 uppercase tracking-wide">
          {data.messageType || 'text'} message
        </div>
        <div className="bg-green-50 p-2 rounded text-sm text-gray-800 border-l-3 border-green-400">
          {data.message || 'Enter your message here...'}
        </div>
        {data.enableButtons && data.buttons && data.buttons.length > 0 && (
          <div className="mt-2 text-xs text-blue-600">
            {data.buttons.length} button{data.buttons.length !== 1 ? 's' : ''}
          </div>
        )}
      </div>
    </div>
  );
};

const UserInputNode = ({ data, selected }) => {
  const getInputIcon = () => {
    switch (data.inputType) {
      case 'email':
        return <Mail className="w-3 h-3" />;
      case 'phone':
        return <Phone className="w-3 h-3" />;
      case 'number':
        return <Hash className="w-3 h-3" />;
      case 'date':
        return <Calendar className="w-3 h-3" />;
      case 'file':
        return <FileText className="w-3 h-3" />;
      default:
        return <User className="w-3 h-3" />;
    }
  };

  return (
    <div
      className={`bg-white rounded-lg shadow-lg border-2 min-w-[200px] max-w-[250px] ${
        selected ? 'border-blue-500 shadow-blue-200' : 'border-gray-200'
      } transition-all duration-200`}
    >
      <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-3 rounded-t-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {getInputIcon()}
            <span className="text-sm font-medium">User Input</span>
          </div>
          {data.timeout && (
            <div className="bg-white/20 px-2 py-1 rounded text-xs">
              {data.timeout}s
            </div>
          )}
        </div>
      </div>
      <div className="p-3">
        <div className="text-xs text-gray-500 mb-2 uppercase tracking-wide">
          Waiting for {data.inputType || 'text'}
        </div>
        <div className="bg-blue-50 p-2 rounded text-sm text-gray-800 border-l-3 border-blue-400">
          {data.inputType || 'Text input'}
        </div>
        {data.variableName && (
          <div className="mt-2 text-xs text-purple-600">
            Store as: {data.variableName}
          </div>
        )}
      </div>
    </div>
  );
};

const ConditionNode = ({ data, selected }) => {
  return (
    <div
      className={`bg-white rounded-lg shadow-lg border-2 min-w-[200px] max-w-[250px] ${
        selected ? 'border-yellow-500 shadow-yellow-200' : 'border-gray-200'
      } transition-all duration-200`}
    >
      <div className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-white p-3 rounded-t-lg">
        <div className="flex items-center space-x-2">
          <Settings className="w-3 h-3" />
          <span className="text-sm font-medium">Condition</span>
        </div>
      </div>
      <div className="p-3">
        <div className="text-xs text-gray-500 mb-2 uppercase tracking-wide">
          {data.conditionType || 'contains'} check
        </div>
        <div className="bg-yellow-50 p-2 rounded text-sm text-gray-800 border-l-3 border-yellow-400">
          {data.checkVariable || 'last_message'}{' '}
          {data.conditionType || 'contains'} "{data.conditionValue || 'value'}"
        </div>
      </div>
    </div>
  );
};

const ActionNode = ({ data, selected }) => {
  const getActionIcon = () => {
    switch (data.actionType) {
      case 'assign_agent':
        return <User className="w-3 h-3" />;
      case 'create_ticket':
        return <FileText className="w-3 h-3" />;
      case 'save_lead':
        return <Database className="w-3 h-3" />;
      case 'send_email':
        return <Mail className="w-3 h-3" />;
      case 'webhook':
        return <Zap className="w-3 h-3" />;
      case 'set_variable':
        return <Settings className="w-3 h-3" />;
      case 'tag_contact':
        return <Hash className="w-3 h-3" />;
      default:
        return <Bot className="w-3 h-3" />;
    }
  };

  return (
    <div
      className={`bg-white rounded-lg shadow-lg border-2 min-w-[200px] max-w-[250px] ${
        selected ? 'border-purple-500 shadow-purple-200' : 'border-gray-200'
      } transition-all duration-200`}
    >
      <div className="bg-gradient-to-r from-purple-500 to-purple-600 text-white p-3 rounded-t-lg">
        <div className="flex items-center space-x-2">
          {getActionIcon()}
          <span className="text-sm font-medium">Action</span>
        </div>
      </div>
      <div className="p-3">
        <div className="text-xs text-gray-500 mb-2 uppercase tracking-wide">
          {data.actionType || 'assign_agent'}
        </div>
        <div className="bg-purple-50 p-2 rounded text-sm text-gray-800 border-l-3 border-purple-400">
          {data.actionType === 'assign_agent' &&
            `Assign to ${data.agentId || 'agent'}`}
          {data.actionType === 'webhook' &&
            `Call ${data.webhookUrl || 'webhook'}`}
          {data.actionType === 'set_variable' &&
            `Set ${data.variableName || 'variable'}`}
          {data.actionType === 'tag_contact' && `Tag: ${data.tags || 'tags'}`}
          {!data.actionType && 'Configure action...'}
        </div>
      </div>
    </div>
  );
};

const CompleteWhatsAppCRM = () => {
  const initialNodes: Node[] = [
    {
      id: '1',
      type: 'message',
      position: { x: 250, y: 50 },
      data: {
        message:
          '👋 Welcome to our WhatsApp support! How can I help you today?',
        messageType: 'text',
        delay: 0,
        enableButtons: true,
        buttons: [
          { text: '💬 General Support', type: 'reply' },
          { text: '💰 Billing', type: 'reply' },
          { text: '🛠️ Technical Help', type: 'reply' },
        ],
      },
    },
    {
      id: '2',
      type: 'userInput',
      position: { x: 250, y: 200 },
      data: {
        inputType: 'text',
        timeout: 60,
        variableName: 'user_choice',
        validationMessage: 'Please select an option or type your message',
      },
    },
    {
      id: '3',
      type: 'condition',
      position: { x: 250, y: 350 },
      data: {
        conditionType: 'contains',
        conditionValue: 'billing',
        checkVariable: 'user_choice',
      },
    },
    {
      id: '4',
      type: 'action',
      position: { x: 50, y: 500 },
      data: {
        actionType: 'assign_agent',
        agentId: 'billing',
      },
    },
    {
      id: '5',
      type: 'message',
      position: { x: 50, y: 650 },
      data: {
        message:
          "💰 I'm connecting you with our billing team. Please wait a moment...",
        delay: 1,
      },
    },
    {
      id: '6',
      type: 'condition',
      position: { x: 450, y: 500 },
      data: {
        conditionType: 'contains',
        conditionValue: 'technical',
        checkVariable: 'user_choice',
      },
    },
    {
      id: '7',
      type: 'message',
      position: { x: 450, y: 650 },
      data: {
        message: '🛠️ Let me collect some information to help you better.',
        delay: 1,
      },
    },
    {
      id: '8',
      type: 'userInput',
      position: { x: 450, y: 800 },
      data: {
        inputType: 'text',
        timeout: 120,
        variableName: 'technical_issue',
        validationMessage: 'Please describe your technical issue',
      },
    },
  ];

  const initialEdges: Edge[] = [
    {
      id: 'e1-2',
      source: '1',
      target: '2',
      animated: true,
      style: { stroke: '#10b981' },
    },
    {
      id: 'e2-3',
      source: '2',
      target: '3',
      animated: true,
      style: { stroke: '#3b82f6' },
    },
    {
      id: 'e3-4',
      source: '3',
      target: '4',
      label: 'Billing',
      animated: true,
      style: { stroke: '#eab308' },
    },
    {
      id: 'e4-5',
      source: '4',
      target: '5',
      animated: true,
      style: { stroke: '#a855f7' },
    },
    {
      id: 'e3-6',
      source: '3',
      target: '6',
      label: 'Other',
      animated: true,
      style: { stroke: '#eab308' },
    },
    {
      id: 'e6-7',
      source: '6',
      target: '7',
      label: 'Technical',
      animated: true,
      style: { stroke: '#eab308' },
    },
    {
      id: 'e7-8',
      source: '7',
      target: '8',
      animated: true,
      style: { stroke: '#10b981' },
    },
  ];

  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);
  const [selectedNodeType, setSelectedNodeType] = useState('message');
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  const [showProperties, setShowProperties] = useState(false);
  const [flowStats, setFlowStats] = useState({
    totalNodes: initialNodes.length,
    messageNodes: 0,
    inputNodes: 0,
    conditionNodes: 0,
    actionNodes: 0,
  });
  const nodeTypes = useMemo(
    () => ({
      message: MessageNode,
      userInput: UserInputNode,
      condition: ConditionNode,
      action: ActionNode,
    }),
    []
  );
  React.useEffect(() => {
    const stats = {
      totalNodes: nodes.length,
      messageNodes: nodes.filter((n) => n.type === 'message').length,
      inputNodes: nodes.filter((n) => n.type === 'userInput').length,
      conditionNodes: nodes.filter((n) => n.type === 'condition').length,
      actionNodes: nodes.filter((n) => n.type === 'action').length,
    };
    setFlowStats(stats);
  }, [nodes]);
  const onConnect = useCallback(
    (params: Connection) =>
      setEdges((eds) =>
        addEdge(
          {
            ...params,
            animated: true,
            style: { stroke: '#6b7280' },
          },
          eds
        )
      ),
    [setEdges]
  );
  const onNodeClick = useCallback((event: React.MouseEvent, node: Node) => {
    setSelectedNode(node);
    setShowProperties(true);
  }, []);
  const addNode = useCallback(() => {
    const newNode: Node = {
      id: `${Date.now()}`,
      type: selectedNodeType,
      position: {
        x: Math.random() * 400 + 100,
        y: Math.random() * 400 + 100,
      },
      data: getDefaultNodeData(selectedNodeType),
    };
    setNodes((nds) => [...nds, newNode]);
  }, [selectedNodeType, setNodes]);
  const updateNode = useCallback(
    (nodeId: string, newData: any) => {
      setNodes((nds) =>
        nds.map((node) =>
          node.id === nodeId
            ? { ...node, data: { ...node.data, ...newData } }
            : node
        )
      );
    },
    [setNodes]
  );
  const deleteSelectedNodes = useCallback(() => {
    setNodes((nds) => nds.filter((node) => !node.selected));
    setEdges((eds) =>
      eds.filter(
        (edge) =>
          !nodes.some(
            (node) =>
              node.selected &&
              (node.id === edge.source || node.id === edge.target)
          )
      )
    );
  }, [setNodes, setEdges, nodes]);
  const getDefaultNodeData = (nodeType: string) => {
    switch (nodeType) {
      case 'message':
        return {
          message: 'New message...',
          messageType: 'text',
          delay: 0,
          enableButtons: false,
          buttons: [],
        };
      case 'userInput':
        return {
          inputType: 'text',
          timeout: 30,
          variableName: '',
          validationMessage: '',
        };
      case 'condition':
        return {
          conditionType: 'contains',
          conditionValue: '',
          checkVariable: 'last_message',
        };
      case 'action':
        return {
          actionType: 'assign_agent',
          agentId: '',
        };
      default:
        return {};
    }
  };
  const saveFlow = () => {
    const flowData = {
      nodes,
      edges,
      timestamp: new Date().toISOString(),
      stats: flowStats,
    };
    localStorage.setItem('whatsapp-flow', JSON.stringify(flowData));
    alert('Flow saved successfully!');
  };
  const loadFlow = () => {
    const savedFlow = localStorage.getItem('whatsapp-flow');
    if (savedFlow) {
      const flowData = JSON.parse(savedFlow);
      setNodes(flowData.nodes || []);
      setEdges(flowData.edges || []);
      alert('Flow loaded successfully!');
    } else {
      alert('No saved flow found!');
    }
  };
  const exportFlow = () => {
    const flowData = {
      nodes,
      edges,
      timestamp: new Date().toISOString(),
      stats: flowStats,
    };
    const dataStr = JSON.stringify(flowData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `whatsapp-flow-${
      new Date().toISOString().split('T')[0]
    }.json`;
    link.click();
  };
  const testFlow = () => {
    console.log('Testing flow with nodes:', nodes);
    console.log('Flow stats:', flowStats);
    alert('Flow test started! Check console for details.');
  };

  return (
    <div className="w-full h-screen bg-gray-50 relative">
      <div className="bg-white border-b border-gray-200 p-4 z-10 relative">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-green-600 rounded-lg flex items-center justify-center">
              <MessageSquare className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-gray-900">
                WhatsApp CRM Flow Builder
              </h1>
              <p className="text-sm text-gray-600">
                Design automated conversation flows for your WhatsApp CRM
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-4 text-sm">
            <div className="flex items-center space-x-1">
              <BarChart3 className="w-4 h-4 text-gray-500" />
              <span className="text-gray-600">
                {flowStats.totalNodes} nodes
              </span>
            </div>
            <div className="flex items-center space-x-1">
              <MessageSquare className="w-4 h-4 text-green-500" />
              <span className="text-gray-600">{flowStats.messageNodes}</span>
            </div>
            <div className="flex items-center space-x-1">
              <User className="w-4 h-4 text-blue-500" />
              <span className="text-gray-600">{flowStats.inputNodes}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Settings className="w-4 h-4 text-yellow-500" />
              <span className="text-gray-600">{flowStats.conditionNodes}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Bot className="w-4 h-4 text-purple-500" />
              <span className="text-gray-600">{flowStats.actionNodes}</span>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={loadFlow}
              className="flex items-center space-x-2 px-3 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"
            >
              <Upload className="w-4 h-4" />
              <span>Load</span>
            </button>
            <button
              onClick={testFlow}
              className="flex items-center space-x-2 px-3 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
            >
              <Play className="w-4 h-4" />
              <span>Test</span>
            </button>
            <button
              onClick={saveFlow}
              className="flex items-center space-x-2 px-3 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
            >
              <Save className="w-4 h-4" />
              <span>Save</span>
            </button>
            <button
              onClick={exportFlow}
              className="flex items-center space-x-2 px-3 py-2 bg-indigo-500 text-white rounded-lg hover:bg-indigo-600 transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Export</span>
            </button>
          </div>
        </div>
      </div>

      <div className="relative w-full h-full">
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          onNodeClick={onNodeClick}
          nodeTypes={nodeTypes}
          fitView
          className="bg-gray-50"
          defaultViewport={{ x: 0, y: 0, zoom: 1 }}
          minZoom={0.2}
          maxZoom={2}
          attributionPosition="bottom-left"
        >
          <Controls
            className="bg-white border border-gray-200 rounded-lg shadow-lg"
            showInteractive={false}
          />

          <MiniMap
            className="bg-white border border-gray-200 rounded-lg shadow-lg"
            nodeColor={(node) => {
              switch (node.type) {
                case 'message':
                  return '#10b981';
                case 'userInput':
                  return '#3b82f6';
                case 'condition':
                  return '#eab308';
                case 'action':
                  return '#a855f7';
                default:
                  return '#6b7280';
              }
            }}
            maskColor="rgba(0, 0, 0, 0.1)"
            pannable
            zoomable
          />

          <Background
            variant={BackgroundVariant.Dots}
            gap={20}
            size={1}
            color="#e5e7eb"
          />

          <Panel
            position="top-left"
            className="bg-white border border-gray-200 rounded-lg p-4 m-4 shadow-lg"
          >
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-semibold text-gray-900 mb-3 flex items-center">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Node
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <input
                      type="radio"
                      id="message"
                      name="nodeType"
                      value="message"
                      checked={selectedNodeType === 'message'}
                      onChange={(e) => setSelectedNodeType(e.target.value)}
                      className="text-green-500 focus:ring-green-500"
                    />
                    <label
                      htmlFor="message"
                      className="text-sm text-gray-700 flex items-center space-x-2 cursor-pointer"
                    >
                      <MessageSquare className="w-4 h-4 text-green-500" />
                      <span>Send Message</span>
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="radio"
                      id="userInput"
                      name="nodeType"
                      value="userInput"
                      checked={selectedNodeType === 'userInput'}
                      onChange={(e) => setSelectedNodeType(e.target.value)}
                      className="text-blue-500 focus:ring-blue-500"
                    />
                    <label
                      htmlFor="userInput"
                      className="text-sm text-gray-700 flex items-center space-x-2 cursor-pointer"
                    >
                      <User className="w-4 h-4 text-blue-500" />
                      <span>Wait for Input</span>
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="radio"
                      id="condition"
                      name="nodeType"
                      value="condition"
                      checked={selectedNodeType === 'condition'}
                      onChange={(e) => setSelectedNodeType(e.target.value)}
                      className="text-yellow-500 focus:ring-yellow-500"
                    />
                    <label
                      htmlFor="condition"
                      className="text-sm text-gray-700 flex items-center space-x-2 cursor-pointer"
                    >
                      <Settings className="w-4 h-4 text-yellow-500" />
                      <span>Add Condition</span>
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="radio"
                      id="action"
                      name="nodeType"
                      value="action"
                      checked={selectedNodeType === 'action'}
                      onChange={(e) => setSelectedNodeType(e.target.value)}
                      className="text-purple-500 focus:ring-purple-500"
                    />
                    <label
                      htmlFor="action"
                      className="text-sm text-gray-700 flex items-center space-x-2 cursor-pointer"
                    >
                      <Bot className="w-4 h-4 text-purple-500" />
                      <span>Perform Action</span>
                    </label>
                  </div>
                </div>
                <button
                  onClick={addNode}
                  className="mt-4 w-full flex items-center justify-center space-x-2 px-3 py-2 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-lg hover:from-blue-600 hover:to-blue-700 transition-all duration-200 shadow-md hover:shadow-lg transform hover:scale-105"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Node</span>
                </button>
              </div>

              <hr className="border-gray-200" />

              <div>
                <h3 className="text-sm font-semibold text-gray-900 mb-3">
                  Actions
                </h3>
                <div className="space-y-2">
                  <button
                    onClick={deleteSelectedNodes}
                    className="w-full flex items-center justify-center space-x-2 px-3 py-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors border border-red-200"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Delete Selected</span>
                  </button>
                  <button
                    onClick={() => {
                      const selectedNodes = nodes.filter((n) => n.selected);
                      if (selectedNodes.length > 0) {
                        const copiedNodes = selectedNodes.map((node) => ({
                          ...node,
                          id: `${Date.now()}-${Math.random()}`,
                          position: {
                            x: node.position.x + 50,
                            y: node.position.y + 50,
                          },
                          selected: false,
                        }));
                        setNodes((nds) => [...nds, ...copiedNodes]);
                      }
                    }}
                    className="w-full flex items-center justify-center space-x-2 px-3 py-2 bg-gray-50 text-gray-600 rounded-lg hover:bg-gray-100 transition-colors border border-gray-200"
                  >
                    <Copy className="w-4 h-4" />
                    <span>Duplicate</span>
                  </button>
                </div>
              </div>
            </div>
          </Panel>

          <Panel
            position="bottom-left"
            className="bg-white border border-gray-200 rounded-lg p-3 m-4 shadow-lg"
          >
            <div className="text-xs text-gray-600 space-y-1">
              <div className="font-medium text-gray-800 mb-2">
                Flow Statistics
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  Total Nodes:{' '}
                  <span className="font-medium">{flowStats.totalNodes}</span>
                </div>
                <div>
                  Messages:{' '}
                  <span className="font-medium text-green-600">
                    {flowStats.messageNodes}
                  </span>
                </div>
                <div>
                  Inputs:{' '}
                  <span className="font-medium text-blue-600">
                    {flowStats.inputNodes}
                  </span>
                </div>
                <div>
                  Conditions:{' '}
                  <span className="font-medium text-yellow-600">
                    {flowStats.conditionNodes}
                  </span>
                </div>
                <div>
                  Actions:{' '}
                  <span className="font-medium text-purple-600">
                    {flowStats.actionNodes}
                  </span>
                </div>
                <div>
                  Connections:{' '}
                  <span className="font-medium">{edges.length}</span>
                </div>
              </div>
            </div>
          </Panel>

          <Panel
            position="top-right"
            className="bg-white border border-gray-200 rounded-lg p-3 m-4 shadow-lg max-w-xs"
          >
            <div className="text-xs text-gray-600">
              <div className="font-medium text-gray-800 mb-2 flex items-center">
                <Eye className="w-4 h-4 mr-1" />
                Quick Guide
              </div>
              <ul className="space-y-1">
                <li>• Click nodes to edit properties</li>
                <li>• Drag from node edges to connect</li>
                <li>• Select multiple nodes with Shift+Click</li>
                <li>• Use mouse wheel to zoom</li>
                <li>• Drag background to pan</li>
              </ul>
            </div>
          </Panel>
        </ReactFlow>
      </div>

      {showProperties && selectedNode && (
        <NodePropertiesPanel
          selectedNode={selectedNode}
          onUpdateNode={updateNode}
          onClose={() => {
            setShowProperties(false);
            setSelectedNode(null);
          }}
        />
      )}

      {false && (
        <div className="absolute inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md mx-4">
            <div className="flex items-center space-x-3">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-green-500"></div>
              <span className="text-gray-700">Testing flow...</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CompleteWhatsAppCRM;
