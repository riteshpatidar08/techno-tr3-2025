// hooks/useSocket.js
import { useEffect, useRef, useCallback } from 'react';
import { useAppDispatch, useAppSelector } from '@/redux/store';
import socketService from '@/services/socketService';
import {
  addNewMessage,
  updateConversationLastMessage,
  setSocketConnected,
  selectSelectedConversation,
} from '@/redux/messageSlice';
import whistleSound from '/whistle.mp3'; // Static import from public folder

export const useSocket = (currentUser) => {
  const dispatch = useAppDispatch();
  const selectedConversation = useAppSelector(selectSelectedConversation);
  const audioRef = useRef(null);
  const isInitialized = useRef(false);
console.log(selectedConversation)

  useEffect(() => {
    const loadAudio = async () => {
      if (!audioRef.current) {
        audioRef.current = new Audio();
        audioRef.current.preload = 'auto';
        audioRef.current.volume = 0.5;

        let hasTriedAlternative = false;

        audioRef.current.addEventListener('canplaythrough', () => {
          console.log('✅ Audio loaded successfully');
        });

        audioRef.current.addEventListener('error', (e) => {
          console.error('❌ Audio failed to load:', e);

          if (!hasTriedAlternative) {
            hasTriedAlternative = true;
            console.log('🔄 Trying alternative audio path...');
            audioRef.current.src = '/whistle.mp3';
          } else {
            console.log(
              '⚠️ All audio paths failed, disabling notification sound'
            );
            audioRef.current = null;
          }
        });

        try {
        
          const audioModule = whistleSound
          audioRef.current.src = audioModule.default;
        } catch (error) {
          console.log('Failed to import audio, trying direct path');
          audioRef.current.src = '/whistle.mp3';
        }
      }
    };

    loadAudio();
  }, []);

  const playNotificationSound = useCallback(() => {
    if (currentUser) {
      try {
      
        if (!audioRef.current) {
        
          const audioContext = new (window.AudioContext ||
            window.webkitAudioContext)();
          const oscillator = audioContext.createOscillator();
          const gainNode = audioContext.createGain();

          oscillator.connect(gainNode);
          gainNode.connect(audioContext.destination);

          oscillator.frequency.value = 800;
          oscillator.type = 'sine';

          gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
          gainNode.gain.exponentialRampToValueAtTime(
            0.01,
            audioContext.currentTime + 0.5
          );

          oscillator.start(audioContext.currentTime);
          oscillator.stop(audioContext.currentTime + 0.5);

          console.log('🔊 Played notification beep');
          return;
        }

      
        audioRef.current.currentTime = 0;
        audioRef.current.play().catch((error) => {
          console.error('Error playing notification sound:', error);
        });
      } catch (error) {
        console.error('Audio playback error:', error);
      }
    }
  }, [currentUser]);

  const handleReceiveMessage = useCallback(
    (eventName, messageData) => {
      console.log('📨 Socket event received:', eventName);
      console.log('📨 Message payload:', messageData);
      console.log('📱 Current user:', currentUser);
      console.log('📱 Selected conversation:', selectedConversation);

      try {
     
        const res = messageData;

        const cleanPhoneNumber = (phone) => {
          if (!phone) return '';
          return phone.toString().replace(/^91/, '');
        };

        console.log('📞 Phone number comparison:', {
          'res.send_from': res.send_from,
          'res.send_to': res.send_to,
          'currentUser.id': currentUser?.id,
          'res.user_id': res.user_id,
          user_id_match: currentUser && res.user_id == currentUser.id,
        });

   
        if (currentUser && res.user_id == currentUser.id) {
          console.log(
            '🔊 Playing notification sound for user:',
            currentUser.id
          );
          playNotificationSound();
        }

     
        if (
          'Notification' in window &&
          Notification.permission === 'granted' &&
          currentUser &&
          res.user_id == currentUser.id
        ) {
          console.log('🔔 Showing browser notification');
          new Notification(
            `New message from ${res.send_from_id || res.send_from}`,
            {
              body: res.text || 'New message received',
              icon: '/favicon.ico',
              tag: `msg-${res.id}`,
            }
          );
        }

    
        const selectedRecipientMobile = cleanPhoneNumber(
          selectedConversation?.contact_number
        );
        const messageFromCleaned = cleanPhoneNumber(res.send_from);

        console.log('📞 Phone number matching:', {
          selectedRecipientMobile: selectedRecipientMobile,
          messageFromCleaned: messageFromCleaned,
          'raw res.send_from': res.send_from,
          'selectedConversation?.contact_number':
            selectedConversation?.contact_number,
          phones_match: messageFromCleaned === selectedRecipientMobile,
        });

   
        if (messageFromCleaned === selectedRecipientMobile) {
          console.log(
            '📱 Message from selected recipient - updating chat messages'
          );
          console.log('📱 Dispatching addNewMessage for selected conversation');

        
          dispatch(
            addNewMessage({
              id: res.id,
              text: res.text,
              type: 'recieve',
              created_at: res.created_at,
              status: res.status?.toString() || '1',
              method: res.method,
              is_media: res.is_media,
              send_from: res.send_from,
              send_to: res.send_to,
            })
          );

          console.log(
            '📱 Dispatching updateConversationLastMessage for selected conversation'
          );
      
          dispatch(
            updateConversationLastMessage({
              contactNumber: messageFromCleaned,
              lastMessage: {
                text: res.text || '',
                created_at: res.created_at || new Date().toISOString(),
                type: 'recieve',
                status: res.status?.toString() || '1',
                method: res.method,
                is_media: res.is_media,
              },
              resetUnreadCount: true, // Reset since this conversation is currently selected
            })
          );
        }
      
        else if (currentUser && res.user_id == currentUser.id) {
          console.log('📱 Message for current user from other contact');
          console.log(
            '📱 Dispatching updateConversationLastMessage for other conversation'
          );

     
          dispatch(
            updateConversationLastMessage({
              contactNumber: messageFromCleaned,
              lastMessage: {
                text: res.text || '',
                created_at: res.created_at || new Date().toISOString(),
                type: 'recieve',
                status: res.status?.toString() || '1',
                method: res.method,
                is_media: res.is_media,
              },
              incrementUnreadCount: true, 
            })
          );
        } else {
          console.log('📱 Message not for current user or conditions not met');
        }

        console.log('✅ Message processed successfully');
      } catch (error) {
        console.error('❌ Error handling socket message:', error);
        console.error('❌ Error details:', error.stack);
      }
    },
    [currentUser, selectedConversation, dispatch, playNotificationSound]
  );


  useEffect(() => {
    if (!currentUser || isInitialized.current) return;

    console.log('🔌 Initializing socket for user:', currentUser.id);

    try {
      // Join user room
      socketService.joinUserRoom(currentUser.id);

      // Listen for receive_msg event (matching your payload format)
      // Your socket sends: ["receive_msg", messageData]
      socketService.on('receive_msg', handleReceiveMessage);

      // Update connection status
      dispatch(setSocketConnected(true));

      isInitialized.current = true;

      console.log('✅ Socket initialized successfully');
    } catch (error) {
      console.error('❌ Socket initialization failed:', error);
      dispatch(setSocketConnected(false));
    }

    // Cleanup function
    return () => {
      console.log('🔌 Cleaning up socket listeners');
      socketService.off('receive_msg', handleReceiveMessage);
      dispatch(setSocketConnected(false));
      isInitialized.current = false;
    };
  }, [currentUser, handleReceiveMessage, dispatch]);

  // Request notification permission on mount
  useEffect(() => {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission().then((permission) => {
        console.log('🔔 Notification permission:', permission);
      });
    }
  }, []);

  // Socket utility functions
  const sendMessage = useCallback(
    (messageData) => {
      socketService.sendMessage({
        ...messageData,
        user_id: currentUser?.id,
        timestamp: new Date().toISOString(),
      });
    },
    [currentUser]
  );

  const sendTyping = useCallback(
    (isTyping) => {
      if (currentUser && selectedConversation) {
        socketService.emit('typing', {
          user_id: currentUser.id,
          contact_number: selectedConversation.contact_number,
          is_typing: isTyping,
        });
      }
    },
    [currentUser, selectedConversation]
  );

  const updatePresence = useCallback(
    (status) => {
      if (currentUser) {
        socketService.emit('presence', {
          user_id: currentUser.id,
          status: status, // 'online', 'offline', 'away'
        });
      }
    },
    [currentUser]
  );

  // Connection status
  const isConnected = socketService.isConnected();

  return {
    // Connection status
    isConnected,

    // Utility functions
    sendMessage,
    sendTyping,
    updatePresence,
    playNotificationSound,

    // Socket service instance
    socketService,
  };
};

export default useSocket;
