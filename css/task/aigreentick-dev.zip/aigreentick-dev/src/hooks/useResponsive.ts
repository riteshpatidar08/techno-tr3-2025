
import { useState, useEffect, useCallback, useMemo } from 'react';


export const BREAKPOINTS = {
  xs: 0,
  sm: 640,
  md: 768,
  lg: 1024,
  xl: 1280,
  '2xl': 1536,
};

// Custom hook for responsive behavior
export const useResponsive = () => {
  const [windowSize, setWindowSize] = useState({
    width: typeof window !== 'undefined' ? window.innerWidth : 1024,
    height: typeof window !== 'undefined' ? window.innerHeight : 768,
  });

  const [orientation, setOrientation] = useState(
    typeof window !== 'undefined'
      ? window.innerWidth > window.innerHeight
        ? 'landscape'
        : 'portrait'
      : 'landscape'
  );

  // Update window size
  const updateSize = useCallback(() => {
    const width = window.innerWidth;
    const height = window.innerHeight;

    setWindowSize({ width, height });
    setOrientation(width > height ? 'landscape' : 'portrait');
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    // Throttled resize handler
    let timeoutId;
    const throttledResize = () => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(updateSize, 150);
    };

    window.addEventListener('resize', throttledResize);
    updateSize(); // Initial call

    return () => {
      window.removeEventListener('resize', throttledResize);
      clearTimeout(timeoutId);
    };
  }, [updateSize]);

  // Memoized responsive values
  const responsive = useMemo(() => {
    const { width } = windowSize;

    return {
      // Current screen size
      width,
      height: windowSize.height,
      orientation,

      // Device type detection
      isMobile: width < BREAKPOINTS.md,
      isTablet: width >= BREAKPOINTS.md && width < BREAKPOINTS.xl,
      isDesktop: width >= BREAKPOINTS.xl,
      isLargeDesktop: width >= BREAKPOINTS['2xl'],

      // Breakpoint checks
      isXs: width >= BREAKPOINTS.xs && width < BREAKPOINTS.sm,
      isSm: width >= BREAKPOINTS.sm && width < BREAKPOINTS.md,
      isMd: width >= BREAKPOINTS.md && width < BREAKPOINTS.lg,
      isLg: width >= BREAKPOINTS.lg && width < BREAKPOINTS.xl,
      isXl: width >= BREAKPOINTS.xl && width < BREAKPOINTS['2xl'],
      is2xl: width >= BREAKPOINTS['2xl'],

      // Utility functions
      up: (breakpoint) => width >= BREAKPOINTS[breakpoint],
      down: (breakpoint) => width < BREAKPOINTS[breakpoint],
      between: (min, max) =>
        width >= BREAKPOINTS[min] && width < BREAKPOINTS[max],
      only: (breakpoint) => {
        if (breakpoint === 'xs') return width < BREAKPOINTS.sm;
        if (breakpoint === '2xl') return width >= BREAKPOINTS['2xl'];

        const breakpoints = Object.keys(BREAKPOINTS);
        const currentIndex = breakpoints.indexOf(breakpoint);
        const nextBreakpoint = breakpoints[currentIndex + 1];

        return (
          width >= BREAKPOINTS[breakpoint] &&
          (nextBreakpoint ? width < BREAKPOINTS[nextBreakpoint] : true)
        );
      },

      // Layout helpers
      columns:
        width >= BREAKPOINTS['2xl'] ? 3 : width >= BREAKPOINTS.lg ? 2 : 1,
      sidebarWidth:
        width >= BREAKPOINTS.xl ? 450 : width >= BREAKPOINTS.lg ? 400 : 300,
      containerMaxWidth:
        width >= BREAKPOINTS['2xl']
          ? '1536px'
          : width >= BREAKPOINTS.xl
          ? '1280px'
          : width >= BREAKPOINTS.lg
          ? '1024px'
          : '100%',

      // Component-specific helpers
      showSidebar: width >= BREAKPOINTS.lg,
      showMiniSidebar: width >= BREAKPOINTS.md && width < BREAKPOINTS.lg,
      stackVertically: width < BREAKPOINTS.md,
      useFullWidth: width < BREAKPOINTS.sm,
    };
  }, [windowSize, orientation]);

  return responsive;
};

// React Context for global responsive state
import React, { createContext, useContext } from 'react';

const ResponsiveContext = createContext();

export const ResponsiveProvider = ({ children }) => {
  const responsive = useResponsive();

  return (
    <ResponsiveContext.Provider value={responsive}>
      {children}
    </ResponsiveContext.Provider>
  );
};

export const useResponsiveContext = () => {
  const context = useContext(ResponsiveContext);
  if (!context) {
    throw new Error(
      'useResponsiveContext must be used within ResponsiveProvider'
    );
  }
  return context;
};

// Higher-order component for responsive behavior
export const withResponsive = (Component) => {
  return React.forwardRef((props, ref) => {
    const responsive = useResponsive();
    return <Component {...props} responsive={responsive} ref={ref} />;
  });
};

// Utility functions for responsive classes
export const createResponsiveClasses = (responsive, classMap) => {
  const classes = [];

  Object.entries(classMap).forEach(([breakpoint, className]) => {
    if (breakpoint === 'base') {
      classes.push(className);
    } else if (responsive.up(breakpoint)) {
      classes.push(className);
    }
  });

  return classes.join(' ');
};

// Responsive grid system
export const useResponsiveGrid = (config) => {
  const responsive = useResponsive();

  return useMemo(() => {
    const { xs = 1, sm = 1, md = 2, lg = 3, xl = 4, '2xl': xxl = 4 } = config;

    let columns = xs;
    if (responsive.up('sm')) columns = sm;
    if (responsive.up('md')) columns = md;
    if (responsive.up('lg')) columns = lg;
    if (responsive.up('xl')) columns = xl;
    if (responsive.up('2xl')) columns = xxl;

    return {
      columns,
      gridClass: `grid-cols-${columns}`,
      gap: responsive.isMobile
        ? 'gap-4'
        : responsive.isTablet
        ? 'gap-6'
        : 'gap-8',
    };
  }, [responsive, config]);
};

// Custom hook for responsive layout management
export const useResponsiveLayout = (layoutConfig = {}) => {
  const responsive = useResponsive();

  return useMemo(() => {
    const {
      mobileLayout = 'stack',
      tabletLayout = 'sidebar',
      desktopLayout = 'three-column',
    } = layoutConfig;

    let currentLayout = mobileLayout;
    if (responsive.isTablet) currentLayout = tabletLayout;
    if (responsive.isDesktop) currentLayout = desktopLayout;

    const layoutProps = {
      layout: currentLayout,
      showSidebar: responsive.showSidebar,
      showMiniSidebar: responsive.showMiniSidebar,
      stackVertically: responsive.stackVertically,
      useFullWidth: responsive.useFullWidth,

      // Layout-specific configurations
      containerClass: responsive.isMobile
        ? 'flex flex-col h-full'
        : responsive.isTablet
        ? 'flex h-full'
        : 'grid grid-cols-12 h-full',

      sidebarClass: responsive.isMobile
        ? 'fixed inset-0 z-50 transform transition-transform'
        : responsive.isTablet
        ? 'col-span-3 border-r border-border'
        : 'col-span-3 border-r border-border',

      mainClass: responsive.isMobile
        ? 'flex-1 flex flex-col'
        : responsive.isTablet
        ? 'flex-1 flex flex-col'
        : 'col-span-6 flex flex-col',

      rightSidebarClass: responsive.isMobile
        ? 'fixed right-0 top-0 h-full w-full max-w-sm transform transition-transform z-50'
        : responsive.isTablet
        ? 'hidden'
        : 'col-span-3 border-l border-border',
    };

    return {
      ...responsive,
      ...layoutProps,
    };
  }, [responsive, layoutConfig]);
};

// Responsive spacing utility
export const useResponsiveSpacing = () => {
  const responsive = useResponsive();

  return useMemo(
    () => ({
      padding: {
        container: responsive.isMobile
          ? 'p-4'
          : responsive.isTablet
          ? 'p-6'
          : 'p-8',
        card: responsive.isMobile ? 'p-4' : 'p-6',
        section: responsive.isMobile ? 'p-3' : 'p-4',
      },
      margin: {
        section: responsive.isMobile
          ? 'mb-4'
          : responsive.isTablet
          ? 'mb-6'
          : 'mb-8',
        card: responsive.isMobile ? 'mb-3' : 'mb-4',
      },
      gap: {
        grid: responsive.isMobile
          ? 'gap-4'
          : responsive.isTablet
          ? 'gap-6'
          : 'gap-8',
        flex: responsive.isMobile
          ? 'space-x-2'
          : responsive.isTablet
          ? 'space-x-4'
          : 'space-x-6',
      },
      text: {
        heading: responsive.isMobile
          ? 'text-xl'
          : responsive.isTablet
          ? 'text-2xl'
          : 'text-3xl',
        subheading: responsive.isMobile ? 'text-lg' : 'text-xl',
        body: responsive.isMobile ? 'text-sm' : 'text-base',
      },
    }),
    [responsive]
  );
};

// Media query hook for CSS-in-JS
export const useMediaQuery = (query) => {
  const [matches, setMatches] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const media = window.matchMedia(query);
    setMatches(media.matches);

    const listener = (event) => setMatches(event.matches);
    media.addEventListener('change', listener);

    return () => media.removeEventListener('change', listener);
  }, [query]);

  return matches;
};

// Responsive component wrapper
export const ResponsiveWrapper = ({
  children,
  mobileComponent,
  tabletComponent,
  desktopComponent,
}) => {
  const responsive = useResponsive();

  if (responsive.isMobile && mobileComponent) {
    return mobileComponent;
  }

  if (responsive.isTablet && tabletComponent) {
    return tabletComponent;
  }

  if (responsive.isDesktop && desktopComponent) {
    return desktopComponent;
  }

  return children;
};

// Tailwind responsive class generator
export const generateResponsiveClasses = (config) => {
  const breakpointPrefixes = {
    xs: '',
    sm: 'sm:',
    md: 'md:',
    lg: 'lg:',
    xl: 'xl:',
    '2xl': '2xl:',
  };

  return Object.entries(config)
    .map(([breakpoint, classes]) => {
      const prefix = breakpointPrefixes[breakpoint] || '';
      return Array.isArray(classes)
        ? classes.map((cls) => `${prefix}${cls}`).join(' ')
        : `${prefix}${classes}`;
    })
    .join(' ');
};

// Export all utilities
export default {
  useResponsive,
  useResponsiveContext,
  ResponsiveProvider,
  withResponsive,
  useResponsiveGrid,
  useResponsiveLayout,
  useResponsiveSpacing,
  useMediaQuery,
  ResponsiveWrapper,
  createResponsiveClasses,
  generateResponsiveClasses,
  BREAKPOINTS,
};
