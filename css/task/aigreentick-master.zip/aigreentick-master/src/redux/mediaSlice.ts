import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import { RootState } from './store';
import AiGreenTickApi from '@/services/api';

// Types
export interface MediaUploadResponse {
  image: string;
  public_url: string;
  message: string;
}

export interface MediaState {
  loading: boolean;
  error: string | null;
  image: string | null;
  publicUrl: string | null;
  handle: string | null;
}

const initialState: MediaState = {
  loading: false,
  error: null,
  image: null,
  publicUrl: null,
  handle: null,
};

// Thunk for uploading media
export const uploadMedia = createAsyncThunk<
  MediaUploadResponse,
  File,
  { rejectValue: string }
>('media/uploadMedia', async (file: File, { rejectWithValue }) => {
  try {
    const response = await AiGreenTickApi.media.upload(file);
    return response;
  } catch (error: any) {
    return rejectWithValue(
      error.response?.data?.message || error.message || 'Failed to upload media'
    );
  }
});

const mediaSlice = createSlice({
  name: 'media',
  initialState,
  reducers: {
    clearMedia: (state) => {
      state.image = null;
      state.publicUrl = null;
      state.handle = null;
      state.error = null;
    },

    clearError: (state) => {
      state.error = null;
    },

    setMedia: (state, action: PayloadAction<MediaUploadResponse>) => {
      state.image = action.payload.image;
      state.publicUrl = action.payload.public_url;

      state.handle = action.payload.image;
      console.log('Media set:', action.payload);
    },
  },
  extraReducers: (builder) => {
    builder

      .addCase(uploadMedia.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(uploadMedia.fulfilled, (state, action) => {
        state.loading = false;
        state.image = action.payload.image;
        state.publicUrl = action.payload.public_url;

        state.handle = action.payload.image;
        state.error = null;
        console.log('Upload successful:', action.payload);
      })
      .addCase(uploadMedia.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { clearMedia, clearError, setMedia } = mediaSlice.actions;

// Selectors
export const selectMediaLoading = (state: RootState): boolean =>
  state.media.loading;
export const selectMediaError = (state: RootState): string | null =>
  state.media.error;
export const selectMediaImage = (state: RootState): string | null =>
  state.media.image;
export const selectMediaPublicUrl = (state: RootState): string | null =>
  state.media.publicUrl;
export const selectMediaHandle = (state: RootState): string | null =>
  state.media.handle;

// Combined selector for all media data
export const selectMediaData = (state: RootState) => ({
  image: state.media.image,
  publicUrl: state.media.publicUrl,
  handle: state.media.handle,
  loading: state.media.loading,
  error: state.media.error,
});

export default mediaSlice.reducer;
