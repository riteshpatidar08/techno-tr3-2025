import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import AiGreenTickApi from '@/services/api';

export interface TemplateComponent {
  id: number;
  template_id: number;
  type: string;
  format: string | null;
  text: string | null;
  image_url: string | null;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  buttons: Array<{
    id: number;
    template_id: number;
    component_id: number;
    type: string;
    number?: string;
    text: string;
    url?: string | null;
    created_at: string;
    updated_at: string;
    deleted_at: string | null;
  }>;
  body_text: any[];
}

export interface Template {
  id: number;
  user_id: number;
  name: string;
  previous_category: string | null;
  language: string;
  status: string;
  category: string;
  wa_id: string;
  payload: string | null;
  response: string | null;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  components: TemplateComponent[];
}

interface TemplatesResponse {
  current_page: number;
  data: Template[];
  first_page_url: string;
  from: number | null;
  last_page: number;
  last_page_url: string;
  links: Array<{
    url: string | null;
    label: string;
    active: boolean;
  }>;
  next_page_url: string | null;
  path: string;
  per_page: number;
  prev_page_url: string | null;
  to: number | null;
  total: number;
}

// Enhanced error interface to handle WhatsApp API errors
interface TemplateError {
  message: string;
  type?: string;
  code?: number;
  error_subcode?: number;
  error_user_title?: string;
  error_user_msg?: string;
  fbtrace_id?: string;
  is_transient?: boolean;
}

interface TemplatesState {
  list: Template[];
  loading: boolean;
  error: string | null;
  currentPage: number;
  lastPage: number;
  total: number;
  perPage: number;
  hasMorePages: boolean;

  selectedTemplate: Template | null;
  selectedTemplateLoading: boolean;

  lastError: TemplateError | null;
  createLoading: boolean;
  updateLoading: boolean;
  deleteLoading: boolean;
}

// Helper function to extract meaningful error messages
const extractErrorMessage = (error: any): TemplateError => {
  console.log('Full error object:', error);

  let errorData = null;

  if (error?.response?.data) {
    errorData = error.response.data;
  } else if (error?.data) {
    errorData = error.data;
  } else if (error?.message || error?.type || error?.code) {
    errorData = error;
  }

  if (errorData) {
    return {
      message:
        errorData.error_user_msg || errorData.message || 'An error occurred',
      type: errorData.type || 'Unknown',
      code: errorData.code,
      error_subcode: errorData.error_subcode,
      error_user_title: errorData.error_user_title,
      error_user_msg: errorData.error_user_msg,
      fbtrace_id: errorData.fbtrace_id,
      is_transient: errorData.is_transient,
    };
  }

  return {
    message: error?.message || 'An unknown error occurred',
    type: 'Unknown',
  };
};

/* ---------- Async Thunks ---------- */
export const fetchTemplates = createAsyncThunk<TemplatesResponse>(
  'templates/fetchAll',
  async (_, thunkAPI) => {
    try {
      const data = await AiGreenTickApi.templates.fetchAll();
      console.log('Templates API Response:', data);
      return data as TemplatesResponse;
    } catch (err: any) {
      console.error('Templates API Error:', err);
      const errorInfo = extractErrorMessage(err);
      return thunkAPI.rejectWithValue(errorInfo);
    }
  }
);

export const fetchTemplatesByPage = createAsyncThunk<TemplatesResponse, number>(
  'templates/fetchByPage',
  async (page, thunkAPI) => {
    try {
      const data = await AiGreenTickApi.templates.fetchByPage(page);
      return data as TemplatesResponse;
    } catch (err: any) {
      const errorInfo = extractErrorMessage(err);
      return thunkAPI.rejectWithValue(errorInfo);
    }
  }
);

export const fetchTemplateById = createAsyncThunk<Template, number>(
  'templates/fetchById',
  async (id, thunkAPI) => {
    try {
      const data = await AiGreenTickApi.templates.fetchById(id);
      console.log('Template by ID API Response:', data);
      return data as Template;
    } catch (err: any) {
      console.error('Template by ID API Error:', err);
      const errorInfo = extractErrorMessage(err);
      return thunkAPI.rejectWithValue(errorInfo);
    }
  }
);

export const createTemplate = createAsyncThunk<Template, Partial<Template>>(
  'templates/create',
  async (body, thunkAPI) => {
    try {
      console.log('Creating template with payload:', body);
      const data = await AiGreenTickApi.templates.create(body);
      console.log('Create template API response:', data);

      if (data && typeof data === 'object' && 'error' in data) {
        console.error('API returned error in success response:', data.error);
        const errorInfo = extractErrorMessage(data);
        return thunkAPI.rejectWithValue(errorInfo);
      }

      if (data && data.error) {
        console.error('API returned error at root level:', data.error);
        const errorInfo = extractErrorMessage(data.error);
        return thunkAPI.rejectWithValue(errorInfo);
      }

      console.log('Template created successfully:', data);
      return data as Template;
    } catch (err: any) {
      console.error('Create template error:', err);
      const errorInfo = extractErrorMessage(err);
      return thunkAPI.rejectWithValue(errorInfo);
    }
  }
);

export const updateTemplate = createAsyncThunk<
  Template,
  { id: number; body: Partial<Template> }
>('templates/update', async ({ id, body }, thunkAPI) => {
  try {
    const data = await AiGreenTickApi.templates.update(id, body);
    return data as Template;
  } catch (err: any) {
    const errorInfo = extractErrorMessage(err);
    return thunkAPI.rejectWithValue(errorInfo);
  }
});

export const deleteTemplate = createAsyncThunk<number, number>(
  'templates/delete',
  async (id, thunkAPI) => {
    try {
      await AiGreenTickApi.templates.delete(id);
      return id;
    } catch (err: any) {
      const errorInfo = extractErrorMessage(err);
      return thunkAPI.rejectWithValue(errorInfo);
    }
  }
);

const initialState: TemplatesState = {
  list: [],
  loading: false,
  error: null,
  currentPage: 1,
  lastPage: 1,
  total: 0,
  perPage: 10,
  hasMorePages: false,
  selectedTemplate: null,
  selectedTemplateLoading: false,
  lastError: null,
  createLoading: false,
  updateLoading: false,
  deleteLoading: false,
};

const templatesSlice = createSlice({
  name: 'templates',
  initialState,
  reducers: {
    clearError(state) {
      state.error = null;
      state.lastError = null;
    },
    resetTemplates(state) {
      state.list = [];
      state.currentPage = 1;
      state.lastPage = 1;
      state.total = 0;
      state.hasMorePages = false;
      state.error = null;
      state.lastError = null;
    },
    clearSelectedTemplate(state) {
      state.selectedTemplate = null;
      state.selectedTemplateLoading = false;
    },
  },
  extraReducers: (builder) => {
    builder

      .addCase(fetchTemplates.pending, (state) => {
        state.loading = true;
        state.error = null;
        state.lastError = null;
      })
      .addCase(fetchTemplates.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.lastError = null;

        const response = action.payload;
        console.log(response.data.data);
        state.list = response.data.data || [];
        state.currentPage = response.current_page || 1;
        state.lastPage = response.last_page || 1;
        state.total = response.total || 0;
        state.perPage = response.per_page || 10;
        state.hasMorePages =
          (response.current_page || 1) < (response.last_page || 1);

        console.log('Templates loaded:', {
          total: state.total,
          templates: state.list.length,
          currentPage: state.currentPage,
          lastPage: state.lastPage,
        });
      })
      .addCase(fetchTemplates.rejected, (state, action) => {
        state.loading = false;
        const errorInfo = action.payload as TemplateError;
        state.error = errorInfo.message;
        state.lastError = errorInfo;
        console.error('Failed to fetch templates:', errorInfo);
      })

      .addCase(fetchTemplatesByPage.pending, (state) => {
        state.loading = true;
        state.error = null;
        state.lastError = null;
      })
      .addCase(fetchTemplatesByPage.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.lastError = null;

        const response = action.payload;
        state.list = response.data || [];
        state.currentPage = response.current_page || 1;
        state.lastPage = response.last_page || 1;
        state.total = response.total || 0;
        state.perPage = response.per_page || 10;
        state.hasMorePages =
          (response.current_page || 1) < (response.last_page || 1);
      })
      .addCase(fetchTemplatesByPage.rejected, (state, action) => {
        state.loading = false;
        const errorInfo = action.payload as TemplateError;
        state.error = errorInfo.message;
        state.lastError = errorInfo;
      })

      .addCase(fetchTemplateById.pending, (state) => {
        state.selectedTemplateLoading = true;
        state.error = null;
        state.lastError = null;
      })
      .addCase(fetchTemplateById.fulfilled, (state, action) => {
        state.selectedTemplateLoading = false;
        state.error = null;
        state.lastError = null;
        console.log(action.payload);
        state.selectedTemplate = action.payload;

        const idx = state.list.findIndex((t) => t.id === action.payload.id);
        if (idx !== -1) {
          state.list[idx] = action.payload;
        }

        console.log('Template fetched by ID:', action.payload);
      })
      .addCase(fetchTemplateById.rejected, (state, action) => {
        state.selectedTemplateLoading = false;
        const errorInfo = action.payload as TemplateError;
        state.error = errorInfo.message;
        state.lastError = errorInfo;
        console.error('Failed to fetch template by ID:', errorInfo);
      })

      .addCase(createTemplate.pending, (state) => {
        state.createLoading = true;
        state.loading = true;
        state.error = null;
        state.lastError = null;
      })
      .addCase(createTemplate.fulfilled, (state, action) => {
        state.createLoading = false;
        state.loading = false;
        state.error = null;
        state.lastError = null;
        state.list.unshift(action.payload);
        state.total += 1;
        console.log('Template created successfully:', action.payload);
      })
      .addCase(createTemplate.rejected, (state, action) => {
        state.createLoading = false;
        state.loading = false;
        const errorInfo = action.payload as TemplateError;
        state.error = errorInfo.message;
        state.lastError = errorInfo;
        console.error('Failed to create template:', errorInfo);
      })

      .addCase(updateTemplate.pending, (state) => {
        state.updateLoading = true;
        state.loading = true;
        state.error = null;
        state.lastError = null;
      })
      .addCase(updateTemplate.fulfilled, (state, action) => {
        state.updateLoading = false;
        state.loading = false;
        state.error = null;
        state.lastError = null;
        const idx = state.list.findIndex((t) => t.id === action.payload.id);
        if (idx !== -1) state.list[idx] = action.payload;
      })
      .addCase(updateTemplate.rejected, (state, action) => {
        state.updateLoading = false;
        state.loading = false;
        const errorInfo = action.payload as TemplateError;
        state.error = errorInfo.message;
        state.lastError = errorInfo;
      })

      .addCase(deleteTemplate.pending, (state) => {
        state.deleteLoading = true;
        state.loading = true;
        state.error = null;
        state.lastError = null;
      })
      .addCase(deleteTemplate.fulfilled, (state, action) => {
        state.deleteLoading = false;
        state.loading = false;
        state.error = null;
        state.lastError = null;
        state.list = state.list.filter((t) => t.id !== action.payload);
        state.total = Math.max(0, state.total - 1);
      })
      .addCase(deleteTemplate.rejected, (state, action) => {
        state.deleteLoading = false;
        state.loading = false;
        const errorInfo = action.payload as TemplateError;
        state.error = errorInfo.message;
        state.lastError = errorInfo;
      });
  },
});

export const { clearError, resetTemplates, clearSelectedTemplate } =
  templatesSlice.actions;

// Existing selectors
export const selectTemplates = (state: { templates: TemplatesState }) =>
  state.templates.list;
export const selectTemplatesLoading = (state: { templates: TemplatesState }) =>
  state.templates.loading;
export const selectTemplatesError = (state: { templates: TemplatesState }) =>
  state.templates.error;
export const selectTemplatesTotal = (state: { templates: TemplatesState }) =>
  state.templates.total;
export const selectTemplatesPagination = (state: {
  templates: TemplatesState;
}) => ({
  currentPage: state.templates.currentPage,
  lastPage: state.templates.lastPage,
  total: state.templates.total,
  perPage: state.templates.perPage,
  hasMorePages: state.templates.hasMorePages,
});

export const selectSelectedTemplate = (state: { templates: TemplatesState }) =>
  state.templates.selectedTemplate;

export const selectSelectedTemplateLoading = (state: {
  templates: TemplatesState;
}) => state.templates.selectedTemplateLoading;

// Enhanced selectors for better error handling
export const selectLastError = (state: { templates: TemplatesState }) =>
  state.templates.lastError;

export const selectCreateLoading = (state: { templates: TemplatesState }) =>
  state.templates.createLoading;

export const selectUpdateLoading = (state: { templates: TemplatesState }) =>
  state.templates.updateLoading;

export const selectDeleteLoading = (state: { templates: TemplatesState }) =>
  state.templates.deleteLoading;

// Utility selector to get user-friendly error message
export const selectUserFriendlyError = (state: {
  templates: TemplatesState;
}) => {
  const lastError = state.templates.lastError;
  if (!lastError) return null;

  return lastError.error_user_msg || lastError.message || 'An error occurred';
};

// Utility selector to check if error is a validation error
export const selectIsValidationError = (state: {
  templates: TemplatesState;
}) => {
  const lastError = state.templates.lastError;
  return lastError?.code === 192 || lastError?.type === 'OAuthException';
};

export default templatesSlice.reducer;
