import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import AiGreenTickApi from '@/services/api';

interface ChatMessage {
  id: number;
  user_id: number;
  contact_id: number;
  send_from: string;
  send_to: string;
  send_from_id: string;
  send_to_id: string;
  text: string;
  type: 'sent' | 'recieve';
  method: string;
  image_id: number | null;
  time: string;
  template_id: number | null;
  status: string;
  is_media: string;
  contact: string;
  response: string;
  message_id: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
}

interface ConversationMessage {
  id: number;
  user_id: number;
  contact_id: number;
  send_from: string;
  send_to: string;
  send_from_id: string;
  send_to_id: string;
  text: string;
  type: 'sent' | 'recieve';
  method: string;
  image_id: number | null;
  time: string;
  template_id: number | null;
  status: string;
  is_media: string;
  contact: string | null;
  response: string;
  message_id: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  user?: User;
  template?: any;
}

interface Contact {
  id: number;
  user_id: number;
  name: string;
  mobile: string;
  time: number;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  total_msg_count: number;
  last_chat: ChatMessage;
}

interface User {
  id: number;
  role_id: number;
  created_by: number | null;
  country_id: number;
  name: string;
  mobile: string;
  profile_photo: string | null;
  rememberToken: string | null;
  api_token: string;
  email: string;
  company_name: string | null;
  city: string | null;
  market_msg_charge: number;
  utilty_msg_charge: number;
  auth_msg_charge: number;
  balance: number;
  balance_enabled: number;
  online_status: string;
  agent_id: number | null;
  credit: number;
  debit: number;
  status: string;
  domain: string | null;
  logo: string | null;
  is_demo: string;
  demo_end: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  webhook_token: string | null;
}

interface Channel {
  id: number;
  user_id: number;
  created_by: number;
  whatsapp_no: string;
  whatsapp_no_id: string;
  whatsapp_biz_id: string;
  parmenent_token: string;
  token: string;
  status: string;
  response: string | null;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  user: User;
}

interface PaginationLink {
  url: string | null;
  label: string;
  active: boolean;
}

interface MessagesResponse {
  users: {
    current_page: number;
    data: Contact[];
    first_page_url: string;
    from: number;
    last_page: number;
    last_page_url: string;
    links: PaginationLink[];
    next_page_url: string | null;
    path: string;
    per_page: number;
    prev_page_url: string | null;
    to: number;
    total: number;
  };
  channel: Channel[];
}

interface ConversationResponse {
  chat: ConversationMessage[];
  channel: Channel[];
}

interface ConversationItem {
  id: number;
  contact_name: string;
  contact_number: string;
  contact_id: number;
  lastMessage: ChatMessage;
  lastMessageTime: string;
  unreadCount: number;
  totalMessageCount: number;
  isActive: boolean;
}

// Updated SendMessageData interface to match your backend payload
interface SendMessageData {
  message: string;
  recipient_mobile: string;
  recipient_name: string;
  template_id?: number | null;
  reaction?: string;
  isReply?: boolean;
  media_type?: string;
  media_url?: string;
  filename?: string;
  caption?: string;
  channel: string;
}

interface MessageState {
  contacts: Contact[];
  channels: Channel[];

  conversations: ConversationItem[];
  selectedConversation: ConversationItem | null;
  selectedContactId: number | null;

  currentConversationMessages: ConversationMessage[];
  conversationLoading: boolean;
  conversationError: string | null;

  currentPage: number;
  lastPage: number;
  total: number;
  perPage: number;
  hasMorePages: boolean;

  loading: boolean;
  error: string | null;
  sendingMessage: boolean;
  sendError: string | null;
  selectedChannelId: number | null;
  searchQuery: string;
}

const organizeContactsIntoConversations = (
  contacts: Contact[]
): ConversationItem[] => {
  return contacts
    .map((contact) => {
      const lastMessageTime = new Date(contact.last_chat.created_at);
      const now = new Date();
      const diffInHours =
        (now.getTime() - lastMessageTime.getTime()) / (1000 * 60 * 60);
      const isActive = diffInHours <= 24;

      const unreadCount =
        contact.last_chat.type === 'recieve' &&
        contact.last_chat.status !== 'read'
          ? 1
          : 0;

      return {
        id: contact.id,
        contact_name: contact.name,
        contact_number: contact.mobile,
        contact_id: contact.id,
        lastMessage: contact.last_chat,
        lastMessageTime: contact.last_chat.created_at,
        unreadCount,
        totalMessageCount: contact.total_msg_count,
        isActive,
      };
    })
    .sort(
      (a, b) =>
        new Date(b.lastMessageTime).getTime() -
        new Date(a.lastMessageTime).getTime()
    );
};

const initialState: MessageState = {
  contacts: [],
  channels: [],
  conversations: [],
  selectedConversation: null,
  selectedContactId: null,
  currentConversationMessages: [],
  conversationLoading: false,
  conversationError: null,
  currentPage: 1,
  lastPage: 1,
  total: 0,
  perPage: 10,
  hasMorePages: false,
  loading: false,
  error: null,
  sendingMessage: false,
  sendError: null,
  selectedChannelId: null,
  searchQuery: '',
};

export const fetchMessages = createAsyncThunk(
  'messages/fetchAll',
  async (
    params: {
      selectedChannel?: string | null;
      chat?: string;
      page?: number;
      search?: string;
    } = {},
    { rejectWithValue }
  ) => {
    try {
      const response = await AiGreenTickApi.messages.fetchAll(params);
      return response as MessagesResponse;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.error ||
          error.message ||
          'Failed to fetch messages'
      );
    }
  }
);

export const fetchConversation = createAsyncThunk(
  'messages/fetchConversation',
  async (
    params: {
      contactNumber: string;
      selectedChannel: string;
      page?: number;
    },
    { rejectWithValue }
  ) => {
    try {
      const response = await AiGreenTickApi.messages.fetchConversation(
        params.contactNumber,
        {
          selectedChannel: params.selectedChannel,
          page: params.page || 1,
        }
      );
      return response as ConversationResponse;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.error ||
          error.message ||
          'Failed to fetch conversation'
      );
    }
  }
);

// Updated sendMessage thunk with new payload structure
export const sendMessage = createAsyncThunk(
  'messages/send',
  async (messageData: SendMessageData, { rejectWithValue, dispatch }) => {
    try {
      const response = await AiGreenTickApi.messages.send(messageData);

      dispatch(fetchMessages({}));

      return response;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.error || error.message || 'Failed to send message'
      );
    }
  }
);

const messageSlice = createSlice({
  name: 'messages',
  initialState,
  reducers: {
    clearError: (state) => {
      state.error = null;
      state.sendError = null;
    },

    setSelectedChannelId: (state, action: PayloadAction<number | null>) => {
      state.selectedChannelId = action.payload;
    },

    setSearchQuery: (state, action: PayloadAction<string>) => {
      state.searchQuery = action.payload;
    },

    selectConversation: (state, action: PayloadAction<string | number>) => {
      const identifier = action.payload;
      const conversation = state.conversations.find(
        (conv) =>
          conv.contact_number === identifier ||
          conv.contact_id === identifier ||
          conv.id === identifier
      );

      if (conversation) {
        state.selectedConversation = conversation;
        state.selectedContactId = conversation.contact_id;

        conversation.unreadCount = 0;

        state.currentConversationMessages = [];
        state.conversationError = null;
      }
    },

    clearSelectedConversation: (state) => {
      state.selectedConversation = null;
      state.selectedContactId = null;
      state.currentConversationMessages = [];
      state.conversationError = null;
    },

    resetMessages: (state) => {
      state.contacts = [];
      state.channels = [];
      state.conversations = [];
      state.selectedConversation = null;
      state.selectedContactId = null;
      state.currentConversationMessages = [];
      state.conversationLoading = false;
      state.conversationError = null;
      state.currentPage = 1;
      state.lastPage = 1;
      state.total = 0;
      state.hasMorePages = false;
      state.error = null;
      state.sendError = null;
    },

    addMessageToConversation: (
      state,
      action: PayloadAction<ConversationMessage>
    ) => {
      const newMessage = action.payload;
      state.currentConversationMessages.push(newMessage);

      if (state.selectedConversation) {
        state.selectedConversation.lastMessage = newMessage as ChatMessage;
        state.selectedConversation.lastMessageTime = newMessage.created_at;
      }
    },

    updateConversationMessage: (
      state,
      action: PayloadAction<{
        contactId: number;
        message: ChatMessage;
      }>
    ) => {
      const { contactId, message } = action.payload;
      const conversationIndex = state.conversations.findIndex(
        (conv) => conv.contact_id === contactId
      );

      if (conversationIndex !== -1) {
        state.conversations[conversationIndex].lastMessage = message;
        state.conversations[conversationIndex].lastMessageTime =
          message.created_at;

        if (message.type === 'recieve') {
          state.conversations[conversationIndex].unreadCount += 1;
        }

        const updatedConversation = state.conversations[conversationIndex];
        state.conversations.splice(conversationIndex, 1);
        state.conversations.unshift(updatedConversation);
      }
    },

    markConversationAsRead: (state, action: PayloadAction<number>) => {
      const contactId = action.payload;
      const conversation = state.conversations.find(
        (conv) => conv.contact_id === contactId
      );

      if (conversation) {
        conversation.unreadCount = 0;
      }
    },
  },
  extraReducers: (builder) => {
    builder

      .addCase(fetchMessages.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(
        fetchMessages.fulfilled,
        (state, action: PayloadAction<MessagesResponse>) => {
          state.loading = false;
          state.error = null;

          state.currentPage = action.payload.users.current_page;
          state.lastPage = action.payload.users.last_page;
          state.total = action.payload.users.total;
          state.perPage = action.payload.users.per_page;
          state.hasMorePages =
            action.payload.users.current_page < action.payload.users.last_page;

          if (action.payload.users.current_page === 1) {
            state.contacts = action.payload.users.data;
            state.conversations = organizeContactsIntoConversations(
              action.payload.users.data
            );
          } else {
            state.contacts = [...state.contacts, ...action.payload.users.data];
            const newConversations = organizeContactsIntoConversations(
              action.payload.users.data
            );
            state.conversations = [...state.conversations, ...newConversations];
          }

          state.channels = action.payload.channel;
        }
      )
      .addCase(fetchMessages.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      .addCase(fetchConversation.pending, (state) => {
        state.conversationLoading = true;
        state.conversationError = null;
      })
      .addCase(
        fetchConversation.fulfilled,
        (state, action: PayloadAction<ConversationResponse>) => {
          state.conversationLoading = false;
          state.conversationError = null;
          state.currentConversationMessages = action.payload.chat;
        }
      )
      .addCase(fetchConversation.rejected, (state, action) => {
        state.conversationLoading = false;
        state.conversationError = action.payload as string;
      })

      .addCase(sendMessage.pending, (state) => {
        state.sendingMessage = true;
        state.sendError = null;
      })
      .addCase(sendMessage.fulfilled, (state) => {
        state.sendingMessage = false;
        state.sendError = null;
      })
      .addCase(sendMessage.rejected, (state, action) => {
        state.sendingMessage = false;
        state.sendError = action.payload as string;
      });
  },
});

export const {
  clearError,
  setSelectedChannelId,
  setSearchQuery,
  selectConversation,
  clearSelectedConversation,
  resetMessages,
  updateConversationMessage,
  markConversationAsRead,
  addMessageToConversation,
} = messageSlice.actions;

export const selectMessages = (state: { messages: MessageState }) =>
  state.messages;
export const selectContacts = (state: { messages: MessageState }) =>
  state.messages?.contacts || [];
export const selectConversations = (state: { messages: MessageState }) =>
  state.messages?.conversations || [];
export const selectSelectedConversation = (state: { messages: MessageState }) =>
  state.messages?.selectedConversation;
export const selectChannels = (state: { messages: MessageState }) =>
  state.messages?.channels || [];
export const selectMessagesLoading = (state: { messages: MessageState }) =>
  state.messages?.loading || false;
export const selectMessagesError = (state: { messages: MessageState }) =>
  state.messages?.error;
export const selectSendingMessage = (state: { messages: MessageState }) =>
  state.messages?.sendingMessage || false;
export const selectSendError = (state: { messages: MessageState }) =>
  state.messages?.sendError;

export const selectCurrentConversationMessages = (state: {
  messages: MessageState;
}) => state.messages?.currentConversationMessages || [];
export const selectConversationLoading = (state: { messages: MessageState }) =>
  state.messages?.conversationLoading || false;
export const selectConversationError = (state: { messages: MessageState }) =>
  state.messages?.conversationError;

export const selectPaginationInfo = (state: { messages: MessageState }) => ({
  currentPage: state.messages?.currentPage || 1,
  lastPage: state.messages?.lastPage || 1,
  total: state.messages?.total || 0,
  perPage: state.messages?.perPage || 10,
  hasMorePages: state.messages?.hasMorePages || false,
});

export const selectFilteredConversations = (state: {
  messages: MessageState;
}) => {
  if (!state.messages) {
    console.warn('Messages state is undefined');
    return [];
  }

  const { conversations = [], searchQuery = '' } = state.messages;

  if (!searchQuery) return conversations;

  return conversations.filter(
    (conv) =>
      conv.contact_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      conv.contact_number?.includes(searchQuery) ||
      conv.lastMessage?.text?.toLowerCase().includes(searchQuery.toLowerCase())
  );
};

export const selectUnreadCount = (state: { messages: MessageState }) => {
  if (!state.messages || !state.messages.conversations) {
    return 0;
  }

  return state.messages.conversations.reduce(
    (total, conv) => total + (conv.unreadCount || 0),
    0
  );
};

export const selectActiveConversations = (state: {
  messages: MessageState;
}) => {
  const conversations = selectConversations(state);
  return conversations.filter((conv) => conv.isActive);
};

export const selectExpiredConversations = (state: {
  messages: MessageState;
}) => {
  const conversations = selectConversations(state);
  return conversations.filter((conv) => !conv.isActive);
};

export default messageSlice.reducer;
