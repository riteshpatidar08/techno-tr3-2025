import {
  createSlice,
  createAsyncThunk,
  PayloadAction,
  current,
} from '@reduxjs/toolkit';
import AiGreenTickApi from '@/services/api';

// Types
export interface Report {
  id: number;
  user_id: number;
  wallet_id: number | null;
  template_id: number;
  whatsapp: number;
  country_id: number;
  campname: string;
  is_media: string;
  data: any;
  total: number;
  schedule_at: string | null;
  status: string;
  numbers: string;
  requests: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  sent_count: number;
  read_count: number;
  dlvd_count: number;
  failed_count: number;
  other_count: number;
  process: number;
  template?: {
    id: number;
    user_id: number;
    name: string;
    previous_category: string | null;
    language: string;
    status: string;
    category: string;
    wa_id: string;
    payload: any;
    response: any;
    created_at: string;
    updated_at: string;
    deleted_at: string | null;
    components: Array<{
      id: number;
      template_id: number;
      type: string;
      format: string | null;
      text: string | null;
      image_url: string | null;
      created_at: string;
      updated_at: string;
      deleted_at: string | null;
      buttons: any[];
    }>;
  };
  user?: {
    id: number;
    role_id: number;
    created_by: number | null;
    country_id: number;
    name: string;
    mobile: string;
    profile_photo: string | null;
    rememberToken: string | null;
    api_token: string;
    email: string;
    company_name: string | null;
    city: string | null;
    market_msg_charge: number | null;
    utilty_msg_charge: number;
    auth_msg_charge: number;
    balance: number;
    balance_enabled: number;
    online_status: string;
    agent_id: number | null;
    credit: number;
    debit: number;
    status: string;
    domain: string | null;
    logo: string | null;
    is_demo: string;
    demo_end: string;
    created_at: string;
    updated_at: string;
    deleted_at: string | null;
    webhook_token: string | null;
  };
  country?: {
    id: number;
    name: string;
    mobile_code: string;
    created_at: string;
    updated_at: string;
    deleted_at: string | null;
  };
}

export interface ReportsResponse {
  current_page: number;
  data: Report[];
  last_page: number;
  per_page: number;
  total: number;
}

export interface ReportsFilters {
  search?: string;
  from?: string;
  to?: string;
  type?: string;
  page?: number;
  per_page?: number;
}

export interface FetchReportByIdParams {
  id: string | number;
  type?: string;
}

export interface FetchReportByUrlParams {
  id: string | number;
  type?: string;
  page?: number;
  per_page?: number;
}

export interface ReportsState {
  reports: Report[];
  currentReport: Report | null;
  currentReportDetails: any[] | null;
  currentReportPagination: {
    currentPage: number;
    lastPage: number;
    perPage: number;
    total: number;
  } | null;
  currentPage: number;
  lastPage: number;
  perPage: number;
  total: number;
  filters: ReportsFilters;
  isLoading: boolean;
  isLoadingCurrentReport: boolean;
  error: string | null;
  currentReportError: string | null;
}

// Async thunk for fetching reports
export const fetchReports = createAsyncThunk<
  ReportsResponse,
  ReportsFilters,
  { rejectValue: string }
>('reports/fetchReports', async (filters, { rejectWithValue }) => {
  try {
    console.log(filters);
    const response = await AiGreenTickApi.reports.fetchAll(filters);
    return response;
  } catch (error: any) {
    if (error.response) {
      const errorMessage =
        error.response.data?.error ||
        error.response.data?.message ||
        'Failed to fetch reports';
      return rejectWithValue(errorMessage);
    } else if (error.request) {
      return rejectWithValue('Network error. Please check your connection.');
    } else {
      return rejectWithValue(error.message || 'An unexpected error occurred.');
    }
  }
});

// Async thunk for fetching a single report by ID
export const fetchReportById = createAsyncThunk<
  Report,
  FetchReportByIdParams,
  { rejectValue: string }
>('reports/fetchReportById', async (params, { rejectWithValue }) => {
  try {
    console.log(
      `Fetching report with ID: ${params.id}, type: ${params.type || 'all'}`
    );
    const response = await AiGreenTickApi.reports.fetchById(params.id, {
      type: params.type,
    });
    return response.data;
  } catch (error: any) {
    if (error.response) {
      const errorMessage =
        error.response.data?.error ||
        error.response.data?.message ||
        'Failed to fetch report';
      return rejectWithValue(errorMessage);
    } else if (error.request) {
      return rejectWithValue('Network error. Please check your connection.');
    } else {
      return rejectWithValue(error.message || 'An unexpected error occurred.');
    }
  }
});

// Async thunk for fetching report details by URL with pagination
export const fetchReportByUrl = createAsyncThunk<
  any,
  FetchReportByUrlParams,
  { rejectValue: string }
>('reports/fetchReportByUrl', async (params, { rejectWithValue }) => {
  try {
    console.log(
      `Fetching report details with ID: ${params.id}, type: ${
        params.type || ''
      }, page: ${params.page || 1}, per_page: ${params.per_page || 10}`
    );
    const response = await AiGreenTickApi.reports.fetchByUrl(params.id, {
      type: params.type || '',
      page: params.page || 1,
      per_page: params.per_page || 10,
    });
    return response;
  } catch (error: any) {
    if (error.response) {
      const errorMessage =
        error.response.data?.error ||
        error.response.data?.message ||
        'Failed to fetch report details';
      return rejectWithValue(errorMessage);
    } else if (error.request) {
      return rejectWithValue('Network error. Please check your connection.');
    } else {
      return rejectWithValue(error.message || 'An unexpected error occurred.');
    }
  }
});

const initialState: ReportsState = {
  reports: [],
  currentReport: null,
  currentReportDetails: null,
  currentReportPagination: null,
  currentPage: 1,
  lastPage: 1,
  perPage: 10,
  total: 0,
  filters: {
    search: '',
    from: '',
    to: '',
    type: '',
    page: 1,
    per_page: 10,
  },
  isLoading: false,
  isLoadingCurrentReport: false,
  error: null,
  currentReportError: null,
};

const reportsSlice = createSlice({
  name: 'reports',
  initialState,
  reducers: {
    clearError: (state) => {
      state.error = null;
    },

    clearCurrentReportError: (state) => {
      state.currentReportError = null;
    },

    setFilters: (state, action: PayloadAction<Partial<ReportsFilters>>) => {
      state.filters = { ...state.filters, ...action.payload };

      if (Object.keys(action.payload).some((key) => key !== 'page')) {
        state.filters.page = 1;
      }
    },

    clearFilters: (state) => {
      state.filters = {
        search: '',
        from: '',
        to: '',
        type: '',
        page: 1,
        per_page: 10,
      };
    },

    setLoading: (state, action: PayloadAction<boolean>) => {
      state.isLoading = action.payload;
    },

    clearReports: (state) => {
      state.reports = [];
      state.currentPage = 1;
      state.lastPage = 1;
      state.total = 0;
    },

    clearCurrentReport: (state) => {
      state.currentReport = null;
      state.currentReportDetails = null;
      state.currentReportPagination = null;
      state.currentReportError = null;
    },
  },
  extraReducers: (builder) => {
    builder

      .addCase(fetchReports.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchReports.fulfilled, (state, action) => {
        console.log(action.payload);
        state.isLoading = false;
        state.reports = action.payload.data.data;
        state.currentPage = action.payload.data.current_page;
        state.lastPage = action.payload.data.last_page;
        state.perPage = action.payload.data.per_page;
        state.total = action.payload.data.total;
        state.error = null;
      })
      .addCase(fetchReports.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload || 'Failed to fetch reports';
      })

      .addCase(fetchReportById.pending, (state) => {
        state.isLoadingCurrentReport = true;
        state.currentReportError = null;
      })
      .addCase(fetchReportById.fulfilled, (state, action) => {
        console.log('Report fetched successfully:', action.payload);
        state.isLoadingCurrentReport = false;
        console.log(action.payload);
        state.currentReport = action.payload;
        state.currentReportError = null;
      })
      .addCase(fetchReportById.rejected, (state, action) => {
        state.isLoadingCurrentReport = false;
        state.currentReportError = action.payload || 'Failed to fetch report';
      })

      .addCase(fetchReportByUrl.pending, (state) => {
        state.isLoadingCurrentReport = true;
        state.currentReportError = null;
      })
      .addCase(fetchReportByUrl.fulfilled, (state, action) => {
        console.log('Report details fetched successfully:', action.payload);
        state.isLoadingCurrentReport = false;

        state.currentReportDetails = action.payload.data?.data || [];

        if (action.payload.data) {
          state.currentReportPagination = {
            currentPage: action.payload.data.current_page,
            lastPage: action.payload.data.last_page,
            perPage: action.payload.data.per_page,
            total: action.payload.data.total,
          };
        }

        state.currentReportError = null;
      })
      .addCase(fetchReportByUrl.rejected, (state, action) => {
        state.isLoadingCurrentReport = false;
        state.currentReportError =
          action.payload || 'Failed to fetch report details';
      });
  },
});

// Export actions
export const {
  clearError,
  clearCurrentReportError,
  setFilters,
  clearFilters,
  setLoading,
  clearReports,
  clearCurrentReport,
} = reportsSlice.actions;

// Selectors
export const selectReports = (state: { reports: ReportsState }) =>
  state.reports.reports;
export const selectCurrentReport = (state: { reports: ReportsState }) =>
  state.reports.currentReport;
export const selectCurrentReportDetails = (state: { reports: ReportsState }) =>
  state.reports.currentReportDetails;
export const selectCurrentReportPagination = (state: {
  reports: ReportsState;
}) => state.reports.currentReportPagination;
export const selectReportsLoading = (state: { reports: ReportsState }) =>
  state.reports.isLoading;
export const selectCurrentReportLoading = (state: { reports: ReportsState }) =>
  state.reports.isLoadingCurrentReport;
export const selectReportsError = (state: { reports: ReportsState }) =>
  state.reports.error;
export const selectCurrentReportError = (state: { reports: ReportsState }) =>
  state.reports.currentReportError;
export const selectReportsFilters = (state: { reports: ReportsState }) =>
  state.reports.filters;
export const selectReportsPagination = (state: { reports: ReportsState }) => ({
  currentPage: state.reports.currentPage,
  lastPage: state.reports.lastPage,
  perPage: state.reports.perPage,
  total: state.reports.total,
});
export const selectReportsState = (state: { reports: ReportsState }) =>
  state.reports;

// Export reducer
export default reportsSlice.reducer;
