import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import AiGreenTickApi from '@/services/api';

export interface User {
  id: number;
  role_id: number;
  created_by: number | null;
  country_id: number;
  name: string;
  mobile: string;
  profile_photo: string | null;
  rememberToken: string | null;
  api_token: string;
  email: string;
  company_name: string | null;
  city: string | null;
  market_msg_charge: number | null;
  utilty_msg_charge: number;
  auth_msg_charge: number;
  balance: number;
  balance_enabled: number;
  online_status: string;
  agent_id: number | null;
  credit: number;
  debit: number;
  status: string;
  domain: string | null;
  logo: string | null;
  is_demo: string;
  demo_end: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  webhook_token: string | null;
  country: {
    id: number;
    name: string;
    mobile_code: string;
    created_at: string;
    updated_at: string;
    deleted_at: string | null;
  };
  agents: any[];
  users: any[];
}

export interface DashboardData {
  chatbot_count: number;
  template_count: number;
  report_count: number;
  user: User;
  balance: number;
}

export interface DashboardState {
  data: DashboardData | null;
  loading: boolean;
  error: string | null;
  lastUpdated: string | null;
}

const initialState: DashboardState = {
  data: null,
  loading: false,
  error: null,
  lastUpdated: null,
};

export const fetchDashboardData = createAsyncThunk(
  'dashboard/fetchData',
  async (_, { rejectWithValue }) => {
    try {
      const response = await AiGreenTickApi.dashboard.fetchData();
   
      return response.data
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || 'Failed to fetch dashboard data'
      );
    }
  }
);

const dashboardSlice = createSlice({
  name: 'dashboard',
  initialState,
  reducers: {
    clearError: (state) => {
      state.error = null;
    },
    resetDashboard: (state) => {
      return initialState;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchDashboardData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchDashboardData.fulfilled, (state, action) => {
        state.loading = false;
        console.log('hello');
        console.log(action.payload);
        state.data = action.payload
        state.error = null;
        state.lastUpdated = new Date().toISOString();
      })
      .addCase(fetchDashboardData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { clearError, resetDashboard } = dashboardSlice.actions;

export const selectDashboardData = (state: { dashboard: DashboardState }) =>
  state.dashboard.data;
export const selectDashboardLoading = (state: { dashboard: DashboardState }) =>
  state.dashboard.loading;
export const selectDashboardError = (state: { dashboard: DashboardState }) =>
  state.dashboard.error;
export const selectDashboardLastUpdated = (state: {
  dashboard: DashboardState;
}) => state.dashboard.lastUpdated;

export default dashboardSlice.reducer;
