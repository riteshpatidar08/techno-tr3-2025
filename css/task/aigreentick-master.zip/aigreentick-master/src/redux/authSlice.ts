import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import { LoginRequest, LoginResponse, AuthState, User } from '../types/auth';
import { AiGreenTickApi } from '@/services/api';

export const loginUser = createAsyncThunk<
  LoginResponse,
  LoginRequest,
  { rejectValue: string }
>('auth/loginUser', async (credentials, { rejectWithValue }) => {
  try {
    const data = await AiGreenTickApi.auth.login(credentials);

    if (data.success) {
      localStorage.setItem('auth_token', data.success.api_token);
      localStorage.setItem('user', JSON.stringify(data.success));
    }
    return data;
  } catch (error: any) {
    if (error.response) {
      const errorMessage =
        error.response.data?.error ||
        error.response.data?.message ||
        'Login failed';
      return rejectWithValue(errorMessage);
    } else if (error.request) {
      return rejectWithValue('Network error. Please check your connection.');
    } else {
      return rejectWithValue(error.message || 'An unexpected error occurred.');
    }
  }
});

export const logoutUser = createAsyncThunk('auth/logoutUser', async () => {
  try {
    await AiGreenTickApi.auth.logout();
  } catch (error) {
    console.warn('Logout request failed, but clearing local data anyway');
  }

  localStorage.removeItem('auth_token');
  localStorage.removeItem('user');
});

export const registerUser = createAsyncThunk<
  LoginResponse,
  { name: string; email: string; password: string; mobile: string },
  { rejectValue: string }
>('auth/registerUser', async (userData, { rejectWithValue }) => {
  try {
    const data = await AiGreenTickApi.auth.register(userData);

    if ('success' in data) {
      localStorage.setItem('auth_token', data.success.api_token);
      localStorage.setItem('user', JSON.stringify(data.success));
      return data;
    } else {
      return rejectWithValue(data.error);
    }
  } catch (error: any) {
    if (error.response) {
      const errorMessage =
        error.response.data?.error ||
        error.response.data?.message ||
        'Registration failed';
      return rejectWithValue(errorMessage);
    } else if (error.request) {
      return rejectWithValue('Network error. Please check your connection.');
    } else {
      return rejectWithValue(error.message || 'An unexpected error occurred.');
    }
  }
});

export const initializeAuth = createAsyncThunk(
  'auth/initializeAuth',
  async () => {
    const token = localStorage.getItem('auth_token');
    const userString = localStorage.getItem('user');

    if (token && userString) {
      try {
        const user = JSON.parse(userString);

        AiGreenTickApi.utils.setAuthToken(token);
        return { user, token };
      } catch (error) {
        localStorage.removeItem('auth_token');
        localStorage.removeItem('user');
        throw new Error('Stored user data is corrupted');
      }
    }

    throw new Error('No stored authentication data');
  }
);

const initialState: AuthState = {
  user: null,
  token: localStorage.getItem('ai_green_tick_token') || null,
  isLoading: false,
  error: null,
  isAuthenticated: localStorage.getItem('isAuthenticated') || null,
};

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    clearError: (state) => {
      state.error = null;
    },
    setCredentials: (
      state,
      action: PayloadAction<{ user: User; token: string }>
    ) => {
      state.user = action.payload.user;
      state.token = action.payload.token;
      state.isAuthenticated = true;

      AiGreenTickApi.utils.setAuthToken(action.payload.token);
    },
    clearCredentials: (state) => {
      state.user = null;
      state.token = null;
      state.isAuthenticated = false;

      localStorage.removeItem('ai_green_tick_token');
      localStorage.removeItem('ai_green_tick_user');
    },
    logout: (state) => {
      state.user = null;
      state.token = null;
      state.isAuthenticated = false;
      state.error = null;
      state.isLoading = false;

      
      localStorage.removeItem('auth_token');
      localStorage.removeItem('user');
      localStorage.removeItem('isAuthenticated');
    },
    setLoading: (state, action: PayloadAction<boolean>) => {
      state.isLoading = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder

      .addCase(loginUser.pending, (state, action) => {
        const isLoginPage = window.location.pathname === '/login';
        if (!isLoginPage) {
          state.isLoading = true;
        }
        state.error = null;
      })
      .addCase(loginUser.fulfilled, (state, action) => {
        state.isLoading = false;
        localStorage.setItem('isAuthenticated', 'true');
        state.user = action.payload.success;
        state.token = action.payload.success.api_token;
        state.isAuthenticated = true;
        state.error = null;
      })
      .addCase(loginUser.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload || 'Login failed';
        state.isAuthenticated = false;
        state.user = null;
        state.token = null;
      })

      .addCase(registerUser.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(registerUser.fulfilled, (state, action) => {
        state.isLoading = false;
        state.user = action.payload.success;
        state.token = action.payload.success.api_token;
        state.isAuthenticated = true;
        state.error = null;
      })
      .addCase(registerUser.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload || 'Registration failed';
        state.isAuthenticated = false;
      })

      .addCase(logoutUser.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(logoutUser.fulfilled, (state) => {
        state.isLoading = false;
        state.user = null;
        state.token = null;
        state.isAuthenticated = false;
        state.error = null;
      })
      .addCase(logoutUser.rejected, (state) => {
        state.isLoading = false;
        state.user = null;
        state.token = null;
        state.isAuthenticated = false;
      })

      .addCase(initializeAuth.fulfilled, (state, action) => {
        state.user = action.payload.user;
        state.token = action.payload.token;
        state.isAuthenticated = true;
        state.error = null;
      })
      .addCase(initializeAuth.rejected, (state) => {
        state.user = null;
        state.token = null;
        state.isAuthenticated = false;
      });
  },
});

export const { clearError, setCredentials, clearCredentials, setLoading , logout } =
  authSlice.actions;
export const selectAuth = (state: { auth: AuthState }) => state.auth;
export const selectUser = (state: { auth: AuthState }) => state.auth.user;
export const selectToken = (state: { auth: AuthState }) => state.auth.token;
export const selectIsAuthenticated = (state: { auth: AuthState }) =>
  state.auth.isAuthenticated;
export const selectIsLoading = (state: { auth: AuthState }) =>
  state.auth.isLoading;
export const selectError = (state: { auth: AuthState }) => state.auth.error;

export default authSlice.reducer;
