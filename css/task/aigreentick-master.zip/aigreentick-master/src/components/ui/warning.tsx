import React from 'react';
import { Button } from '@/components/ui/button';
import {
  AlertCircle,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Info,
  RefreshCw,
  X,
  ChevronRight,
} from 'lucide-react';

export type WarningType = 'error' | 'warning' | 'success' | 'info';

export interface WarningAction {
  label: string;
  onClick: () => void;
  variant?: 'default' | 'outline' | 'ghost' | 'destructive';
  icon?: React.ComponentType<{ className?: string }>;
  loading?: boolean;
  className?: string;
  disabled?: boolean;
}

export interface WarningComponentProps {
  type: WarningType;
  title: string;
  message?: string;
  description?: string;
  actions?: WarningAction[];
  onClose?: () => void;
  dismissible?: boolean;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showIcon?: boolean;
  bordered?: boolean;
  rounded?: boolean;
}

const WarningComponent: React.FC<WarningComponentProps> = ({
  type = 'info',
  title,
  message,
  description,
  actions = [],
  onClose,
  dismissible = false,
  className = '',
  size = 'md',
  showIcon = true,
  bordered = true,
  rounded = true,
}) => {
  const getIcon = () => {
    switch (type) {
      case 'error':
        return XCircle;
      case 'warning':
        return AlertTriangle;
      case 'success':
        return CheckCircle;
      case 'info':
      default:
        return AlertCircle;
    }
  };

  const getStyles = () => {
    switch (type) {
      case 'error':
        return {
          container: 'bg-red-50 border-red-200 text-red-800',
          border: 'border-l-red-500',
          icon: 'text-red-500',
          title: 'text-red-900',
          message: 'text-red-700',
          buttonStyles: {
            default: 'bg-red-600 hover:bg-red-700 text-white border-red-600',
            outline:
              'border-red-300 text-red-700 hover:bg-red-50 hover:text-red-800',
            ghost: 'text-red-600 hover:bg-red-100 hover:text-red-700',
          },
        };
      case 'warning':
        return {
          container: 'bg-yellow-50 border-yellow-200 text-yellow-800',
          border: 'border-l-yellow-500',
          icon: 'text-yellow-500',
          title: 'text-yellow-900',
          message: 'text-yellow-700',
          buttonStyles: {
            default:
              'bg-yellow-600 hover:bg-yellow-700 text-white border-yellow-600',
            outline:
              'border-yellow-300 text-yellow-700 hover:bg-yellow-50 hover:text-yellow-800',
            ghost: 'text-yellow-600 hover:bg-yellow-100 hover:text-yellow-700',
          },
        };
      case 'success':
        return {
          container: 'bg-green-50 border-green-200 text-green-800',
          border: 'border-l-green-500',
          icon: 'text-green-500',
          title: 'text-green-900',
          message: 'text-green-700',
          buttonStyles: {
            default:
              'bg-green-600 hover:bg-green-700 text-white border-green-600',
            outline:
              'border-green-300 text-green-700 hover:bg-green-50 hover:text-green-800',
            ghost: 'text-green-600 hover:bg-green-100 hover:text-green-700',
          },
        };
      case 'info':
      default:
        return {
          container: 'bg-blue-50 border-blue-200 text-blue-800',
          border: 'border-l-blue-500',
          icon: 'text-blue-500',
          title: 'text-blue-900',
          message: 'text-blue-700',
          buttonStyles: {
            default: 'bg-blue-600 hover:bg-blue-700 text-white border-blue-600',
            outline:
              'border-blue-300 text-blue-700 hover:bg-blue-50 hover:text-blue-800',
            ghost: 'text-blue-600 hover:bg-blue-100 hover:text-blue-700',
          },
        };
    }
  };

  const getSizeStyles = () => {
    switch (size) {
      case 'sm':
        return {
          padding: 'p-3',
          iconSize: 'w-4 h-4',
          titleSize: 'text-sm',
          messageSize: 'text-xs',
          buttonSize: 'sm' as const,
        };
      case 'lg':
        return {
          padding: 'p-6',
          iconSize: 'w-6 h-6',
          titleSize: 'text-lg',
          messageSize: 'text-base',
          buttonSize: 'default' as const,
        };
      case 'md':
      default:
        return {
          padding: 'p-4',
          iconSize: 'w-5 h-5',
          titleSize: 'text-base',
          messageSize: 'text-sm',
          buttonSize: 'sm' as const,
        };
    }
  };

  const Icon = getIcon();
  const styles = getStyles();
  const sizeStyles = getSizeStyles();

  const containerClasses = [
    styles.container,
    bordered ? `border ${styles.border}` : '',
    rounded ? 'rounded-lg' : '',
    sizeStyles.padding,
    'relative',
    className,
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <div className={containerClasses}>
      {dismissible && onClose && (
        <button
          onClick={onClose}
          className={`absolute top-3 right-3 ${styles.icon} hover:opacity-70 transition-opacity`}
          aria-label="Close"
        >
          <X className="w-4 h-4" />
        </button>
      )}

      <div className="flex items-start space-x-3">
        {showIcon && (
          <div className="flex-shrink-0">
            <Icon className={`${sizeStyles.iconSize} ${styles.icon}`} />
          </div>
        )}

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h3
                className={`font-semibold ${sizeStyles.titleSize} ${styles.title}`}
              >
                {title}
              </h3>
              {/* Message */}
              {message && (
                <p
                  className={`mt-1 ${sizeStyles.messageSize} ${styles.message}`}
                >
                  {message}
                </p>
              )}

              {description && (
                <p
                  className={`mt-2 ${sizeStyles.messageSize} ${styles.message} opacity-80`}
                >
                  {description}
                </p>
              )}
            </div>
          </div>

          {actions.length > 0 && (
            <div className="mt-4 flex flex-wrap items-center gap-2">
              {actions.map((action, index) => {
                const ActionIcon = action.icon;
                const variant = action.variant || 'outline';

                // Get the appropriate button styling based on variant and warning type
                const getButtonClassName = () => {
                  if (action.className) {
                    return action.className;
                  }

                  // Use type-specific styling if no custom className is provided
                  return (
                    styles.buttonStyles[variant] || styles.buttonStyles.outline
                  );
                };

                const buttonClassName = getButtonClassName();

                return (
                  <Button
                    key={index}
                    onClick={action.onClick}
                    variant={variant}
                    size={sizeStyles.buttonSize}
                    disabled={action.loading || action.disabled}
                    className={buttonClassName}
                  >
                    {action.loading ? (
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    ) : ActionIcon ? (
                      <ActionIcon className="w-4 h-4 mr-2" />
                    ) : null}
                    {action.label}
                  </Button>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export const ErrorWarning: React.FC<Omit<WarningComponentProps, 'type'>> = (
  props
) => <WarningComponent {...props} type="error" />;

export const SuccessWarning: React.FC<Omit<WarningComponentProps, 'type'>> = (
  props
) => <WarningComponent {...props} type="success" />;

export const InfoWarning: React.FC<Omit<WarningComponentProps, 'type'>> = (
  props
) => <WarningComponent {...props} type="info" />;

export const AlertWarning: React.FC<Omit<WarningComponentProps, 'type'>> = (
  props
) => <WarningComponent {...props} type="warning" />;

export const useWarning = () => {
  const [warnings, setWarnings] = React.useState<
    Array<WarningComponentProps & { id: string }>
  >([]);

  const addWarning = (warning: Omit<WarningComponentProps, 'onClose'>) => {
    const id = Math.random().toString(36).substr(2, 9);
    setWarnings((prev) => [
      ...prev,
      { ...warning, id, onClose: () => removeWarning(id) },
    ]);
    return id;
  };

  const removeWarning = (id: string) => {
    setWarnings((prev) => prev.filter((w) => w.id !== id));
  };

  const clearWarnings = () => {
    setWarnings([]);
  };

  return {
    warnings,
    addWarning,
    removeWarning,
    clearWarnings,
  };
};

export const WarningContext = React.createContext<{
  addWarning: (warning: Omit<WarningComponentProps, 'onClose'>) => string;
  removeWarning: (id: string) => void;
  clearWarnings: () => void;
} | null>(null);

export const WarningProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const { warnings, addWarning, removeWarning, clearWarnings } = useWarning();

  return (
    <WarningContext.Provider
      value={{ addWarning, removeWarning, clearWarnings }}
    >
      {children}

      <div className="fixed top-4 right-4 z-50 space-y-2 max-w-md">
        {warnings
          .filter((w) => w.dismissible !== false)
          .map((warning) => (
            <WarningComponent key={warning.id} {...warning} />
          ))}
      </div>
    </WarningContext.Provider>
  );
};

export const useGlobalWarning = () => {
  const context = React.useContext(WarningContext);
  if (!context) {
    throw new Error('useGlobalWarning must be used within a WarningProvider');
  }
  return context;
};

export default WarningComponent;

/*
<WarningComponent
  type="error"
  title="Connection Error"
  message="Failed to connect to the server"
  actions={[
    {
      label: "Retry",
      onClick: handleRetry,
      icon: RefreshCw,
      variant: "default"
    },
    {
      label: "Cancel",
      onClick: handleCancel,
      variant: "outline"
    },
    {
      label: "Settings",
      onClick: handleSettings,
      variant: "ghost"
    }
  ]}
  dismissible
/>
*/
