import { useEffect } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import {
  selectIsAuthenticated,
  selectIsLoading,
  initializeAuth,
} from '@/redux/authSlice';

interface ProtectedRoutesProps {
  children: React.ReactNode;
  redirectTo?: string;
  requireAuth?: boolean;
}

const ProtectedRoutes: React.FC<ProtectedRoutesProps> = ({
  children,
  redirectTo = '/login',
  requireAuth = true,
}) => {
 
  const location = useLocation();
  const isAuthenticated = useSelector(selectIsAuthenticated);
  const isLoading = useSelector(selectIsLoading);
  console.log(isAuthenticated);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }
  if (requireAuth && !isAuthenticated) {
    return <Navigate to={redirectTo} state={{ from: location }} replace />;
  }
  if (!requireAuth && isAuthenticated) {
    return <Navigate to="/dashboard" replace />;
  }
  return <>{children}</>;
};

export default ProtectedRoutes;
export const PublicRoutes: React.FC<{
  children: React.ReactNode;
  redirectTo?: string;
}> = ({ children, redirectTo = '/dashboard' }) => {
  return (
    <ProtectedRoutes requireAuth={false} redirectTo={redirectTo}>
      {children}
    </ProtectedRoutes>
  );
};
export const withProtectedRoute = <P extends object>(
  Component: React.ComponentType<P>,
  options?: { redirectTo?: string; requireAuth?: boolean }
) => {
  const WrappedComponent: React.FC<P> = (props) => (
    <ProtectedRoutes {...options}>
      <Component {...props} />
    </ProtectedRoutes>
  );

  WrappedComponent.displayName = `withProtectedRoute(${
    Component.displayName || Component.name
  })`;

  return WrappedComponent;
};
