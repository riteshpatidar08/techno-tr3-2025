import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Badge } from './UIComponents';
import { NavigationItem } from './types';

interface NavigationItemsProps {
  items: NavigationItem[];
  mounted: boolean;
  hoveredItem: string | null;
  onHover: (item: string | null) => void;
  onNavigate: (itemName: string) => void;
}

export const NavigationItems: React.FC<NavigationItemsProps> = ({
  items,
  mounted,
  hoveredItem,
  onHover,
  onNavigate,
}) => {
  const location = useLocation();

  return (
    <div className="hidden lg:flex items-center space-x-1">
      {items.map((item: NavigationItem, index: number) => {
        const Icon = item.icon;
        const isActive = location.pathname === item.href;

        return (
          <Link
            key={item.name}
            to={item.href}
            className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium relative overflow-hidden group transition-all duration-300 ease-out transform hover:scale-105 hover:-translate-y-0.5 ${
              isActive
                ? 'text-primary bg-primary/10 shadow-sm ring-1 ring-primary/20'
                : 'text-muted-foreground hover:text-foreground hover:bg-accent hover:shadow-lg'
            } ${
              mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
            onClick={() => onNavigate(item.name)}
            onMouseEnter={() => onHover(item.name)}
            onMouseLeave={() => onHover(null)}
            style={{
              transitionDelay: mounted ? `${index * 50}ms` : '0ms',
            }}
          >
            {/* Hover Background Effect */}
            <div
              className={`absolute inset-0 bg-gradient-to-r from-primary/0 via-primary/10 to-primary/0 transition-all duration-500 ease-out ${
                hoveredItem === item.name
                  ? 'opacity-100 scale-100'
                  : 'opacity-0 scale-95'
              }`}
            />

            {/* Active/Hover Bottom Border */}
            <div
              className={`absolute bottom-0 left-0 h-0.5 bg-gradient-to-r from-primary via-chart-1 to-primary transition-all duration-300 ease-out ${
                isActive ? 'w-full' : 'w-0 group-hover:w-full'
              }`}
            />

            {/* Active Press Effect */}
            <div className="absolute inset-0 rounded-lg">
              <div className="absolute inset-0 rounded-lg bg-primary opacity-0 group-active:opacity-25 scale-0 group-active:scale-100 transition-all duration-300 ease-out" />
            </div>

            {/* Icon */}
            <Icon
              className={`w-4 h-4 relative z-10 transition-all duration-300 ease-out ${
                isActive
                  ? 'text-primary scale-110'
                  : 'group-hover:text-primary group-hover:scale-110 group-hover:rotate-6'
              }`}
            />

            {/* Label */}
            <span
              className={`relative z-10 transition-all duration-300 ease-out ${
                hoveredItem === item.name ? 'translate-x-0.5' : ''
              }`}
            >
              {item.name}
            </span>

            {/* Badge */}
            {item.badge && (
              <Badge
                variant={item.badgeVariant || 'secondary'}
                className={`ml-1 text-xs px-1.5 py-0.5 relative z-10 transition-all duration-300 ease-out ${
                  hoveredItem === item.name
                    ? 'scale-110 shadow-sm'
                    : 'animate-pulse'
                } ${
                  item.badgeVariant === 'destructive'
                    ? 'bg-destructive text-destructive-foreground'
                    : item.badgeVariant === 'outline'
                    ? 'bg-background border-border text-foreground hover:bg-accent'
                    : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                }`}
              >
                {item.badge}
              </Badge>
            )}
          </Link>
        );
      })}
    </div>
  );
};
