import React from 'react';
import { Languages } from 'lucide-react';

interface LanguageButtonProps {
  mounted: boolean;
  onLanguageToggle: () => void;
}

export const LanguageButton: React.FC<LanguageButtonProps> = ({
  mounted,
  onLanguageToggle,
}) => {
  return (
    <button
      className={`hidden md:flex items-center space-x-1 px-3 py-2 rounded-lg text-gray-600 hover:text-gray-900 transition-all duration-300 ease-out hover:scale-105 hover:bg-gray-100 hover:shadow-lg group transform hover:-translate-y-0.5 ${
        mounted ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'
      }`}
      onClick={onLanguageToggle}
      type="button"
      style={{ transitionDelay: mounted ? '400ms' : '0ms' }}
    >
      <Languages className="w-4 h-4 transition-all duration-300 ease-out group-hover:rotate-180 group-hover:scale-110" />
      <span className="text-sm font-medium transition-all duration-300 ease-out group-hover:translate-x-0.5">
        RTL
      </span>
    </button>
  );
};
