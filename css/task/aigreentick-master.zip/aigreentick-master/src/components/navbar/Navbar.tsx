import React, { useState, useEffect } from 'react';
import { Menu } from 'lucide-react';
import logoImage from '@/assets/images/logos/aiGreenTick.png';
import { Logo } from './Logo';
import { NavigationItems } from './NavigationItems';
import { MoreDropdown } from './MoreDropdown';
import { LanguageButton } from './LanguageButton';
import { OptionsDropdown } from './OptionsDropdown';
import { UserDropdown } from './UserDropdown';
import { MobileMenu } from './MobileMenu';
import { NotificationDropdown } from './NotificationDropdown';
import { MetaConnectionButton } from './MetaConnectionButton';
import {
  navigationItems,
  popoverItems,
  userManagementItems,
  generalOptionsItems,
  profileMenuItems,
} from './constants';
import { NavbarProps } from './types';

const Navbar: React.FC<NavbarProps> = ({
  className = '',
  logoText = 'aiGreenTick',
  userImage,
  onNavigate,
}) => {
  const [dropdownOpen, setDropdownOpen] = useState<string | null>(null);
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);
  const [mounted, setMounted] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userInitials, setUserInitials] = useState<string>('');

  useEffect(() => {
    setMounted(true);

    try {
      const storedUserData = localStorage.getItem('ai_green_tick_user');
      if (storedUserData) {
        const userData = JSON.parse(storedUserData);
        if (userData.name) {
          const initials = userData.name
            .split(' ')
            .map((n: string) => n[0])
            .join('')
            .toUpperCase()
            .slice(0, 2);
          setUserInitials(initials);
        }
      } else {
        setUserInitials('U');
      }
    } catch (error) {
      console.error('Error loading user data from localStorage:', error);
      setUserInitials('U');
    }
  }, []);

  const handleNavClick = (itemName: string): void => {
    if (onNavigate) {
      onNavigate(itemName);
    }
    setMobileMenuOpen(false);
  };

  const handleDropdownItemClick = (action: string): void => {
    console.log(`${action} clicked`);
    setDropdownOpen(null);
  };

  const handleLanguageToggle = (): void => {
    console.log('Language toggle clicked');
  };

  return (
    <>
      <nav
        className={`bg-white fixed w-full top-0 z-100 border-b border-gray-200 px-4 py-3 ${className}`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-6">
            <button
              className="lg:hidden p-2 rounded-lg text-gray-600 hover:text-gray-900 hover:bg-gray-100 transition-all duration-200"
              onClick={() => setMobileMenuOpen(true)}
              type="button"
            >
              <Menu className="w-5 h-5" />
            </button>

            <Logo logoImage={logoImage} logoText={logoText} mounted={mounted} />

            <NavigationItems
              items={navigationItems}
              mounted={mounted}
              hoveredItem={hoveredItem}
              onHover={setHoveredItem}
              onNavigate={handleNavClick}
            />

            <div className="hidden lg:block">
              <MoreDropdown
                items={popoverItems}
                mounted={mounted}
                navigationItemsLength={navigationItems.length}
                dropdownOpen={dropdownOpen}
                onDropdownToggle={setDropdownOpen}
              />
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <NotificationDropdown
              mounted={mounted}
              dropdownOpen={dropdownOpen}
              onDropdownToggle={setDropdownOpen}
            />

            <MetaConnectionButton
              mounted={mounted}
              isConnected={false}
              onConnect={() => console.log('Connect to Meta')}
              onDisconnect={() => console.log('Disconnect from Meta')}
            />

            <LanguageButton
              mounted={mounted}
              onLanguageToggle={handleLanguageToggle}
            />

            <OptionsDropdown
              mounted={mounted}
              dropdownOpen={dropdownOpen}
              userManagementItems={userManagementItems}
              generalOptionsItems={generalOptionsItems}
              onDropdownToggle={setDropdownOpen}
              onDropdownItemClick={handleDropdownItemClick}
            />

            <UserDropdown
              userImage={userImage}
              userInitials={userInitials}
              mounted={mounted}
              dropdownOpen={dropdownOpen}
              profileMenuItems={profileMenuItems}
              onDropdownToggle={setDropdownOpen}
              onDropdownItemClick={handleDropdownItemClick}
            />
          </div>
        </div>

        {dropdownOpen && (
          <div
            className="fixed inset-0 z-40"
            onClick={() => setDropdownOpen(null)}
          />
        )}
      </nav>

      <MobileMenu
        isOpen={mobileMenuOpen}
        onClose={() => setMobileMenuOpen(false)}
        logoText={logoText}
        navigationItems={navigationItems}
        userManagementItems={userManagementItems}
        popoverItems={popoverItems}
        userImage={userImage}
        userInitials={userInitials}
        onNavigate={handleNavClick}
        onDropdownItemClick={handleDropdownItemClick}
      />

      <style jsx>{`
        @keyframes ping {
          75%,
          100% {
            transform: scale(2);
            opacity: 0;
          }
        }

        .animate-ping {
          animation: ping 1s cubic-bezier(0, 0, 0.2, 1) infinite;
        }

        .animation-delay-200 {
          animation-delay: 200ms;
        }

        @keyframes springIn {
          0% {
            opacity: 0;
            transform: scale(0.9) translateY(-10px);
          }
          50% {
            transform: scale(1.02) translateY(2px);
          }
          100% {
            opacity: 1;
            transform: scale(1) translateY(0);
          }
        }

        @keyframes shimmer {
          0% {
            background-position: -200% center;
          }
          100% {
            background-position: 200% center;
          }
        }

        .animate-shimmer {
          background: linear-gradient(
            90deg,
            transparent 25%,
            rgba(255, 255, 255, 0.3) 50%,
            transparent 75%
          );
          background-size: 200% 100%;
          animation: shimmer 2s infinite;
        }
      `}</style>
    </>
  );
};

export default Navbar;
