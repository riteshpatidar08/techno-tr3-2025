import React from 'react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Wifi,
  WifiOff,
  CheckCircle,
  AlertCircle,
  Settings,
  RefreshCw,
  ExternalLink,
  Shield,
} from 'lucide-react';

interface MetaConnectionButtonProps {
  mounted: boolean;
  isConnected: boolean;
  onConnect: () => void;
  onDisconnect: () => void;
}

export const MetaConnectionButton: React.FC<MetaConnectionButtonProps> = ({
  mounted,
  isConnected,
  onConnect,
  onDisconnect,
}) => {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          className={`relative p-2 rounded-lg transition-all duration-300 ease-out hover:scale-105 hover:shadow-lg group transform hover:-translate-y-0.5 ${
            isConnected
              ? 'text-green-600 hover:text-green-700 bg-green-50 hover:bg-green-100'
              : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
          } ${
            mounted ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'
          }`}
          style={{ transitionDelay: mounted ? '375ms' : '0ms' }}
          title={isConnected ? 'Meta Connected' : 'Meta Disconnected'}
        >
          {isConnected ? (
            <Wifi className="w-5 h-5 transition-all duration-300 ease-out group-hover:scale-110" />
          ) : (
            <WifiOff className="w-5 h-5 transition-all duration-300 ease-out group-hover:scale-110 group-hover:rotate-12" />
          )}

          <div
            className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 border-2 border-white rounded-full ${
              isConnected ? 'bg-green-400' : 'bg-red-400'
            }`}
          >
            {isConnected && (
              <div className="absolute inset-0 bg-green-400 rounded-full animate-ping opacity-75"></div>
            )}
          </div>

          <div className="absolute -top-1 -left-1 w-4 h-4 bg-blue-600 rounded-full flex items-center justify-center">
            <span className="text-white text-xs font-bold">f</span>
          </div>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-72 border-0 shadow-xl">
        <DropdownMenuLabel className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
            <span className="text-white text-sm font-bold">f</span>
          </div>
          <div>
            <span className="font-semibold">Meta Business</span>
            <div className="flex items-center space-x-1 mt-1">
              {isConnected ? (
                <>
                  <CheckCircle className="w-3 h-3 text-green-500" />
                  <span className="text-xs text-green-600 font-medium">
                    Connected
                  </span>
                </>
              ) : (
                <>
                  <AlertCircle className="w-3 h-3 text-red-500" />
                  <span className="text-xs text-red-600 font-medium">
                    Disconnected
                  </span>
                </>
              )}
            </div>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />

        <div className="p-3 bg-gray-50 m-2 rounded-lg">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-700">
              WhatsApp Business API
            </span>
            <div
              className={`w-2 h-2 rounded-full ${
                isConnected ? 'bg-green-400' : 'bg-red-400'
              }`}
            />
          </div>
          <p className="text-xs text-gray-600">
            {isConnected
              ? 'Your WhatsApp Business account is connected and ready to send messages.'
              : 'Connect your WhatsApp Business account to start sending messages.'}
          </p>
          {isConnected && (
            <div className="mt-2 text-xs text-gray-500">
              Phone: +1 (555) 123-4567
            </div>
          )}
        </div>

        {isConnected ? (
          <>
            <DropdownMenuItem className="cursor-pointer">
              <Settings className="w-4 h-4 mr-2" />
              Connection Settings
            </DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer">
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh Connection
            </DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer">
              <Shield className="w-4 h-4 mr-2" />
              Security Settings
            </DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer">
              <ExternalLink className="w-4 h-4 mr-2" />
              Meta Business Manager
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={onDisconnect}
              className="text-red-600 focus:text-red-600 cursor-pointer"
            >
              <WifiOff className="w-4 h-4 mr-2" />
              Disconnect Account
            </DropdownMenuItem>
          </>
        ) : (
          <>
            <DropdownMenuItem
              onClick={onConnect}
              className="cursor-pointer bg-blue-50 text-blue-600 focus:text-blue-700"
            >
              <Wifi className="w-4 h-4 mr-2" />
              Connect to Meta Business
            </DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer">
              <ExternalLink className="w-4 h-4 mr-2" />
              Setup Instructions
            </DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer">
              <Shield className="w-4 h-4 mr-2" />
              Security Requirements
            </DropdownMenuItem>
          </>
        )}

        <DropdownMenuSeparator />
        <div className="p-3 text-center">
          <p className="text-xs text-gray-500">
            Powered by Meta Business Platform
          </p>
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
