import React from 'react';
import { Link } from 'react-router-dom';

interface LogoProps {
  logoImage?: string;
  logoText: string;
  mounted: boolean;
}

export const Logo: React.FC<LogoProps> = ({ logoImage, logoText, mounted }) => {
  return (
    <Link
      to="/"
      className={`flex items-center space-x-2 transition-all duration-500 ${
        mounted ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'
      }`}
    >
      <div className="w-32 h-8 rounded-lg flex items-center justify-center relative overflow-hidden group cursor-pointer transform transition-all duration-300 ease-out hover:from-green-600 hover:to-green-700 hover:scale-105 hover:shadow-xl">
        <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -skew-x-12 translate-x-[-200%] group-hover:translate-x-[200%] transition-transform duration-1000 ease-out" />
        </div>

        <div className="absolute inset-0 rounded-lg opacity-0 group-hover:opacity-30 bg-white animate-ping" />

        {logoImage ? (
          <img
            src={logoImage}
            alt="Logo"
            className="w-36 object-contain relative z-10 transition-transform duration-300 ease-out"
          />
        ) : (
          <span className="text-white font-bold text-sm relative z-10 transition-all duration-300 ease-out group-hover:scale-105 group-hover:tracking-wider">
            {logoText}
          </span>
        )}
      </div>
    </Link>
  );
};
