import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { Avatar, AvatarFallback } from './UIComponents';
import { DropdownItem } from './types';

import { logout } from '@/redux/authSlice';

interface UserDropdownProps {
  userImage?: string;
  userInitials: string;
  mounted: boolean;
  dropdownOpen: string | null;
  profileMenuItems: DropdownItem[];
  onDropdownToggle: (dropdown: string | null) => void;
  onDropdownItemClick: (action: string) => void;
}

export const UserDropdown: React.FC<UserDropdownProps> = ({
  userImage,
  userInitials,
  mounted,
  dropdownOpen,
  profileMenuItems,
  onDropdownToggle,
  onDropdownItemClick,
}) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const handleSignOut = () => {
    try {
      onDropdownToggle(null);

      dispatch(logout());

      console.log('Successfully signed out');

      navigate('/login', { replace: true });
    } catch (error) {
      console.error('Error during sign out:', error);

      navigate('/login', { replace: true });
    }
  };

  const handleItemClick = (item: DropdownItem) => {
    if (
      item.action === 'signout' ||
      item.action === 'logout' ||
      item.label.toLowerCase().includes('sign out') ||
      item.label.toLowerCase().includes('logout')
    ) {
      handleSignOut();
    } else {
      onDropdownItemClick(item.action);
    }
  };

  return (
    <div className="relative cursor-pointer">
      <button
        className={`relative h-10 w-10 rounded-full transition-all duration-300 ease-out hover:scale-110 hover:shadow-xl group transform hover:-translate-y-0.5 ${
          mounted ? 'opacity-100 scale-100' : 'opacity-0 scale-75'
        }`}
        onClick={() =>
          onDropdownToggle(dropdownOpen === 'profile' ? null : 'profile')
        }
        type="button"
        style={{ transitionDelay: mounted ? '500ms' : '0ms' }}
      >
        <Avatar className="cursor-pointer h-10 w-10 rounded-full transition-all duration-300 ease-out group-hover:ring-2 group-hover:ring-green-500 group-hover:ring-offset-2 overflow-hidden">
          {userImage ? (
            <img
              src={userImage}
              alt="Profile"
              className="w-full h-full object-cover transition-transform duration-300 ease-out group-hover:scale-110"
            />
          ) : (
            <AvatarFallback className="bg-gradient-to-br from-green-500 to-green-600 text-white transition-all duration-300 ease-out group-hover:from-green-600 group-hover:to-green-700 w-full h-full">
              {userInitials}
            </AvatarFallback>
          )}
        </Avatar>

        <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-400 border-2 border-white rounded-full shadow-sm">
          <div className="absolute inset-0 bg-green-400 rounded-full animate-ping opacity-75"></div>
          <div className="absolute inset-0 bg-green-400 rounded-full animate-ping animation-delay-200 opacity-50"></div>
        </div>
      </button>

      <div
        className={`absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-gray-200 z-50 transition-all duration-300 ease-out transform origin-top-right ${
          dropdownOpen === 'profile'
            ? 'opacity-100 scale-100 translate-y-0'
            : 'opacity-0 scale-95 -translate-y-2 pointer-events-none'
        }`}
      >
        {profileMenuItems.map((item, index) => {
          const isSignOutItem =
            item.action === 'signout' ||
            item.action === 'logout' ||
            item.label.toLowerCase().includes('sign out') ||
            item.label.toLowerCase().includes('logout');

          if (isSignOutItem) {
            return (
              <button
                key={item.action}
                onClick={() => handleItemClick(item)}
                className={`w-full flex items-center px-4 py-3 text-sm transition-all duration-200 ease-out group first:rounded-t-xl last:rounded-b-xl ${
                  item.color === 'red'
                    ? 'text-red-600 hover:bg-gradient-to-r hover:from-red-50 hover:to-red-100'
                    : 'text-gray-700 hover:bg-gradient-to-r hover:from-green-50 hover:to-green-100 hover:text-green-600'
                } ${
                  dropdownOpen === 'profile'
                    ? 'opacity-100 translate-x-0'
                    : 'opacity-0 -translate-x-4'
                }`}
                style={{
                  transitionDelay:
                    dropdownOpen === 'profile' ? `${index * 50}ms` : '0ms',
                }}
              >
                <item.icon className="w-4 h-4 mr-3 transition-all duration-200 ease-out group-hover:scale-110 group-hover:rotate-12" />
                <span className="transition-transform duration-200 ease-out group-hover:translate-x-1">
                  {item.label}
                </span>
              </button>
            );
          }

          return (
            <Link
              to={item.href}
              key={item.action}
              onClick={() => handleItemClick(item)}
              className={`w-full flex items-center px-4 py-3 text-sm transition-all duration-200 ease-out group first:rounded-t-xl last:rounded-b-xl ${
                item.color === 'red'
                  ? 'text-red-600 hover:bg-gradient-to-r hover:from-red-50 hover:to-red-100'
                  : 'text-gray-700 hover:bg-gradient-to-r hover:from-green-50 hover:to-green-100 hover:text-green-600'
              } ${
                dropdownOpen === 'profile'
                  ? 'opacity-100 translate-x-0'
                  : 'opacity-0 -translate-x-4'
              }`}
              style={{
                transitionDelay:
                  dropdownOpen === 'profile' ? `${index * 50}ms` : '0ms',
              }}
            >
              <item.icon className="w-4 h-4 mr-3 transition-all duration-200 ease-out group-hover:scale-110 group-hover:rotate-12" />
              <span className="transition-transform duration-200 ease-out group-hover:translate-x-1">
                {item.label}
              </span>
            </Link>
          );
        })}
      </div>
    </div>
  );
};
