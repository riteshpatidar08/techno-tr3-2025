import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Bell,
  CheckCircle,
  AlertCircle,
  Info,
  MessageSquare,
  Settings,
  Trash2,
} from 'lucide-react';

interface NotificationDropdownProps {
  mounted: boolean;
  dropdownOpen: string | null;
  onDropdownToggle: (dropdown: string | null) => void;
}
const notifications = [
  {
    id: 1,
    type: 'success',
    title: 'Template Approved',
    message: 'Your "welcome_message" template has been approved by Meta.',
    time: '2 minutes ago',
    read: false,
  },
  {
    id: 2,
    type: 'warning',
    title: 'Message Limit Warning',
    message: 'You have used 85% of your monthly message limit.',
    time: '1 hour ago',
    read: false,
  },
  {
    id: 3,
    type: 'info',
    title: 'New Feature Available',
    message: 'Try our new broadcast scheduling feature.',
    time: '3 hours ago',
    read: true,
  },
  {
    id: 4,
    type: 'message',
    title: 'New Message Received',
    message: 'John Doe sent you a message on WhatsApp.',
    time: '5 hours ago',
    read: true,
  },
];

export const NotificationDropdown: React.FC<NotificationDropdownProps> = ({
  mounted,
  dropdownOpen,
  onDropdownToggle,
}) => {
  const unreadCount = notifications.filter((n) => !n.read).length;

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'warning':
        return <AlertCircle className="w-4 h-4 text-yellow-500" />;
      case 'info':
        return <Info className="w-4 h-4 text-blue-500" />;
      case 'message':
        return <MessageSquare className="w-4 h-4 text-purple-500" />;
      default:
        return <Bell className="w-4 h-4 text-gray-500" />;
    }
  };

  return (
    <DropdownMenu
      open={dropdownOpen === 'notifications'}
      onOpenChange={(open) => onDropdownToggle(open ? 'notifications' : null)}
    >
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          className={`relative p-2 rounded-lg text-gray-600 hover:text-gray-900 transition-all duration-300 ease-out hover:scale-105 hover:bg-gray-100 hover:shadow-lg group transform hover:-translate-y-0.5 ${
            mounted ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'
          }`}
          style={{ transitionDelay: mounted ? '350ms' : '0ms' }}
        >
          <Bell
            className={`w-5 h-5 transition-all duration-300 ease-out ${
              dropdownOpen === 'notifications'
                ? 'rotate-12 scale-110'
                : 'group-hover:rotate-12 group-hover:scale-110'
            }`}
          />
          {unreadCount > 0 && (
            <Badge className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center p-0 animate-pulse">
              {unreadCount > 9 ? '9+' : unreadCount}
            </Badge>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80 border-0 shadow-xl">
        <DropdownMenuLabel className="flex items-center justify-between">
          <span className="font-semibold">Notifications</span>
          <div className="flex items-center space-x-2">
            {unreadCount > 0 && (
              <Badge variant="secondary" className="text-xs">
                {unreadCount} new
              </Badge>
            )}
            <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
              <Settings className="w-3 h-3" />
            </Button>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />

        <div className="max-h-96 overflow-y-auto">
          {notifications.length === 0 ? (
            <div className="p-6 text-center">
              <Bell className="w-8 h-8 text-gray-300 mx-auto mb-2" />
              <p className="text-sm text-gray-500">No notifications</p>
            </div>
          ) : (
            notifications.map((notification, index) => (
              <DropdownMenuItem
                key={notification.id}
                className={`flex items-start p-4 cursor-pointer transition-all duration-200 ${
                  !notification.read ? 'bg-blue-50' : ''
                } ${
                  dropdownOpen === 'notifications'
                    ? 'opacity-100 translate-x-0'
                    : 'opacity-0 -translate-x-4'
                }`}
                style={{
                  transitionDelay:
                    dropdownOpen === 'notifications'
                      ? `${index * 50}ms`
                      : '0ms',
                }}
              >
                <div className="flex-shrink-0 mr-3 mt-1">
                  {getNotificationIcon(notification.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-sm font-medium text-gray-900 truncate">
                      {notification.title}
                    </p>
                    {!notification.read && (
                      <div className="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0 ml-2" />
                    )}
                  </div>
                  <p className="text-xs text-gray-600 mb-2 line-clamp-2">
                    {notification.message}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-500">
                      {notification.time}
                    </span>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-5 w-5 p-0 opacity-0 group-hover:opacity-100"
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </DropdownMenuItem>
            ))
          )}
        </div>

        <DropdownMenuSeparator />
        <DropdownMenuItem className="justify-center text-blue-600 hover:text-blue-700 cursor-pointer">
          <span className="text-sm font-medium">View all notifications</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
