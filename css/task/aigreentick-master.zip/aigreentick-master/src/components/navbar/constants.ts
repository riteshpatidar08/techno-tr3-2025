import {
  LayoutDashboard,
  Send,
  Bot,
  Inbox,
  SquareUser,
  FileText,
  MoreHorizontal,
  Radio,
  Settings,
  Users,
  Zap,
  HelpCircle,
  User,
  LogOut,
} from 'lucide-react';
import { NavigationItem, PopoverItem, DropdownItem } from './types';

export const navigationItems: NavigationItem[] = [
  {
    name: 'Dashboard',
    icon: LayoutDashboard,
    href: '/dashboard',
  },
  {
    name: 'Inbox',
    icon: Inbox,
    href: '/inbox',
  },
  {
    name: 'Campaigns',
    icon: Send,
    badge: 'New',
    badgeVariant: 'destructive',
    href: '/campaigns',
  },
  {
    name: 'Chatbots',
    icon: Bot,
    href: '/chatbots',
  },

  {
    name: 'Contacts',
    icon: SquareUser,
    href: '/phonebook',
  },
];

export const popoverItems: PopoverItem[] = [
  {
    name: 'API Docs',
    icon: FileText,
    href: '/api-docs',
    description: 'Access API documentation and keys',
  },
  {
    name: 'More features',
    icon: MoreHorizontal,
    href: '/features',
    description: 'Explore additional platform features',
  },
  {
    name: 'Broadcast',
    icon: Radio,
    href: '/broadcast-legacy',
    description: 'Legacy broadcast system',
    deprecated: true,
  },
  {
    name: 'Chatbot',
    icon: Bot,
    href: '/chatbot-legacy',
    description: 'Legacy chatbot interface',
    deprecated: true,
  },
  {
    name: 'Chatbot Flow',
    icon: Settings,
    href: '/chatbot-flow',
    description: 'Visual chatbot flow builder',
    deprecated: true,
  },
];

export const userManagementItems: DropdownItem[] = [
  {
    icon: Users,
    label: 'User Management',
    action: 'Manage Users',
    href: '/users',
    description: 'View and manage all users',
  },
];

export const generalOptionsItems: DropdownItem[] = [
  {
    icon: Zap,
    label: 'Integrations',
    action: 'Integrations',
    href: '/integrations',
  },
  {
    icon: Settings,
    label: 'Manage ',
    action: 'Manage',
    href: '/manage',
  },
  {
    icon: HelpCircle,
    label: 'Support',
    action: 'Support',
    href: '/support',
  },
];

export const profileMenuItems: DropdownItem[] = [
  {
    icon: User,
    label: 'Profile',
    action: 'Profile',
    href: '/user/profile',
    color: 'green',
  },
 
  {
    icon: LogOut,
    label: 'Sign Out',
    href: ' ',
    action: 'Sign Out',
    color: 'red',
  },
];
