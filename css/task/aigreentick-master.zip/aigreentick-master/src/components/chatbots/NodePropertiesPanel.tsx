import React, { useState, useEffect } from 'react';
import { Node } from 'reactflow';
import {
  X,
  Save,
  Image,
  FileText,
  Phone,
  Link,
  Clock,
  Hash,
  MessageSquare,
  User,
  Settings,
  Bot
} from 'lucide-react';

interface NodePropertiesPanelProps {
  selectedNode: Node | null;
  onUpdateNode: (nodeId: string, newData: any) => void;
  onClose: () => void;
}

const NodePropertiesPanel: React.FC<NodePropertiesPanelProps> = ({
  selectedNode,
  onUpdateNode,
  onClose,
}) => {
  const [nodeData, setNodeData] = useState<any>({});

  useEffect(() => {
    if (selectedNode) {
      setNodeData(selectedNode.data || {});
    }
  }, [selectedNode]);

  if (!selectedNode) return null;

  const handleSave = () => {
    onUpdateNode(selectedNode.id, nodeData);
    onClose();
  };

  const renderMessageProperties = () => (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Message Text
        </label>
        <textarea
          value={nodeData.message || ''}
          onChange={(e) =>
            setNodeData({ ...nodeData, message: e.target.value })
          }
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
          rows={4}
          placeholder="Enter your message..."
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Message Type
        </label>
        <select
          value={nodeData.messageType || 'text'}
          onChange={(e) =>
            setNodeData({ ...nodeData, messageType: e.target.value })
          }
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
        >
          <option value="text">Text Message</option>
          <option value="image">Image</option>
          <option value="document">Document</option>
          <option value="template">Template Message</option>
        </select>
      </div>

      {nodeData.messageType === 'image' && (
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <Image className="w-4 h-4 inline mr-1" />
            Image URL
          </label>
          <input
            type="url"
            value={nodeData.imageUrl || ''}
            onChange={(e) =>
              setNodeData({ ...nodeData, imageUrl: e.target.value })
            }
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
            placeholder="https://example.com/image.jpg"
          />
        </div>
      )}

      {nodeData.messageType === 'document' && (
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <FileText className="w-4 h-4 inline mr-1" />
            Document URL
          </label>
          <input
            type="url"
            value={nodeData.documentUrl || ''}
            onChange={(e) =>
              setNodeData({ ...nodeData, documentUrl: e.target.value })
            }
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
            placeholder="https://example.com/document.pdf"
          />
        </div>
      )}

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          <Clock className="w-4 h-4 inline mr-1" />
          Delay (seconds)
        </label>
        <input
          type="number"
          value={nodeData.delay || 0}
          onChange={(e) =>
            setNodeData({ ...nodeData, delay: parseInt(e.target.value) })
          }
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
          min="0"
          max="60"
        />
      </div>

      <div className="flex items-center space-x-2">
        <input
          type="checkbox"
          id="enableButtons"
          checked={nodeData.enableButtons || false}
          onChange={(e) =>
            setNodeData({ ...nodeData, enableButtons: e.target.checked })
          }
          className="rounded text-green-500 focus:ring-green-500"
        />
        <label htmlFor="enableButtons" className="text-sm text-gray-700">
          Add Interactive Buttons
        </label>
      </div>

      {nodeData.enableButtons && (
        <div className="space-y-3">
          <label className="block text-sm font-medium text-gray-700">
            Buttons
          </label>
          {(nodeData.buttons || []).map((button: any, index: number) => (
            <div key={index} className="flex space-x-2">
              <input
                type="text"
                value={button.text || ''}
                onChange={(e) => {
                  const newButtons = [...(nodeData.buttons || [])];
                  newButtons[index] = { ...button, text: e.target.value };
                  setNodeData({ ...nodeData, buttons: newButtons });
                }}
                className="flex-1 p-2 border border-gray-300 rounded"
                placeholder="Button text"
              />
              <select
                value={button.type || 'reply'}
                onChange={(e) => {
                  const newButtons = [...(nodeData.buttons || [])];
                  newButtons[index] = { ...button, type: e.target.value };
                  setNodeData({ ...nodeData, buttons: newButtons });
                }}
                className="p-2 border border-gray-300 rounded"
              >
                <option value="reply">Quick Reply</option>
                <option value="url">URL</option>
                <option value="phone">Phone</option>
              </select>
              <button
                onClick={() => {
                  const newButtons = (nodeData.buttons || []).filter(
                    (_: any, i: number) => i !== index
                  );
                  setNodeData({ ...nodeData, buttons: newButtons });
                }}
                className="p-2 text-red-500 hover:bg-red-50 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ))}
          <button
            onClick={() => {
              const newButtons = [
                ...(nodeData.buttons || []),
                { text: '', type: 'reply' },
              ];
              setNodeData({ ...nodeData, buttons: newButtons });
            }}
            className="text-sm text-green-600 hover:text-green-700"
          >
            + Add Button
          </button>
        </div>
      )}
    </div>
  );

  const renderUserInputProperties = () => (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Input Type
        </label>
        <select
          value={nodeData.inputType || 'text'}
          onChange={(e) =>
            setNodeData({ ...nodeData, inputType: e.target.value })
          }
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
        >
          <option value="text">Text Input</option>
          <option value="number">Number</option>
          <option value="email">Email</option>
          <option value="phone">Phone Number</option>
          <option value="date">Date</option>
          <option value="file">File Upload</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Validation Message
        </label>
        <input
          type="text"
          value={nodeData.validationMessage || ''}
          onChange={(e) =>
            setNodeData({ ...nodeData, validationMessage: e.target.value })
          }
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          placeholder="Please enter a valid input..."
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          <Clock className="w-4 h-4 inline mr-1" />
          Timeout (seconds)
        </label>
        <input
          type="number"
          value={nodeData.timeout || 30}
          onChange={(e) =>
            setNodeData({ ...nodeData, timeout: parseInt(e.target.value) })
          }
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          min="10"
          max="300"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Variable Name
        </label>
        <input
          type="text"
          value={nodeData.variableName || ''}
          onChange={(e) =>
            setNodeData({ ...nodeData, variableName: e.target.value })
          }
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          placeholder="user_name"
        />
        <p className="text-xs text-gray-500 mt-1">
          Store user input in this variable for later use
        </p>
      </div>
    </div>
  );

  const renderConditionProperties = () => (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Condition Type
        </label>
        <select
          value={nodeData.conditionType || 'contains'}
          onChange={(e) =>
            setNodeData({ ...nodeData, conditionType: e.target.value })
          }
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500"
        >
          <option value="contains">Text Contains</option>
          <option value="equals">Equals</option>
          <option value="starts_with">Starts With</option>
          <option value="ends_with">Ends With</option>
          <option value="regex">Regular Expression</option>
          <option value="number_greater">Number Greater Than</option>
          <option value="number_less">Number Less Than</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Condition Value
        </label>
        <input
          type="text"
          value={nodeData.conditionValue || ''}
          onChange={(e) =>
            setNodeData({ ...nodeData, conditionValue: e.target.value })
          }
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500"
          placeholder="Enter value to check against..."
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Variable to Check
        </label>
        <select
          value={nodeData.checkVariable || 'last_message'}
          onChange={(e) =>
            setNodeData({ ...nodeData, checkVariable: e.target.value })
          }
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500"
        >
          <option value="last_message">Last User Message</option>
          <option value="user_name">User Name</option>
          <option value="user_email">User Email</option>
          <option value="user_phone">User Phone</option>
          <option value="custom">Custom Variable</option>
        </select>
      </div>

      {nodeData.checkVariable === 'custom' && (
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Custom Variable Name
          </label>
          <input
            type="text"
            value={nodeData.customVariable || ''}
            onChange={(e) =>
              setNodeData({ ...nodeData, customVariable: e.target.value })
            }
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500"
            placeholder="variable_name"
          />
        </div>
      )}
    </div>
  );

  const renderActionProperties = () => (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Action Type
        </label>
        <select
          value={nodeData.actionType || 'assign_agent'}
          onChange={(e) =>
            setNodeData({ ...nodeData, actionType: e.target.value })
          }
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
        >
          <option value="assign_agent">Assign to Agent</option>
          <option value="create_ticket">Create Support Ticket</option>
          <option value="save_lead">Save as Lead</option>
          <option value="send_email">Send Email</option>
          <option value="webhook">Call Webhook</option>
          <option value="set_variable">Set Variable</option>
          <option value="tag_contact">Tag Contact</option>
        </select>
      </div>

      {nodeData.actionType === 'assign_agent' && (
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Agent/Department
          </label>
          <select
            value={nodeData.agentId || ''}
            onChange={(e) =>
              setNodeData({ ...nodeData, agentId: e.target.value })
            }
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
          >
            <option value="">Select Agent/Department</option>
            <option value="support">Support Team</option>
            <option value="sales">Sales Team</option>
            <option value="technical">Technical Support</option>
            <option value="billing">Billing Department</option>
          </select>
        </div>
      )}

      {nodeData.actionType === 'webhook' && (
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <Link className="w-4 h-4 inline mr-1" />
            Webhook URL
          </label>
          <input
            type="url"
            value={nodeData.webhookUrl || ''}
            onChange={(e) =>
              setNodeData({ ...nodeData, webhookUrl: e.target.value })
            }
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            placeholder="https://api.example.com/webhook"
          />
        </div>
      )}

      {nodeData.actionType === 'set_variable' && (
        <div className="space-y-3">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Variable Name
            </label>
            <input
              type="text"
              value={nodeData.variableName || ''}
              onChange={(e) =>
                setNodeData({ ...nodeData, variableName: e.target.value })
              }
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
              placeholder="variable_name"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Variable Value
            </label>
            <input
              type="text"
              value={nodeData.variableValue || ''}
              onChange={(e) =>
                setNodeData({ ...nodeData, variableValue: e.target.value })
              }
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
              placeholder="variable_value"
            />
          </div>
        </div>
      )}

      {nodeData.actionType === 'tag_contact' && (
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <Hash className="w-4 h-4 inline mr-1" />
            Tags (comma separated)
          </label>
          <input
            type="text"
            value={nodeData.tags || ''}
            onChange={(e) => setNodeData({ ...nodeData, tags: e.target.value })}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            placeholder="lead, interested, high-priority"
          />
        </div>
      )}

      {nodeData.actionType === 'send_email' && (
        <div className="space-y-3">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Email Template
            </label>
            <select
              value={nodeData.emailTemplate || ''}
              onChange={(e) =>
                setNodeData({ ...nodeData, emailTemplate: e.target.value })
              }
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            >
              <option value="">Select Template</option>
              <option value="welcome">Welcome Email</option>
              <option value="follow_up">Follow Up</option>
              <option value="support_ticket">Support Ticket Created</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Recipient Email
            </label>
            <input
              type="email"
              value={nodeData.recipientEmail || ''}
              onChange={(e) =>
                setNodeData({ ...nodeData, recipientEmail: e.target.value })
              }
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
              placeholder="user@example.com or use {{user_email}}"
            />
          </div>
        </div>
      )}
    </div>
  );

  const getNodeTypeIcon = () => {
    switch (selectedNode.type) {
      case 'message':
        return <MessageSquare className="w-5 h-5 text-green-500" />;
      case 'userInput':
        return <User className="w-5 h-5 text-blue-500" />;
      case 'condition':
        return <Settings className="w-5 h-5 text-yellow-500" />;
      case 'action':
        return <Bot className="w-5 h-5 text-purple-500" />;
      default:
        return <Settings className="w-5 h-5 text-gray-500" />;
    }
  };

  const getNodeTypeName = () => {
    switch (selectedNode.type) {
      case 'message':
        return 'Message Node';
      case 'userInput':
        return 'User Input Node';
      case 'condition':
        return 'Condition Node';
      case 'action':
        return 'Action Node';
      default:
        return 'Unknown Node';
    }
  };

  const renderProperties = () => {
    switch (selectedNode.type) {
      case 'message':
        return renderMessageProperties();
      case 'userInput':
        return renderUserInputProperties();
      case 'condition':
        return renderConditionProperties();
      case 'action':
        return renderActionProperties();
      default:
        return <div>No properties available for this node type.</div>;
    }
  };

  return (
    <div className="fixed right-0 top-0 h-full w-96 bg-white border-l border-gray-200 shadow-lg z-50 overflow-y-auto">
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {getNodeTypeIcon()}
            <h3 className="text-lg font-semibold text-gray-900">
              {getNodeTypeName()}
            </h3>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded">
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>
        <p className="text-sm text-gray-600 mt-1">Node ID: {selectedNode.id}</p>
      </div>

      <div className="p-4">{renderProperties()}</div>

      <div className="p-4 border-t border-gray-200 bg-gray-50">
        <div className="flex space-x-3">
          <button
            onClick={handleSave}
            className="flex-1 flex items-center justify-center space-x-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
          >
            <Save className="w-4 h-4" />
            <span>Save Changes</span>
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default NodePropertiesPanel;
