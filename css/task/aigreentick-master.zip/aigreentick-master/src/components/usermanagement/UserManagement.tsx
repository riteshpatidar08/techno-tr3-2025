import React, { useState, useEffect } from 'react';
import {
  Plus,
  Eye,
  Trash2,
  UserCheck,
  X,
  MessageSquare,
  User,
  Users,
  Phone,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

interface Agent {
  id: number;
  name: string;
  email: string;
  mobile: string;
  comments: string;
  isActive: boolean;
  chats: number;
}

interface NewAgent {
  email: string;
  password: string;
  name: string;
  mobile: string;
  comments: string;
}
const AgentSidebar = () => {
  const sidebarItems = [
    { icon: Users, label: 'Agents Login', active: true },
    { icon: MessageSquare, label: 'Agent Task(s)', active: false },
    { icon: Phone, label: 'Chat Widget', active: false },
  ];

  return (
    <div className="w-64 bg-white border-r border-gray-200 min-h-full">
      <div className="p-4 space-y-1">
        {sidebarItems.map((item) => (
          <Button
            key={item.label}
            variant={item.active ? 'default' : 'ghost'}
            className={`w-full justify-start ${
              item.active
                ? 'bg-green-50 text-green-600 border-r-2 border-green-500'
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
            }`}
          >
            <item.icon className="w-4 h-4 mr-3" />
            {item.label}
          </Button>
        ))}
      </div>
    </div>
  );
};
const AddAgentForm = ({
  onClose,
  onAdd,
}: {
  onClose: () => void;
  onAdd: (agent: NewAgent) => void;
}) => {
  const [formData, setFormData] = useState<NewAgent>({
    email: '',
    password: '',
    name: '',
    mobile: '',
    comments: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAdd(formData);
    setFormData({
      email: '',
      password: '',
      name: '',
      mobile: '',
      comments: '',
    });
    onClose();
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6 mb-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-gray-900">Add New Agent</h2>
          <p className="text-gray-600 mt-1">
            Fill in the details to create a new agent account
          </p>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={onClose}
          className="bg-green-500 hover:bg-green-600 text-white"
        >
          <X className="w-4 h-4 mr-1" />
          Close
        </Button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Email
            </label>
            <Input
              type="email"
              value={formData.email}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, email: e.target.value }))
              }
              placeholder="Enter email address"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Password
            </label>
            <Input
              type="password"
              value={formData.password}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, password: e.target.value }))
              }
              placeholder="Enter password"
              required
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Enter name
            </label>
            <Input
              type="text"
              value={formData.name}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, name: e.target.value }))
              }
              placeholder="Enter full name"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Mobile
            </label>
            <Input
              type="tel"
              value={formData.mobile}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, mobile: e.target.value }))
              }
              placeholder="Enter mobile number"
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Short comment (optional)
          </label>
          <Textarea
            value={formData.comments}
            onChange={(e) =>
              setFormData((prev) => ({ ...prev, comments: e.target.value }))
            }
            placeholder="Enter any comments or notes"
            rows={3}
          />
        </div>

        <div className="flex justify-start">
          <Button
            type="submit"
            className="bg-green-500 hover:bg-green-600 text-white"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add
          </Button>
        </div>
      </form>
    </div>
  );
};
const TableSkeleton = () => (
  <TableBody>
    {Array.from({ length: 3 }).map((_, index) => (
      <TableRow key={index}>
        <TableCell>
          <Skeleton className="h-6 w-6 rounded" />
        </TableCell>
        <TableCell>
          <Skeleton className="h-4 w-20" />
        </TableCell>
        <TableCell>
          <Skeleton className="h-4 w-32" />
        </TableCell>
        <TableCell>
          <Skeleton className="h-4 w-24" />
        </TableCell>
        <TableCell>
          <Skeleton className="h-4 w-28" />
        </TableCell>
        <TableCell>
          <Skeleton className="h-6 w-10 rounded-full" />
        </TableCell>
        <TableCell>
          <Skeleton className="h-8 w-8 rounded-full" />
        </TableCell>
        <TableCell>
          <Skeleton className="h-8 w-8 rounded-full" />
        </TableCell>
      </TableRow>
    ))}
  </TableBody>
);

const UserManagement = () => {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const dummyAgents: Agent[] = [
    {
      id: 1,
      name: 'john',
      email: 'john@agent.com',
      mobile: '7778888000',
      comments: 'some comments',
      isActive: true,
      chats: 5,
    },
  ];
  useEffect(() => {
    const fetchAgents = async () => {
      setIsLoading(true);
      await new Promise((resolve) => setTimeout(resolve, 1500));
      setAgents(dummyAgents);
      setIsLoading(false);
    };

    fetchAgents();
  }, []);

  const handleToggleActive = async (id: number) => {
    setAgents((prev) =>
      prev.map((agent) =>
        agent.id === id ? { ...agent, isActive: !agent.isActive } : agent
      )
    );
  };

  const handleDelete = async (id: number) => {
    setAgents((prev) => prev.filter((agent) => agent.id !== id));
  };

  const handleAddAgent = (newAgentData: NewAgent) => {
    const newAgent: Agent = {
      id: Date.now(),
      name: newAgentData.name,
      email: newAgentData.email,
      mobile: newAgentData.mobile,
      comments: newAgentData.comments,
      isActive: true,
      chats: 0,
    };
    setAgents((prev) => [...prev, newAgent]);
  };

  const handleViewChats = (id: number) => {
    console.log('View chats for agent:', id);
  };

  return (
    <div className="flex bg-gray-50 min-h-screen">
      <AgentSidebar />

      <div className="flex-1 flex flex-col">
        <div className="bg-white border-b border-gray-200 px-6 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-2">Agents</h1>
              <p className="text-gray-600">
                Add or remove agent account. An agent is someone to whom you can
                assign chats.
              </p>
            </div>
            <Button
              onClick={() => setShowForm(!showForm)}
              className="bg-green-500 hover:bg-green-600 text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Agent
            </Button>
          </div>
        </div>

        <div className="flex-1 p-6">
          {showForm && (
            <AddAgentForm
              onClose={() => setShowForm(false)}
              onAdd={handleAddAgent}
            />
          )}

          <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
            <Table className="border-0">
              <TableHeader className="border-0">
                <TableRow className="bg-gray-50 border-0">
                  <TableHead className="text-gray-600 font-medium">
                    Auto login
                  </TableHead>
                  <TableHead className="text-gray-600 font-medium">
                    Name
                  </TableHead>
                  <TableHead className="text-gray-600 font-medium">
                    Email
                  </TableHead>
                  <TableHead className="text-gray-600 font-medium">
                    Mobile
                  </TableHead>
                  <TableHead className="text-gray-600 font-medium">
                    Comments
                  </TableHead>
                  <TableHead className="text-gray-600 font-medium">
                    Is active?
                  </TableHead>
                  <TableHead className="text-gray-600 font-medium">
                    Chats
                  </TableHead>
                  <TableHead className="text-gray-600 font-medium">
                    Delete
                  </TableHead>
                </TableRow>
              </TableHeader>

              {isLoading ? (
                <TableSkeleton />
              ) : (
                <TableBody>
                  {agents.map((agent) => (
                    <TableRow key={agent.id} className="hover:bg-gray-50">
                      <TableCell>
                        <div className="w-6 h-6 bg-green-100 rounded flex items-center justify-center">
                          <UserCheck className="w-4 h-4 text-green-600" />
                        </div>
                      </TableCell>

                      <TableCell className="text-gray-900">
                        {agent.name}
                      </TableCell>

                      <TableCell className="text-gray-900">
                        {agent.email}
                      </TableCell>

                      <TableCell className="text-gray-900">
                        {agent.mobile}
                      </TableCell>

                      <TableCell className="text-gray-600">
                        {agent.comments}
                      </TableCell>

                      <TableCell>
                        <Switch
                          checked={agent.isActive}
                          onCheckedChange={() => handleToggleActive(agent.id)}
                          className="data-[state=checked]:bg-green-500"
                        />
                      </TableCell>

                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleViewChats(agent.id)}
                          className="p-1 h-8 w-8 rounded-full bg-blue-100 hover:bg-blue-200"
                        >
                          <Eye className="w-4 h-4 text-blue-600" />
                        </Button>
                      </TableCell>

                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(agent.id)}
                          className="p-1 h-8 w-8 rounded-full bg-red-100 hover:bg-red-200"
                        >
                          <Trash2 className="w-4 h-4 text-red-600" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              )}
            </Table>

            {!isLoading && agents.length === 0 && (
              <div className="text-center py-12">
                <div className="text-gray-400 mb-4">
                  <UserCheck className="w-12 h-12 mx-auto" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  No agents found
                </h3>
                <p className="text-gray-600 mb-4">
                  Get started by adding your first agent.
                </p>
                <Button
                  onClick={() => setShowForm(true)}
                  className="bg-green-500 hover:bg-green-600 text-white"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Agent
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserManagement;
