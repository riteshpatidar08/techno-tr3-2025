import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import {
  ChevronUp,
  ChevronDown,
  Edit3,
  Copy,
  Tag,
  StickyNote,
  X,
  Contact,
  Check,
  Plus,
  Trash2,
  User,
  Phone,
  Hash,
  FileText,
} from 'lucide-react';

interface ContactInfo {
  name: string;
  phone: string;
  avatar: string;
  userName: string;
}

interface ContactAttribute {
  key: string;
  value: string;
}

interface ChatSidebarProps {
  selectedConversation: ContactInfo;
  chatNote: string;
  onChatNoteChange: (note: string) => void;
}

export default function ChatSidebar({
  selectedConversation,
  chatNote,
  onChatNoteChange,
}: ChatSidebarProps) {
  const [expandedSections, setExpandedSections] = useState({
    contactInfo: true,
    contactAttributes: true,
    tags: true,
    notes: true,
  });

  const [isEditingNote, setIsEditingNote] = useState(false);
  const [tempNote, setTempNote] = useState('');
  const [newTag, setNewTag] = useState('');
  const [tags, setTags] = useState<string[]>(['VIP', 'Customer', 'Follow-up']);
  const [notes, setNotes] = useState<
    Array<{ id: string; text: string; timestamp: string }>
  >([
    {
      id: '1',
      text: 'Customer interested in premium package. Follow up next week.',
      timestamp: 'Dec 15, 2:30 PM',
    },
    {
      id: '2',
      text: 'Resolved technical query about API integration.',
      timestamp: 'Dec 14, 11:45 AM',
    },
  ]);
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);

  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }));
  };

  const handleSaveNote = () => {
    if (tempNote.trim()) {
      if (editingNoteId) {
        setNotes(
          notes.map((note) =>
            note.id === editingNoteId
              ? { ...note, text: tempNote.trim() }
              : note
          )
        );
        setEditingNoteId(null);
      } else {
        const newNote = {
          id: Date.now().toString(),
          text: tempNote.trim(),
          timestamp: new Date().toLocaleString('en-US', {
            month: 'short',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true,
          }),
        };
        setNotes([...notes, newNote]);
      }
      setTempNote('');
      setIsEditingNote(false);
    }
  };

  const handleCancelNote = () => {
    setTempNote('');
    setIsEditingNote(false);
    setEditingNoteId(null);
  };

  const handleEditNote = (note: {
    id: string;
    text: string;
    timestamp: string;
  }) => {
    setTempNote(note.text);
    setEditingNoteId(note.id);
    setIsEditingNote(true);
  };

  const handleDeleteNote = (noteId: string) => {
    setNotes(notes.filter((note) => note.id !== noteId));
  };

  const handleAddTag = () => {
    if (newTag.trim() && !tags.includes(newTag.trim())) {
      setTags([...tags, newTag.trim()]);
      setNewTag('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter((tag) => tag !== tagToRemove));
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const contactAttributes: ContactAttribute[] = [
    { key: 'Email', value: 'john.doe@example.com' },
    { key: 'Company', value: 'Tech Solutions Inc.' },
    { key: 'Location', value: 'Mumbai, India' },
    { key: 'Lead Score', value: '85/100' },
  ];

  return (
    <div className="h-full w-full bg-gradient-to-b from-card to-card/95 border-l border-border/50 flex flex-col overflow-hidden">
      {/* Header with Avatar - Enhanced */}
      <div className="p-4 border-b border-border/50 flex-shrink-0 bg-gradient-to-r from-background/50 to-background/30">
        <div className="flex items-center space-x-3">
          <div className="relative">
            <div className="w-12 h-12 bg-gradient-to-br from-primary to-primary/80 rounded-full flex items-center justify-center text-primary-foreground font-semibold text-sm shadow-lg">
              {selectedConversation.name.charAt(0)}
            </div>
            <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-chart-2 border-2 border-background rounded-full"></div>
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-card-foreground text-base truncate">
              {selectedConversation.name}
            </h3>
            <div className="flex items-center space-x-1 mt-0.5">
              <Phone className="w-3 h-3 text-muted-foreground" />
              <p className="text-sm text-muted-foreground truncate">
                {selectedConversation.phone}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 min-h-0 overflow-y-auto scrollbar-hide">
        {/* Contact Info Section */}
        <div className="border-b border-border/30">
          <div
            className="flex items-center justify-between p-4 cursor-pointer hover:bg-accent/50 transition-all duration-200"
            onClick={() => toggleSection('contactInfo')}
          >
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-primary/10 rounded-lg">
                <User className="text-primary w-4 h-4" />
              </div>
              <span className="font-medium text-card-foreground text-sm">
                Contact Details
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <Edit3 className="w-4 h-4 text-muted-foreground hover:text-primary cursor-pointer transition-colors" />
              {expandedSections.contactInfo ? (
                <ChevronUp className="w-4 h-4 text-muted-foreground" />
              ) : (
                <ChevronDown className="w-4 h-4 text-muted-foreground" />
              )}
            </div>
          </div>

          {expandedSections.contactInfo && (
            <div className="px-4 pb-4 space-y-3 bg-gradient-to-b from-primary/5 to-transparent">
              <div className="flex justify-between items-center p-3  rounded-lg border border-border/30">
                <div className="flex items-center space-x-2">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">Phone</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-sm">🇮🇳</span>
                  <span className="text-sm text-card-foreground font-medium">
                    {selectedConversation.phone}
                  </span>
                  <Copy
                    className="w-4 h-4 text-muted-foreground hover:text-primary cursor-pointer transition-colors"
                    onClick={() => copyToClipboard(selectedConversation.phone)}
                  />
                </div>
              </div>

              <div className="flex justify-between items-center p-3  rounded-lg border border-border/30">
                <div className="flex items-center space-x-2">
                  <User className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">
                    Username
                  </span>
                </div>
                <span className="text-sm text-card-foreground font-medium">
                  {selectedConversation.userName || selectedConversation.phone}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Contact Attributes Section */}
        <div className="border-b border-border/30">
          <div
            className="flex items-center justify-between p-4 cursor-pointer hover:bg-accent/50 transition-all duration-200"
            onClick={() => toggleSection('contactAttributes')}
          >
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-secondary/50 rounded-lg">
                <Hash className="text-secondary-foreground w-4 h-4" />
              </div>
              <span className="font-medium text-card-foreground text-sm">
                Attributes
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <Edit3 className="w-4 h-4 text-muted-foreground hover:text-primary cursor-pointer transition-colors" />
              {expandedSections.contactAttributes ? (
                <ChevronUp className="w-4 h-4 text-muted-foreground" />
              ) : (
                <ChevronDown className="w-4 h-4 text-muted-foreground" />
              )}
            </div>
          </div>

          {expandedSections.contactAttributes && (
            <div className="px-4 pb-4 space-y-2 bg-gradient-to-b from-secondary/10 to-transparent">
              {contactAttributes.map((attr, index) => (
                <div
                  key={index}
                  className="flex justify-between items-center p-3  rounded-lg border border-border/30"
                >
                  <span className="text-sm text-muted-foreground font-medium">
                    {attr.key}
                  </span>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-card-foreground">
                      {attr.value}
                    </span>
                    {attr.key === 'Lead Score' && (
                      <Badge
                        variant="secondary"
                        className="text-xs bg-chart-2/20 text-chart-2 border-chart-2/30"
                      >
                        High
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Tags Section */}
        <div className="border-b border-border/30">
          <div
            className="flex items-center justify-between p-4 cursor-pointer hover:bg-accent/50 transition-all duration-200"
            onClick={() => toggleSection('tags')}
          >
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-accent/50 rounded-lg">
                <Tag className="w-4 h-4 text-accent-foreground" />
              </div>
              <span className="font-medium text-card-foreground text-sm">
                Tags
              </span>
              <Badge variant="outline" className="text-xs">
                {tags.length}
              </Badge>
            </div>
            {expandedSections.tags ? (
              <ChevronUp className="w-4 h-4 text-muted-foreground" />
            ) : (
              <ChevronDown className="w-4 h-4 text-muted-foreground" />
            )}
          </div>

          {expandedSections.tags && (
            <div className="px-4 pb-4 bg-gradient-to-b from-accent/10 to-transparent">
              {/* Add Tag Input */}
              <div className="flex items-center space-x-2 mb-3">
                <Input
                  placeholder="Add a tag..."
                  value={newTag}
                  onChange={(e) => setNewTag(e.target.value)}
                  className="flex-1 h-9 text-sm  border-border/50 text-foreground"
                  onKeyPress={(e) => e.key === 'Enter' && handleAddTag()}
                />
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleAddTag}
                  className="h-9 w-9 p-0 border-border/50 hover:bg-accent"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>

              {/* Tags List */}
              <div className="max-h-32 overflow-y-auto scrollbar-hide">
                <div className="flex flex-wrap gap-2">
                  {tags.length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-4 w-full">
                      No tags added
                    </p>
                  ) : (
                    tags.map((tag, index) => (
                      <Badge
                        key={index}
                        variant="secondary"
                        className="flex items-center gap-1 px-3 py-1 bg-gradient-to-r from-primary/10 to-primary/5 border border-primary/20 text-primary hover:bg-primary/10 transition-colors"
                      >
                        {tag}
                        <X
                          className="w-3 h-3 text-primary/70 hover:text-destructive cursor-pointer transition-colors"
                          onClick={() => handleRemoveTag(tag)}
                        />
                      </Badge>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Notes Section */}
        <div className="flex-1 flex flex-col min-h-0">
          <div
            className="flex items-center justify-between p-4 cursor-pointer hover:bg-accent/50 transition-all duration-200 flex-shrink-0"
            onClick={() => toggleSection('notes')}
          >
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-muted/50 rounded-lg">
                <FileText className="w-4 h-4 text-muted-foreground" />
              </div>
              <span className="font-medium text-card-foreground text-sm">
                Notes
              </span>
              <Badge variant="outline" className="text-xs">
                {notes.length}
              </Badge>
            </div>
            <div className="flex items-center space-x-2">
              <Button
                size="sm"
                variant="ghost"
                className="text-primary hover:text-primary/80 hover:bg-primary/10 h-7 px-3 text-xs font-medium"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsEditingNote(true);
                }}
              >
                Add Note
              </Button>
              {expandedSections.notes ? (
                <ChevronUp className="w-4 h-4 text-muted-foreground" />
              ) : (
                <ChevronDown className="w-4 h-4 text-muted-foreground" />
              )}
            </div>
          </div>

          {expandedSections.notes && (
            <div className="flex-1 flex flex-col min-h-0 bg-gradient-to-b from-muted/10 to-transparent">
              <div className="px-4 pb-4 flex-1 flex flex-col min-h-0">
                {isEditingNote ? (
                  <div className="space-y-3 flex-shrink-0">
                    <Textarea
                      value={tempNote}
                      onChange={(e) => setTempNote(e.target.value)}
                      placeholder="Add your notes here..."
                      className="min-h-[100px] text-sm resize-none border-muted bg-muted/20 text-foreground"
                    />
                    <div className="flex items-center justify-end space-x-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={handleCancelNote}
                        className="h-8 px-3 text-sm hover:bg-muted"
                      >
                        <X className="w-4 h-4 mr-1" />
                        Cancel
                      </Button>
                      <Button
                        size="sm"
                        onClick={handleSaveNote}
                        className="h-8 px-3 text-sm bg-primary hover:bg-primary/90 text-primary-foreground"
                      >
                        <Check className="w-4 h-4 mr-1" />
                        Save Note
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="flex-1 min-h-0 overflow-y-auto scrollbar-hide">
                    {notes.length === 0 ? (
                      <div className="p-8 text-center">
                        <div className="w-16 h-16 bg-muted/50 rounded-full flex items-center justify-center mx-auto mb-3">
                          <StickyNote className="w-8 h-8 text-muted-foreground" />
                        </div>
                        <p className="text-sm text-muted-foreground">
                          No notes added yet
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Click "Add Note" to get started
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {notes.map((note) => (
                          <div
                            key={note.id}
                            className="p-4  border border-border/50 rounded-lg shadow-sm hover:shadow-md transition-all duration-200"
                          >
                            <div className="flex items-start justify-between mb-3">
                              <div className="flex items-center space-x-2">
                                <div className="w-6 h-6 bg-gradient-to-br from-primary to-primary/80 rounded-full flex items-center justify-center">
                                  <StickyNote className="w-3 h-3 text-primary-foreground" />
                                </div>
                                <div>
                                  <p className="text-sm font-medium text-card-foreground">
                                    Note
                                  </p>
                                  <p className="text-xs text-muted-foreground">
                                    {note.timestamp}
                                  </p>
                                </div>
                              </div>
                              <div className="flex items-center space-x-1">
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => handleEditNote(note)}
                                  className="h-6 w-6 p-0 hover:bg-accent"
                                >
                                  <Edit3 className="w-3 h-3 text-muted-foreground" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => handleDeleteNote(note.id)}
                                  className="h-6 w-6 p-0 hover:bg-destructive/10"
                                >
                                  <Trash2 className="w-3 h-3 text-muted-foreground hover:text-destructive transition-colors" />
                                </Button>
                              </div>
                            </div>
                            <p className="text-sm text-foreground leading-relaxed">
                              {note.text}
                            </p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Custom Styles */}
      <style jsx>{`
        .scrollbar-hide {
          scrollbar-width: none;
          -ms-overflow-style: none;
        }

        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }

        .scrollbar-hide {
          scroll-behavior: smooth;
        }

        .min-h-0 {
          min-height: 0;
        }
      `}</style>
    </div>
  );
}
