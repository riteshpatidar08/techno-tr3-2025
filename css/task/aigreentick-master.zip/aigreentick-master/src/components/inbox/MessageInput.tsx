import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Send,
  Paperclip,
  Smile,
  Plus,
  Image,
  FileText,
  Calendar,
  MapPin,
  X,
  Loader2,
  Video,
  Mic,
  Square,
  Play,
  Pause,
  RotateCcw,
  CheckCircle,
  AlertCircle,
} from 'lucide-react';
import EmojiPicker from 'emoji-picker-react';
import bgimage from '@/assets/images/backgrounds/whitebg.jpg';

import { useAppDispatch, useAppSelector } from '@/redux/store';
import {
  sendMessage,
  fetchConversation,
  selectSelectedConversation,
  selectChannels,
  selectSendingMessage,
  selectSendError,
} from '@/redux/messageSlice';
import { uploadMedia, clearMedia, selectMediaData } from '@/redux/mediaSlice';

type PreviewFile = {
  file: File;
  url?: string;
  uploadedUrl?: string;
  isUploading?: boolean;
};

type VoiceRecording = {
  blob: Blob | null;
  duration: number;
  isRecording: boolean;
  isPaused: boolean;
  isPlaying: boolean;
  audioUrl: string | null;
};

interface MessageInputProps {
  newMessage?: string;
  onMessageChange?: (message: string) => void;
  onSendMessage?: () => void;
  onFileSelect?: (files: FileList) => void;
}

export default function MessageInput({
  newMessage = '',
  onMessageChange = () => {},
  onFileSelect = () => {},
}: MessageInputProps) {
  const dispatch = useAppDispatch();
  const selectedConversation = useAppSelector(selectSelectedConversation);
  const channels = useAppSelector(selectChannels);
  const isSending = useAppSelector(selectSendingMessage);
  const sendError = useAppSelector(selectSendError);
  const mediaData = useAppSelector(selectMediaData);

  const [showOptionsMenu, setShowOptionsMenu] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [message, setMessage] = useState(newMessage);
  const [selectedFiles, setSelectedFiles] = useState<PreviewFile[]>([]);
  const [voiceRecording, setVoiceRecording] = useState<VoiceRecording>({
    blob: null,
    duration: 0,
    isRecording: false,
    isPaused: false,
    isPlaying: false,
    audioUrl: null,
  });

  const optionsRef = useRef<HTMLDivElement>(null);
  const emojiRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const documentInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordingTimerRef = useRef<NodeJS.Timeout | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Handle media upload response
  useEffect(() => {
    if (mediaData.publicUrl && !mediaData.loading && !mediaData.error) {
      setSelectedFiles((prev) =>
        prev.map((file) =>
          file.isUploading
            ? { ...file, uploadedUrl: mediaData.publicUrl, isUploading: false }
            : file
        )
      );
    }
    if (mediaData.error) {
      setSelectedFiles((prev) =>
        prev.map((file) =>
          file.isUploading ? { ...file, isUploading: false } : file
        )
      );
    }
  }, [mediaData]);

  // Voice Recording Functions
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);

      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, {
          type: 'audio/wav',
        });
        const audioUrl = URL.createObjectURL(audioBlob);

        setVoiceRecording((prev) => ({
          ...prev,
          blob: audioBlob,
          audioUrl,
          isRecording: false,
        }));

        // Stop all tracks
        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorder.start();
      setVoiceRecording((prev) => ({
        ...prev,
        isRecording: true,
        duration: 0,
      }));

      // Start timer
      recordingTimerRef.current = setInterval(() => {
        setVoiceRecording((prev) => ({ ...prev, duration: prev.duration + 1 }));
      }, 1000);
    } catch (error) {
      console.error('Error starting recording:', error);
      alert('Unable to access microphone. Please check permissions.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && voiceRecording.isRecording) {
      mediaRecorderRef.current.stop();
      if (recordingTimerRef.current) {
        clearInterval(recordingTimerRef.current);
      }
    }
  };

  const playRecording = () => {
    if (voiceRecording.audioUrl) {
      if (audioRef.current) {
        audioRef.current.pause();
      }

      audioRef.current = new Audio(voiceRecording.audioUrl);
      audioRef.current.play();

      setVoiceRecording((prev) => ({ ...prev, isPlaying: true }));

      audioRef.current.onended = () => {
        setVoiceRecording((prev) => ({ ...prev, isPlaying: false }));
      };
    }
  };

  const pauseRecording = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      setVoiceRecording((prev) => ({ ...prev, isPlaying: false }));
    }
  };

  const deleteRecording = () => {
    if (voiceRecording.audioUrl) {
      URL.revokeObjectURL(voiceRecording.audioUrl);
    }
    if (audioRef.current) {
      audioRef.current.pause();
    }
    setVoiceRecording({
      blob: null,
      duration: 0,
      isRecording: false,
      isPaused: false,
      isPlaying: false,
      audioUrl: null,
    });
  };

  const sendVoiceMessage = async () => {
    if (!voiceRecording.blob) return;

    // Create a File from the blob
    const audioFile = new File(
      [voiceRecording.blob],
      `voice_${Date.now()}.wav`,
      {
        type: 'audio/wav',
      }
    );

    // Upload the audio file
    const preview: PreviewFile = {
      file: audioFile,
      isUploading: true,
    };

    setSelectedFiles([preview]);

    try {
      dispatch(clearMedia());
      await dispatch(uploadMedia(audioFile)).unwrap();

      // The rest will be handled by the existing send message logic
      deleteRecording();
    } catch (error) {
      console.error('Failed to upload voice message:', error);
      setSelectedFiles([]);
      alert('Failed to upload voice message. Please try again.');
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSendMessage = async () => {
    if (!message.trim() && selectedFiles.length === 0) return;
    if (!selectedConversation) return;
    if (isSending) return;

    const hasUploadingFiles = selectedFiles.some((file) => file.isUploading);
    if (hasUploadingFiles) return;

    try {
      const uploadedFile = selectedFiles.find((file) => file.uploadedUrl);

      await dispatch(
        sendMessage({
          message: message.trim(),
          recipient_mobile: selectedConversation.contact_number,
          recipient_name: selectedConversation.contact_name,
          template_id: null,
          reaction: '',
          isReply: false,
          media_type: uploadedFile ? getMediaType(uploadedFile.file) : '',
          media_url: uploadedFile?.uploadedUrl || '',
          filename: uploadedFile?.file.name || '',
          caption: uploadedFile ? message.trim() : '',
          channel: channels[0]?.whatsapp_no || '',
        })
      ).unwrap();

      setMessage('');
      onMessageChange('');
      setShowEmojiPicker(false);

      selectedFiles.forEach((p) => p.url && URL.revokeObjectURL(p.url));
      setSelectedFiles([]);
      dispatch(clearMedia());

      if (channels[0]) {
        await dispatch(
          fetchConversation({
            contactNumber: selectedConversation.contact_number,
            selectedChannel: channels[0].whatsapp_no,
            page: 1,
          })
        );
      }
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const getMediaType = (file: File): string => {
    if (file.type.startsWith('image/')) return 'image';
    if (file.type.startsWith('video/')) return 'video';
    if (file.type.startsWith('audio/')) return 'audio';
    return 'document';
  };

  const handleMessageChange = (value: string) => {
    setMessage(value);
    onMessageChange(value);
  };

  const handleEmojiClick = (emojiData: any) => {
    const newText = message + emojiData.emoji;
    setMessage(newText);
    onMessageChange(newText);
  };

  useEffect(() => {
    const closeOnOutside = (e: MouseEvent) => {
      const t = e.target as Node;
      if (optionsRef.current && !optionsRef.current.contains(t))
        setShowOptionsMenu(false);
      if (emojiRef.current && !emojiRef.current.contains(t))
        setShowEmojiPicker(false);
    };
    document.addEventListener('mousedown', closeOnOutside);
    return () => document.removeEventListener('mousedown', closeOnOutside);
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (recordingTimerRef.current) {
        clearInterval(recordingTimerRef.current);
      }
      if (voiceRecording.audioUrl) {
        URL.revokeObjectURL(voiceRecording.audioUrl);
      }
      if (audioRef.current) {
        audioRef.current.pause();
      }
    };
  }, []);

  const uploadFileToAPI = async (file: File) => {
    try {
      dispatch(clearMedia());
      await dispatch(uploadMedia(file)).unwrap();
    } catch (error) {
      throw error;
    }
  };

  const messageOptions = [
    {
      icon: Image,
      label: 'Photos',
      description: 'Share images',
      color: 'text-green-600',
      bgColor: 'bg-green-50 hover:bg-green-100',
      borderColor: 'border-green-200',
      action: () => imageInputRef.current?.click(),
    },
    {
      icon: Video,
      label: 'Videos',
      description: 'Share videos',
      color: 'text-green-600',
      bgColor: 'bg-green-50 hover:bg-green-100',
      borderColor: 'border-green-200',
      action: () => imageInputRef.current?.click(),
    },
    {
      icon: FileText,
      label: 'Documents',
      description: 'Share files',
      color: 'text-green-600',
      bgColor: 'bg-green-50 hover:bg-green-100',
      borderColor: 'border-green-200',
      action: () => documentInputRef.current?.click(),
    },
    {
      icon: Calendar,
      label: 'Schedule',
      description: 'Set meeting',
      color: 'text-green-600',
      bgColor: 'bg-green-50 hover:bg-green-100',
      borderColor: 'border-green-200',
      action: () => console.log('Schedule meeting clicked'),
    },
    {
      icon: MapPin,
      label: 'Location',
      description: 'Share location',
      color: 'text-green-600',
      bgColor: 'bg-green-50 hover:bg-green-100',
      borderColor: 'border-green-200',
      action: () => console.log('Location clicked'),
    },
    {
      icon: Mic,
      label: 'Voice',
      description: 'Record audio',
      color: 'text-green-600',
      bgColor: 'bg-green-50 hover:bg-green-100',
      borderColor: 'border-green-200',
      action: startRecording,
    },
  ];

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    onFileSelect(files);
    const file = files[0];

    // Enhanced file validation with better UX
    const validationResult = validateFile(file);
    if (!validationResult.valid) {
      alert(validationResult.message);
      e.target.value = '';
      return;
    }

    const preview: PreviewFile = {
      file,
      url: file.type.startsWith('image/')
        ? URL.createObjectURL(file)
        : undefined,
      isUploading: true,
    };

    setSelectedFiles([preview]);

    try {
      await uploadFileToAPI(file);
    } catch (error) {
      setSelectedFiles([]);
      alert('Failed to upload file. Please try again.');
    }

    e.target.value = '';
  };

  const validateFile = (file: File) => {
    if (file.type.startsWith('image/')) {
      if (file.size > 5 * 1024 * 1024) {
        return { valid: false, message: 'Image files must be less than 5MB' };
      }
    } else if (file.type.startsWith('video/')) {
      if (file.size > 16 * 1024 * 1024) {
        return { valid: false, message: 'Video files must be less than 16MB' };
      }
    } else {
      if (file.size > 100 * 1024 * 1024) {
        return { valid: false, message: 'Files must be less than 100MB' };
      }
    }
    return { valid: true, message: '' };
  };

  const removeFile = (idx: number) => {
    setSelectedFiles((prev) => {
      const clone = [...prev];
      const [removed] = clone.splice(idx, 1);
      if (removed?.url) URL.revokeObjectURL(removed.url);
      return clone;
    });
    dispatch(clearMedia());
  };

  const hasUploadingFiles = selectedFiles.some((file) => file.isUploading);
  const canSend =
    (message.trim() || selectedFiles.length > 0) &&
    selectedConversation &&
    !isSending &&
    !hasUploadingFiles;

  return (
    <div className="relative">
      {/* Background with subtle pattern */}
      <div
        className="absolute inset-0 opacity-30"
        style={{
          backgroundImage: `url(${bgimage})`,
          backgroundSize: 'contain',
          backgroundPosition: 'center',
          backgroundRepeat: 'repeat',
        }}
      />

      <div className="relativ backdrop-blur-sm border-t border-border">
        {/* Hidden file inputs */}
        <input
          ref={fileInputRef}
          type="file"
          multiple
          className="hidden"
          onChange={handleFileChange}
          accept="*/*"
        />
        <input
          ref={imageInputRef}
          type="file"
          className="hidden"
          onChange={handleFileChange}
          accept="image/*,video/*"
        />
        <input
          ref={documentInputRef}
          type="file"
          className="hidden"
          onChange={handleFileChange}
          accept=".pdf,.doc,.docx,.txt,.xls,.xlsx,.ppt,.pptx"
        />

        {/* Voice Recording Modal */}
        {voiceRecording.blob && (
          <div className="px-6 py-4 border-b border-border bg-green-50">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  <Mic className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <div className="text-sm font-medium text-green-800">
                    Voice Message
                  </div>
                  <div className="text-xs text-green-600">
                    {formatDuration(voiceRecording.duration)}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 flex-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={
                    voiceRecording.isPlaying ? pauseRecording : playRecording
                  }
                  className="text-green-600 hover:bg-green-100"
                >
                  {voiceRecording.isPlaying ? (
                    <Pause className="w-4 h-4" />
                  ) : (
                    <Play className="w-4 h-4" />
                  )}
                </Button>

                <Button
                  variant="ghost"
                  size="sm"
                  onClick={deleteRecording}
                  className="text-red-600 hover:bg-red-100"
                >
                  <RotateCcw className="w-4 h-4" />
                </Button>

                <Button
                  onClick={sendVoiceMessage}
                  size="sm"
                  className="bg-green-600 hover:bg-green-700 text-white ml-auto"
                >
                  <Send className="w-4 h-4 mr-1" />
                  Send Voice
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Recording Indicator */}
        {voiceRecording.isRecording && (
          <div className="px-6 py-3 border-b border-border bg-red-50">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                <span className="text-sm font-medium text-red-700">
                  Recording...
                </span>
              </div>
              <span className="text-sm text-red-600">
                {formatDuration(voiceRecording.duration)}
              </span>
              <Button
                onClick={stopRecording}
                size="sm"
                variant="ghost"
                className="text-red-600 hover:bg-red-100 ml-auto"
              >
                <Square className="w-4 h-4 mr-1" />
                Stop
              </Button>
            </div>
          </div>
        )}

        {/* Options Menu */}
        {showOptionsMenu && (
          <div
            ref={optionsRef}
            className="absolute bottom-full left-4 right-4 mb-3 bg-card rounded-2xl shadow-2xl border border-border z-50 overflow-hidden animate-in slide-in-from-bottom duration-300"
          >
            <div className="p-6">
              <div className="mb-4">
                <h3 className="text-sm font-semibold text-card-foreground mb-1">
                  Share Content
                </h3>
                <p className="text-xs text-muted-foreground">
                  Choose what you'd like to share
                </p>
              </div>
              <div className="grid grid-cols-3 gap-3">
                {messageOptions.map((opt, i) => {
                  const Icon = opt.icon;
                  return (
                    <button
                      key={i}
                      onClick={() => {
                        opt.action();
                        setShowOptionsMenu(false);
                      }}
                      className={`group relative flex flex-col items-center p-4 rounded-xl transition-all duration-200 ${opt.bgColor} border ${opt.borderColor} hover:scale-105 hover:shadow-md active:scale-95`}
                    >
                      <div
                        className={`w-12 h-12 rounded-full flex items-center justify-center mb-3 ${opt.color} bg-background shadow-sm group-hover:shadow-md transition-shadow`}
                      >
                        <Icon className="w-6 h-6" />
                      </div>
                      <div className="text-center">
                        <div className="font-medium text-card-foreground text-sm mb-1">
                          {opt.label}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {opt.description}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* Emoji Picker */}
        {showEmojiPicker && (
          <div
            ref={emojiRef}
            className="absolute bottom-full right-4 mb-3 z-50 shadow-2xl rounded-2xl overflow-hidden border border-border"
          >
            <EmojiPicker
              onEmojiClick={handleEmojiClick}
              width={350}
              height={400}
              lazyLoadEmojis
              previewConfig={{ showPreview: false }}
            />
          </div>
        )}

        {/* File Previews */}
        {selectedFiles.length > 0 && (
          <div className="px-6 py-4 border-b border-border">
            <div className="flex items-center gap-3">
              <div className="text-sm font-medium text-card-foreground">
                Attachments
              </div>
              <div className="flex gap-3">
                {selectedFiles.map((file, idx) => (
                  <div key={idx} className="relative group">
                    <div className="relative w-20 h-20 rounded-xl overflow-hidden border-2 border-border bg-muted">
                      {file.url ? (
                        <img
                          src={file.url}
                          alt={file.file.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex flex-col items-center justify-center text-muted-foreground">
                          <FileText className="w-8 h-8 mb-1" />
                          <span className="text-xs font-medium truncate px-1">
                            {file.file.name.length > 10
                              ? `${file.file.name.slice(0, 10)}...`
                              : file.file.name}
                          </span>
                        </div>
                      )}

                      {/* Upload overlay */}
                      {file.isUploading && (
                        <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                          <div className="text-center text-white">
                            <Loader2 className="w-6 h-6 animate-spin mx-auto mb-1" />
                            <div className="text-xs font-medium">
                              Uploading...
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Success indicator */}
                      {file.uploadedUrl && !file.isUploading && (
                        <div className="absolute top-1 right-1 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center shadow-sm">
                          <CheckCircle className="w-4 h-4 text-white" />
                        </div>
                      )}
                    </div>

                    {/* Remove button */}
                    <button
                      onClick={() => removeFile(idx)}
                      disabled={file.isUploading}
                      className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center shadow-lg opacity-0 group-hover:opacity-100 transition-opacity disabled:opacity-50"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Error Messages */}
        {(sendError || mediaData.error) && (
          <div className="px-6 py-3 bg-destructive/10 border-b border-destructive/20">
            <div className="flex items-center gap-2 text-destructive">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span className="text-sm font-medium">
                {sendError || `Upload Error: ${mediaData.error}`}
              </span>
            </div>
          </div>
        )}

        {/* Connection status */}
        {!selectedConversation && (
          <div className="px-6 py-3 bg-amber-50 border-b border-amber-200">
            <div className="flex items-center gap-2 text-amber-700">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span className="text-sm">
                Please select a conversation to start messaging
              </span>
            </div>
          </div>
        )}

        {/* Main Input Area */}
        <div className="px-6 py-4">
          <div className="flex items-end gap-3">
            {/* Action buttons */}
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => {
                  setShowOptionsMenu(!showOptionsMenu);
                  setShowEmojiPicker(false);
                }}
                className="w-10 h-10 rounded-full text-muted-foreground hover:text-foreground hover:bg-accent transition-all duration-200"
                disabled={
                  isSending || hasUploadingFiles || voiceRecording.isRecording
                }
              >
                <Plus
                  className={`w-5 h-5 transition-transform duration-200 ${
                    showOptionsMenu ? 'rotate-45' : ''
                  }`}
                />
              </Button>

              <Button
                variant="ghost"
                size="icon"
                onClick={() => fileInputRef.current?.click()}
                className="w-10 h-10 rounded-full text-muted-foreground hover:text-foreground hover:bg-accent transition-all duration-200"
                disabled={
                  isSending || hasUploadingFiles || voiceRecording.isRecording
                }
              >
                <Paperclip className="w-5 h-5" />
              </Button>

              {/* Voice Recording Button */}
              <Button
                variant="ghost"
                size="icon"
                onClick={
                  voiceRecording.isRecording ? stopRecording : startRecording
                }
                className={`w-10 h-10 rounded-full transition-all duration-200 ${
                  voiceRecording.isRecording
                    ? 'text-red-600 hover:text-red-700 hover:bg-red-50'
                    : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                }`}
                disabled={isSending || hasUploadingFiles}
              >
                {voiceRecording.isRecording ? (
                  <Square className="w-5 h-5" />
                ) : (
                  <Mic className="w-5 h-5" />
                )}
              </Button>
            </div>

            {/* Message input */}
            <div className="flex-1 relative">
              <div className="relative">
                <Input
                  placeholder={
                    hasUploadingFiles
                      ? 'Uploading file...'
                      : isSending
                      ? 'Sending message...'
                      : voiceRecording.isRecording
                      ? 'Recording voice message...'
                      : !selectedConversation
                      ? 'Select a conversation to start messaging...'
                      : 'Type your message...'
                  }
                  value={message}
                  onChange={(e) => handleMessageChange(e.target.value)}
                  onKeyPress={handleKeyPress}
                  disabled={
                    isSending ||
                    !selectedConversation ||
                    hasUploadingFiles ||
                    voiceRecording.isRecording
                  }
                  className="bg-muted border-input rounded-2xl py-3 px-4 pr-12 text-sm placeholder:text-muted-foreground focus:bg-background focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 disabled:bg-muted disabled:text-muted-foreground"
                />

                {/* Emoji button inside input */}
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    setShowEmojiPicker(!showEmojiPicker);
                    setShowOptionsMenu(false);
                  }}
                  className={`absolute right-1 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full text-muted-foreground hover:text-foreground hover:bg-accent transition-all duration-200 ${
                    showEmojiPicker ? 'bg-accent text-foreground' : ''
                  }`}
                  disabled={
                    isSending || hasUploadingFiles || voiceRecording.isRecording
                  }
                >
                  <Smile className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Send button */}
            <Button
              onClick={handleSendMessage}
              disabled={!canSend}
              className={`w-11 h-11 rounded-full transition-all duration-200 ${
                canSend
                  ? 'bg-green-600 hover:bg-green-700 text-white shadow-lg hover:shadow-xl hover:scale-105 active:scale-95'
                  : 'bg-muted text-muted-foreground cursor-not-allowed'
              }`}
            >
              {isSending || hasUploadingFiles ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <Send className="w-5 h-5" />
              )}
            </Button>
          </div>

          {/* Character count or status */}
          {message.length > 0 && (
            <div className="flex justify-between items-center mt-2 px-1">
              <div className="text-xs text-muted-foreground">
                {message.length > 500 ? (
                  <span className="text-orange-500">
                    {message.length}/1000 characters
                  </span>
                ) : (
                  `${message.length} characters`
                )}
              </div>
              {hasUploadingFiles && (
                <div className="text-xs text-green-600 flex items-center gap-1">
                  <Loader2 className="w-3 h-3 animate-spin" />
                  Processing file...
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
