import React, { useState, useEffect } from 'react';
import ConversationList from './ConversationList';
import ChatHeader from './ChatHeader';
import ChatMessages from './ChatMessages';
import MessageInput from './MessageInput';
import ChatSidebar from './ChatSidebar';
import FilterModal from './FilterModal';
import { Button } from '../ui/button';
import { useAppDispatch, useAppSelector } from '@/redux/store';
import {
  fetchMessages,
  fetchConversation,
  sendMessage,
  selectConversation,
  selectSelectedConversation,
  selectCurrentConversationMessages,
  selectConversationLoading,
  selectChannels,
  selectSendingMessage,
} from '@/redux/messageSlice';

export default function Inbox() {
  const dispatch = useAppDispatch();

  const selectedConversation = useAppSelector(selectSelectedConversation);
  const conversationMessages = useAppSelector(
    selectCurrentConversationMessages
  );
  const conversationLoading = useAppSelector(selectConversationLoading);
  const channels = useAppSelector(selectChannels);
  const sendingMessage = useAppSelector(selectSendingMessage);

  const [isInitialLoad, setIsInitialLoad] = useState(true);
  const [newMessage, setNewMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [chatNote, setChatNote] = useState('');
  const [rating, setRating] = useState(0);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedAgent, setSelectedAgent] = useState(null);

  const selectedChannel = channels[0]?.whatsapp_no || '';

  useEffect(() => {
    dispatch(fetchMessages());
  }, [dispatch]);

  useEffect(() => {
    if (selectedConversation && selectedChannel) {
      setIsInitialLoad(true);
      dispatch(
        fetchConversation({
          contactNumber: selectedConversation.contact_number,
          selectedChannel: selectedChannel,
          page: 1,
        })
      );
    }
  }, [selectedConversation, selectedChannel, dispatch]);

  const formattedMessages = conversationMessages.map((msg) => ({
    id: msg.id.toString(),
    text: msg.text,
    sender: msg.type === 'sent' ? 'user' : 'contact',
    timestamp: new Date(msg.created_at).toLocaleString('en-GB', {
      day: '2-digit',
      month: '2-digit',
      year: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    }),
    status: msg.status,
    buttons: undefined,
  }));

  const formattedSelectedConversation = selectedConversation
    ? {
        id: selectedConversation.id.toString(),
        name: selectedConversation.contact_name,
        phone: selectedConversation.contact_number,
        avatar: selectedConversation.contact_name.charAt(0).toUpperCase(),
        isOnline: selectedConversation.isActive,
        messages: formattedMessages,
      }
    : null;

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !selectedConversation || sendingMessage) return;

    const messageToSend = newMessage.trim();
    setNewMessage('');
    setIsInitialLoad(false);

    try {
      await dispatch(
        sendMessage({
          to: selectedConversation.contact_number,
          message: messageToSend,
          type: 'text',
          channel_id: channels[0]?.id,
        })
      ).unwrap();

      if (selectedChannel) {
        dispatch(
          fetchConversation({
            contactNumber: selectedConversation.contact_number,
            selectedChannel: selectedChannel,
            page: 1,
          })
        );
      }
    } catch (error) {
      console.error('Failed to send message:', error);
      setNewMessage(messageToSend);
    }
  };

  const handleSelectConversation = (conversation) => {
    setIsInitialLoad(true);
  };

  const handleApplyFilters = () => {
    setShowFilterModal(false);
  };

  const handleResetFilters = () => {
    setStartDate('');
    setEndDate('');
  };

  const handleAgentChange = (agent) => {
    setSelectedAgent(agent);
  };

  return (
    <div className="h-screen bg-white flex flex-col overflow-hidden">
      {/* Main Content Container - No Y-axis overflow */}
      <div className="flex-1 flex min-h-0 overflow-x-auto overflow-y-hidden">
        {/* Conversation List - Fixed Width 450px */}
        <div className="w-[450px] border-r border-gray-200 bg-white flex-shrink-0 h-full">
          <ConversationList />
        </div>

        {/* Chat Area - Flexible Center Content */}
        <div className="flex-1 flex flex-col min-w-0 bg-white h-full overflow-hidden">
          {selectedConversation ? (
            <>
              
              <div className="flex-shrink-0 border-b border-gray-200">
                <ChatHeader
                  selectedConversation={formattedSelectedConversation}
                  showFilterModal={showFilterModal}
                  onToggleFilter={() => setShowFilterModal(!showFilterModal)}
                  selectedAgent={selectedAgent}
                  onAgentChange={handleAgentChange}
                />
              </div>

            
              <div className="flex-1 relative min-h-0 bg-gray-50 overflow-hidden">
           
                <div className="absolute inset-0 pb-20">
                  <div className="h-full overflow-y-auto scrollbar-hide">
                    <ChatMessages
                      messages={formattedMessages}
                      isInitialLoad={isInitialLoad}
                      isLoading={conversationLoading}
                    />
                  </div>
                </div>

                <div className="absolute bottom-16 left-0 right-0 bg-white border-t border-gray-200 shadow-lg z-10">
                  <MessageInput
                    newMessage={newMessage}
                    onMessageChange={setNewMessage}
                    onSendMessage={handleSendMessage}
                    isSending={sendingMessage}
                  />
                </div>
              </div>
            </>
          ) : (
            /* Welcome Screen - Full Height Center */
            <div className="flex-1 flex items-center justify-center relative overflow-hidden bg-gradient-to-br from-gray-50 to-white">
              {/* Background Decoration */}
              <div className="absolute inset-0 opacity-[0.02] dark:opacity-[0.05] overflow-hidden">
                <div className="absolute top-20 left-20 w-64 h-64 bg-primary/20 rounded-full mix-blend-multiply filter blur-xl animate-blob"></div>
                <div className="absolute top-40 right-20 w-64 h-64 bg-chart-2/20 rounded-full mix-blend-multiply filter blur-xl animate-blob animation-delay-2000"></div>
                <div className="absolute bottom-20 left-40 w-64 h-64 bg-chart-3/20 rounded-full mix-blend-multiply filter blur-xl animate-blob animation-delay-4000"></div>
              </div>

              {/* Welcome Content */}
              <div className="text-center z-10 animate-fadeInUp max-w-md mx-auto px-6">
                <div className="relative mb-8">
                  <div className="w-24 h-24 bg-primary rounded-2xl flex items-center justify-center mx-auto shadow-lg transform hover:scale-105 transition-transform duration-300">
                    <svg
                      className="w-12 h-12 text-primary-foreground"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={1.5}
                        d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                      />
                    </svg>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xl font-semibold text-foreground tracking-tight">
                    Welcome to your inbox
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Select a conversation from the sidebar to start messaging,
                    or create a new conversation to connect with your contacts.
                  </p>

                  <div className="flex flex-col sm:flex-row gap-3 justify-center mt-8">
                    <Button className="px-6 py-3 shadow-md hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200">
                      Start New Chat
                    </Button>

                    <Button
                      variant="outline"
                      className="px-6 py-3 transition-colors duration-200"
                    >
                      View All Contacts
                    </Button>
                  </div>
                </div>

                {/* Feature Cards */}
                <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center opacity-75">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                      <svg
                        className="w-6 h-6 text-primary"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M13 10V3L4 14h7v7l9-11h-7z"
                        />
                      </svg>
                    </div>
                    <h4 className="text-sm font-medium text-foreground mb-1">
                      Instant Messaging
                    </h4>
                    <p className="text-xs text-muted-foreground">
                      Real-time conversations
                    </p>
                  </div>

                  <div className="text-center opacity-75">
                    <div className="w-12 h-12 bg-chart-2/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                      <svg
                        className="w-6 h-6 text-chart-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                        />
                      </svg>
                    </div>
                    <h4 className="text-sm font-medium text-foreground mb-1">
                      Message Status
                    </h4>
                    <p className="text-xs text-muted-foreground">
                      Delivery confirmations
                    </p>
                  </div>

                  <div className="text-center opacity-75">
                    <div className="w-12 h-12 bg-chart-3/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                      <svg
                        className="w-6 h-6 text-chart-3"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z"
                        />
                      </svg>
                    </div>
                    <h4 className="text-sm font-medium text-foreground mb-1">
                      Smart Filters
                    </h4>
                    <p className="text-xs text-muted-foreground">
                      Organize conversations
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Chat Sidebar - Fixed Width 450px */}
        {selectedConversation && (
          <div className="w-[450px] border-l border-gray-200 bg-gray-50 flex-shrink-0 h-full">
            <ChatSidebar
              selectedConversation={formattedSelectedConversation}
              chatNote={chatNote}
              onChatNoteChange={setChatNote}
              rating={rating}
              onRatingChange={setRating}
            />
          </div>
        )}
      </div>

      {/* Filter Modal */}
      <FilterModal
        show={showFilterModal}
        onClose={() => setShowFilterModal(false)}
        startDate={startDate}
        endDate={endDate}
        onStartDateChange={setStartDate}
        onEndDateChange={setEndDate}
        onApplyFilters={handleApplyFilters}
        onResetFilters={handleResetFilters}
      />

      {/* Global Styles */}
      <style jsx>{`
        /* Hide all scrollbars */
        .scrollbar-hide {
          scrollbar-width: none; /* Firefox */
          -ms-overflow-style: none; /* IE/Edge */
        }

        .scrollbar-hide::-webkit-scrollbar {
          display: none; /* Chrome, Safari, Opera */
        }

        /* Hide body scrollbar if needed */
        body {
          overflow: hidden;
        }

        /* Ensure no scrollbars on main container */
        .overflow-y-hidden {
          overflow-y: hidden !important;
        }

        /* Animations */
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes blob {
          0% {
            transform: translate(0px, 0px) scale(1);
          }
          33% {
            transform: translate(30px, -50px) scale(1.1);
          }
          66% {
            transform: translate(-20px, 20px) scale(0.9);
          }
          100% {
            transform: translate(0px, 0px) scale(1);
          }
        }

        .animate-fadeIn {
          animation: fadeIn 0.3s ease-out forwards;
          opacity: 0;
        }

        .animate-fadeInUp {
          animation: fadeInUp 0.8s ease-out forwards;
        }

        .animate-blob {
          animation: blob 7s infinite;
        }

        .animation-delay-2000 {
          animation-delay: 2s;
        }

        .animation-delay-4000 {
          animation-delay: 4s;
        }

        /* Smooth scrolling only for internal areas */
        .scroll-smooth {
          scroll-behavior: smooth;
        }

        /* Button hover effects */
        button:hover {
          transform: translateY(-1px);
        }

        button:active {
          transform: translateY(0);
        }

        /* Message input shadow */
        .message-input-container {
          box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
        }

        /* Ensure proper height inheritance */
        .min-h-0 {
          min-height: 0;
        }

        /* Custom focus states */
        .focus-visible:focus {
          outline: 2px solid #3b82f6;
          outline-offset: 2px;
        }

        /* Prevent any accidental scrollbars */
        * {
          box-sizing: border-box;
        }

        /* Container height management */
        .h-full {
          height: 100%;
        }

        /* Absolute positioning for messages */
        .absolute {
          position: absolute;
        }

        .inset-0 {
          top: 0;
          right: 0;
          bottom: 0;
          left: 0;
        }
      `}</style>
    </div>
  );
}
