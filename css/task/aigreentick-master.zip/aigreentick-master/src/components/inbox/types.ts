export interface Message {
  id: string;
  text: string;
  sender: 'user' | 'contact';
  timestamp: string;
  status: 'sent' | 'delivered' | 'read';
  buttons?: string[];
}

export interface Conversation {
  id: string;
  name: string;
  phone: string;
  lastMessage: string;
  timestamp: string;
  avatar: string;
  isActive: boolean;
  isOnline?: boolean;
  isImportant?: boolean;
  tag?: string;
  messages?: Message[];
}

export interface FilterState {
  origin: string;
  agent: string;
  startDate: string;
  endDate: string;
}
