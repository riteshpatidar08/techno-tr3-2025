import React, { useState, useRef, useEffect } from 'react';
import {
  Search,
  Plus,
  ChevronDown,
  ChevronUp,
  ChevronRight,
  Filter,
  ArrowLeft,
  Bot,
  MessageSquare,
  Loader2,
  Settings,
  Archive,
  Star,
  MoreHorizontal,
  Clock,
  CheckCircle2,
  AlertCircle,
  Users,
  Zap,
  TrendingUp,
  Calendar,
  Eye,
  EyeOff,
  Phone,
  Check,
  CheckCheck,
  Volume2,
  VolumeX,
  Pin,
} from 'lucide-react';
import PhoneInput from 'react-phone-number-input';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

import { useAppDispatch, useAppSelector } from '@/redux/store';
import {
  fetchMessages,
  fetchConversation,
  sendMessage,
  selectConversation,
  selectConversations,
  selectSelectedConversation,
  selectChannels,
  selectMessagesLoading,
  selectMessagesError,
  selectFilteredConversations,
  selectUnreadCount,
  setSearchQuery,
  clearError,
  selectPaginationInfo,
} from '@/redux/messageSlice';

const channels = [
  {
    id: 'all',
    name: 'All',
    icon: MessageSquare,
    description: 'All messages',
  },
  {
    id: 'unread',
    name: 'Unread',
    icon: AlertCircle,
    description: 'Unread messages',
  },
  { id: 'active', name: 'Active', icon: Zap, description: 'Active chats' },
  {
    id: 'archived',
    name: 'Archived',
    icon: Archive,
    description: 'Archived chats',
  },
];

const chatFilters = [
  {
    id: 'All Chats',
    name: 'All Chats',
    icon: MessageSquare,
    description: 'Show all conversations',
  },
  {
    id: 'Active chats',
    name: 'Active Chats',
    icon: Zap,
    description: 'Currently active conversations',
  },
  { id: 'CTWA', name: 'CTWA', icon: Phone, description: 'Click to WhatsApp' },
  { id: 'G-CTWA', name: 'G-CTWA', icon: Users, description: 'Group CTWA' },
  {
    id: 'Broadcasts',
    name: 'Broadcasts',
    icon: TrendingUp,
    description: 'Broadcast messages',
  },
  {
    id: 'Unassigned',
    name: 'Unassigned',
    icon: AlertCircle,
    description: 'Unassigned conversations',
  },
  {
    id: 'Unread',
    name: 'Unread',
    icon: AlertCircle,
    description: 'Messages requiring attention',
  },
  {
    id: 'Last 24 Hours',
    name: 'Last 24 Hours',
    icon: Clock,
    description: 'Recent conversations',
  },
];

export default function ConversationList() {
  const dispatch = useAppDispatch();
  const conversations = useAppSelector(selectFilteredConversations) || [];
  const selectedConversation = useAppSelector(selectSelectedConversation);
  const apiChannels = useAppSelector(selectChannels) || [];
  const loading = useAppSelector(selectMessagesLoading) || false;
  const error = useAppSelector(selectMessagesError);
  const unreadCount = useAppSelector(selectUnreadCount) || 0;
  const paginationInfo = useAppSelector(selectPaginationInfo);

  const [selectedChannel, setSelectedChannel] = useState('all');
  const [searchType, setSearchType] = useState('name');
  const [showFiltersDropdown, setShowFiltersDropdown] = useState(false);
  const [selectedChatFilter, setSelectedChatFilter] = useState('All Chats');
  const [showChooseContact, setShowChooseContact] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState('+91');
  const [contactSearchQuery, setContactSearchQuery] = useState('');
  const [localSearchQuery, setLocalSearchQuery] = useState('');
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [showCompactView, setShowCompactView] = useState(false);

  // New state for expandable date groups
  const [expandedGroups, setExpandedGroups] = useState(
    new Set(['Today', 'Yesterday'])
  );

  const dropdownRef = useRef(null);
  const containerRef = useRef(null);
  const scrollContainerRef = useRef(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        await dispatch(fetchMessages()).unwrap();
      } catch (error) {
        console.error('Failed to fetch messages:', error);
      }
    };

    fetchData();
  }, [dispatch]);

  useEffect(() => {
    const debounceTimer = setTimeout(() => {
      dispatch(setSearchQuery(localSearchQuery));
    }, 300);

    return () => clearTimeout(debounceTimer);
  }, [localSearchQuery, dispatch]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setShowFiltersDropdown(false);
      }
    };

    if (showFiltersDropdown) {
      document.addEventListener('mousedown', handleClickOutside);
      return () =>
        document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [showFiltersDropdown]);

  useEffect(() => {
    const scrollContainer = scrollContainerRef.current;
    if (!scrollContainer) return;

    const handleScroll = async () => {
      const { scrollTop, scrollHeight, clientHeight } = scrollContainer;
      const scrollThreshold = 200;

      const isNearBottom =
        scrollTop + clientHeight >= scrollHeight - scrollThreshold;
      const canLoadMore = paginationInfo.currentPage < paginationInfo.lastPage;

      if (isNearBottom && canLoadMore && !loading && !isLoadingMore) {
        setIsLoadingMore(true);

        try {
          await dispatch(
            fetchMessages({
              page: paginationInfo.currentPage + 1,
              selectedChannel:
                selectedChannel !== 'all' ? selectedChannel : undefined,
              search: localSearchQuery,
            })
          ).unwrap();
        } catch (error) {
          console.error('Failed to load more conversations:', error);
        } finally {
          setIsLoadingMore(false);
        }
      }
    };

    scrollContainer.addEventListener('scroll', handleScroll);
    return () => scrollContainer.removeEventListener('scroll', handleScroll);
  }, [
    dispatch,
    paginationInfo.currentPage,
    paginationInfo.lastPage,
    loading,
    isLoadingMore,
    selectedChannel,
    localSearchQuery,
  ]);

  const formatTimestamp = (timestamp) => {
    const date =
      typeof timestamp === 'number'
        ? new Date(timestamp * 1000)
        : new Date(timestamp);

    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);

    if (diffInHours < 1) {
      return 'now';
    } else if (diffInHours < 24) {
      return date.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: false,
      });
    } else if (diffInHours < 48) {
      return 'Yesterday';
    } else {
      return date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
      });
    }
  };

  const getConversationStatus = (conversation) => {
    return conversation.isActive ? 'active' : 'expired';
  };

  const getPriorityFromUnread = (unreadCount) => {
    if (unreadCount > 5) return 'high';
    if (unreadCount > 2) return 'medium';
    return 'low';
  };

  const getMessageStatusIcon = (message) => {
    if (!message) return null;

    switch (message.status) {
      case 'sent':
        return <Check className="w-3 h-3 text-muted-foreground" />;
      case 'delivered':
        return <CheckCheck className="w-3 h-3 text-muted-foreground" />;
      case 'read':
        return <CheckCheck className="w-3 h-3 text-blue-500" />;
      default:
        return null;
    }
  };

  const groupedConversations = React.useMemo(() => {
    if (!conversations || conversations.length === 0) {
      return {};
    }

    // Sort conversations by pinned status first, then by last message time
    const sortedConversations = [...conversations].sort((a, b) => {
      // First sort by pinned status
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;

      // Then sort by last message time
      const timeA = new Date(a.lastMessageTime).getTime();
      const timeB = new Date(b.lastMessageTime).getTime();
      return timeB - timeA;
    });

    return sortedConversations.reduce((acc, conv) => {
      if (!conv || !conv.lastMessageTime) {
        return acc;
      }

      const messageDate = new Date(conv.lastMessageTime);
      const today = new Date();
      const yesterday = new Date(today.getTime() - 24 * 60 * 60 * 1000);
      const lastWeek = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);

      let dateKey;

      if (messageDate.toDateString() === today.toDateString()) {
        dateKey = 'Today';
      } else if (messageDate.toDateString() === yesterday.toDateString()) {
        dateKey = 'Yesterday';
      } else if (messageDate >= lastWeek) {
        dateKey = 'This Week';
      } else {
        dateKey = 'Older';
      }

      if (!acc[dateKey]) {
        acc[dateKey] = [];
      }
      acc[dateKey].push(conv);

      return acc;
    }, {});
  }, [conversations]);

  const toggleGroupExpansion = (groupKey) => {
    const newExpanded = new Set(expandedGroups);
    if (newExpanded.has(groupKey)) {
      newExpanded.delete(groupKey);
    } else {
      newExpanded.add(groupKey);
    }
    setExpandedGroups(newExpanded);
  };

  const getGroupCounts = (convs) => {
    const total = convs.length;
    const unread = convs.filter((conv) => conv.unreadCount > 0).length;
    return { total, unread };
  };

  const handleConversationSelect = async (conversation) => {
    console.log('Selecting conversation:', conversation);

    dispatch(selectConversation(conversation.contact_id || conversation.id));

    if (apiChannels.length > 0) {
      const selectedChannelNumber = apiChannels[0].whatsapp_no;

      console.log('Fetching conversation for:', {
        contactNumber: conversation.contact_number,
        selectedChannel: selectedChannelNumber,
      });

      try {
        await dispatch(
          fetchConversation({
            contactNumber: conversation.contact_number,
            selectedChannel: selectedChannelNumber,
            page: 1,
          })
        ).unwrap();

        console.log('Conversation fetched successfully');
      } catch (error) {
        console.error('Failed to fetch conversation:', error);
      }
    } else {
      console.error('No channels available for fetching conversation');
    }
  };

  const handleContactSelect = (contactId, contactName) => {
    setShowChooseContact(false);
    setPhoneNumber('+91');
    setContactSearchQuery('');
    dispatch(selectConversation(contactId));
  };

  const handleBackToChats = () => {
    setShowChooseContact(false);
    setPhoneNumber('+91');
    setContactSearchQuery('');
  };

  const handleNextClick = () => {
    if (phoneNumber.length > 3) {
      console.log('Starting conversation with:', phoneNumber);
      setShowChooseContact(false);
      setPhoneNumber('+91');
      setContactSearchQuery('');
      dispatch(selectConversation(phoneNumber));
    }
  };

  useEffect(() => {
    return () => {
      dispatch(clearError());
    };
  }, [dispatch]);

  // Calculate stats
  const totalConversations = conversations.length;
  const activeConversations = conversations.filter(
    (conv) => conv.isActive
  ).length;

  if (showChooseContact) {
    return (
      <div className="h-full  border-r border-border flex flex-col">
        {/* Header */}
        <div className="flex-shrink-0 p-4 border-b border-border">
          <div className="flex items-center space-x-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleBackToChats}
              className="p-2 hover:bg-accent text-muted-foreground hover:text-foreground"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h2 className="font-semibold text-lg text-foreground">
                New chat
              </h2>
              <p className="text-sm text-muted-foreground">
                {conversations.length} contacts
              </p>
            </div>
          </div>
        </div>

        {/* Search */}
        <div className="flex-shrink-0 p-4 border-b border-border">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search contacts..."
              value={contactSearchQuery}
              onChange={(e) => setContactSearchQuery(e.target.value)}
              className="pl-10  border-input"
            />
          </div>
        </div>

        {/* Phone Number Input */}
        <div className="flex-shrink-0 p-4 border-b border-border">
          <div className="space-y-3">
            <div className="flex items-center space-x-3 p-3 hover:bg-accent cursor-pointer rounded-lg">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <Users className="w-5 h-5 text-primary-foreground" />
              </div>
              <div className="flex-1">
                <p className="font-medium text-foreground">New group</p>
              </div>
            </div>
            <div className="flex items-center space-x-3 p-3 hover:bg-accent cursor-pointer rounded-lg">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <Plus className="w-5 h-5 text-primary-foreground" />
              </div>
              <div className="flex-1">
                <p className="font-medium text-foreground">New contact</p>
                <PhoneInput
                  international
                  defaultCountry="IN"
                  value={phoneNumber}
                  onChange={(value) => setPhoneNumber(value || '+91')}
                  className="text-sm text-muted-foreground mt-1"
                />
              </div>
              {phoneNumber.length > 3 && (
                <Button size="sm" onClick={handleNextClick}>
                  <MessageSquare className="w-4 h-4" />
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Contact List */}
        <div className="flex-1 overflow-y-auto">
          <div className="p-4">
            <h3 className="text-sm font-medium text-muted-foreground mb-3 uppercase tracking-wide">
              Contacts on WhatsApp
            </h3>
            <div className="space-y-1">
              {conversations
                .filter(
                  (conv) =>
                    !contactSearchQuery ||
                    conv.contact_name
                      .toLowerCase()
                      .includes(contactSearchQuery.toLowerCase()) ||
                    conv.contact_number.includes(contactSearchQuery)
                )
                .map((conversation) => (
                  <div
                    key={conversation.id}
                    onClick={() =>
                      handleContactSelect(
                        conversation.contact_id || conversation.id,
                        conversation.contact_name
                      )
                    }
                    className="flex items-center space-x-3 p-3 rounded-lg hover:bg-accent cursor-pointer"
                  >
                    <div className="w-10 h-10 bg-muted rounded-full flex items-center justify-center text-foreground font-medium">
                      {conversation.contact_name.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground truncate">
                        {conversation.contact_name}
                      </p>
                      <p className="text-sm text-muted-foreground truncate">
                        {conversation.contact_number}
                      </p>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="h-full border-r border-border flex flex-col"
    >
      {/* Header */}
      <div className="flex-shrink-0 p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-semibold text-foreground">Chats</h1>
          <div className="flex items-center space-x-1">
            <Button variant="ghost" size="sm" className="h-9 w-9 p-0">
              <MoreHorizontal className="w-5 h-5" />
            </Button>
            <Button
              onClick={() => setShowChooseContact(true)}
              size="sm"
              className="h-9 w-9 p-0"
            >
              <Plus className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <Input
            placeholder="Search or start new chat"
            value={localSearchQuery}
            onChange={(e) => setLocalSearchQuery(e.target.value)}
            className="pl-10 bg-muted/30 border-0 focus-visible:ring-1 focus-visible:ring-primary"
          />
        </div>

        {/* Filter Tabs */}
        <div className="flex space-x-0 mb-2">
          {channels.map((channel) => (
            <button
              key={channel.id}
              onClick={() => setSelectedChannel(channel.id)}
              className={`px-4 py-2 text-sm font-medium rounded-full transition-colors ${
                selectedChannel === channel.id
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent'
              }`}
            >
              {channel.name}
            </button>
          ))}
        </div>
      </div>

      {/* Error Message */}
      {error && (
        <div className="flex-shrink-0 p-4 bg-destructive/10 border-l-4 border-destructive text-destructive">
          <div className="flex">
            <div className="flex-1">
              <p className="text-sm font-medium">Error loading conversations</p>
              <p className="text-sm">{error}</p>
            </div>
            <button
              onClick={() => dispatch(fetchMessages())}
              className="text-sm underline hover:no-underline font-medium"
            >
              Try again
            </button>
          </div>
        </div>
      )}

      {/* Loading State */}
      {loading && conversations.length === 0 && (
        <div className="flex-shrink-0 flex items-center justify-center p-8">
          <div className="flex items-center space-x-3">
            <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
            <span className="text-muted-foreground">Loading chats...</span>
          </div>
        </div>
      )}

      {/* Conversations List */}
      <div
        ref={scrollContainerRef}
        className="flex-1 min-h-0 overflow-y-auto scrollbar-hide"
      >
        {!loading && conversations.length === 0 && (
          <div className="flex flex-col items-center justify-center p-8 text-center h-full">
            <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mb-4">
              <MessageSquare className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-medium text-foreground mb-2">
              No chats yet
            </h3>
            <p className="text-sm text-muted-foreground mb-6 max-w-sm">
              Start a conversation with your contacts to see them here.
            </p>
            <Button
              onClick={() => setShowChooseContact(true)}
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              <Plus className="w-4 h-4 mr-2" />
              Start new chat
            </Button>
          </div>
        )}

        {Object.entries(groupedConversations).map(([date, convs]) => {
          const isExpanded = expandedGroups.has(date);
          const { total, unread } = getGroupCounts(convs);

          return (
            <div key={date}>
              {/* Date Header - Expandable */}
              <div
                onClick={() => toggleGroupExpansion(date)}
                className="sticky top-0 z-10  backdrop-blur-sm border-b border-border/50 px-4 py-2 cursor-pointer hover:bg-accent/50 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    {isExpanded ? (
                      <ChevronDown className="w-4 h-4 text-muted-foreground" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-muted-foreground" />
                    )}
                    <span className="text-sm font-medium text-foreground">
                      {date}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs text-muted-foreground">
                      {total} chat{total !== 1 ? 's' : ''}
                    </span>
                    {unread > 0 && (
                      <Badge className="bg-primary text-primary-foreground text-xs h-5 px-2">
                        {unread}
                      </Badge>
                    )}
                  </div>
                </div>
              </div>

              {/* Conversations for this date */}
              {isExpanded &&
                convs.map((conversation) => {
                  const status = getConversationStatus(conversation);
                  const isSelected =
                    selectedConversation?.id === conversation.id;

                  return (
                    <div
                      key={conversation.id}
                      onClick={() => handleConversationSelect(conversation)}
                      className={`flex items-center px-4 py-3 hover:bg-accent cursor-pointer transition-colors relative ${
                        isSelected ? 'bg-accent' : ''
                      }`}
                    >
                      {/* Pinned indicator */}
                      {conversation.isPinned && (
                        <Pin className="absolute left-1 top-2 w-3 h-3 text-muted-foreground" />
                      )}

                      {/* Avatar */}
                      <div className="relative mr-3 flex-shrink-0">
                        <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center text-foreground font-medium">
                          {conversation.contact_name.charAt(0).toUpperCase()}
                        </div>
                        {conversation.isActive && (
                          <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 border-2 border-background rounded-full"></div>
                        )}
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        {/* Header Row */}
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center space-x-2 min-w-0 flex-1">
                            <h4 className="font-medium text-foreground truncate">
                              {conversation.contact_name}
                            </h4>
                            {conversation.isMuted && (
                              <VolumeX className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                            )}
                          </div>
                          <span className="text-xs text-muted-foreground flex-shrink-0 ml-2">
                            {formatTimestamp(conversation.lastMessageTime)}
                          </span>
                        </div>

                        {/* Message Row */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-1 flex-1 min-w-0 mr-3">
                            {conversation.lastMessage?.method === 'bot' && (
                              <Bot className="w-4 h-4 text-blue-500 flex-shrink-0" />
                            )}
                            {getMessageStatusIcon(conversation.lastMessage)}
                            <p className="text-sm text-muted-foreground truncate">
                              {conversation.lastMessage?.text ||
                                'No messages yet'}
                            </p>
                          </div>

                          <div className="flex items-center space-x-1 flex-shrink-0">
                            {conversation.unreadCount > 0 && (
                              <Badge className="bg-primary text-primary-foreground text-xs h-5 px-2 min-w-[20px] text-center">
                                {conversation.unreadCount > 99
                                  ? '99+'
                                  : conversation.unreadCount}
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
            </div>
          );
        })}

        {/* Loading More */}
        {isLoadingMore && (
          <div className="flex items-center justify-center p-6">
            <div className="flex items-center space-x-3">
              <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
              <span className="text-sm text-muted-foreground">
                Loading more chats...
              </span>
            </div>
          </div>
        )}

        {/* End of List */}
        {!loading &&
          !isLoadingMore &&
          conversations.length > 0 &&
          paginationInfo.currentPage >= paginationInfo.lastPage && (
            <div className="flex items-center justify-center p-6">
              <span className="text-sm text-muted-foreground">
                You're all caught up
              </span>
            </div>
          )}
      </div>

      {/* Custom Styles */}
      <style jsx>{`
        /* Hide scrollbar for clean look */
        div::-webkit-scrollbar {
          width: 0px;
          background: transparent;
        }

        /* Smooth animations */
        * {
          transition: all 0.15s ease-in-out;
        }

        /* WhatsApp-like hover effects */
        .hover-lift:hover {
          transform: translateY(-1px);
        }

        /* Custom phone input styling */
        .phone-input input {
          border: none !important;
          outline: none !important;
          background: transparent !important;
        }

        /* Enhanced focus states */
        button:focus-visible,
        input:focus-visible {
          outline: 2px solid hsl(var(--primary));
          outline-offset: 2px;
        }

        /* Custom badge animations */
        .animate-badge {
          animation: badgePulse 1s ease-in-out infinite;
        }

        @keyframes badgePulse {
          0%,
          100% {
            transform: scale(1);
          }
          50% {
            transform: scale(1.05);
          }
        }

        /* Gradient overlays for depth */
        .gradient-overlay {
          background: linear-gradient(
            180deg,
            transparent 0%,
            hsl(var(--background)) / 0.05 100%
          );
        }

        /* Enhanced shadows */
        .shadow-elegant {
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1),
            0 1px 2px rgba(0, 0, 0, 0.06);
        }

        /* Compact mode styles */
        .compact .conversation-item {
          padding: 8px 16px;
        }

        .compact .avatar {
          width: 40px;
          height: 40px;
        }

        /* Message status indicators */
        .status-sent {
          color: hsl(var(--muted-foreground));
        }
        .status-delivered {
          color: hsl(var(--muted-foreground));
        }
        .status-read {
          color: hsl(var(--primary));
        }

        /* Priority indicators with subtle animations */
        .priority-indicator {
          animation: priorityPulse 2s ease-in-out infinite;
        }

        @keyframes priorityPulse {
          0%,
          100% {
            opacity: 1;
          }
          50% {
            opacity: 0.7;
          }
        }

        /* Expandable group animations */
        .group-header {
          transition: background-color 0.2s ease;
        }

        .group-header:hover {
          background-color: hsl(var(--accent)) / 0.5;
        }

        /* Conversation item animations */
        .conversation-item {
          transition: all 0.2s ease;
          border-left: 3px solid transparent;
        }

        .conversation-item:hover {
          background-color: hsl(var(--accent));
          border-left-color: hsl(var(--primary)) / 0.3;
        }

        .conversation-item.selected {
          background-color: hsl(var(--accent));
          border-left-color: hsl(var(--primary));
        }

        /* Pinned conversation indicator */
        .pinned-indicator {
          animation: pinPulse 3s ease-in-out infinite;
        }

        @keyframes pinPulse {
          0%,
          100% {
            opacity: 0.6;
          }
          50% {
            opacity: 1;
          }
        }

        /* Message status colors */
        .message-status-sent {
          color: hsl(var(--muted-foreground));
        }
        .message-status-delivered {
          color: hsl(var(--muted-foreground));
        }
        .message-status-read {
          color: hsl(var(--primary));
        }

        /* Unread badge glow effect */
        .unread-badge {
          box-shadow: 0 0 8px hsl(var(--primary)) / 0.3;
        }

        /* Date group collapse/expand animation */
        .group-content {
          overflow: hidden;
          transition: max-height 0.3s ease-in-out;
        }

        /* Loading shimmer effect */
        .loading-shimmer {
          background: linear-gradient(
            90deg,
            hsl(var(--muted)) 25%,
            hsl(var(--muted)) / 50% 50%,
            hsl(var(--muted)) 75%
          );
          background-size: 200% 100%;
          animation: shimmer 2s infinite;
        }

        @keyframes shimmer {
          0% {
            background-position: 200% 0;
          }
          100% {
            background-position: -200% 0;
          }
        }

        /* Active status indicator */
        .active-status {
          background: linear-gradient(135deg, #10b981, #059669);
          box-shadow: 0 0 6px rgba(16, 185, 129, 0.4);
        }

        /* Muted conversation styling */
        .muted-conversation {
          opacity: 0.7;
        }

        .muted-conversation:hover {
          opacity: 1;
        }

        /* Search highlight */
        .search-highlight {
          background: hsl(var(--primary)) / 0.2;
          padding: 1px 2px;
          border-radius: 2px;
        }

        /* Responsive design */
        @media (max-width: 768px) {
          .conversation-item {
            padding: 12px 16px;
          }

          .avatar {
            width: 48px;
            height: 48px;
          }

          .conversation-header {
            padding: 16px;
          }

          .search-input {
            font-size: 16px; /* Prevents zoom on iOS */
          }
        }

        /* Dark mode enhancements */
        @media (prefers-color-scheme: dark) {
          .conversation-item:hover {
            background-color: hsl(var(--accent)) / 0.8;
          }

          .group-header:hover {
            background-color: hsl(var(--accent)) / 0.6;
          }
        }

        /* High contrast mode support */
        @media (prefers-contrast: high) {
          .conversation-item {
            border: 1px solid hsl(var(--border));
          }

          .unread-badge {
            border: 2px solid hsl(var(--background));
          }
        }

        /* Reduced motion support */
        @media (prefers-reduced-motion: reduce) {
          * {
            animation-duration: 0.01ms !important;
            animation-iteration-count: 1 !important;
            transition-duration: 0.01ms !important;
          }
        }

        /* Focus management for accessibility */
        .conversation-item:focus {
          outline: 2px solid hsl(var(--primary));
          outline-offset: -2px;
        }

        .group-header:focus {
          outline: 2px solid hsl(var(--primary));
          outline-offset: -2px;
        }

        /* Smooth scrolling */
        html {
          scroll-behavior: smooth;
        }

        /* Enhanced backdrop blur for sticky headers */
        .sticky-header {
          backdrop-filter: blur(8px);
          -webkit-backdrop-filter: blur(8px);
        }
      `}</style>
    </div>
  );
}
