import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { X, Calendar, MoreVertical } from 'lucide-react';

interface FilterModalProps {
  show: boolean;
  onClose: () => void;
  startDate: string;
  endDate: string;
  onStartDateChange: (date: string) => void;
  onEndDateChange: (date: string) => void;
  onApplyFilters: () => void;
  onResetFilters: () => void;
}

export default function FilterModal({
  show,
  onClose,
  startDate,
  endDate,
  onStartDateChange,
  onEndDateChange,
  onApplyFilters,
  onResetFilters,
}: FilterModalProps) {
  if (!show) return null;

  return (
    <div className="fixed inset-0 backdrop-blur-[1px]  bg-opacity-20 flex items-start justify-center z-50 pt-20 animate-fadeIn">
      <div className="bg-white rounded-3xl shadow-2xl w-[720px] max-h-[80vh] overflow-hidden animate-slideDown">
        <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900">
            Filter Conversation
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Search Message
            </label>
            <Input placeholder="Search in conversation..." className="w-full" />
          </div>

          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Date Range
            </label>
            <div className="space-y-4">
              <div className="relative">
                <Input
                  type="text"
                  placeholder="Start Date"
                  value={startDate}
                  onFocus={(e) => (e.target.type = 'date')}
                  onBlur={(e) => !e.target.value && (e.target.type = 'text')}
                  onChange={(e) => onStartDateChange(e.target.value)}
                  className="w-full pr-10"
                />
                <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
              </div>
              <div className="relative">
                <Input
                  type="text"
                  placeholder="End Date"
                  value={endDate}
                  onFocus={(e) => (e.target.type = 'date')}
                  onBlur={(e) => !e.target.value && (e.target.type = 'text')}
                  onChange={(e) => onEndDateChange(e.target.value)}
                  className="w-full pr-10"
                />
                <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
              </div>
            </div>
          </div>

          <div className="mb-6">
            <button className="w-full py-3 text-green-600 font-medium border-2 border-dashed border-gray-300 rounded-lg hover:border-green-500 hover:bg-green-50 transition-all duration-200 flex items-center justify-center space-x-2">
              <div className="flex space-x-1">
                <span
                  className="w-1 h-1 bg-green-600 rounded-full animate-bounce"
                  style={{ animationDelay: '0ms' }}
                ></span>
                <span
                  className="w-1 h-1 bg-green-600 rounded-full animate-bounce"
                  style={{ animationDelay: '150ms' }}
                ></span>
                <span
                  className="w-1 h-1 bg-green-600 rounded-full animate-bounce"
                  style={{ animationDelay: '300ms' }}
                ></span>
              </div>
              <span>Load More Messages</span>
            </button>
          </div>

          <div className="flex items-center justify-between">
            <button
              onClick={onResetFilters}
              className="flex items-center space-x-2 text-gray-600 hover:text-gray-800 transition-colors"
            >
              <div className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center hover:border-gray-400 transition-colors">
                <MoreVertical className="w-4 h-4 rotate-90" />
              </div>
              <span className="text-sm font-medium">Reset</span>
            </button>

            <Button
              onClick={onApplyFilters}
              className="bg-green-500 hover:bg-green-600 text-white px-6 py-2.5 rounded-lg font-medium transition-all duration-200 hover:shadow-lg hover:scale-105"
            >
              Apply Filters
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
