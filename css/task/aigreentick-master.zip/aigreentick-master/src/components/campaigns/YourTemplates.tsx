import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import TemplateHeader from '@/components/campaigns/TemplateHeader';
import TemplateControls from '@/components/campaigns/TemplateControls';
import TemplateTable from '@/components/campaigns/TemplateTable';
import TemplateForm from '@/components/campaigns/TemplateForm';
import ChatWidget from '@/components/campaigns/ChatWidget';
import { Skeleton } from '@/components/ui/skeleton';
import WarningComponent, {
  ErrorWarning,
  InfoWarning,
  AlertWarning,
} from '@/components/ui/warning';
import { RefreshCw, AlertCircle, Plus } from 'lucide-react';
import {
  fetchTemplates,
  selectTemplates,
  selectTemplatesLoading,
  selectTemplatesError,
  selectTemplatesTotal,
  selectTemplatesPagination,
  clearError,
  resetTemplates,
  Template,
} from '@/redux/templateSlice';

const TemplateHeaderSkeleton = () => (
  <div className="flex justify-between items-center mb-6">
    <div className="space-y-2">
      <Skeleton className="h-8 w-48" />
      <Skeleton className="h-4 w-64" />
    </div>
    <Skeleton className="h-10 w-32" />
  </div>
);

const TemplateControlsSkeleton = () => (
  <div className="flex justify-between items-center mb-6">
    <div className="flex space-x-4">
      <Skeleton className="h-10 w-64" />
      <Skeleton className="h-10 w-32" />
    </div>
    <div className="flex space-x-2">
      <Skeleton className="h-10 w-24" />
      <Skeleton className="h-10 w-24" />
    </div>
  </div>
);

const TemplateTableSkeleton = () => (
  <div className="bg-white rounded-lg">
    <div className="grid grid-cols-6 gap-4 p-4 bg-gray-50">
      <Skeleton className="h-4 w-20" />
      <Skeleton className="h-4 w-16" />
      <Skeleton className="h-4 w-12" />
      <Skeleton className="h-4 w-16" />
      <Skeleton className="h-4 w-20" />
      <Skeleton className="h-4 w-12" />
    </div>

    {Array.from({ length: 3 }).map((_, index) => (
      <div key={index} className="grid grid-cols-6 gap-4 p-4">
        <div className="space-y-2">
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-3 w-16" />
        </div>
        <Skeleton className="h-6 w-16 rounded-full" />
        <Skeleton className="h-6 w-20 rounded-full" />
        <Skeleton className="h-4 w-16" />
        <Skeleton className="h-4 w-20" />
        <div className="flex space-x-2">
          <Skeleton className="h-8 w-8 rounded" />
          <Skeleton className="h-8 w-8 rounded" />
          <Skeleton className="h-8 w-8 rounded" />
        </div>
      </div>
    ))}
  </div>
);

const LoadingSkeleton = () => (
  <div className="flex-1 flex flex-col">
    <div className="p-6">
      <div className="max-w-7xl mx-auto">
        <TemplateHeaderSkeleton />
        <TemplateControlsSkeleton />
        <TemplateTableSkeleton />
      </div>
    </div>
  </div>
);

const YourTemplates: React.FC = () => {
  const dispatch = useDispatch();

  const templates = useSelector(selectTemplates) || [];
  console.log(templates)
  const loading = useSelector(selectTemplatesLoading) || false;
  const error = useSelector(selectTemplatesError) || null;
  const total = useSelector(selectTemplatesTotal) || 0;
  const pagination = useSelector(selectTemplatesPagination) || {
    currentPage: 1,
    lastPage: 1,
    total: 0,
    perPage: 10,
    hasMorePages: false,
  };

  const [activeTab, setActiveTab] = useState<string>('Your Templates');
  const [sortBy, setSortBy] = useState<string>('latest');
  const [showTemplateForm, setShowTemplateForm] = useState<boolean>(false);
  const [filteredTemplates, setFilteredTemplates] = useState<Template[]>([]);

  useEffect(() => {
    console.log('YourTemplates: Fetching templates...');
    dispatch(fetchTemplates() as any);

    return () => {
      dispatch(clearError());
    };
  }, [dispatch]);

  useEffect(() => {
    if (!Array.isArray(templates)) {
      console.warn('Templates is not an array:', templates);
      setFilteredTemplates([]);
      return;
    }

    let filtered = [...templates];

    switch (sortBy) {
      case 'latest':
        filtered.sort((a, b) => {
          const dateA = new Date(a.updated_at || a.created_at).getTime();
          const dateB = new Date(b.updated_at || b.created_at).getTime();
          return dateB - dateA;
        });
        break;
      case 'oldest':
        filtered.sort((a, b) => {
          const dateA = new Date(a.updated_at || a.created_at).getTime();
          const dateB = new Date(b.updated_at || b.created_at).getTime();
          return dateA - dateB;
        });
        break;
      case 'name':
        filtered.sort((a, b) => (a.name || '').localeCompare(b.name || ''));
        break;
      case 'status':
        filtered.sort((a, b) => (a.status || '').localeCompare(b.status || ''));
        break;
      default:
        break;
    }

    setFilteredTemplates(filtered);
  }, [templates, sortBy]);

  const handleRefresh = () => {
    console.log('YourTemplates: Refreshing templates...');
    dispatch(resetTemplates());
    dispatch(fetchTemplates() as any);
  };

  const handleRetry = () => {
    dispatch(clearError());
    handleRefresh();
  };

  if (loading && (!Array.isArray(templates) || templates.length === 0)) {
    return <LoadingSkeleton />;
  }

  if (showTemplateForm) {
    return (
      <TemplateForm
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onBack={() => setShowTemplateForm(false)}
      />
    );
  }

  return (
    <div className="flex-1 flex flex-col">
      <div className="p-6">
        <div className="max-w-7xl mx-auto space-y-4">
          {error && (
            <ErrorWarning
              title="Failed to load templates"
              message={error}
              actions={[
                {
                  label: 'Retry',
                  onClick: handleRetry,
                  icon: RefreshCw,
                  variant: 'outline',
                  loading: loading,
                },
              ]}
              dismissible={true}
              onClose={() => dispatch(clearError())}
            />
          )}

          {!loading &&
            !error &&
            Array.isArray(templates) &&
            templates.length === 0 && (
              <InfoWarning
                title="No templates found"
                message="Your templates will appear here once you create them."
                description="Get started by creating your first template to streamline your messaging campaigns."
                actions={[
                  {
                    label: 'Create Template',
                    onClick: () => setShowTemplateForm(true),
                    icon: Plus,
                    variant: 'default',
                  },
                ]}
                size="lg"
              />
            )}

          {!loading && !Array.isArray(templates) && (
            <AlertWarning
              title="Data loading issue"
              message="Templates data is not in the expected format."
              description="This might be a temporary issue. Please try refreshing the page."
              actions={[
                {
                  label: 'Refresh',
                  onClick: handleRefresh,
                  icon: RefreshCw,
                  variant: 'outline',
                },
              ]}
            />
          )}

          <TemplateHeader onNewTemplate={() => setShowTemplateForm(true)} />

          {/* <TemplateControls
            sortBy={sortBy}
            setSortBy={setSortBy}
            onRefresh={handleRefresh}
            totalTemplates={total}
            loading={loading}
          /> */}

          <TemplateTable
            templates={
              Array.isArray(filteredTemplates) ? filteredTemplates : []
            }
            loading={loading}
            onRefresh={handleRefresh}
          />
        </div>
      </div>

      <ChatWidget />
    </div>
  );
};

export default YourTemplates;
