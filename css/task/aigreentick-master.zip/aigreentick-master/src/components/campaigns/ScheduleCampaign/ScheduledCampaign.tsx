import React, { useState, useEffect } from 'react';
import { ScheduledBroadcastsList } from './ScheduledBroadcastsList';
import { CreateBroadcastView } from './CreateBroadcastView';
import {
  enhancedContacts,
  availableTemplates,
  scheduledBroadcasts,
  defaultVariableValues,
} from './constants';
import {
  filterContacts,
  getCurrentTemplate,
  getTemplateVariables,
} from './utils';
import { FilterCondition } from './types';

const ScheduledCampaign: React.FC = () => {
  const [currentView, setCurrentView] = useState<'list' | 'create'>('list');
  const [broadcastName, setBroadcastName] = useState('Untitled_070720251429');
  const [selectedTemplate, setSelectedTemplate] = useState('welcome_wati_v1');
  const [sendOption, setSendOption] = useState('now');
  const [selectedContacts, setSelectedContacts] = useState(new Set([1]));
  const [searchTerm, setSearchTerm] = useState('');
  const [activeFilters, setActiveFilters] = useState<FilterCondition[]>([]);
  const [filteredContacts, setFilteredContacts] = useState(enhancedContacts);
  const [variableValues, setVariableValues] = useState(defaultVariableValues);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const currentTemplate = getCurrentTemplate(
    selectedTemplate,
    availableTemplates
  );
  const templateVariables = getTemplateVariables(currentTemplate);
  const applyFilters = (conditions: FilterCondition[]) => {
    const filtered = filterContacts(enhancedContacts, searchTerm, conditions);
    setFilteredContacts(filtered);
    setActiveFilters(conditions);
  };
  useEffect(() => {
    applyFilters(activeFilters);
  }, [searchTerm]);
  const handleApplyFilters = (conditions: FilterCondition[]) => {
    applyFilters(conditions);
    setShowFilterModal(false);
  };

  const handleContactSelect = (contactId: number) => {
    const newSelected = new Set(selectedContacts);
    if (newSelected.has(contactId)) {
      newSelected.delete(contactId);
    } else {
      newSelected.add(contactId);
    }
    setSelectedContacts(newSelected);
  };

  const handleSelectAll = () => {
    const eligibleContacts = filteredContacts.filter((c) => c.allowBroadcast);
    if (selectedContacts.size === eligibleContacts.length) {
      setSelectedContacts(new Set());
    } else {
      setSelectedContacts(new Set(eligibleContacts.map((c) => c.id)));
    }
  };

  const handleVariableChange = (variable: string, value: string) => {
    setVariableValues((prev) => ({
      ...prev,
      [variable]: value,
    }));
  };

  const handleClearFilters = () => {
    setActiveFilters([]);
    applyFilters([]);
  };

  const handleAddBroadcast = () => {
    console.log('Adding broadcast:', {
      name: broadcastName,
      template: selectedTemplate,
      contacts: Array.from(selectedContacts),
      sendOption,
      variables: variableValues,
    });
    setCurrentView('list');
  };

  return currentView === 'list' ? (
    <ScheduledBroadcastsList
      broadcasts={scheduledBroadcasts}
      onCreateNew={() => setCurrentView('create')}
    />
  ) : (
    <CreateBroadcastView
      broadcastName={broadcastName}
      selectedTemplate={selectedTemplate}
      sendOption={sendOption}
      filteredContacts={filteredContacts}
      selectedContacts={selectedContacts}
      searchTerm={searchTerm}
      activeFilters={activeFilters}
      availableTemplates={availableTemplates}
      currentTemplate={currentTemplate}
      templateVariables={templateVariables}
      variableValues={variableValues}
      showFilterModal={showFilterModal}
      onBack={() => setCurrentView('list')}
      onDiscard={() => setCurrentView('list')}
      onAddBroadcast={handleAddBroadcast}
      onBroadcastNameChange={setBroadcastName}
      onTemplateChange={setSelectedTemplate}
      onSendOptionChange={setSendOption}
      onContactSelect={handleContactSelect}
      onSelectAll={handleSelectAll}
      onSearchChange={setSearchTerm}
      onShowFilter={() => setShowFilterModal(true)}
      onCloseFilter={() => setShowFilterModal(false)}
      onApplyFilters={handleApplyFilters}
      onClearFilters={handleClearFilters}
      onVariableChange={handleVariableChange}
    />
  );
};

export default ScheduledCampaign;
