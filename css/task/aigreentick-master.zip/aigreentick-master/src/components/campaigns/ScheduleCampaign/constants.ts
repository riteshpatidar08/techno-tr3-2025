import {
  Contact,
  AvailableTemplate,
  ScheduledBroadcast,
  VariableValues,
} from './types';

export const enhancedContacts: Contact[] = [
  {
    id: 1,
    name: 'KRUSHNA 👑 ♨️',
    phone: '918432482806',
    allowBroadcast: true,
    attributes: {
      channel: 'web',
      source: 'whatsapp',
      type: 'customer',
      priority: 'high',
      leadScore: '85',
    },
  },
  {
    id: 2,
    name: 'Piyush Agrawal',
    phone: '918357950987',
    allowBroadcast: true,
    attributes: {
      channel: 'mobile',
      source: 'manual',
      type: 'lead',
      priority: 'medium',
      leadScore: '72',
    },
  },
  {
    id: 3,
    name: 'Rajat Goyal',
    phone: '919772165018',
    allowBroadcast: true,
    attributes: {
      channel: 'social',
      source: 'wati',
      type: 'test',
      priority: 'low',
      leadScore: '45',
    },
  },
  {
    id: 4,
    name: 'Shri Balaji Message',
    phone: '919784690987',
    allowBroadcast: true,
    attributes: {
      channel: 'referral',
      source: 'whatsapp',
      type: 'prospect',
      priority: 'medium',
      leadScore: '68',
    },
  },
  {
    id: 5,
    name: 'sonu',
    phone: '918379081309',
    allowBroadcast: true,
    attributes: {
      channel: 'web',
      source: 'import',
      type: 'customer',
      priority: 'high',
      leadScore: '90',
    },
  },
];

export const availableTemplates: AvailableTemplate[] = [
  {
    id: 1,
    name: 'welcome_wati_v1',
    category: 'welcome',
    template: {
      name: 'welcome_wati_v1',
      components: [
        {
          type: 'HEADER',
          format: 'TEXT',
          text: 'Welcome to WATI! 👋',
        },
        {
          type: 'BODY',
          text: 'Hi {{name}},\n\nThank you for your message.\n\nHow can I help you today?',
        },
        {
          type: 'FOOTER',
          text: "WATI's Chatbot",
        },
        {
          type: 'BUTTONS',
          buttons: [
            { type: 'QUICK_REPLY', text: 'Know the Pricing' },
            { type: 'QUICK_REPLY', text: 'Know how WATI works?' },
            { type: 'QUICK_REPLY', text: 'Get Started' },
          ],
        },
      ],
    },
  },
  {
    id: 2,
    name: 'order_confirmation',
    category: 'transactional',
    template: {
      name: 'order_confirmation',
      components: [
        {
          type: 'HEADER',
          format: 'TEXT',
          text: 'Order Confirmed! ✅',
        },
        {
          type: 'BODY',
          text: 'Hello {{customer_name}},\n\nYour order #{{order_id}} has been confirmed!\n\nOrder Total: {{amount}}\nExpected Delivery: {{delivery_date}}\n\nThank you for shopping with us!',
        },
        {
          type: 'FOOTER',
          text: 'Track your order anytime',
        },
        {
          type: 'BUTTONS',
          buttons: [
            { type: 'QUICK_REPLY', text: 'Track Order' },
            { type: 'QUICK_REPLY', text: 'Contact Support' },
          ],
        },
      ],
    },
  },
];

export const scheduledBroadcasts: ScheduledBroadcast[] = [
  {
    id: 1,
    name: 'Welcome Campaign Q4',
    template: 'welcome_wati_v1',
    contacts: 1250,
    scheduled: '2025-07-08 10:00 AM',
    status: 'scheduled',
    createdAt: '2025-07-07',
  },
  {
    id: 2,
    name: 'Product Launch Announcement',
    template: 'product_launch_v2',
    contacts: 3500,
    scheduled: '2025-07-09 2:00 PM',
    status: 'scheduled',
    createdAt: '2025-07-07',
  },
];

export const defaultVariableValues: VariableValues = {
  name: 'Peter',
  customer_name: 'Peter',
  order_id: 'ORD123456',
  amount: '$299.99',
  delivery_date: 'July 10, 2025',
  discount: '25',
  promo_code: 'SAVE25',
  expiry_date: 'July 15, 2025',
};
