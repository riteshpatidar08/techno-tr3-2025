import React from 'react';
import {
  ArrowLeft,
  Phone,
  Video,
  MoreVertical,
  Info,
  CheckCheck,
} from 'lucide-react';
import { Template, VariableValues } from './types';

interface TemplatePreviewProps {
  template: Template;
  variableValues: VariableValues;
}

export const TemplatePreview: React.FC<TemplatePreviewProps> = ({
  template,
  variableValues,
}) => {
  const replaceVariables = (text: string): string => {
    if (!text) return '';
    let replacedText = text;
    Object.entries(variableValues).forEach(([key, value]) => {
      replacedText = replacedText.replace(
        new RegExp(`{{${key}}}`, 'g'),
        value || `{{${key}}}`
      );
    });
    return replacedText;
  };

  const headerComponent = template.components?.find((c) => c.type === 'HEADER');
  const bodyComponent = template.components?.find((c) => c.type === 'BODY');
  const footerComponent = template.components?.find((c) => c.type === 'FOOTER');
  const buttonsComponent = template.components?.find(
    (c) => c.type === 'BUTTONS'
  );

  return (
    <div className="bg-[#0a7c59] p-4 rounded-t-3xl">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <ArrowLeft className="w-6 h-6 text-white" />
          <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center">
            <span className="text-green-600 font-bold text-sm">Demo</span>
          </div>
          <div>
            <span className="text-white font-medium block">Demo Template</span>
            <span className="text-green-100 text-xs">online</span>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <Phone className="w-5 h-5 text-white" />
          <Video className="w-5 h-5 text-white" />
          <MoreVertical className="w-5 h-5 text-white" />
        </div>
      </div>

      <div className="bg-green-100 p-2 rounded-lg mb-3 flex items-center space-x-2">
        <Info className="w-4 h-4 text-green-600" />
        <span className="text-green-700 text-xs">
          This business uses a secure service from Meta to manage this chat. Tap
          to learn more
        </span>
      </div>

      <div className="bg-white rounded-2xl rounded-bl-sm p-4 shadow-lg max-w-sm ml-auto relative mb-4">
        {headerComponent && (
          <div className="mb-3">
            {headerComponent.format === 'IMAGE' &&
              headerComponent.image_url && (
                <img
                  src={headerComponent.image_url}
                  alt="Header"
                  className="w-full h-32 object-cover rounded-lg mb-2"
                />
              )}
            {headerComponent.text && (
              <div className="font-bold text-gray-800 text-lg">
                {replaceVariables(headerComponent.text)}
              </div>
            )}
          </div>
        )}

        {bodyComponent && bodyComponent.text && (
          <div className="mb-3 text-gray-700 leading-relaxed">
            {replaceVariables(bodyComponent.text)
              .split('\n')
              .map((line, index) => (
                <div key={index} className="mb-1">
                  {line}
                </div>
              ))}
          </div>
        )}

        {footerComponent && footerComponent.text && (
          <div className="text-xs text-gray-500 mb-3 italic">
            {replaceVariables(footerComponent.text)}
          </div>
        )}

        {buttonsComponent &&
          buttonsComponent.buttons &&
          buttonsComponent.buttons.length > 0 && (
            <div className="space-y-2 mt-3 pt-3 border-t border-gray-100">
              {buttonsComponent.buttons.map((button, index) => (
                <button
                  key={index}
                  className="w-full p-3 border border-green-500 rounded-lg text-green-600 text-sm font-medium hover:bg-green-50 transition-colors flex items-center justify-center"
                >
                  {button.text}
                </button>
              ))}
            </div>
          )}

        <div className="flex items-center justify-end mt-3 space-x-1">
          <span className="text-xs text-gray-400">14:29</span>
          <CheckCheck className="w-4 h-4 text-blue-500" />
        </div>

        <div className="absolute -bottom-0 right-4 w-0 h-0 border-l-8 border-l-transparent border-r-8 border-r-transparent border-t-8 border-t-white"></div>
      </div>
    </div>
  );
};
