import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Search, Filter } from 'lucide-react';
import { Contact, FilterCondition } from './types';

interface ContactSelectorProps {
  contacts: Contact[];
  selectedContacts: Set<number>;
  searchTerm: string;
  activeFilters: FilterCondition[];
  onContactSelect: (contactId: number) => void;
  onSelectAll: () => void;
  onSearchChange: (term: string) => void;
  onShowFilter: () => void;
  onClearFilters: () => void;
}

export const ContactSelector: React.FC<ContactSelectorProps> = ({
  contacts,
  selectedContacts,
  searchTerm,
  activeFilters,
  onContactSelect,
  onSelectAll,
  onSearchChange,
  onShowFilter,
  onClearFilters,
}) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Who do you want to send it to?</CardTitle>
        <div className="flex items-center space-x-3">
          <span className="text-sm text-gray-500">
            Select contacts below or
          </span>
          <Button variant="link" className="text-blue-500 p-0">
            Download sample format for contact upload
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="border-green-300 text-green-700"
          >
            Import Contacts
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center space-x-3">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => onSearchChange(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={onShowFilter}
              className={`${
                activeFilters.length > 0
                  ? 'bg-green-500 text-white border-green-500'
                  : ''
              }`}
            >
              <Filter className="w-4 h-4 mr-2" />
              Filter contacts
              {activeFilters.length > 0 && (
                <Badge className="ml-2 bg-white text-green-600">
                  {activeFilters.length}
                </Badge>
              )}
            </Button>
          </div>

          {activeFilters.length > 0 && (
            <div className="p-3 bg-blue-50 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-blue-900">
                  Active Filters:
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onClearFilters}
                  className="text-blue-600 hover:text-blue-800 h-6 text-xs"
                >
                  Clear all
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {activeFilters.map((filter) => (
                  <Badge
                    key={filter.id}
                    variant="outline"
                    className="bg-white border-blue-200 text-blue-800"
                  >
                    {filter.attribute} {filter.operation} "{filter.value}"
                  </Badge>
                ))}
              </div>
            </div>
          )}

          <div className="flex items-center justify-between">
            <div className="text-sm text-gray-600">
              Selected:{' '}
              <span className="font-medium text-green-600">
                {selectedContacts.size}
              </span>{' '}
              /
              <span className="font-medium text-gray-900">
                {contacts.filter((c) => c.allowBroadcast).length}
              </span>{' '}
              Contacts remaining
            </div>
            <div className="text-sm text-gray-500">
              Current limits:{' '}
              <span className="font-medium">250 unique contacts/24 hours</span>
            </div>
          </div>

          <div className="border border-gray-200 rounded-lg overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-left">
                    <Checkbox
                      checked={
                        selectedContacts.size ===
                        contacts.filter((c) => c.allowBroadcast).length
                      }
                      onCheckedChange={onSelectAll}
                    />
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Name
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Phone
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Allow broadcast
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {contacts.map((contact) => (
                  <tr key={contact.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3">
                      <Checkbox
                        checked={selectedContacts.has(contact.id)}
                        onCheckedChange={() => onContactSelect(contact.id)}
                        disabled={!contact.allowBroadcast}
                      />
                    </td>
                    <td className="px-4 py-3 text-sm font-medium text-gray-900">
                      {contact.name}
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-900">
                      {contact.phone}
                    </td>
                    <td className="px-4 py-3">
                      <Badge
                        variant={
                          contact.allowBroadcast ? 'default' : 'secondary'
                        }
                        className={
                          contact.allowBroadcast
                            ? 'bg-green-100 text-green-800'
                            : ''
                        }
                      >
                        {contact.allowBroadcast ? 'TRUE' : 'FALSE'}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex items-center justify-between text-sm text-gray-500">
            <span>Rows per page: 5</span>
            <span>1-5 of {contacts.length}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
