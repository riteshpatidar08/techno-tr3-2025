// import React, { useState, useRef } from 'react';
// import {
//   ArrowLeft,
//   Save,
//   Upload,
//   Plus,
//   X,
//   Bold,
//   Italic,
//   Strikethrough,
//   Smile,
//   Eye,
//   Phone,
//   ExternalLink,
//   MessageSquare,
//   Info,
//   Image as ImageIcon,
// } from 'lucide-react';
// import { Button } from '@/components/ui/button';
// import { Input } from '@/components/ui/input';
// import { Label } from '@/components/ui/label';
// import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
// import { Badge } from '@/components/ui/badge';
// import { Textarea } from '@/components/ui/textarea';
// import {
//   Select,
//   SelectContent,
//   SelectItem,
//   SelectTrigger,
//   SelectValue,
// } from '@/components/ui/select';
// import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
// import {
//   DropdownMenu,
//   DropdownMenuContent,
//   DropdownMenuItem,
//   DropdownMenuTrigger,
// } from '@/components/ui/dropdown-menu';
// import { useEditor, EditorContent } from '@tiptap/react';
// import StarterKit from '@tiptap/starter-kit';
// import Underline from '@tiptap/extension-underline';
// import Placeholder from '@tiptap/extension-placeholder';

//
// const TemplatePreview = ({ template, variables, loading = false }) => {
//   if (loading) {
//     return (
//       <Card className="border-0 bg-gradient-to-br from-card to-card/50 shadow-lg sticky top-6">
//         <CardHeader className="pb-4">
//           <CardTitle className="flex items-center gap-3 text-lg text-card-foreground">
//             <div className="p-2 bg-primary/10 rounded-lg">
//               <Eye className="h-5 w-5 text-primary" />
//             </div>
//             Template Preview
//           </CardTitle>
//         </CardHeader>
//         <CardContent>
//           <div className="animate-pulse space-y-6">
//             <div className="space-y-3">
//               <div className="h-4 bg-gradient-to-r from-muted to-muted/50 rounded-lg w-3/4"></div>
//               <div className="h-32 bg-gradient-to-br from-muted to-muted/30 rounded-xl"></div>
//               <div className="h-4 bg-gradient-to-r from-muted to-muted/50 rounded-lg w-1/2"></div>
//             </div>
//           </div>
//         </CardContent>
//       </Card>
//     );
//   }

//   const renderComponent = (component) => {
//     switch (component.type) {
//       case 'HEADER':
//         if (component.format === 'IMAGE' && component.image_url) {
//           return (
//             <div className="mb-3">
//               <div className="relative rounded-lg overflow-hidden bg-gradient-to-br from-muted/30 to-muted/10">
//                 <img
//                   src={component.image_url}
//                   alt="Template Header"
//                   className="w-full h-32 object-cover"
//                   onError={(e) => {
//                     e.target.style.display = 'none';
//                     e.target.nextSibling.style.display = 'flex';
//                   }}
//                 />
//                 <div className="hidden w-full h-32 bg-gradient-to-br from-muted/50 to-muted/20 items-center justify-center">
//                   <div className="p-3 bg-background/50 rounded-full">
//                     <ImageIcon className="h-6 w-6 text-muted-foreground" />
//                   </div>
//                 </div>
//               </div>
//             </div>
//           );
//         } else if (component.format === 'VIDEO' && component.video_url) {
//           return (
//             <div className="mb-3">
//               <div className="relative rounded-lg overflow-hidden bg-gradient-to-br from-muted/30 to-muted/10">
//                 <video
//                   src={component.video_url}
//                   className="w-full h-32 object-cover"
//                   controls
//                 />
//               </div>
//             </div>
//           );
//         } else if (component.format === 'DOCUMENT' && component.document_url) {
//           return (
//             <div className="mb-3">
//               <div className="w-full h-32 bg-gradient-to-br from-muted/50 to-muted/20 rounded-lg flex items-center justify-center">
//                 <div className="text-center">
//                   <div className="text-2xl mb-2">📄</div>
//                   <span className="text-sm text-muted-foreground">
//                     Document
//                   </span>
//                 </div>
//               </div>
//             </div>
//           );
//         } else if (component.text) {
//           return (
//             <div className="mb-3">
//               <div className="p-3 bg-gradient-to-r from-primary/10 to-primary/5 border border-primary/20 rounded-lg">
//                 <h3 className="font-semibold text-primary text-sm leading-tight">
//                   {component.text}
//                 </h3>
//               </div>
//             </div>
//           );
//         }
//         return null;

//       case 'BODY':
//         return (
//           <div className="mb-3">
//             <div className="p-3 bg-background/50 rounded-lg border border-border/30">
//               <div
//                 className="text-foreground whitespace-pre-wrap leading-relaxed text-sm"
//                 dangerouslySetInnerHTML={{ __html: component.text }}
//               />
//             </div>
//           </div>
//         );

//       case 'FOOTER':
//         return (
//           <div className="mb-3">
//             <div className="p-2 bg-muted/20 rounded-md border-t border-border/50">
//               <p className="text-xs text-muted-foreground font-medium text-center">
//                 {component.text}
//               </p>
//             </div>
//           </div>
//         );

//       case 'BUTTONS':
//         if (component.buttons && component.buttons.length > 0) {
//           const urlButtons = component.buttons.filter(
//             (btn) => btn.type === 'URL'
//           );
//           const phoneButtons = component.buttons.filter(
//             (btn) => btn.type === 'PHONE_NUMBER'
//           );
//           const quickReplyButtons = component.buttons.filter(
//             (btn) => btn.type === 'QUICK_REPLY'
//           );

//           return (
//             <div className="space-y-3">
//               {/* URL and Phone buttons */}
//               {(urlButtons.length > 0 || phoneButtons.length > 0) && (
//                 <div className="space-y-1.5">
//                   {phoneButtons.map((button, index) => (
//                     <Button
//                       key={index}
//                       variant="outline"
//                       className="w-full justify-center gap-2 text-xs h-8 bg-gradient-to-r from-green-50 to-green-50/50 border-green-200 text-green-700 transition-all duration-200"
//                       disabled
//                     >
//                       <Phone className="h-3 w-3" />
//                       {button.text}
//                     </Button>
//                   ))}
//                   {urlButtons.map((button, index) => (
//                     <Button
//                       key={index}
//                       variant="outline"
//                       className="w-full justify-center gap-2 text-xs h-8 bg-gradient-to-r from-blue-50 to-blue-50/50 border-blue-200 text-blue-700 transition-all duration-200"
//                       disabled
//                     >
//                       <ExternalLink className="h-3 w-3" />
//                       {button.text}
//                     </Button>
//                   ))}
//                 </div>
//               )}

//               {/* Quick Reply buttons */}
//               {quickReplyButtons.length > 0 && (
//                 <div className="space-y-2">
//                   <div className="flex items-center gap-2 text-xs text-muted-foreground font-medium">
//                     <div className="w-1 h-1 bg-muted-foreground/50 rounded-full"></div>
//                     Quick Replies
//                   </div>
//                   <div className="flex flex-wrap gap-1.5">
//                     {quickReplyButtons.map((button, index) => (
//                       <Badge
//                         key={index}
//                         variant="secondary"
//                         className="px-2 py-1 text-xs font-medium bg-gradient-to-r from-secondary to-secondary/70 transition-all duration-200 cursor-default border border-border/50"
//                       >
//                         {button.text}
//                       </Badge>
//                     ))}
//                   </div>
//                 </div>
//               )}
//             </div>
//           );
//         }
//         return null;

//       default:
//         return null;
//     }
//   };

//   return (
//     <Card className="border-0  bg-gradient-to-br from-card via-card/95 to-card/90 shadow-xl sticky top-6">
//       <CardHeader className="pb-3">
//         <div className="flex items-center justify-between">
//           <CardTitle className="flex items-center gap-2 text-base text-card-foreground">
//             <div className="p-1.5 bg-primary/10 rounded-lg">
//               <Eye className="h-4 w-4 text-primary" />
//             </div>
//             Live Preview
//           </CardTitle>
//           <div className="flex items-center gap-1.5">
//             <Badge
//               variant="outline"
//               className="text-xs bg-background/50 border-border/50"
//             >
//               {template.category}
//             </Badge>
//             <Badge
//               variant="default"
//               className="text-xs bg-green-100 text-green-700 border-green-200"
//             >
//               DRAFT
//             </Badge>
//           </div>
//         </div>
//       </CardHeader>
//       <CardContent className="pt-0">
//         {/* Phone Mockup Container */}
//         <div className="relative mx-auto max-w-[300px]">
//           {/* Phone Frame */}
//           <div className="relative bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 rounded-[1.5rem] p-1.5 shadow-2xl">
//             {/* Screen */}
//             <div className="bg-gradient-to-b from-gray-50 to-white rounded-[1.25rem] overflow-hidden">
//               {/* Status Bar */}
//               <div className="bg-white px-4 py-1.5 flex justify-between items-center text-xs font-medium text-black">
//                 <span>9:41</span>
//                 <div className="flex items-center gap-1">
//                   <div className="flex gap-0.5">
//                     <div className="w-0.5 h-0.5 bg-black rounded-full"></div>
//                     <div className="w-0.5 h-0.5 bg-black rounded-full"></div>
//                     <div className="w-0.5 h-0.5 bg-black/30 rounded-full"></div>
//                   </div>
//                   <div className="ml-1 w-5 h-2.5 border border-black/30 rounded-sm">
//                     <div className="w-3 h-1 bg-green-500 rounded-sm m-0.5"></div>
//                   </div>
//                 </div>
//               </div>

//               {/* WhatsApp Header */}
//               <div className="bg-[#075E54] px-3 py-2 flex items-center gap-2">
//                 <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center">
//                   <MessageSquare className="h-3 w-3 text-white" />
//                 </div>
//                 <div className="flex-1">
//                   <h4 className="text-white font-medium text-xs">
//                     Business Account
//                   </h4>
//                   <p className="text-white/70 text-xs">Template Message</p>
//                 </div>
//               </div>

//               {/* Message Content - Scrollable for long content */}
//               <div className="p-3 bg-[#E5DDD5] max-h-[400px] overflow-y-auto scrollbar-hide">
//                 <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
//                   <div className="p-3 space-y-2">
//                     {template.components && template.components.length > 0 ? (
//                       [...template.components]
//                         .sort((a, b) => {
//                           const order = {
//                             HEADER: 1,
//                             BODY: 2,
//                             FOOTER: 3,
//                             BUTTONS: 4,
//                           };
//                           return (order[a.type] || 5) - (order[b.type] || 5);
//                         })
//                         .map((component, index) => (
//                           <div key={component.id || index}>
//                             {renderComponent(component)}
//                           </div>
//                         ))
//                     ) : (
//                       <div className="text-center py-8 text-muted-foreground">
//                         <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-50" />
//                         <p className="text-sm">Start building your template</p>
//                       </div>
//                     )}
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>

//         {/* Template Metadata */}
//         <div className="mt-4 p-3 bg-gradient-to-r from-muted/30 to-muted/10 rounded-lg border border-border/50">
//           <h4 className="font-semibold text-sm text-foreground mb-2 flex items-center gap-2">
//             <Info className="h-3 w-3" />
//             Template Info
//           </h4>
//           <div className="space-y-1.5 text-xs">
//             <div className="flex justify-between">
//               <span className="text-muted-foreground">Name:</span>
//               <span className="font-medium">{template.name || 'Untitled'}</span>
//             </div>
//             <div className="flex justify-between">
//               <span className="text-muted-foreground">Language:</span>
//               <span className="font-medium">
//                 {template.language || 'English (US)'}
//               </span>
//             </div>
//             <div className="flex justify-between">
//               <span className="text-muted-foreground">Components:</span>
//               <Badge variant="outline" className="text-xs h-5">
//                 {template.components?.length || 0}
//               </Badge>
//             </div>
//           </div>
//         </div>

//         {/* Variables */}
//         {variables.length > 0 && (
//           <div className="mt-4 p-3 bg-gradient-to-r from-blue/10 to-blue/5 rounded-lg border border-blue/20">
//             <h4 className="font-semibold text-sm text-foreground mb-2">
//               Variables Used
//             </h4>
//             <div className="flex flex-wrap gap-1.5">
//               {variables.map((variable, index) => (
//                 <Badge
//                   key={index}
//                   variant="outline"
//                   className="text-xs bg-blue-50 text-blue-700 border-blue-200"
//                 >
//                   {variable}
//                 </Badge>
//               ))}
//             </div>
//           </div>
//         )}
//       </CardContent>
//     </Card>
//   );
// };

// export default function TemplateForm({ onBack = () => {} }) {
//   /* ------------------------------------------------------------------------ */
//   /* Rich-text editor setup for body content                                  */
//   /* ------------------------------------------------------------------------ */
//   const editor = useEditor({
//     extensions: [
//       StarterKit,
//       Underline,
//       Placeholder.configure({
//         placeholder: 'hi {{name}}',
//       }),
//     ],
//     content: 'hi {{name}}',
//     editorProps: {
//       attributes: {
//         class:
//           'prose prose-sm sm:prose lg:prose-lg xl:prose-2xl mx-auto focus:outline-none min-h-[100px] p-3',
//       },
//     },
//   });

//   /* ------------------------------------------------------------------------ */
//   /* Component state                                                          */
//   /* ------------------------------------------------------------------------ */
//   const [template, setTemplate] = useState({
//     name: 'gas',
//     category: 'Marketing',
//     language: 'English (US)',
//     components: [],
//   });

//   const [broadcastType, setBroadcastType] = useState('image');
//   const [mediaUrl, setMediaUrl] = useState(
//     'https://cdn.clare.ai/wati/images/WATI_logo_square_2.png'
//   );
//   const [headerText, setHeaderText] = useState('');
//   const [footerText, setFooterText] = useState('');
//   const [buttons, setButtons] = useState([]);
//   const [variables, setVariables] = useState(['{{name}}']);
//   const fileInputRef = useRef(null);

//   /* ------------------------------------------------------------------------ */
//   /* Variables and helpers                                                    */
//   /* ------------------------------------------------------------------------ */
//   const availableVariables = [
//     'name',
//     'email',
//     'phone',
//     'company',
//     'order_id',
//     'amount',
//     'date',
//     'time',
//   ];
//   const categories = ['Marketing', 'Utility', 'Authentication'];
//   const languages = ['English (US)', 'Hindi', 'Spanish', 'French', 'German'];

//   const insertVariable = (variable) => {
//     if (!editor) return;
//     try {
//       const variableText = `{{${variable}}}`;
//       editor.chain().focus().insertContent(variableText).run();
//       if (!variables.includes(variableText)) {
//         setVariables([...variables, variableText]);
//       }
//     } catch (error) {
//       console.error('Error inserting variable:', error);
//     }
//   };

//   const handleFileUpload = (event) => {
//     const file = event.target.files?.[0];
//     if (file) {
//       const url = URL.createObjectURL(file);
//       setMediaUrl(url);
//     }
//   };

//   const formatText = (format) => {
//     if (!editor) return;

//     try {
//       switch (format) {
//         case 'bold':
//           editor.chain().focus().toggleBold().run();
//           break;
//         case 'italic':
//           editor.chain().focus().toggleItalic().run();
//           break;
//         case 'strikethrough':
//           editor.chain().focus().toggleStrike().run();
//           break;
//         case 'underline':
//           editor.chain().focus().toggleUnderline().run();
//           break;
//       }
//     } catch (error) {
//       console.error('Error formatting text:', error);
//     }
//   };

//   const addButton = (type = 'QUICK_REPLY') => {
//     const newButton = {
//       id: Date.now().toString(),
//       type: type,
//       text: '',
//       url: type === 'URL' ? 'https://' : '',
//       phone_number: type === 'PHONE_NUMBER' ? '+1' : '',
//     };
//     setButtons([...buttons, newButton]);
//   };

//   const updateButton = (buttonId, field, value) => {
//     setButtons(
//       buttons.map((button) =>
//         button.id === buttonId ? { ...button, [field]: value } : button
//       )
//     );
//   };

//   const removeButton = (buttonId) => {
//     setButtons(buttons.filter((button) => button.id !== buttonId));
//   };

//   const getEditorText = () => {
//     if (!editor) return '';
//     try {
//       return editor.getText() || '';
//     } catch (error) {
//       return '';
//     }
//   };

//   const getEditorHTML = () => {
//     if (!editor) return '';
//     try {
//       return editor.getHTML() || '';
//     } catch (error) {
//       return '';
//     }
//   };

//   const buildTemplateForPreview = () => {
//     const components = [];

//
//     if (broadcastType !== 'none') {
//       const headerComponent = {
//         id: 'header',
//         type: 'HEADER',
//         format: broadcastType.toUpperCase(),
//       };

//       if (broadcastType === 'image' && mediaUrl) {
//         headerComponent.image_url = mediaUrl;
//       } else if (broadcastType === 'video' && mediaUrl) {
//         headerComponent.video_url = mediaUrl;
//       } else if (broadcastType === 'document' && mediaUrl) {
//         headerComponent.document_url = mediaUrl;
//       } else if (broadcastType === 'text' && headerText) {
//         headerComponent.text = headerText;
//       }

//       components.push(headerComponent);
//     }

//
//     const bodyHTML = getEditorHTML();
//     if (bodyHTML && bodyHTML !== '<p></p>') {
//
//       const processedBodyHTML = bodyHTML.replace(
//         /\{\{(\w+)\}\}/g,
//         (match, varName) => {
//           const sampleValues = {
//             name: 'John',
//             email: 'john@example.com',
//             phone: '+1234567890',
//             company: 'Acme Corp',
//             order_id: 'ORD123',
//             amount: '$99.99',
//             date: '2024-01-15',
//             time: '2:30 PM',
//           };
//           return sampleValues[varName] || match;
//         }
//       );

//       components.push({
//         id: 'body',
//         type: 'BODY',
//         text: processedBodyHTML,
//       });
//     }

//
//     if (footerText) {
//       components.push({
//         id: 'footer',
//         type: 'FOOTER',
//         text: footerText,
//       });
//     }

//
//     if (buttons.length > 0) {
//       components.push({
//         id: 'buttons',
//         type: 'BUTTONS',
//         buttons: buttons
//           .filter((button) => button.text.trim())
//           .map((button) => ({
//             type: button.type,
//             text: button.text,
//             url: button.url,
//             phone_number: button.phone_number,
//           })),
//       });
//     }

//     return {
//       ...template,
//       components,
//     };
//   };

//   /* ------------------------------------------------------------------------ */
//   /* Render                                                                   */
//   /* ------------------------------------------------------------------------ */
//   return (
//     <div className="flex h-screen scrollbar-hide bg-gray-50">
//       {/* Main Content */}
//       <div className="flex-1 flex flex-col">
//         {/* Header */}
//         <div className="bg-white border-b border-gray-200 px-6 py-4 flex-shrink-0">
//           <div className="flex items-center justify-between">
//             <div className="flex items-center space-x-4">
//               <Button variant="ghost" onClick={onBack} size="sm">
//                 <ArrowLeft className="w-4 h-4" />
//               </Button>
//               <div>
//                 <h1 className="text-xl font-semibold text-gray-900">
//                   New Templates
//                 </h1>
//               </div>
//             </div>
//             <Button className="bg-green-600 hover:bg-green-700">
//               <Save className="w-4 h-4 mr-2" />
//               Save Template
//             </Button>
//           </div>
//         </div>

//         {/* Form and Preview Layout */}
//         <div className="flex flex-1 min-h-0 scrollbar-hide">
//           {/* Form Content */}
//           <div className="flex-1 overflow-y-auto scrollbar-hide">
//             <div className="p-6">
//               <div className="max-w-4xl mx-auto space-y-6 pb-8">
//                 <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 space-y-8">
//                   {/* Basic Template Info */}
//                   <div className="space-y-4">
//                     <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
//                       <div className="space-y-2">
//                         <Label htmlFor="templateName">Template Name</Label>
//                         <Input
//                           id="templateName"
//                           value={template.name}
//                           onChange={(e) =>
//                             setTemplate({ ...template, name: e.target.value })
//                           }
//                           placeholder="e.g., welcome_message"
//                         />
//                       </div>
//                       <div className="space-y-2">
//                         <Label>Category</Label>
//                         <Select
//                           value={template.category}
//                           onValueChange={(value) =>
//                             setTemplate({ ...template, category: value })
//                           }
//                         >
//                           <SelectTrigger>
//                             <SelectValue />
//                           </SelectTrigger>
//                           <SelectContent>
//                             {categories.map((category) => (
//                               <SelectItem key={category} value={category}>
//                                 {category}
//                               </SelectItem>
//                             ))}
//                           </SelectContent>
//                         </Select>
//                       </div>
//                       <div className="space-y-2">
//                         <Label>Language</Label>
//                         <Select
//                           value={template.language}
//                           onValueChange={(value) =>
//                             setTemplate({ ...template, language: value })
//                           }
//                         >
//                           <SelectTrigger>
//                             <SelectValue />
//                           </SelectTrigger>
//                           <SelectContent>
//                             {languages.map((language) => (
//                               <SelectItem key={language} value={language}>
//                                 {language}
//                               </SelectItem>
//                             ))}
//                           </SelectContent>
//                         </Select>
//                       </div>
//                     </div>
//                   </div>

//                   {/* Header Section */}
//                   <div className="space-y-4">
//                     <div>
//                       <h3 className="text-lg font-semibold text-gray-900 flex items-center">
//                         Broadcast title
//                         <Badge variant="secondary" className="ml-2">
//                           Optional
//                         </Badge>
//                       </h3>
//                       <p className="text-sm text-muted-foreground">
//                         Highlight your brand here, use images or videos, to
//                         stand out
//                       </p>
//                     </div>

//                     <RadioGroup
//                       value={broadcastType}
//                       onValueChange={setBroadcastType}
//                       className="flex flex-wrap gap-6"
//                     >
//                       {[
//                         { value: 'none', label: 'None' },
//                         { value: 'text', label: 'Text' },
//                         { value: 'image', label: 'Image' },
//                         { value: 'video', label: 'Video' },
//                         { value: 'document', label: 'Document' },
//                       ].map(({ value, label }) => (
//                         <div
//                           key={value}
//                           className="flex items-center space-x-2"
//                         >
//                           <RadioGroupItem value={value} id={value} />
//                           <Label htmlFor={value} className="cursor-pointer">
//                             {label}
//                           </Label>
//                         </div>
//                       ))}
//                     </RadioGroup>

//                     {(broadcastType === 'image' ||
//                       broadcastType === 'video' ||
//                       broadcastType === 'document') && (
//                       <div className="space-y-3">
//                         <p className="text-sm text-blue-600">
//                           {broadcastType === 'image' && '(Image: .jpeg, .png)'}
//                           {broadcastType === 'video' && '(Video: .mp4, .3gp)'}
//                           {broadcastType === 'document' &&
//                             '(Document: .pdf, .doc, .docx)'}
//                         </p>
//                         <div className="flex items-center space-x-4">
//                           <Input
//                             placeholder={
//                               broadcastType === 'image'
//                                 ? 'https://cdn.clare.ai/wati/images/WATI_logo_square_2.png'
//                                 : `Enter ${broadcastType} URL`
//                             }
//                             value={mediaUrl}
//                             onChange={(e) => setMediaUrl(e.target.value)}
//                             className="flex-1"
//                           />
//                           <Badge variant="outline">0/2000</Badge>
//                           <span className="text-muted-foreground">or</span>
//                           <Button
//                             variant="outline"
//                             onClick={() => fileInputRef.current?.click()}
//                             className="border-green-500 text-green-600 hover:bg-green-50"
//                           >
//                             <Upload className="w-4 h-4 mr-2" />
//                             Upload Media
//                           </Button>
//                           <input
//                             ref={fileInputRef}
//                             type="file"
//                             accept={
//                               broadcastType === 'image'
//                                 ? 'image/*'
//                                 : broadcastType === 'video'
//                                 ? 'video/*'
//                                 : broadcastType === 'document'
//                                 ? '.pdf,.doc,.docx'
//                                 : '*'
//                             }
//                             onChange={handleFileUpload}
//                             className="hidden"
//                           />
//                         </div>
//                       </div>
//                     )}

//                     {broadcastType === 'text' && (
//                       <div className="space-y-3">
//                         <Input
//                           placeholder="Enter header text"
//                           value={headerText}
//                           onChange={(e) => setHeaderText(e.target.value)}
//                         />
//                       </div>
//                     )}
//                   </div>

//                   {/* Body Section */}
//                   <div className="space-y-4">
//                     <div className="flex items-center justify-between">
//                       <h3 className="text-lg font-semibold text-gray-900">
//                         Body
//                       </h3>
//                       <DropdownMenu>
//                         <DropdownMenuTrigger asChild>
//                           <Button
//                             variant="link"
//                             size="sm"
//                             className="px-0 text-green-600"
//                           >
//                             <Plus className="w-4 h-4 mr-1" />
//                             Add Variable
//                           </Button>
//                         </DropdownMenuTrigger>
//                         <DropdownMenuContent>
//                           {availableVariables.map((variable) => (
//                             <DropdownMenuItem
//                               key={variable}
//                               onClick={() => insertVariable(variable)}
//                             >
//                               <span className="font-mono text-sm">
//                                 {'{{' + variable + '}}'}
//                               </span>
//                             </DropdownMenuItem>
//                           ))}
//                         </DropdownMenuContent>
//                       </DropdownMenu>
//                     </div>
//                     <p className="text-sm text-muted-foreground">
//                       Make your messages personal using variables like{' '}
//                       <code className="text-green-600 bg-green-50 px-1 rounded">
//                         {'{{name}}'}
//                       </code>{' '}
//                       and get more replies!
//                     </p>

//                     <div className="flex items-center justify-between p-2 bg-muted rounded-md">
//                       <div className="flex items-center space-x-1">
//                         <Button
//                           variant="ghost"
//                           size="sm"
//                           onClick={() => formatText('bold')}
//                           className={`h-8 w-8 p-0 ${
//                             editor?.isActive('bold') ? 'bg-gray-200' : ''
//                           }`}
//                         >
//                           <Bold className="w-4 h-4" />
//                         </Button>
//                         <Button
//                           variant="ghost"
//                           size="sm"
//                           onClick={() => formatText('italic')}
//                           className={`h-8 w-8 p-0 ${
//                             editor?.isActive('italic') ? 'bg-gray-200' : ''
//                           }`}
//                         >
//                           <Italic className="w-4 h-4" />
//                         </Button>
//                         <Button
//                           variant="ghost"
//                           size="sm"
//                           onClick={() => formatText('strikethrough')}
//                           className={`h-8 w-8 p-0 ${
//                             editor?.isActive('strike') ? 'bg-gray-200' : ''
//                           }`}
//                         >
//                           <Strikethrough className="w-4 h-4" />
//                         </Button>
//                         <div className="w-px h-6 bg-gray-300 mx-2"></div>
//                         <Button
//                           variant="ghost"
//                           size="sm"
//                           className="h-8 w-8 p-0"
//                         >
//                           <Smile className="w-4 h-4" />
//                         </Button>
//                       </div>
//                       <Badge variant="outline">
//                         {getEditorText().length || 0}/1024
//                       </Badge>
//                     </div>

//                     <div className="border border-gray-300 rounded-lg min-h-[120px] focus-within:ring-2 focus-within:ring-green-500 focus-within:border-transparent">
//                       {editor ? (
//                         <EditorContent
//                           editor={editor}
//                           className="prose max-w-none"
//                         />
//                       ) : (
//                         <div className="p-3 text-gray-500">
//                           Loading editor...
//                         </div>
//                       )}
//                     </div>
//                   </div>

//                   {/* Footer Section */}
//                   <div className="space-y-4">
//                     <div>
//                       <h3 className="text-lg font-semibold text-gray-900 flex items-center">
//                         Footer
//                         <Badge variant="secondary" className="ml-2">
//                           Optional
//                         </Badge>
//                       </h3>
//                       <p className="text-sm text-muted-foreground">
//                         Add a short line of text to the bottom of your message
//                         template.
//                       </p>
//                     </div>
//                     <Input
//                       value={footerText}
//                       onChange={(e) => setFooterText(e.target.value)}
//                       placeholder="Footer text (optional)"
//                       maxLength={60}
//                     />
//                   </div>

//                   {/* Buttons Section */}
//                   <div className="space-y-4">
//                     <div>
//                       <h3 className="text-lg font-semibold text-gray-900 flex items-center">
//                         Buttons
//                         <Badge variant="secondary" className="ml-2">
//                           Optional
//                         </Badge>
//                       </h3>
//                       <p className="text-sm text-muted-foreground">
//                         Add interactive buttons to your template (max 3
//                         buttons).
//                       </p>
//                     </div>

//                     <div className="space-y-4">
//                       {buttons.map((button) => (
//                         <Card key={button.id} className="p-4">
//                           <div className="flex items-start space-x-3">
//                             <Select
//                               value={button.type}
//                               onValueChange={(value) =>
//                                 updateButton(button.id, 'type', value)
//                               }
//                             >
//                               <SelectTrigger className="w-40">
//                                 <SelectValue />
//                               </SelectTrigger>
//                               <SelectContent>
//                                 <SelectItem value="QUICK_REPLY">
//                                   Quick Reply
//                                 </SelectItem>
//                                 <SelectItem value="PHONE_NUMBER">
//                                   Call Phone
//                                 </SelectItem>
//                                 <SelectItem value="URL">
//                                   Visit Website
//                                 </SelectItem>
//                               </SelectContent>
//                             </Select>

//                             <div className="flex-1 space-y-2">
//                               <Input
//                                 placeholder="Button text"
//                                 value={button.text}
//                                 onChange={(e) =>
//                                   updateButton(
//                                     button.id,
//                                     'text',
//                                     e.target.value
//                                   )
//                                 }
//                                 maxLength={20}
//                               />

//                               {button.type === 'URL' && (
//                                 <Input
//                                   placeholder="https://example.com"
//                                   value={button.url || ''}
//                                   onChange={(e) =>
//                                     updateButton(
//                                       button.id,
//                                       'url',
//                                       e.target.value
//                                     )
//                                   }
//                                 />
//                               )}

//                               {button.type === 'PHONE_NUMBER' && (
//                                 <Input
//                                   placeholder="+1234567890"
//                                   value={button.phone_number || ''}
//                                   onChange={(e) =>
//                                     updateButton(
//                                       button.id,
//                                       'phone_number',
//                                       e.target.value
//                                     )
//                                   }
//                                 />
//                               )}
//                             </div>

//                             <Button
//                               variant="ghost"
//                               size="sm"
//                               onClick={() => removeButton(button.id)}
//                               className="text-red-500 hover:text-red-700"
//                             >
//                               <X className="w-4 h-4" />
//                             </Button>
//                           </div>
//                         </Card>
//                       ))}

//                       {buttons.length < 3 && (
//                         <DropdownMenu>
//                           <DropdownMenuTrigger asChild>
//                             <Button
//                               variant="outline"
//                               className="w-full border-dashed border-2 h-12"
//                             >
//                               <Plus className="w-4 h-4 mr-2" />
//                               Add Button
//                             </Button>
//                           </DropdownMenuTrigger>
//                           <DropdownMenuContent>
//                             <DropdownMenuItem
//                               onClick={() => addButton('QUICK_REPLY')}
//                             >
//                               Quick Reply
//                             </DropdownMenuItem>
//                             <DropdownMenuItem
//                               onClick={() => addButton('PHONE_NUMBER')}
//                             >
//                               Call Phone
//                             </DropdownMenuItem>
//                             <DropdownMenuItem onClick={() => addButton('URL')}>
//                               Visit Website
//                             </DropdownMenuItem>
//                           </DropdownMenuContent>
//                         </DropdownMenu>
//                       )}
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>

//           {/* Template Preview - Right Sidebar */}
//           <div className="w-80 flex-shrink-0 p-4">
//             <TemplatePreview
//               template={buildTemplateForPreview()}
//               variables={variables}
//             />
//           </div>
//         </div>
//       </div>
//     </div>
//   );
//
