import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Plus, X, Calendar, Send, Tag } from 'lucide-react';
import {
  fetchTemplates,
  selectTemplates,
  clearError,
} from '@/redux/templateSlice';

function SendByTags() {
  const [selectedTemplate, setSelectedTemplate] = useState('');
  const [selectedTags, setSelectedTags] = useState([]);
  const [newTag, setNewTag] = useState('');
  const dispatch = useDispatch();
  const templates = useSelector(selectTemplates) || [];
  console.log(templates);

  useEffect(() => {
    console.log('YourTemplates: Fetching templates...');
    dispatch(fetchTemplates() as any);

    return () => {
      dispatch(clearError());
    };
  }, [dispatch]);
  const availableTags = [
    'New Users',
    'Premium',
    'Active',
    'Inactive',
    'VIP',
    'Regular',
    'Beta Testers',
  ];

  const handleAddTag = (tag) => {
    if (tag && !selectedTags.includes(tag)) {
      setSelectedTags([...selectedTags, tag]);
    }
  };

  const handleRemoveTag = (tagToRemove) => {
    setSelectedTags(selectedTags.filter((tag) => tag !== tagToRemove));
  };

  const handleAddNewTag = () => {
    if (newTag.trim() && !selectedTags.includes(newTag.trim())) {
      setSelectedTags([...selectedTags, newTag.trim()]);
      setNewTag('');
    }
  };

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="space-y-2">
          <div className="flex gap-3 items-center">
            <div className="bg-primary p-3 rounded-xl">
              <Tag className="h-8 w-8 text-primary-foreground" />
            </div>
            <div className="flex flex-col gap-1">
              <h1 className="text-3xl font-bold text-foreground">
                Send by Tag
              </h1>
              <p className="text-muted-foreground">
                Manage Tagging User Number
              </p>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Template Selection */}
          <Card className=" border-0 bg-card">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-card-foreground">
                Select Template
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Select
                value={selectedTemplate}
                onValueChange={setSelectedTemplate}
              >
                <SelectTrigger className="w-full bg-card border-input text-card-foreground">
                  <SelectValue placeholder="Choose a template..." />
                </SelectTrigger>
                <SelectContent className="bg-popover border-border">
                  {templates.map((template) => (
                    <SelectItem
                      key={template.id}
                      value={template.id}
                      className="text-popover-foreground"
                    >
                      {template.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          {/* Tag Selection */}
          <Card className="border-0 bg-card">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-card-foreground">
                Select Tag
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Select onValueChange={handleAddTag}>
                <SelectTrigger className="w-full bg-card border-input text-card-foreground">
                  <SelectValue placeholder="Choose tags..." />
                </SelectTrigger>
                <SelectContent className="bg-popover border-border">
                  {availableTags.map((tag) => (
                    <SelectItem
                      key={tag}
                      value={tag}
                      className="text-popover-foreground"
                    >
                      {tag}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Selected Tags */}
              {selectedTags.length > 0 && (
                <div className="space-y-2">
                  <Label className="text-sm font-medium text-card-foreground">
                    Selected Tags:
                  </Label>
                  <div className="flex flex-wrap gap-2">
                    {selectedTags.map((tag) => (
                      <Badge
                        key={tag}
                        variant="secondary"
                        className="flex items-center gap-1 bg-secondary text-secondary-foreground border-border"
                      >
                        {tag}
                        <X
                          className="h-3 w-3 cursor-pointer hover:text-destructive"
                          onClick={() => handleRemoveTag(tag)}
                        />
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Action Buttons Row */}
        <Card className=" border-0 bg-card">
          <CardContent className="pt-6">
            <div className="flex flex-wrap gap-3">
              {/* Add New Tag */}
              <div className="flex gap-2 items-center">
                <Input
                  placeholder="Enter new tag"
                  value={newTag}
                  onChange={(e) => setNewTag(e.target.value)}
                  className="w-40 bg-card border-input text-card-foreground"
                  onKeyPress={(e) => e.key === 'Enter' && handleAddNewTag()}
                />
                <Button
                  onClick={handleAddNewTag}
                  variant="outline"
                  size="sm"
                  className="whitespace-nowrap border-border hover:bg-accent text-foreground"
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Add New Tag
                </Button>
              </div>

              <Button
                variant="outline"
                size="sm"
                className="bg-accent border-border text-accent-foreground hover:bg-accent/80"
              >
                Exclude Past Campaigns
              </Button>

              <Button
                variant="outline"
                size="sm"
                className="bg-accent border-border text-accent-foreground hover:bg-accent/80"
              >
                Exclude Numbers
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Send Actions */}
        <Card className=" border-0 bg-card">
          <CardContent className="pt-6">
            <div className="flex gap-3">
              <Button
                className="bg-primary hover:bg-primary/90 text-primary-foreground"
                disabled={!selectedTemplate || selectedTags.length === 0}
              >
                <Send className="h-4 w-4 mr-2" />
                Send Now
              </Button>

              <Button
                variant="outline"
                className="bg-secondary text-secondary-foreground hover:bg-secondary/80 border-border"
                disabled={!selectedTemplate || selectedTags.length === 0}
              >
                <Calendar className="h-4 w-4 mr-2" />
                Schedule Date
              </Button>
            </div>

            {(!selectedTemplate || selectedTags.length === 0) && (
              <p className="text-sm text-muted-foreground mt-2">
                Please select a template and at least one tag to proceed
              </p>
            )}
          </CardContent>
        </Card>

        {/* Stats Card */}
        {selectedTags.length > 0 && (
          <Card className=" bg-accent border-border">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-accent-foreground">
                    Campaign Preview
                  </h3>
                  <p className="text-muted-foreground text-sm">
                    Ready to send to users with tags: {selectedTags.join(', ')}
                  </p>
                </div>
                <Badge
                  variant="outline"
                  className="bg-primary text-primary-foreground border-border"
                >
                  {Math.floor(Math.random() * 1000) + 100} Recipients
                </Badge>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

export default SendByTags;
