import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Phone,
  ExternalLink,
  MapPin,
  MessageSquare,
  User,
  Clock,
  CheckCircle2,
  Play,
  FileText,
  Image,
  TrendingUp,
  Send,
  Eye,
  AlertCircle,
  Loader,
} from 'lucide-react';

interface Template {
  name: string;
  wa_id: string;
  category: string;
  status: string;
  language: string;
  components?: Array<{
    type: string;
    format?: string;
    text?: string;
    image_url?: string;
    buttons?: Array<{
      id: string;
      type: string;
      text: string;
      url?: string;
      number?: string;
      phone_number?: string;
    }>;
  }>;
}

interface WhatsAppTemplateViewerProps {
  template: Template;
  showStats?: boolean;
  showExpandedView?: boolean;
  className?: string;
  reportData?: {
    total?: number;
    sent_count?: number;
    dlvd_count?: number;
    read_count?: number;
    failed_count?: number;
    other_count?: number;
    created_at?: string;
    updated_at?: string;
    status?: string;
    user?: { name?: string };
    country?: { name?: string };
  };
}

const WhatsAppTemplateViewer: React.FC<WhatsAppTemplateViewerProps> = ({
  template,
  showStats = false,
  showExpandedView = false,
  className = '',
  reportData,
}) => {
  const getMessagePreview = (template: Template) => {
    const body = template.components?.find((c) => c.type === 'BODY');
    return body?.text
      ? body.text.length > 80
        ? body.text.slice(0, 80) + '...'
        : body.text
      : 'No message content';
  };

  const getFullMessage = (template: Template) =>
    template.components?.find((c) => c.type === 'BODY')?.text ||
    'No message content';

  const getHeaderContent = (template: Template) => {
    const headerComponent = template.components?.find(
      (c) => c.type === 'HEADER'
    );
    if (!headerComponent) return null;

    if (headerComponent.format === 'TEXT') {
      return {
        type: 'text',
        content: headerComponent.text || 'Header Text',
      };
    }

    if (['IMAGE', 'VIDEO', 'DOCUMENT'].includes(headerComponent.format || '')) {
      return {
        type: headerComponent.format?.toLowerCase(),
        content: headerComponent.image_url || null,
      };
    }

    return null;
  };

  const getFooterContent = (template: Template) => {
    const footerComponent = template.components?.find(
      (c) => c.type === 'FOOTER'
    );
    return footerComponent?.text || null;
  };

  const getTemplateButtons = (template: Template) => {
    const buttonComponent = template.components?.find(
      (c) => c.type === 'BUTTONS'
    );
    return buttonComponent?.buttons || [];
  };

  const renderButton = (button: any) => {
    const baseClasses =
      'w-full justify-start text-sm font-medium transition-all duration-200 hover:scale-[1.02] active:scale-[0.98]';

    switch (button.type) {
      case 'PHONE_NUMBER':
        return (
          <Button
            key={button.id}
            variant="outline"
            size="sm"
            className={`${baseClasses} border-green-200 text-green-700 hover:bg-green-50 hover:border-green-300 hover:text-green-800 dark:border-green-800 dark:text-green-400 dark:hover:bg-green-950 dark:hover:border-green-700`}
            onClick={() =>
              window.open(
                `tel:${button.number || button.phone_number}`,
                '_self'
              )
            }
          >
            <Phone className="h-4 w-4 mr-2" />
            {button.text}
          </Button>
        );
      case 'URL':
        return (
          <Button
            key={button.id}
            variant="outline"
            size="sm"
            className={`${baseClasses} border-blue-200 text-blue-700 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-800 dark:border-blue-800 dark:text-blue-400 dark:hover:bg-blue-950 dark:hover:border-blue-700`}
            onClick={() => window.open(button.url, '_blank')}
          >
            <ExternalLink className="h-4 w-4 mr-2" />
            {button.text}
          </Button>
        );
      case 'QUICK_REPLY':
        return (
          <Button
            key={button.id}
            variant="outline"
            size="sm"
            className={`${baseClasses} border-border text-muted-foreground hover:bg-accent hover:text-accent-foreground`}
          >
            {button.text}
          </Button>
        );
      default:
        return (
          <Button
            key={button.id}
            variant="outline"
            size="sm"
            className={`${baseClasses} border-border text-foreground hover:bg-accent hover:text-accent-foreground`}
          >
            {button.text}
          </Button>
        );
    }
  };

  const formatDate = (dateString: string) =>
    new Date(dateString).toLocaleDateString('en-GB');

  const formatTime = (dateString: string) =>
    new Date(dateString).toLocaleTimeString('en-GB', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });

  const getDeliveryRate = (data: any) => {
    const total = data?.total || 0;
    const delivered = data?.dlvd_count || 0;
    return total > 0 ? ((delivered / total) * 100).toFixed(1) : '0';
  };

  const getReadRate = (data: any) => {
    const delivered = data?.dlvd_count || 0;
    const read = data?.read_count || 0;
    return delivered > 0 ? ((read / delivered) * 100).toFixed(1) : '0';
  };

  const headerContent = getHeaderContent(template);
  const footerContent = getFooterContent(template);
  const buttons = getTemplateButtons(template);

  const getCategoryStyles = (category: string) => {
    switch (category) {
      case 'MARKETING':
        return 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950 dark:text-blue-400 dark:border-blue-800';
      case 'UTILITY':
        return 'bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-950 dark:text-purple-400 dark:border-purple-800';
      default:
        return 'bg-orange-50 text-orange-700 border-orange-200 dark:bg-orange-950 dark:text-orange-400 dark:border-orange-800';
    }
  };

  const getStatusStyles = (status: string) => {
    switch (status) {
      case 'APPROVED':
        return 'bg-green-50 text-green-700 border-green-200 dark:bg-green-950 dark:text-green-400 dark:border-green-800';
      case 'PENDING':
        return 'bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-950 dark:text-yellow-400 dark:border-yellow-800';
      default:
        return 'bg-red-50 text-red-700 border-red-200 dark:bg-red-950 dark:text-red-400 dark:border-red-800';
    }
  };

  return (
    <div className={`space-y-6 ${className}`}>
      {/* WhatsApp Message Preview */}
      <Card className="max-w-md mx-auto bg-card border-border shadow-lg hover:shadow-xl transition-shadow duration-300">
        <CardContent className="p-0">
          {/* WhatsApp Header */}
          <div className="bg-gradient-to-r from-green-600 to-green-500 text-white p-4 rounded-t-lg">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                <User className="w-5 h-5" />
              </div>
              <div>
                <div className="font-semibold text-sm">{template.name}</div>
                <div className="text-xs opacity-90 flex items-center">
                  <div className="w-2 h-2 rounded-full mr-2 animate-pulse"></div>
                  WhatsApp Business
                </div>
              </div>
            </div>
          </div>

          {/* Message Content */}
          <div className="p-4 space-y-4 bg-gradient-to-b from-gray-50 to-white dark:from-card dark:to-card">
            {/* Header Content */}
            {headerContent && (
              <div className="space-y-3">
                {headerContent.type === 'text' && (
                  <div className="font-semibold text-foreground text-sm bg-muted/30 p-3 rounded-lg border-l-4 border-primary">
                    {headerContent.content}
                  </div>
                )}

                {headerContent.type === 'image' && headerContent.content && (
                  <div className="rounded-xl overflow-hidden border border-border shadow-sm group">
                    <div className="relative">
                      <img
                        src={headerContent.content}
                        alt="Template Header"
                        className="w-full h-40 object-cover transition-transform duration-300 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                      <div className="absolute top-2 right-2">
                        <Image className="w-4 h-4 text-white/80" />
                      </div>
                    </div>
                  </div>
                )}

                {headerContent.type === 'video' && headerContent.content && (
                  <div className="rounded-xl overflow-hidden border border-border bg-muted/50 h-40 flex items-center justify-center group hover:bg-muted/70 transition-colors cursor-pointer">
                    <div className="text-center text-muted-foreground">
                      <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-2 group-hover:bg-primary/20 transition-colors">
                        <Play className="w-6 h-6 text-primary ml-1" />
                      </div>
                      <div className="text-sm font-medium">Video Content</div>
                    </div>
                  </div>
                )}

                {headerContent.type === 'document' && (
                  <div className="rounded-lg border border-border bg-muted/30 p-4 flex items-center space-x-3 hover:bg-muted/50 transition-colors cursor-pointer">
                    <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                      <FileText className="w-5 h-5 text-primary" />
                    </div>
                    <div className="flex-1">
                      <div className="text-sm font-medium text-foreground">
                        Document
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Attachment
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Body Text */}
            <div className="text-foreground text-sm leading-relaxed whitespace-pre-wrap bg-white dark:bg-card p-4 rounded-lg border border-border/50 shadow-sm">
              {showExpandedView
                ? getFullMessage(template)
                : getMessagePreview(template)}
            </div>

            {/* Footer */}
            {footerContent && (
              <div className="text-xs text-muted-foreground border-t border-border/50 pt-3 px-1">
                {footerContent}
              </div>
            )}

            {/* Buttons */}
            {buttons.length > 0 && (
              <div className="space-y-3 border-t border-border/50 pt-4">
                <div className="text-xs text-muted-foreground mb-2 font-medium">
                  Quick Actions:
                </div>
                <div className="flex flex-col space-y-2">
                  {buttons.map((button, index) => (
                    <div key={button.id || index} className="w-full">
                      {renderButton(button)}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Template Info Footer */}
          <div className="bg-muted/30 px-4 py-3 rounded-b-lg border-t border-border/50">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center space-x-2">
                <Badge
                  variant="outline"
                  className={`text-xs font-medium ${getCategoryStyles(
                    template.category
                  )}`}
                >
                  {template.category}
                </Badge>
                <Badge
                  variant="outline"
                  className={`text-xs font-medium ${getStatusStyles(
                    template.status
                  )}`}
                >
                  {template.status}
                </Badge>
              </div>
              <div className="text-right text-muted-foreground">
                <div className="font-mono">ID: {template.wa_id}</div>
                <div className="font-medium">
                  {template.language.toUpperCase()}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Campaign Stats */}
      {showStats && reportData && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Performance Metrics */}
          <Card className="bg-card border-border hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <h4 className="text-sm font-semibold text-foreground mb-4 flex items-center">
                <div className="w-8 h-8 bg-green-100 dark:bg-green-950 rounded-lg flex items-center justify-center mr-3">
                  <TrendingUp className="h-4 w-4 text-green-600 dark:text-green-400" />
                </div>
                Performance Metrics
              </h4>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between items-center p-2 bg-muted/30 rounded-md">
                  <span className="text-muted-foreground">Delivery Rate:</span>
                  <span className="font-semibold text-green-600 dark:text-green-400">
                    {getDeliveryRate(reportData)}%
                  </span>
                </div>
                <div className="flex justify-between items-center p-2 bg-muted/30 rounded-md">
                  <span className="text-muted-foreground">Read Rate:</span>
                  <span className="font-semibold text-blue-600 dark:text-blue-400">
                    {getReadRate(reportData)}%
                  </span>
                </div>
                <div className="flex justify-between items-center p-2 bg-muted/30 rounded-md">
                  <span className="text-muted-foreground">
                    Total Recipients:
                  </span>
                  <span className="font-semibold text-foreground">
                    {reportData.total}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Campaign Info */}
          <Card className="bg-card border-border hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <h4 className="text-sm font-semibold text-foreground mb-4 flex items-center">
                <div className="w-8 h-8 bg-blue-100 dark:bg-blue-950 rounded-lg flex items-center justify-center mr-3">
                  <User className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                </div>
                Campaign Info
              </h4>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between items-center p-2 bg-muted/30 rounded-md">
                  <span className="text-muted-foreground">Template:</span>
                  <span className="font-semibold text-foreground">
                    {template.name}
                  </span>
                </div>
                {reportData.user?.name && (
                  <div className="flex justify-between items-center p-2 bg-muted/30 rounded-md">
                    <span className="text-muted-foreground">User:</span>
                    <span className="font-semibold text-foreground">
                      {reportData.user.name}
                    </span>
                  </div>
                )}
                {reportData.country?.name && (
                  <div className="flex justify-between items-center p-2 bg-muted/30 rounded-md">
                    <span className="text-muted-foreground">Country:</span>
                    <span className="font-semibold text-foreground flex items-center">
                      <MapPin className="h-3 w-3 mr-1" />
                      {reportData.country.name}
                    </span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Status & Timing */}
          <Card className="bg-card border-border hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <h4 className="text-sm font-semibold text-foreground mb-4 flex items-center">
                <div className="w-8 h-8 bg-orange-100 dark:bg-orange-950 rounded-lg flex items-center justify-center mr-3">
                  <Clock className="h-4 w-4 text-orange-600 dark:text-orange-400" />
                </div>
                Status & Timing
              </h4>
              <div className="space-y-3 text-sm">
                {reportData.status && (
                  <div className="flex justify-between items-center p-2 bg-muted/30 rounded-md">
                    <span className="text-muted-foreground">Status:</span>
                    <Badge
                      variant="outline"
                      className={`text-xs ${
                        reportData.status === '1'
                          ? 'bg-green-50 text-green-700 border-green-200 dark:bg-green-950 dark:text-green-400 dark:border-green-800'
                          : 'bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-950 dark:text-yellow-400 dark:border-yellow-800'
                      }`}
                    >
                      {reportData.status === '1' ? 'Completed' : 'Pending'}
                    </Badge>
                  </div>
                )}
                {reportData.created_at && (
                  <div className="flex justify-between items-center p-2 bg-muted/30 rounded-md">
                    <span className="text-muted-foreground">Created:</span>
                    <span className="font-semibold text-foreground">
                      {formatDate(reportData.created_at)}
                    </span>
                  </div>
                )}
                {reportData.updated_at && (
                  <div className="flex justify-between items-center p-2 bg-muted/30 rounded-md">
                    <span className="text-muted-foreground">Updated:</span>
                    <span className="font-semibold text-foreground">
                      {formatDate(reportData.updated_at)}
                    </span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Detailed Analytics */}
      {showExpandedView && reportData && (
        <div className="space-y-8">
          {/* Message Content Card */}
          <div>
            <h4 className="text-lg font-semibold text-foreground mb-4 flex items-center">
              <div className="w-10 h-10 bg-purple-100 dark:bg-purple-950 rounded-xl flex items-center justify-center mr-3">
                <MessageSquare className="h-5 w-5 text-purple-600 dark:text-purple-400" />
              </div>
              Full Message Content
            </h4>
            <Card className="bg-card border-border">
              <CardContent className="p-6">
                <div className="text-foreground leading-relaxed whitespace-pre-wrap bg-muted/20 p-4 rounded-lg border border-border/50">
                  {getFullMessage(template)}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Detailed Analytics */}
          <div>
            <h4 className="text-lg font-semibold text-foreground mb-4 flex items-center">
              <div className="w-10 h-10 bg-chart-1/10 rounded-xl flex items-center justify-center mr-3">
                <CheckCircle2 className="h-5 w-5 text-chart-1" />
              </div>
              Detailed Analytics
            </h4>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900 border-blue-200 dark:border-blue-800 hover:shadow-md transition-all duration-200">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-blue-600 dark:bg-blue-500 rounded-xl flex items-center justify-center mx-auto mb-3">
                    <Send className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-2xl font-bold text-blue-700 dark:text-blue-400">
                    {reportData.sent_count || 0}
                  </div>
                  <div className="text-sm text-blue-600 dark:text-blue-500 font-medium">
                    Messages Sent
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950 dark:to-green-900 border-green-200 dark:border-green-800 hover:shadow-md transition-all duration-200">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-green-600 dark:bg-green-500 rounded-xl flex items-center justify-center mx-auto mb-3">
                    <CheckCircle2 className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-2xl font-bold text-green-700 dark:text-green-400">
                    {reportData.dlvd_count || 0}
                  </div>
                  <div className="text-sm text-green-600 dark:text-green-500 font-medium">
                    Delivered
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-950 dark:to-purple-900 border-purple-200 dark:border-purple-800 hover:shadow-md transition-all duration-200">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-purple-600 dark:bg-purple-500 rounded-xl flex items-center justify-center mx-auto mb-3">
                    <Eye className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-2xl font-bold text-purple-700 dark:text-purple-400">
                    {reportData.read_count || 0}
                  </div>
                  <div className="text-sm text-purple-600 dark:text-purple-500 font-medium">
                    Read
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-red-50 to-red-100 dark:from-red-950 dark:to-red-900 border-red-200 dark:border-red-800 hover:shadow-md transition-all duration-200">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-red-600 dark:bg-red-500 rounded-xl flex items-center justify-center mx-auto mb-3">
                    <AlertCircle className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-2xl font-bold text-red-700 dark:text-red-400">
                    {reportData.failed_count || 0}
                  </div>
                  <div className="text-sm text-red-600 dark:text-red-500 font-medium">
                    Failed
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-yellow-50 to-yellow-100 dark:from-yellow-950 dark:to-yellow-900 border-yellow-200 dark:border-yellow-800 hover:shadow-md transition-all duration-200">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-yellow-600 dark:bg-yellow-500 rounded-xl flex items-center justify-center mx-auto mb-3">
                    <Loader className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-2xl font-bold text-yellow-700 dark:text-yellow-400">
                    {reportData.other_count || 0}
                  </div>
                  <div className="text-sm text-yellow-600 dark:text-yellow-500 font-medium">
                    Pending
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default WhatsAppTemplateViewer;
