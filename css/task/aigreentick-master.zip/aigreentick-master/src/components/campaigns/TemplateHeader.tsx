import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Plus, MessageSquare } from 'lucide-react';

interface TemplateHeaderProps {
  onNewTemplate: () => void;
  totalTemplates: number;
}

const TemplateHeader: React.FC<TemplateHeaderProps> = ({
  onNewTemplate,
  totalTemplates,
}) => {
  return (
    <div className="space-y-4 mb-6">
      {/* Main Header */}
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <div className="flex gap-3 items-center">
            <div className="bg-primary p-3 rounded-xl">
              <MessageSquare className="h-8 w-8 text-primary-foreground" />
            </div>
            <div className="flex flex-col gap-1">
              <h1 className="text-3xl font-bold text-foreground">
                Your Templates
              </h1>
              <p className="text-muted-foreground">
                Select or create your template and submit it for WhatsApp
                approval
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          {/* Templates Count Badge */}
          <Badge
            variant="outline"
            className="bg-secondary text-secondary-foreground border-border px-3 py-1.5"
          >
            {totalTemplates} Templates
          </Badge>

          {/* New Template Button */}
          <Button
            size="sm"
            className="bg-primary hover:bg-primary/90 text-primary-foreground transition-all duration-200 hover:scale-105"
            onClick={onNewTemplate}
          >
            <Plus className="w-4 h-4 mr-2" />
            New Template Message
          </Button>
        </div>
      </div>

      {/* Guidelines Section */}
      <div className="bg-muted/30 border border-border rounded-lg p-4">
        <p className="text-muted-foreground text-sm">
          All templates must adhere to{' '}
          <a
            href="#"
            className="text-primary underline hover:text-primary/80 transition-colors"
          >
            WhatsApp's guidelines
          </a>
          . Templates are reviewed and approved by WhatsApp before they can be
          used.
        </p>
      </div>
    </div>
  );
};

export default TemplateHeader;
