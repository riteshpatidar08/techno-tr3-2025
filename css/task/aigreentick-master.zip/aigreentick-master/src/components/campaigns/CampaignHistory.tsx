import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Search,
  Calendar,
  Plus,
  Minus,
  Download,
  Eye,
  RotateCcw,
  ChevronLeft,
  ChevronRight,
  Phone,
  ExternalLink,
  User,
  MapPin,
  MessageSquare,
  Clock,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  AlertTriangle,
  XCircle,
  X,
  Filter,
  BarChart3,
  TrendingUp,
  Send
} from 'lucide-react';
import WarningComponent from '@/components/ui/warning';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  fetchReports,
  fetchReportById,
  fetchReportByUrl,
  setFilters,
  clearFilters,
  selectReports,
  selectReportsLoading,
  selectReportsError,
  selectReportsFilters,
  selectReportsPagination,
  selectCurrentReport,
  selectCurrentReportLoading,
  selectCurrentReportError,
  selectCurrentReportDetails,
  selectCurrentReportPagination,
} from '@/redux/reportsSlice';

const CampaignHistory = () => {
  const dispatch = useDispatch();
  const reports = useSelector(selectReports);
  const isLoading = useSelector(selectReportsLoading);
  const error = useSelector(selectReportsError);
  const filters = useSelector(selectReportsFilters);
  const pagination = useSelector(selectReportsPagination);
  const currentReport = useSelector(selectCurrentReport);
  const isLoadingCurrentReport = useSelector(selectCurrentReportLoading);
  const currentReportError = useSelector(selectCurrentReportError);
  const reportDetails = useSelector(selectCurrentReportDetails);
  const reportDetailsPagination = useSelector(selectCurrentReportPagination);

  const [searchTerm, setSearchTerm] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [reportType, setReportType] = useState('all');
  const [recordsPerPage, setRecordsPerPage] = useState(10);
  const [expandedRows, setExpandedRows] = useState(new Set());
  const [showLogs, setShowLogs] = useState(false);
  const [downloadingReports, setDownloadingReports] = useState(new Set());
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedCampaignId, setSelectedCampaignId] = useState(null);
  const [dialogPage, setDialogPage] = useState(1);
  const [dialogPerPage, setDialogPerPage] = useState(10);
  const [logs, setLogs] = useState([
    {
      id: 1,
      type: 'success',
      title: 'Campaign Sent Successfully',
      message: 'Marketing Campaign #001 has been sent to 1,250 recipients',
      timestamp: '2025-01-24 10:30:15',
      campaignId: 'camp_001',
    },
    {
      id: 2,
      type: 'warning',
      title: 'Delivery Rate Alert',
      message:
        'Campaign #002 has a delivery rate below 85%. Consider reviewing your contact list.',
      timestamp: '2025-01-24 09:15:22',
      campaignId: 'camp_002',
    },
    {
      id: 3,
      type: 'error',
      title: 'Template Validation Failed',
      message:
        'Campaign #003 template contains invalid WhatsApp formatting. Please review and resubmit.',
      timestamp: '2025-01-24 08:45:10',
      campaignId: 'camp_003',
    },
  ]);

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      const newFilters = {
        search: searchTerm.trim(),
        from: fromDate,
        to: toDate,
        type: reportType === 'all' ? '' : reportType,
        per_page: recordsPerPage,
        page: 1,
      };
      dispatch(setFilters(newFilters));
      dispatch(fetchReports(newFilters));
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [searchTerm, fromDate, toDate, reportType, recordsPerPage, dispatch]);

  useEffect(() => {
    setSearchTerm(filters.search || '');
    setFromDate(filters.from || '');
    setToDate(filters.to || '');
    setReportType(filters.type || 'all');
  }, [filters]);

  const handleClearFilters = () => {
    setSearchTerm('');
    setFromDate('');
    setToDate('');
    setReportType('all');
    setRecordsPerPage(10);
    const clearedFilters = {
      search: '',
      from: '',
      to: '',
      type: '',
      per_page: 10,
      page: 1,
    };
    dispatch(setFilters(clearedFilters));
    dispatch(fetchReports(clearedFilters));
  };

  const handlePageChange = (page) => {
    const newFilters = {
      ...filters,
      search: searchTerm.trim(),
      from: fromDate,
      to: toDate,
      type: reportType === 'all' ? '' : reportType,
      per_page: recordsPerPage,
      page,
    };
    dispatch(setFilters(newFilters));
    dispatch(fetchReports(newFilters));
  };

  useEffect(() => {
    dispatch(fetchReports({ page: 1, per_page: 10 }));
  }, [dispatch]);

  const getDeliveryRate = (report) => {
    const total = report.total || 0;
    const delivered = report.dlvd_count || 0;
    return total > 0 ? ((delivered / total) * 100).toFixed(1) : '0';
  };

  const getReadRate = (report) => {
    const delivered = report.dlvd_count || 0;
    const read = report.read_count || 0;
    return delivered > 0 ? ((read / delivered) * 100).toFixed(1) : '0';
  };

  const handleRecordsPerPageChange = (newPerPage) => {
    setRecordsPerPage(parseInt(newPerPage));
    const newFilters = {
      ...filters,
      search: searchTerm.trim(),
      from: fromDate,
      to: toDate,
      type: reportType === 'all' ? '' : reportType,
      per_page: parseInt(newPerPage),
      page: 1,
    };
    dispatch(setFilters(newFilters));
    dispatch(fetchReports(newFilters));
  };

  const toggleRowExpansion = (id) => {
    const newSet = new Set(expandedRows);
    newSet.has(id) ? newSet.delete(id) : newSet.add(id);
    setExpandedRows(newSet);
  };

  const handleViewCampaign = (campaignId) => {
    console.log('Viewing campaign:', campaignId);
    setSelectedCampaignId(campaignId);
    setDialogPage(1);
    setIsDialogOpen(true);

    dispatch(
      fetchReportByUrl({
        id: campaignId,
        type: '',
        page: 1,
        per_page: dialogPerPage,
      })
    );
  };

  const handleDialogPageChange = (page) => {
    setDialogPage(page);
    if (selectedCampaignId) {
      dispatch(
        fetchReportByUrl({
          id: selectedCampaignId,
          type: '',
          page: page,
          per_page: dialogPerPage,
        })
      );
    }
  };

  const handleDialogPerPageChange = (newPerPage) => {
    setDialogPerPage(parseInt(newPerPage));
    setDialogPage(1);
    if (selectedCampaignId) {
      dispatch(
        fetchReportByUrl({
          id: selectedCampaignId,
          type: '',
          page: 1,
          per_page: parseInt(newPerPage),
        })
      );
    }
  };

  const parseWebhookResponse = (responseString) => {
    try {
      if (!responseString) return {};
      const response = JSON.parse(responseString);
      const statusInfo =
        response?.entry?.[0]?.changes?.[0]?.value?.statuses?.[0] || {};
      const metadata =
        response?.entry?.[0]?.changes?.[0]?.value?.metadata || {};
      return { statusInfo, metadata };
    } catch (e) {
      console.warn('Failed to parse webhook response:', e);
      return {};
    }
  };

  const handleDownloadReport = async (reportId) => {
    try {
      setDownloadingReports((prev) => new Set([...prev, reportId]));

      console.log('Downloading report for ID:', reportId);

      const resultAction = await dispatch(
        fetchReportById({
          id: reportId,
          type: 'all',
        })
      );

      if (fetchReportById.fulfilled.match(resultAction)) {
        console.log('Report data fetched successfully:', resultAction.payload);

        const reportData = resultAction.payload;

        const excelData = [];

        if (reportData.data && Array.isArray(reportData.data)) {
          reportData.data.forEach((item, index) => {
            let parsedResponse = {};
            try {
              if (item.response) {
                parsedResponse = JSON.parse(item.response);
              }
            } catch (e) {
              console.warn('Failed to parse response JSON for item:', item.id);
            }

            const statusInfo =
              parsedResponse?.entry?.[0]?.changes?.[0]?.value?.statuses?.[0] ||
              {};
            const metadata =
              parsedResponse?.entry?.[0]?.changes?.[0]?.value?.metadata || {};

            excelData.push({
              'S.No': index + 1,
              ID: item.id,
              'User ID': item.user_id,
              'Broadcast ID': item.broadcast_id,
              'Campaign ID': item.campaign_id || 'N/A',
              'Mobile Number': item.mobile,
              'WhatsApp ID': item.wa_id,
              Type: item.type,
              'Message ID': item.message_id,
              'Message Status': item.message_status,
              Status: item.status,
              'Payment Status': item.payment_status === 1 ? 'Paid' : 'Unpaid',
              Platform: item.platform,
              'Display Phone Number': metadata.display_phone_number || 'N/A',
              'Phone Number ID': metadata.phone_number_id || 'N/A',
              'Webhook Status': statusInfo.status || 'N/A',
              'Webhook Timestamp': statusInfo.timestamp
                ? new Date(
                    parseInt(statusInfo.timestamp) * 1000
                  ).toLocaleString()
                : 'N/A',
              'Recipient ID': statusInfo.recipient_id || 'N/A',
              Contact: item.contact || 'N/A',
              'Created At': new Date(item.created_at).toLocaleString(),
              'Updated At': new Date(item.updated_at).toLocaleString(),
              'Deleted At': item.deleted_at
                ? new Date(item.deleted_at).toLocaleString()
                : 'N/A',
            });
          });
        }

        if (excelData.length > 0) {
          const headers = Object.keys(excelData[0]);

          const escapeCSVValue = (value) => {
            if (value === null || value === undefined) {
              return '';
            }
            const stringValue = String(value);

            if (
              stringValue.includes(',') ||
              stringValue.includes('"') ||
              stringValue.includes('\n') ||
              stringValue.includes('\r')
            ) {
              return `"${stringValue.replace(/"/g, '""')}"`;
            }
            return stringValue;
          };

          const csvRows = [
            headers.map(escapeCSVValue).join(','),
            ...excelData.map((row) =>
              headers.map((header) => escapeCSVValue(row[header])).join(',')
            ),
          ];

          const csvContent = csvRows.join('\n');

          try {
            const BOM = '\uFEFF';
            const blob = new Blob([BOM + csvContent], {
              type: 'text/csv;charset=utf-8;',
            });

            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');

            link.href = url;
            link.download = `campaign_report_${reportId}_${
              new Date().toISOString().split('T')[0]
            }.csv`;

            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);

            setTimeout(() => URL.revokeObjectURL(url), 100);

            console.log('CSV file download initiated successfully');
          } catch (downloadError) {
            console.error('Error creating download:', downloadError);
            throw new Error('Failed to create download file');
          }

          setLogs((prev) => [
            ...prev,
            {
              id: Date.now(),
              type: 'success',
              title: 'Report Downloaded Successfully',
              message: `Campaign report #${reportId} with ${excelData.length} records has been downloaded successfully`,
              timestamp: new Date().toISOString(),
              campaignId: `camp_${reportId}`,
            },
          ]);
        } else {
          setLogs((prev) => [
            ...prev,
            {
              id: Date.now(),
              type: 'warning',
              title: 'No Data Found',
              message: `Report #${reportId} contains no data to download`,
              timestamp: new Date().toISOString(),
              campaignId: `camp_${reportId}`,
            },
          ]);
        }
      } else {
        console.error('Failed to fetch report:', resultAction.payload);

        setLogs((prev) => [
          ...prev,
          {
            id: Date.now(),
            type: 'error',
            title: 'Download Failed',
            message: `Failed to download report #${reportId}: ${
              resultAction.payload || 'Unknown error'
            }`,
            timestamp: new Date().toISOString(),
            campaignId: `camp_${reportId}`,
          },
        ]);
      }
    } catch (error) {
      console.error('Error downloading report:', error);

      setLogs((prev) => [
        ...prev,
        {
          id: Date.now(),
          type: 'error',
          title: 'Download Error',
          message: `An unexpected error occurred while downloading report #${reportId}`,
          timestamp: new Date().toISOString(),
          campaignId: `camp_${reportId}`,
        },
      ]);
    } finally {
      setDownloadingReports((prev) => {
        const newSet = new Set(prev);
        newSet.delete(reportId);
        return newSet;
      });
    }
  };

  const handleResendCampaign = (reportId) => {
    console.log('Resending campaign:', reportId);
  };

  const handleRetryAction = (logId) => {
    console.log('Retrying action for log:', logId);
  };

  const handleDismissLog = (logId) => {
    setLogs(logs.filter((log) => log.id !== logId));
  };

  const formatDate = (dateString) =>
    new Date(dateString).toLocaleDateString('en-GB');

  const formatTime = (dateString) =>
    new Date(dateString).toLocaleTimeString('en-GB', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });

  const formatLogTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleString('en-GB', {
      day: '2-digit',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getMessagePreview = (report) => {
    const body = report.template?.components?.find((c) => c.type === 'BODY');
    return body?.text
      ? body.text.length > 80
        ? body.text.slice(0, 80) + '...'
        : body.text
      : 'No message content';
  };

  const getFullMessage = (report) =>
    report.template?.components?.find((c) => c.type === 'BODY')?.text ||
    'No message content';

  const getMediaImage = (report) =>
    report.template?.components?.find(
      (c) => c.type === 'HEADER' && c.format === 'IMAGE'
    )?.image_url;

  const getTemplateButtons = (report) => {
    const buttonComponent = report.template?.components?.find(
      (c) => c.type === 'BUTTONS'
    );
    return buttonComponent?.buttons || [];
  };

  const renderButton = (button) => {
    switch (button.type) {
      case 'PHONE_NUMBER':
        return (
          <Button
            key={button.id}
            variant="outline"
            size="sm"
            className="flex items-center gap-2 border-green-200 text-green-700 hover:bg-green-50 dark:border-green-800 dark:text-green-400 dark:hover:bg-green-950"
            onClick={() => window.open(`tel:${button.number}`, '_self')}
          >
            <Phone className="h-4 w-4" />
            {button.text}
          </Button>
        );
      case 'URL':
        return (
          <Button
            key={button.id}
            variant="outline"
            size="sm"
            className="flex items-center gap-2 border-blue-200 text-blue-700 hover:bg-blue-50 dark:border-blue-800 dark:text-blue-400 dark:hover:bg-blue-950"
            onClick={() => window.open(button.url, '_blank')}
          >
            <ExternalLink className="h-4 w-4" />
            {button.text}
          </Button>
        );
      default:
        return (
          <Button
            key={button.id}
            variant="outline"
            size="sm"
            className="flex items-center gap-2 border-border text-foreground hover:bg-accent"
          >
            {button.text}
          </Button>
        );
    }
  };

  const getActiveFilters = () => {
    const activeFilters = [];

    if (searchTerm.trim()) {
      activeFilters.push({
        label: 'Search',
        value: searchTerm.trim(),
        key: 'search',
      });
    }

    if (reportType && reportType !== 'all') {
      activeFilters.push({
        label: 'Type',
        value: reportType.charAt(0).toUpperCase() + reportType.slice(1),
        key: 'type',
      });
    }

    if (fromDate) {
      activeFilters.push({
        label: 'From',
        value: new Date(fromDate).toLocaleDateString('en-GB'),
        key: 'from',
      });
    }

    if (toDate) {
      activeFilters.push({
        label: 'To',
        value: new Date(toDate).toLocaleDateString('en-GB'),
        key: 'to',
      });
    }

    return activeFilters;
  };

  const removeFilter = (filterKey) => {
    switch (filterKey) {
      case 'search':
        setSearchTerm('');
        break;
      case 'type':
        setReportType('all');
        break;
      case 'from':
        setFromDate('');
        break;
      case 'to':
        setToDate('');
        break;
    }

    const newFilters = {
      search: filterKey === 'search' ? '' : searchTerm.trim(),
      from: filterKey === 'from' ? '' : fromDate,
      to: filterKey === 'to' ? '' : toDate,
      type: filterKey === 'type' ? '' : reportType === 'all' ? '' : reportType,
      per_page: recordsPerPage,
      page: 1,
    };

    dispatch(setFilters(newFilters));
    dispatch(fetchReports(newFilters));
  };

  return (
    <TooltipProvider>
      <div className="min-h-screen ">
        <div className="p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div className="space-y-2">
              <div className="flex gap-3 items-center">
                <div className="bg-primary p-3 rounded-xl">
                  <BarChart3 className="h-8 w-8 text-primary-foreground" />
                </div>
                <div className="flex flex-col gap-1">
                  <h1 className="text-3xl font-bold text-foreground">
                    Campaign History
                  </h1>
                  <p className="text-muted-foreground">
                    Track and analyze your WhatsApp campaign performance
                  </p>
                </div>
              </div>
            </div>

            <Button
              onClick={() => setShowLogs(!showLogs)}
              variant="outline"
              className="border-border hover:bg-accent text-foreground"
            >
              <AlertCircle className="h-4 w-4 mr-2" />
              {showLogs ? 'Hide' : 'Show'} Logs
              {logs.length > 0 && (
                <Badge className="ml-2 bg-destructive text-destructive-foreground">
                  {logs.length}
                </Badge>
              )}
            </Button>
          </div>

          {/* System Logs */}
          {showLogs && (
            <Card className="bg-card border-border">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold text-card-foreground">
                    System Logs
                  </h2>
                  <Button
                    onClick={() => setLogs([])}
                    variant="ghost"
                    size="sm"
                    className="text-muted-foreground hover:text-foreground"
                  >
                    Clear All
                  </Button>
                </div>

                {logs.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <AlertCircle className="h-12 w-12 mx-auto mb-3 opacity-50" />
                    <p>No logs to display</p>
                  </div>
                ) : (
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {logs.map((log) => (
                      <WarningComponent
                        key={log.id}
                        type={log.type}
                        title={log.title}
                        message={log.message}
                        size="sm"
                        dismissible
                        onClose={() => handleDismissLog(log.id)}
                        actions={
                          log.type === 'error' || log.type === 'warning'
                            ? [
                                {
                                  label: 'Retry',
                                  onClick: () => handleRetryAction(log.id),
                                  icon: RefreshCw,
                                  variant: 'outline',
                                  className: 'text-xs',
                                },
                                ...(log.campaignId
                                  ? [
                                      {
                                        label: 'View Campaign',
                                        onClick: () =>
                                          handleViewCampaign(log.campaignId),
                                        icon: Eye,
                                        variant: 'ghost',
                                        className: 'text-xs',
                                      },
                                    ]
                                  : []),
                              ]
                            : log.campaignId
                            ? [
                                {
                                  label: 'View Campaign',
                                  onClick: () =>
                                    handleViewCampaign(log.campaignId),
                                  icon: Eye,
                                  variant: 'ghost',
                                  className: 'text-xs',
                                },
                              ]
                            : []
                        }
                        description={`${formatLogTimestamp(log.timestamp)}${
                          log.campaignId ? ` • Campaign: ${log.campaignId}` : ''
                        }`}
                      />
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Filters */}
          <Card className="bg-card border-border">
            <CardContent className="p-6 space-y-4">
              {/* Active Filters Display */}
              {getActiveFilters().length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Filter className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium text-foreground">
                        Active Filters
                      </span>
                    </div>
                    <Button
                      onClick={handleClearFilters}
                      variant="ghost"
                      size="sm"
                      className="text-muted-foreground hover:text-foreground hover:bg-accent text-xs"
                    >
                      Clear All
                    </Button>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {getActiveFilters().map((filter) => (
                      <Badge
                        key={filter.key}
                        variant="secondary"
                        className="bg-secondary text-secondary-foreground border-border flex items-center gap-1.5"
                      >
                        <span className="font-medium">{filter.label}:</span>
                        <span>{filter.value}</span>
                        <button
                          onClick={() => removeFilter(filter.key)}
                          className="ml-1 p-0.5 text-muted-foreground hover:text-foreground hover:bg-accent rounded-full transition-colors"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>

                  <div className="border-t border-border pt-4"></div>
                </div>
              )}

              <div className="grid md:grid-cols-4 gap-4">
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-card-foreground">
                    Search
                  </label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      placeholder="Search by number/message"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10  border-input text-foreground"
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-card-foreground">
                    Type
                  </label>
                  <Select value={reportType} onValueChange={setReportType}>
                    <SelectTrigger className=" border-input text-foreground">
                      <SelectValue placeholder="All Type" />
                    </SelectTrigger>
                    <SelectContent className="bg-popover border-border">
                      <SelectItem
                        value="all"
                        className="text-popover-foreground"
                      >
                        All
                      </SelectItem>
                      <SelectItem
                        value="web"
                        className="text-popover-foreground"
                      >
                        Web
                      </SelectItem>
                      <SelectItem
                        value="api"
                        className="text-popover-foreground"
                      >
                        API
                      </SelectItem>
                      <SelectItem
                        value="chatbot"
                        className="text-popover-foreground"
                      >
                        Chatbot
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-card-foreground">
                    From
                  </label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      type="date"
                      value={fromDate}
                      onChange={(e) => setFromDate(e.target.value)}
                      className="pl-10  border-input text-foreground"
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-card-foreground">
                    To
                  </label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      type="date"
                      value={toDate}
                      onChange={(e) => setToDate(e.target.value)}
                      className="pl-10  border-input text-foreground"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Error States */}
          {error && (
            <Card className="bg-destructive/10 border-destructive/20">
              <CardContent className="p-4 text-destructive text-sm">
                {error}
              </CardContent>
            </Card>
          )}

          {/* Current Report Error */}
          {currentReportError && (
            <Card className="bg-destructive/10 border-destructive/20">
              <CardContent className="p-4 text-destructive text-sm">
                Download Error: {currentReportError}
              </CardContent>
            </Card>
          )}

          {/* Main Table */}
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <Table className="w-full table-fixed">
                <TableHeader>
                  <TableRow className="border-0 hover:bg-transparent">
                    <TableHead className="text-muted-foreground font-semibold text-xs uppercase tracking-wider py-3 px-2 bg-transparent border-0 w-[4%]"></TableHead>
                    <TableHead className="text-muted-foreground font-semibold text-xs uppercase tracking-wider py-3 px-2 bg-transparent border-0 w-[16%]">
                      Campaign
                    </TableHead>
                    <TableHead className="text-muted-foreground font-semibold text-xs uppercase tracking-wider py-3 px-2 bg-transparent border-0 text-center w-[6%]">
                      Total
                    </TableHead>
                    <TableHead className="text-muted-foreground font-semibold text-xs uppercase tracking-wider py-3 px-2 bg-transparent border-0 w-[24%]">
                      Message
                    </TableHead>
                    <TableHead className="text-muted-foreground font-semibold text-xs uppercase tracking-wider py-3 px-2 bg-transparent border-0 w-[10%]">
                      Date
                    </TableHead>
                    <TableHead className="text-muted-foreground font-semibold text-xs uppercase tracking-wider py-3 px-2 bg-transparent border-0 text-center w-[6%]">
                      Sent
                    </TableHead>
                    <TableHead className="text-muted-foreground font-semibold text-xs uppercase tracking-wider py-3 px-2 bg-transparent border-0 text-center w-[6%]">
                      Read
                    </TableHead>
                    <TableHead className="text-muted-foreground font-semibold text-xs uppercase tracking-wider py-3 px-2 bg-transparent border-0 text-center w-[6%]">
                      DLVD
                    </TableHead>
                    <TableHead className="text-muted-foreground font-semibold text-xs uppercase tracking-wider py-3 px-2 bg-transparent border-0 text-center w-[6%]">
                      Failed
                    </TableHead>
                    <TableHead className="text-muted-foreground font-semibold text-xs uppercase tracking-wider py-3 px-2 bg-transparent border-0 text-center w-[6%]">
                      Pending
                    </TableHead>
                    <TableHead className="text-muted-foreground font-semibold text-xs uppercase tracking-wider py-3 px-2 bg-transparent border-0 text-center w-[10%]">
                      Actions
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    <TableRow className="border-0">
                      <TableCell colSpan={11} className="h-32 border-0">
                        <div className="flex items-center justify-center">
                          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                          <span className="ml-2 text-muted-foreground">
                            Loading...
                          </span>
                        </div>
                      </TableCell>
                    </TableRow>
                  ) : reports?.length === 0 ? (
                    <TableRow className="border-0">
                      <TableCell
                        colSpan={11}
                        className="h-32 text-center text-muted-foreground border-0"
                      >
                        No reports found
                      </TableCell>
                    </TableRow>
                  ) : (
                    reports?.map((report, index) => (
                      <React.Fragment key={report.id}>
                        {/* Main Row */}
                        <TableRow
                          className={`hover:bg-muted/50 border-0 ${
                            index !== reports.length - 1
                              ? 'border-b border-border'
                              : ''
                          }`}
                        >
                          <TableCell className="py-3 px-2 border-0 w-[4%]">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => toggleRowExpansion(report.id)}
                              className="h-6 w-6 p-0 rounded-full bg-primary/10 text-primary hover:bg-primary/20 border-0"
                            >
                              {expandedRows.has(report.id) ? (
                                <Minus className="h-3 w-3" />
                              ) : (
                                <Plus className="h-3 w-3" />
                              )}
                            </Button>
                          </TableCell>
                          <TableCell className="py-3 px-2 border-0 w-[16%]">
                            <div className="font-medium text-foreground text-sm truncate">
                              {report.template?.name ||
                                report.campname ||
                                'No template'}
                            </div>
                          </TableCell>
                          <TableCell className="py-3 px-2 text-center border-0 w-[6%]">
                            <span className="font-medium text-foreground text-sm">
                              {report.total}
                            </span>
                          </TableCell>
                          <TableCell className="py-3 px-2 border-0 w-[24%]">
                            <div className="text-muted-foreground text-sm truncate">
                              {getMessagePreview(report)}
                            </div>
                          </TableCell>
                          <TableCell className="py-3 px-2 border-0 w-[10%]">
                            <div className="text-foreground font-medium text-xs">
                              {formatDate(report.created_at)}
                            </div>
                            <div className="text-muted-foreground text-xs">
                              {formatTime(report.created_at)}
                            </div>
                          </TableCell>
                          <TableCell className="py-3 px-2 text-center border-0 w-[6%]">
                            <span className="font-medium text-foreground text-sm">
                              {report.sent_count}
                            </span>
                          </TableCell>
                          <TableCell className="py-3 px-2 text-center border-0 w-[6%]">
                            <span className="font-medium text-foreground text-sm">
                              {report.read_count}
                            </span>
                          </TableCell>
                          <TableCell className="py-3 px-2 text-center border-0 w-[6%]">
                            <span className="font-medium text-foreground text-sm">
                              {report.dlvd_count}
                            </span>
                          </TableCell>
                          <TableCell className="py-3 px-2 text-center border-0 w-[6%]">
                            <span className="font-medium text-foreground text-sm">
                              {report.failed_count}
                            </span>
                          </TableCell>
                          <TableCell className="py-3 px-2 text-center border-0 w-[6%]">
                            <span className="font-medium text-foreground text-sm">
                              {report.other_count}
                            </span>
                          </TableCell>
                          <TableCell className="py-3 px-2 border-0 w-[10%]">
                            <div className="flex gap-1 justify-center">
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    size="sm"
                                    className="bg-primary hover:bg-primary/90 text-primary-foreground text-xs px-1 h-6"
                                    onClick={() =>
                                      handleDownloadReport(report.id)
                                    }
                                    disabled={downloadingReports.has(report.id)}
                                  >
                                    {downloadingReports.has(report.id) ? (
                                      <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-primary-foreground"></div>
                                    ) : (
                                      <Download className="h-3 w-3" />
                                    )}
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>
                                    {downloadingReports.has(report.id)
                                      ? 'Downloading...'
                                      : 'Download Report'}
                                  </p>
                                </TooltipContent>
                              </Tooltip>

                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    className="border-border text-foreground hover:bg-accent text-xs px-1 h-6"
                                    onClick={() =>
                                      handleViewCampaign(report.id)
                                    }
                                  >
                                    <Eye className="h-3 w-3" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>View Campaign Details</p>
                                </TooltipContent>
                              </Tooltip>

                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    size="sm"
                                    className="bg-primary hover:bg-primary/90 text-primary-foreground text-xs px-1 h-6"
                                    onClick={() =>
                                      handleResendCampaign(report.id)
                                    }
                                  >
                                    <RotateCcw className="h-3 w-3" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>Resend Campaign</p>
                                </TooltipContent>
                              </Tooltip>
                            </div>
                          </TableCell>
                        </TableRow>

                        {/* Expanded Row */}
                        {expandedRows.has(report.id) && (
                          <TableRow className="border-0">
                            <TableCell
                              colSpan={11}
                              className="p-0 bg-muted/30 border-0"
                            >
                              <div className="p-6 space-y-6">
                                {/* Campaign Stats */}
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                  {/* Performance Metrics */}
                                  <Card className="bg-card border-border">
                                    <CardContent className="p-4">
                                      <h4 className="text-sm font-semibold text-card-foreground mb-3 flex items-center">
                                        <TrendingUp className="h-4 w-4 mr-2 text-primary" />
                                        Performance Metrics
                                      </h4>
                                      <div className="space-y-3 text-sm">
                                        <div className="flex justify-between items-center p-2 bg-muted/30 rounded-md">
                                          <span className="text-muted-foreground">
                                            Delivery Rate:
                                          </span>
                                          <span className="font-semibold text-primary">
                                            {getDeliveryRate(report)}%
                                          </span>
                                        </div>
                                        <div className="flex justify-between items-center p-2 bg-muted/30 rounded-md">
                                          <span className="text-muted-foreground">
                                            Read Rate:
                                          </span>
                                          <span className="font-semibold text-chart-2">
                                            {getReadRate(report)}%
                                          </span>
                                        </div>
                                        <div className="flex justify-between items-center p-2 bg-muted/30 rounded-md">
                                          <span className="text-muted-foreground">
                                            Total Recipients:
                                          </span>
                                          <span className="font-semibold text-foreground">
                                            {report.total}
                                          </span>
                                        </div>
                                      </div>
                                    </CardContent>
                                  </Card>

                                  {/* Campaign Info */}
                                  <Card className="bg-card border-border">
                                    <CardContent className="p-4">
                                      <h4 className="text-sm font-semibold text-card-foreground mb-3 flex items-center">
                                        <User className="h-4 w-4 mr-2 text-chart-3" />
                                        Campaign Info
                                      </h4>
                                      <div className="space-y-3 text-sm">
                                        <div className="flex justify-between items-center p-2 bg-muted/30 rounded-md">
                                          <span className="text-muted-foreground">
                                            Campaign ID:
                                          </span>
                                          <span className="font-semibold text-foreground">
                                            {report.id}
                                          </span>
                                        </div>
                                        <div className="flex justify-between items-center p-2 bg-muted/30 rounded-md">
                                          <span className="text-muted-foreground">
                                            User:
                                          </span>
                                          <span className="font-semibold text-foreground">
                                            {report.user?.name || 'N/A'}
                                          </span>
                                        </div>
                                        <div className="flex justify-between items-center p-2 bg-muted/30 rounded-md">
                                          <span className="text-muted-foreground">
                                            Country:
                                          </span>
                                          <span className="font-semibold text-foreground flex items-center">
                                            <MapPin className="h-3 w-3 mr-1" />
                                            {report.country?.name || 'N/A'}
                                          </span>
                                        </div>
                                      </div>
                                    </CardContent>
                                  </Card>

                                  {/* Status & Timing */}
                                  <Card className="bg-card border-border">
                                    <CardContent className="p-4">
                                      <h4 className="text-sm font-semibold text-card-foreground mb-3 flex items-center">
                                        <Clock className="h-4 w-4 mr-2 text-chart-4" />
                                        Status & Timing
                                      </h4>
                                      <div className="space-y-3 text-sm">
                                        <div className="flex justify-between items-center p-2 bg-muted/30 rounded-md">
                                          <span className="text-muted-foreground">
                                            Status:
                                          </span>
                                          <Badge
                                            variant="outline"
                                            className={`text-xs ${
                                              report.status === '1'
                                                ? 'bg-primary/10 text-primary border-primary/20'
                                                : 'bg-secondary text-secondary-foreground border-border'
                                            }`}
                                          >
                                            {report.status === '1'
                                              ? 'Completed'
                                              : 'Pending'}
                                          </Badge>
                                        </div>
                                        <div className="flex justify-between items-center p-2 bg-muted/30 rounded-md">
                                          <span className="text-muted-foreground">
                                            Created:
                                          </span>
                                          <span className="font-semibold text-foreground">
                                            {formatDate(report.created_at)}
                                          </span>
                                        </div>
                                        <div className="flex justify-between items-center p-2 bg-muted/30 rounded-md">
                                          <span className="text-muted-foreground">
                                            Updated:
                                          </span>
                                          <span className="font-semibold text-foreground">
                                            {formatDate(report.updated_at)}
                                          </span>
                                        </div>
                                      </div>
                                    </CardContent>
                                  </Card>
                                </div>

                                {/* Message Content */}
                                <div>
                                  <h4 className="text-lg font-semibold text-foreground mb-3 flex items-center">
                                    <MessageSquare className="h-5 w-5 mr-2 text-chart-5" />
                                    Message Content
                                  </h4>
                                  <Card className="bg-card border-border">
                                    <CardContent className="p-4">
                                      <div className="text-foreground leading-relaxed whitespace-pre-wrap bg-muted/20 p-4 rounded-lg border border-border/50">
                                        {getFullMessage(report)}
                                      </div>
                                    </CardContent>
                                  </Card>
                                </div>

                                {/* Template Buttons */}
                                {getTemplateButtons(report).length > 0 && (
                                  <div>
                                    <h4 className="text-lg font-semibold text-foreground mb-3">
                                      Template Buttons
                                    </h4>
                                    <div className="flex flex-wrap gap-3">
                                      {getTemplateButtons(report).map(
                                        renderButton
                                      )}
                                    </div>
                                  </div>
                                )}

                                {/* Media Content */}
                                {getMediaImage(report) && (
                                  <div>
                                    <h4 className="text-lg font-semibold text-foreground mb-3">
                                      Media Content
                                    </h4>
                                    <div className="flex gap-4">
                                      <Card className="w-48 h-32 border-border">
                                        <CardContent className="p-0 h-full rounded-lg overflow-hidden">
                                          <img
                                            src={getMediaImage(report)}
                                            alt="Campaign Media"
                                            className="w-full h-full object-cover"
                                          />
                                        </CardContent>
                                      </Card>
                                    </div>
                                  </div>
                                )}

                                {/* Detailed Analytics */}
                                <div>
                                  <h4 className="text-lg font-semibold text-foreground mb-3 flex items-center">
                                    <CheckCircle2 className="h-5 w-5 mr-2 text-chart-1" />
                                    Detailed Analytics
                                  </h4>
                                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                                    <Card className="bg-gradient-to-br from-chart-1/10 to-chart-1/5 border-chart-1/20 hover:shadow-md transition-all duration-200">
                                      <CardContent className="p-6 text-center">
                                        <div className="w-12 h-12 bg-chart-1/20 rounded-xl flex items-center justify-center mx-auto mb-3">
                                          <Send className="w-6 h-6 text-chart-1" />
                                        </div>
                                        <div className="text-2xl font-bold text-chart-1">
                                          {report.sent_count}
                                        </div>
                                        <div className="text-sm text-chart-1/80 font-medium">
                                          Messages Sent
                                        </div>
                                      </CardContent>
                                    </Card>

                                    <Card className="bg-gradient-to-br from-chart-2/10 to-chart-2/5 border-chart-2/20 hover:shadow-md transition-all duration-200">
                                      <CardContent className="p-6 text-center">
                                        <div className="w-12 h-12 bg-chart-2/20 rounded-xl flex items-center justify-center mx-auto mb-3">
                                          <CheckCircle2 className="w-6 h-6 text-chart-2" />
                                        </div>
                                        <div className="text-2xl font-bold text-chart-2">
                                          {report.dlvd_count}
                                        </div>
                                        <div className="text-sm text-chart-2/80 font-medium">
                                          Delivered
                                        </div>
                                      </CardContent>
                                    </Card>

                                    <Card className="bg-gradient-to-br from-chart-3/10 to-chart-3/5 border-chart-3/20 hover:shadow-md transition-all duration-200">
                                      <CardContent className="p-6 text-center">
                                        <div className="w-12 h-12 bg-chart-3/20 rounded-xl flex items-center justify-center mx-auto mb-3">
                                          <Eye className="w-6 h-6 text-chart-3" />
                                        </div>
                                        <div className="text-2xl font-bold text-chart-3">
                                          {report.read_count}
                                        </div>
                                        <div className="text-sm text-chart-3/80 font-medium">
                                          Read
                                        </div>
                                      </CardContent>
                                    </Card>

                                    <Card className="bg-gradient-to-br from-destructive/10 to-destructive/5 border-destructive/20 hover:shadow-md transition-all duration-200">
                                      <CardContent className="p-6 text-center">
                                        <div className="w-12 h-12 bg-destructive/20 rounded-xl flex items-center justify-center mx-auto mb-3">
                                          <AlertCircle className="w-6 h-6 text-destructive" />
                                        </div>
                                        <div className="text-2xl font-bold text-destructive">
                                          {report.failed_count}
                                        </div>
                                        <div className="text-sm text-destructive/80 font-medium">
                                          Failed
                                        </div>
                                      </CardContent>
                                    </Card>

                                    <Card className="bg-gradient-to-br from-chart-4/10 to-chart-4/5 border-chart-4/20 hover:shadow-md transition-all duration-200">
                                      <CardContent className="p-6 text-center">
                                        <div className="w-12 h-12 bg-chart-4/20 rounded-xl flex items-center justify-center mx-auto mb-3">
                                          <Clock className="w-6 h-6 text-chart-4" />
                                        </div>
                                        <div className="text-2xl font-bold text-chart-4">
                                          {report.other_count}
                                        </div>
                                        <div className="text-sm text-chart-4/80 font-medium">
                                          Pending
                                        </div>
                                      </CardContent>
                                    </Card>
                                  </div>
                                </div>
                              </div>
                            </TableCell>
                          </TableRow>
                        )}
                      </React.Fragment>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* Campaign Details Dialog */}
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogContent className="w-full min-w-6xl max-h-[90vh] mt-8 p-8 bg-card flex flex-col">
              <DialogHeader className="border-b border-border px-6 py-4">
                <DialogTitle className="text-xl font-semibold text-card-foreground">
                  Campaign Details
                </DialogTitle>
                <DialogDescription className="text-muted-foreground">
                  Campaign ID:{' '}
                  <span className="font-medium text-foreground">
                    {selectedCampaignId}
                  </span>{' '}
                  • Detailed message delivery status and analytics
                </DialogDescription>
              </DialogHeader>

              <div className="flex flex-col h-[calc(95vh-140px)] bg-card">
                {/* Loading State */}
                {isLoadingCurrentReport && (
                  <div className="flex items-center justify-center flex-1">
                    <div className="text-center">
                      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
                      <p className="text-muted-foreground">
                        Loading campaign details...
                      </p>
                    </div>
                  </div>
                )}

                {currentReportError && !isLoadingCurrentReport && (
                  <div className="flex items-center justify-center flex-1">
                    <Card className="bg-destructive/10 border-destructive/20 max-w-md">
                      <CardContent className="p-6 text-center">
                        <AlertCircle className="h-12 w-12 text-destructive mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-destructive mb-2">
                          Error Loading Data
                        </h3>
                        <p className="text-destructive/80 text-sm">
                          {currentReportError}
                        </p>
                      </CardContent>
                    </Card>
                  </div>
                )}

                {/* Content Area */}
                {!isLoadingCurrentReport && !currentReportError && (
                  <>
                    {reportDetailsPagination && (
                      <Card className="bg-muted/30 border-border mb-4">
                        <CardContent className="p-4">
                          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                            <div className="text-center">
                              <div className="text-2xl font-bold text-foreground">
                                {reportDetailsPagination.total.toLocaleString()}
                              </div>
                              <div className="text-sm text-muted-foreground">
                                Total Messages
                              </div>
                            </div>
                            <div className="text-center">
                              <div className="text-2xl font-bold text-chart-2">
                                {reportDetails?.filter(
                                  (r) => r.status === 'read'
                                ).length || 0}
                              </div>
                              <div className="text-sm text-muted-foreground">
                                Read
                              </div>
                            </div>
                            <div className="text-center">
                              <div className="text-2xl font-bold text-chart-3">
                                {reportDetails?.filter(
                                  (r) => r.status === 'delivered'
                                ).length || 0}
                              </div>
                              <div className="text-sm text-muted-foreground">
                                Delivered
                              </div>
                            </div>
                            <div className="text-center">
                              <div className="text-2xl font-bold text-chart-4">
                                {reportDetails?.filter(
                                  (r) => r.status === 'sent'
                                ).length || 0}
                              </div>
                              <div className="text-sm text-muted-foreground">
                                Sent
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    )}

                    {/* Table Container */}
                    <Card className="flex-1 bg-card border-border overflow-hidden">
                      {reportDetails && reportDetails.length > 0 ? (
                        <div className="h-full flex flex-col">
                          <div className="flex-1 overflow-x-auto scrollbar-hide overflow-y-auto max-h-[40vh]">
                            <div className="min-w-[1200px]">
                              <Table>
                                <TableHeader className="bg-muted/50 sticky top-0 z-10">
                                  <TableRow className="border-b border-border">
                                    <TableHead className="text-left font-semibold text-muted-foreground py-3 px-3 w-[60px]">
                                      S.No
                                    </TableHead>
                                    <TableHead className="text-left font-semibold text-muted-foreground py-3 px-3 w-[140px]">
                                      Mobile Number
                                    </TableHead>
                                    <TableHead className="text-left font-semibold text-muted-foreground py-3 px-3 w-[100px]">
                                      Status
                                    </TableHead>
                                    <TableHead className="text-left font-semibold text-muted-foreground py-3 px-3 w-[120px]">
                                      Message Status
                                    </TableHead>
                                    <TableHead className="text-left font-semibold text-muted-foreground py-3 px-3 w-[120px]">
                                      Webhook Status
                                    </TableHead>
                                    <TableHead className="text-left font-semibold text-muted-foreground py-3 px-3 w-[100px]">
                                      Created At
                                    </TableHead>
                                    <TableHead className="text-left font-semibold text-muted-foreground py-3 px-3 w-[80px]">
                                      Platform
                                    </TableHead>
                                    <TableHead className="text-left font-semibold text-muted-foreground py-3 px-3 w-[80px]">
                                      Payment
                                    </TableHead>
                                    <TableHead className="text-left font-semibold text-muted-foreground py-3 px-3 w-[80px]">
                                      Type
                                    </TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {reportDetails.map((record, index) => {
                                    const { statusInfo, metadata } =
                                      parseWebhookResponse(record.response);
                                    const globalIndex = reportDetailsPagination
                                      ? (reportDetailsPagination?.currentPage -
                                          1) *
                                          reportDetailsPagination?.perPage +
                                        index +
                                        1
                                      : index + 1;

                                    return (
                                      <TableRow
                                        key={record?.id}
                                        className="hover:bg-muted/50 border-b border-border"
                                      >
                                        <TableCell className="py-3 px-3 font-medium text-foreground">
                                          {globalIndex}
                                        </TableCell>
                                        <TableCell className="py-3 px-3">
                                          <div className="font-mono text-sm text-foreground truncate">
                                            {record?.mobile}
                                          </div>
                                          <div className="text-xs text-muted-foreground font-mono truncate">
                                            {record?.wa_id}
                                          </div>
                                        </TableCell>
                                        <TableCell className="py-3 px-3">
                                          <Badge
                                            variant="outline"
                                            className={`text-xs whitespace-nowrap ${
                                              record?.status === 'read'
                                                ? 'bg-chart-2/10 text-chart-2 border-chart-2/20'
                                                : record?.status === 'delivered'
                                                ? 'bg-chart-3/10 text-chart-3 border-chart-3/20'
                                                : record?.status === 'sent'
                                                ? 'bg-chart-4/10 text-chart-4 border-chart-4/20'
                                                : 'bg-muted text-muted-foreground border-border'
                                            }`}
                                          >
                                            {record?.status || 'N/A'}
                                          </Badge>
                                        </TableCell>
                                        <TableCell className="py-3 px-3">
                                          <Badge
                                            variant="outline"
                                            className={`text-xs whitespace-nowrap ${
                                              record?.message_status ===
                                              'accepted'
                                                ? 'bg-chart-2/10 text-chart-2 border-chart-2/20'
                                                : 'bg-muted text-muted-foreground border-border'
                                            }`}
                                          >
                                            {record?.message_status}
                                          </Badge>
                                        </TableCell>
                                        <TableCell className="py-3 px-3">
                                          <Badge
                                            variant="outline"
                                            className={`text-xs whitespace-nowrap ${
                                              statusInfo?.status === 'read'
                                                ? 'bg-chart-2/10 text-chart-2 border-chart-2/20'
                                                : statusInfo?.status ===
                                                  'delivered'
                                                ? 'bg-chart-3/10 text-chart-3 border-chart-3/20'
                                                : statusInfo?.status === 'sent'
                                                ? 'bg-chart-4/10 text-chart-4 border-chart-4/20'
                                                : 'bg-muted text-muted-foreground border-border'
                                            }`}
                                          >
                                            {statusInfo?.status || 'N/A'}
                                          </Badge>
                                        </TableCell>
                                        <TableCell className="py-3 px-3">
                                          <div className="text-sm text-foreground whitespace-nowrap">
                                            {new Date(
                                              record?.created_at
                                            ).toLocaleDateString('en-GB')}
                                          </div>
                                          <div className="text-xs text-muted-foreground whitespace-nowrap">
                                            {new Date(
                                              record?.created_at
                                            ).toLocaleTimeString('en-GB', {
                                              hour: '2-digit',
                                              minute: '2-digit',
                                            })}
                                          </div>
                                        </TableCell>
                                        <TableCell className="py-3 px-3">
                                          <Badge
                                            variant="outline"
                                            className="text-xs bg-muted text-muted-foreground border-border whitespace-nowrap"
                                          >
                                            {record?.platform}
                                          </Badge>
                                        </TableCell>
                                        <TableCell className="py-3 px-3">
                                          <Badge
                                            variant="outline"
                                            className={`text-xs whitespace-nowrap ${
                                              record?.payment_status === 1
                                                ? 'bg-chart-2/10 text-chart-2 border-chart-2/20'
                                                : 'bg-destructive/10 text-destructive border-destructive/20'
                                            }`}
                                          >
                                            {record?.payment_status === 1
                                              ? 'Paid'
                                              : 'Unpaid'}
                                          </Badge>
                                        </TableCell>
                                        <TableCell className="py-3 px-3">
                                          <Badge
                                            variant="outline"
                                            className="text-xs bg-chart-5/10 text-chart-5 border-chart-5/20 whitespace-nowrap"
                                          >
                                            {record?.type}
                                          </Badge>
                                        </TableCell>
                                      </TableRow>
                                    );
                                  })}
                                </TableBody>
                              </Table>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-center justify-center h-64">
                          <div className="text-center">
                            <AlertCircle className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                            <h3 className="text-lg font-medium text-foreground mb-2">
                              No Data Available
                            </h3>
                            <p className="text-muted-foreground">
                              No campaign details found for this ID.
                            </p>
                          </div>
                        </div>
                      )}
                    </Card>

                    {/* Pagination */}
                    {reportDetailsPagination &&
                      reportDetailsPagination.lastPage > 1 && (
                        <Card className="bg-card border-t border-border mt-4">
                          <CardContent className="px-4 py-3">
                            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                                <div className="text-sm text-muted-foreground">
                                  Showing{' '}
                                  <span className="font-medium text-foreground">
                                    {Math.min(
                                      (reportDetailsPagination.currentPage -
                                        1) *
                                        reportDetailsPagination.perPage +
                                        1,
                                      reportDetailsPagination.total
                                    )}
                                  </span>{' '}
                                  to{' '}
                                  <span className="font-medium text-foreground">
                                    {Math.min(
                                      reportDetailsPagination.currentPage *
                                        reportDetailsPagination.perPage,
                                      reportDetailsPagination.total
                                    )}
                                  </span>{' '}
                                  of{' '}
                                  <span className="font-medium text-foreground">
                                    {reportDetailsPagination.total.toLocaleString()}
                                  </span>{' '}
                                  results
                                </div>

                                <div className="text-sm text-muted-foreground font-medium">
                                  Page {reportDetailsPagination.currentPage} of{' '}
                                  {reportDetailsPagination.lastPage}
                                </div>
                              </div>

                              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                                <div className="flex items-center gap-2">
                                  <span className="text-sm text-muted-foreground whitespace-nowrap">
                                    Rows per page:
                                  </span>
                                  <Select
                                    value={dialogPerPage.toString()}
                                    onValueChange={handleDialogPerPageChange}
                                  >
                                    <SelectTrigger className="w-20 h-8 text-sm border-input">
                                      <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent className="bg-popover border-border">
                                      <SelectItem
                                        value="5"
                                        className="text-popover-foreground"
                                      >
                                        5
                                      </SelectItem>
                                      <SelectItem
                                        value="10"
                                        className="text-popover-foreground"
                                      >
                                        10
                                      </SelectItem>
                                      <SelectItem
                                        value="20"
                                        className="text-popover-foreground"
                                      >
                                        20
                                      </SelectItem>
                                      <SelectItem
                                        value="50"
                                        className="text-popover-foreground"
                                      >
                                        50
                                      </SelectItem>
                                    </SelectContent>
                                  </Select>
                                </div>

                                <div className="flex items-center gap-1">
                                  <Button
                                    onClick={() => handleDialogPageChange(1)}
                                    disabled={
                                      reportDetailsPagination.currentPage <= 1
                                    }
                                    variant="outline"
                                    size="sm"
                                    className="px-3 py-1 text-sm border-border hover:bg-accent"
                                  >
                                    First
                                  </Button>

                                  <Button
                                    onClick={() =>
                                      handleDialogPageChange(
                                        reportDetailsPagination.currentPage - 1
                                      )
                                    }
                                    disabled={
                                      reportDetailsPagination.currentPage <= 1
                                    }
                                    variant="outline"
                                    size="sm"
                                    className="px-2 py-1 border-border hover:bg-accent"
                                  >
                                    <ChevronLeft className="h-4 w-4" />
                                  </Button>

                                  <div className="flex gap-1">
                                    {Array.from(
                                      {
                                        length: Math.min(
                                          7,
                                          reportDetailsPagination.lastPage
                                        ),
                                      },
                                      (_, i) => {
                                        let page;

                                        if (
                                          reportDetailsPagination.lastPage <= 7
                                        ) {
                                          page = i + 1;
                                        } else if (
                                          reportDetailsPagination.currentPage <=
                                          4
                                        ) {
                                          page = i + 1;
                                        } else if (
                                          reportDetailsPagination.currentPage >=
                                          reportDetailsPagination.lastPage - 3
                                        ) {
                                          page =
                                            reportDetailsPagination.lastPage -
                                            6 +
                                            i;
                                        } else {
                                          page =
                                            reportDetailsPagination.currentPage -
                                            3 +
                                            i;
                                        }

                                        if (
                                          page >= 1 &&
                                          page <=
                                            reportDetailsPagination.lastPage
                                        ) {
                                          return (
                                            <Button
                                              key={page}
                                              onClick={() =>
                                                handleDialogPageChange(page)
                                              }
                                              variant={
                                                page ===
                                                reportDetailsPagination.currentPage
                                                  ? 'default'
                                                  : 'outline'
                                              }
                                              size="sm"
                                              className={`w-8 h-8 p-0 text-sm ${
                                                page ===
                                                reportDetailsPagination.currentPage
                                                  ? 'bg-primary hover:bg-primary/90 text-primary-foreground border-primary'
                                                  : 'border-border hover:bg-accent'
                                              }`}
                                            >
                                              {page}
                                            </Button>
                                          );
                                        }
                                        return null;
                                      }
                                    )}
                                  </div>

                                  <Button
                                    onClick={() =>
                                      handleDialogPageChange(
                                        reportDetailsPagination.currentPage + 1
                                      )
                                    }
                                    disabled={
                                      reportDetailsPagination.currentPage >=
                                      reportDetailsPagination.lastPage
                                    }
                                    variant="outline"
                                    size="sm"
                                    className="px-2 py-1 border-border hover:bg-accent"
                                  >
                                    <ChevronRight className="h-4 w-4" />
                                  </Button>

                                  <Button
                                    onClick={() =>
                                      handleDialogPageChange(
                                        reportDetailsPagination.lastPage
                                      )
                                    }
                                    disabled={
                                      reportDetailsPagination.currentPage >=
                                      reportDetailsPagination.lastPage
                                    }
                                    variant="outline"
                                    size="sm"
                                    className="px-3 py-1 text-sm border-border hover:bg-accent"
                                  >
                                    Last
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      )}
                  </>
                )}
              </div>
            </DialogContent>
          </Dialog>

          {/* Main Pagination */}
          {pagination?.lastPage > 1 && (
            <Card className="bg-card border-border">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="text-sm text-muted-foreground">
                    Showing{' '}
                    <span className="font-medium text-foreground">
                      {(pagination.currentPage - 1) * pagination.perPage + 1}
                    </span>{' '}
                    to{' '}
                    <span className="font-medium text-foreground">
                      {Math.min(
                        pagination.currentPage * pagination.perPage,
                        pagination.total
                      )}
                    </span>{' '}
                    of{' '}
                    <span className="font-medium text-foreground">
                      {pagination.total}
                    </span>{' '}
                    results
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      onClick={() =>
                        handlePageChange(pagination.currentPage - 1)
                      }
                      disabled={pagination.currentPage <= 1}
                      variant="outline"
                      size="sm"
                      className="flex items-center gap-1 border-border hover:bg-accent"
                    >
                      <ChevronLeft className="h-4 w-4" />
                      Previous
                    </Button>

                    <div className="flex gap-1">
                      {Array.from(
                        { length: Math.min(5, pagination.lastPage) },
                        (_, i) => {
                          const startPage = Math.max(
                            1,
                            pagination.currentPage - 2
                          );
                          const page = startPage + i;

                          if (page <= pagination.lastPage) {
                            return (
                              <Button
                                key={page}
                                onClick={() => handlePageChange(page)}
                                variant={
                                  page === pagination.currentPage
                                    ? 'default'
                                    : 'outline'
                                }
                                size="sm"
                                className={`w-8 h-8 p-0 ${
                                  page === pagination.currentPage
                                    ? 'bg-primary hover:bg-primary/90 text-primary-foreground'
                                    : 'border-border hover:bg-accent'
                                }`}
                              >
                                {page}
                              </Button>
                            );
                          }
                          return null;
                        }
                      )}
                    </div>

                    <Button
                      onClick={() =>
                        handlePageChange(pagination.currentPage + 1)
                      }
                      disabled={pagination.currentPage >= pagination.lastPage}
                      variant="outline"
                      size="sm"
                      className="flex items-center gap-1 border-border hover:bg-accent"
                    >
                      Next
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </TooltipProvider>
  );
};

export default CampaignHistory;
