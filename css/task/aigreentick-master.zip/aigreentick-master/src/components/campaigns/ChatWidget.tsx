import React from 'react';
import { Button } from '@/components/ui/button';
import { MessageSquare } from 'lucide-react';

const ChatWidget: React.FC = () => {
  return (
    <div className="fixed bottom-4 right-4">
      <Button className="rounded-full w-12 h-12 bg-green-600 hover:bg-green-700 shadow-lg transition-all duration-200 hover:scale-110">
        <MessageSquare className="w-6 h-6" />
      </Button>
    </div>
  );
};

export default ChatWidget;
