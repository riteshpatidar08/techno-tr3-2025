import React, { useState } from 'react';
import {
  MessageCircle,
  CheckCircle,
  CheckCheck,
  AlertTriangle,
  BarChart3,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
} from '@/components/ui/chart';
import {
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
} from 'recharts';

const CampaignDashboard = () => {
  const [activeTab, setActiveTab] = useState('Dashboard Overview');
  const pieChartConfig = {
    completed: {
      label: 'Completed',
      color: 'hsl(var(--chart-2))',
    },
  };

  const lineChartConfig = {
    sent: {
      label: 'Sent',
      color: 'hsl(var(--chart-1))',
    },
    delivered: {
      label: 'Delivered',
      color: 'hsl(var(--chart-2))',
    },
    read: {
      label: 'Read',
      color: 'hsl(var(--chart-5))',
    },
  };

  const pieData = [
    { name: 'COMPLETED', value: 100, fill: 'hsl(var(--chart-2))' },
  ];

  const lineData = [
    { day: 'Day 1', sent: 8, delivered: 8, read: 0 },
    { day: 'Day 5', sent: 7, delivered: 7, read: 0 },
    { day: 'Day 10', sent: 6, delivered: 6, read: 0 },
    { day: 'Day 15', sent: 5, delivered: 5, read: 0 },
    { day: 'Day 20', sent: 4.5, delivered: 4.5, read: 0 },
    { day: 'Day 25', sent: 4, delivered: 4, read: 0 },
    { day: 'Day 30', sent: 4, delivered: 4, read: 0 },
  ];

  const campaigns = [
    {
      id: 1,
      name: 'testing with image',
      phonebook: 'Codeyon',
      status: 'COMPLETED',
      sent: 4,
      delivered: 4,
      read: 0,
      failed: 0,
      created: '10/6/2025, 3:48:55 pm',
    },
    {
      id: 2,
      name: 'send campaign',
      phonebook: '',
      status: 'COMPLETED',
      sent: 8,
      delivered: 8,
      read: 0,
      failed: 0,
      created: '6/6/2025, 9:29:54 pm',
    },
  ];

  const stats = [
    {
      icon: MessageCircle,
      value: '2',
      label: 'Total Campaigns',
      iconColor: 'text-chart-1',
      bgColor: 'bg-chart-1/10',
    },
    {
      icon: CheckCircle,
      value: '12',
      label: 'Messages Sent',
      iconColor: 'text-chart-2',
      bgColor: 'bg-chart-2/10',
    },
    {
      icon: CheckCheck,
      value: '12',
      label: 'Messages Delivered',
      iconColor: 'text-chart-3',
      bgColor: 'bg-chart-3/10',
    },
    {
      icon: AlertTriangle,
      value: '0',
      label: 'Failed Messages',
      iconColor: 'text-destructive',
      bgColor: 'bg-destructive/10',
    },
  ];

  return (
    <div className="flex-1 flex flex-col bg-background min-h-screen">
      {/* Header */}
      <div className="bg-card border-b border-border px-6 py-6">
        <div className="space-y-2 mb-6">
          <div className="flex gap-3 items-center">
            <div className="bg-primary p-3 rounded-xl">
              <BarChart3 className="h-8 w-8 text-primary-foreground" />
            </div>
            <div className="flex flex-col gap-1">
              <h1 className="text-3xl font-bold text-foreground">
                Campaign Dashboard
              </h1>
              <p className="text-muted-foreground">
                Monitor and analyze your WhatsApp campaign performance
              </p>
            </div>
          </div>
        </div>

        <div className="flex space-x-8">
          <button
            onClick={() => setActiveTab('Dashboard Overview')}
            className={`pb-2 border-b-2 font-medium transition-colors ${
              activeTab === 'Dashboard Overview'
                ? 'border-primary text-primary'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            Dashboard Overview
          </button>
          <button
            onClick={() => setActiveTab('All Campaigns')}
            className={`pb-2 border-b-2 font-medium transition-colors ${
              activeTab === 'All Campaigns'
                ? 'border-primary text-primary'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            All Campaigns
          </button>
        </div>
      </div>

      <div className="flex-1 p-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card
              key={index}
              className="bg-card border-border shadow-sm hover:shadow-md transition-shadow"
            >
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className={`p-3 rounded-xl ${stat.bgColor}`}>
                    <stat.icon className={`w-8 h-8 ${stat.iconColor}`} />
                  </div>
                  <div>
                    <div className="text-3xl font-bold text-card-foreground">
                      {stat.value}
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">
                      {stat.label}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Pie Chart */}
          <Card className="bg-card border-border shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-card-foreground">
                Campaign Status Distribution
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={pieChartConfig}
                className="mx-auto aspect-square max-h-[250px]"
              >
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={0}
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                  <text
                    x="50%"
                    y="50%"
                    textAnchor="middle"
                    dominantBaseline="middle"
                    className="text-2xl font-bold fill-card-foreground"
                  >
                    100.0%
                  </text>
                  <ChartTooltip content={<ChartTooltipContent />} />
                </PieChart>
              </ChartContainer>
              <div className="flex items-center justify-center mt-4">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 rounded-full bg-chart-2"></div>
                  <span className="text-sm text-muted-foreground">
                    COMPLETED
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Line Chart */}
          <Card className="bg-card border-border shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-card-foreground">
                Message Statistics (Last 30 Days)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={lineChartConfig}
                className="max-h-[250px] w-full"
              >
                <LineChart data={lineData}>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="hsl(var(--muted-foreground))"
                    strokeOpacity={0.3}
                  />
                  <XAxis
                    dataKey="day"
                    axisLine={false}
                    tickLine={false}
                    tick={{
                      fontSize: 12,
                      fill: 'hsl(var(--muted-foreground))',
                    }}
                  />
                  <YAxis
                    axisLine={false}
                    tickLine={false}
                    tick={{
                      fontSize: 12,
                      fill: 'hsl(var(--muted-foreground))',
                    }}
                  />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <ChartLegend content={<ChartLegendContent />} />
                  <Line
                    type="monotone"
                    dataKey="sent"
                    stroke="var(--color-sent)"
                    strokeWidth={2}
                    dot={{ fill: 'var(--color-sent)', r: 4 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="delivered"
                    stroke="var(--color-delivered)"
                    strokeWidth={2}
                    dot={{ fill: 'var(--color-delivered)', r: 4 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="read"
                    stroke="var(--color-read)"
                    strokeWidth={2}
                    dot={{ fill: 'var(--color-read)', r: 4 }}
                  />
                </LineChart>
              </ChartContainer>
            </CardContent>
          </Card>
        </div>

        {/* Campaigns Table */}
        <Card className="bg-card border-border shadow-sm">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg font-semibold text-card-foreground">
                Recent Campaigns
              </CardTitle>
              <Button
                variant="outline"
                className="text-primary border-primary hover:bg-primary/10"
              >
                View All
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-muted/30 border-b border-border">
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                      Campaign Name
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                      Phonebook
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                      Sent
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                      Delivered
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                      Read
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                      Failed
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                      Created
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-card divide-y divide-border">
                  {campaigns.map((campaign) => (
                    <tr
                      key={campaign.id}
                      className="hover:bg-muted/30 transition-colors"
                    >
                      <td className="px-6 py-4 whitespace-nowrap font-medium text-card-foreground">
                        {campaign.name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-muted-foreground">
                        {campaign.phonebook}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Badge className="bg-chart-2 hover:bg-chart-2/90 text-white border-0">
                          {campaign.status}
                        </Badge>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-card-foreground">
                        {campaign.sent}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-card-foreground">
                        {campaign.delivered}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-card-foreground">
                        {campaign.read}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-card-foreground">
                        {campaign.failed}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-muted-foreground text-sm">
                        {campaign.created}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-primary border-primary hover:bg-primary/10"
                        >
                          Details
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CampaignDashboard;
