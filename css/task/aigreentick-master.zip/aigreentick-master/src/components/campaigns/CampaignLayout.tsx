import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import CampaignSidebar from './CampaignSidebar';

const CampaignLayout = () => {
  const [activeTab, setActiveTab] = useState('Template Library');

  return (
    <div className="flex h-screen bg-gray-50">
      <CampaignSidebar activeTab={activeTab} setActiveTab={setActiveTab} />

      <div className="flex-1 ml-64  flex flex-col ">
        <Outlet />
      </div>
    </div>
  );
};

export default CampaignLayout;
