import React, { useState, useMemo } from 'react';
import { useDispatch } from 'react-redux';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  flexRender,
  getCoreRowModel,
  useReactTable,
  createColumnHelper,
  getSortedRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  SortingState,
  ColumnFiltersState,
  PaginationState,
  ColumnDef,
} from '@tanstack/react-table';
import {
  Copy,
  Eye,
  MoreHorizontal,
  ArrowUpDown,
  Search,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  Edit,
  Trash2,
  Download,
  RefreshCw,
  MessageCircle,
} from 'lucide-react';
import { Template, deleteTemplate } from '@/redux/templateSlice';
import WhatsAppTemplateViewer from './WhatsAppTemplateViewer';

interface TemplateTableProps {
  templates: Template[];
  loading?: boolean;
  onRefresh?: () => void;
  onCopy?: (template: Template) => void;
  onView?: (template: Template) => void;
  onEdit?: (template: Template) => void;
  onDelete?: (template: Template) => void;
  onDownload?: (template: Template) => void;
}

const TemplateTable: React.FC<TemplateTableProps> = ({
  templates,
  loading = false,
  onRefresh,
  onCopy,
  onView,
  onEdit,
  onDelete,
  onDownload,
}) => {
  const dispatch = useDispatch();
  const [sorting, setSorting] = useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
  const [globalFilter, setGlobalFilter] = useState('');
  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
  });

  const [previewDialogOpen, setPreviewDialogOpen] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(
    null
  );

  const getStatusColor = (status: string) => {
    switch (status.toUpperCase()) {
      case 'APPROVED':
        return 'bg-chart-2/10 text-chart-2 border-chart-2/20';
      case 'PENDING':
        return 'bg-chart-4/10 text-chart-4 border-chart-4/20';
      case 'REJECTED':
        return 'bg-destructive/10 text-destructive border-destructive/20';
      case 'DRAFT':
        return 'bg-muted text-muted-foreground border-border';
      default:
        return 'bg-muted text-muted-foreground border-border';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category.toUpperCase()) {
      case 'MARKETING':
        return 'bg-chart-1/10 text-chart-1 border-chart-1/20';
      case 'UTILITY':
        return 'bg-chart-5/10 text-chart-5 border-chart-5/20';
      case 'AUTHENTICATION':
        return 'bg-chart-3/10 text-chart-3 border-chart-3/20';
      default:
        return 'bg-muted text-muted-foreground border-border';
    }
  };

  const getLanguageDisplay = (language: string) => {
    const languageMap: { [key: string]: string } = {
      en: 'English',
      en_US: 'English (US)',
      hi: 'Hindi',
      es: 'Spanish',
      fr: 'French',
      de: 'German',
      pt: 'Portuguese',
      ar: 'Arabic',
    };
    return languageMap[language] || language.toUpperCase();
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-GB', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });
  };

  const tableData = useMemo(() => {
    return templates.map((template) => ({
      ...template,
      displayName: template.name,
      displayCategory: template.category,
      displayStatus: template.status,
      displayLanguage: getLanguageDisplay(template.language),
      lastUpdated: formatDate(template.updated_at),
      componentCount: template.components?.length || 0,
      hasButtons:
        template.components?.some((comp) => comp.buttons?.length > 0) || false,
    }));
  }, [templates]);

  const handleDelete = async (template: Template) => {
    if (
      window.confirm(
        `Are you sure you want to delete "${template.name}"? This action cannot be undone.`
      )
    ) {
      try {
        await dispatch(deleteTemplate(template.id) as any);
      } catch (error) {
        console.error('Failed to delete template:', error);
      }
    }
  };

  const handleViewTemplate = (template: Template) => {
    setSelectedTemplate(template);
    setPreviewDialogOpen(true);
    if (onView) {
      onView(template);
    }
  };

  const columnHelper = createColumnHelper<
    Template & {
      displayName: string;
      displayCategory: string;
      displayStatus: string;
      displayLanguage: string;
      lastUpdated: string;
      componentCount: number;
      hasButtons: boolean;
    }
  >();

  const columns: ColumnDef<
    Template & {
      displayName: string;
      displayCategory: string;
      displayStatus: string;
      displayLanguage: string;
      lastUpdated: string;
      componentCount: number;
      hasButtons: boolean;
    }
  >[] = [
    columnHelper.accessor('displayName', {
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')}
          className="h-auto p-0 font-semibold text-muted-foreground text-sm uppercase tracking-wide hover:bg-transparent hover:text-foreground"
        >
          Template Name
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => {
        const template = row.original;
        return (
          <div className="flex items-center space-x-3">
            <div className="flex flex-col">
              <span
                className="text-foreground font-medium cursor-pointer hover:text-primary transition-colors duration-200"
                onClick={() => handleViewTemplate(template)}
              >
                {template.name}
              </span>
              <span className="text-xs text-muted-foreground">
                ID: {template.wa_id}
              </span>
            </div>
          </div>
        );
      },
    }),
    columnHelper.accessor('displayCategory', {
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')}
          className="h-auto p-0 font-semibold text-muted-foreground text-sm uppercase tracking-wide hover:bg-transparent hover:text-foreground"
        >
          Category
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => {
        const template = row.original;
        return (
          <Badge
            variant="outline"
            className={`${getCategoryColor(
              template.category
            )} border font-medium`}
          >
            {template.category}
          </Badge>
        );
      },
    }),
    columnHelper.accessor('displayStatus', {
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')}
          className="h-auto p-0 font-semibold text-muted-foreground text-sm uppercase tracking-wide hover:bg-transparent hover:text-foreground"
        >
          Status
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => {
        const template = row.original;
        return (
          <div className="flex flex-col space-y-1">
            <Badge
              variant="outline"
              className={`${getStatusColor(
                template.status
              )} border font-medium w-fit`}
            >
              {template.status}
            </Badge>
            {template.componentCount > 0 && (
              <span className="text-xs text-muted-foreground">
                {template.componentCount} component
                {template.componentCount !== 1 ? 's' : ''}
              </span>
            )}
          </div>
        );
      },
    }),
    columnHelper.accessor('displayLanguage', {
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')}
          className="h-auto p-0 font-semibold text-muted-foreground text-sm uppercase tracking-wide hover:bg-transparent hover:text-foreground"
        >
          Language
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => {
        const template = row.original;
        return (
          <div className="flex flex-col">
            <span className="text-foreground font-medium">
              {template.displayLanguage}
            </span>
            <span className="text-xs text-muted-foreground">
              {template.language}
            </span>
          </div>
        );
      },
    }),
    columnHelper.accessor('lastUpdated', {
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')}
          className="h-auto p-0 font-semibold text-muted-foreground text-sm uppercase tracking-wide hover:bg-transparent hover:text-foreground"
        >
          Last Updated
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => {
        const template = row.original;
        const createdDate = formatDate(template.created_at);
        return (
          <div className="flex flex-col">
            <span className="text-muted-foreground text-sm">
              {template.lastUpdated}
            </span>
            <span className="text-xs text-muted-foreground/70">
              Created: {createdDate}
            </span>
          </div>
        );
      },
    }),
    columnHelper.display({
      id: 'actions',
      header: () => (
        <div className="text-right font-semibold text-muted-foreground text-sm uppercase tracking-wide">
          Actions
        </div>
      ),
      cell: ({ row }) => {
        const template = row.original;
        return (
          <div className="flex items-center justify-end space-x-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onCopy?.(template)}
              className="h-8 w-8 p-0 hover:bg-accent hover:scale-110 transition-all duration-200"
              title="Copy template"
            >
              <Copy className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleViewTemplate(template)}
              className="h-8 w-8 p-0 hover:bg-accent hover:scale-110 transition-all duration-200"
              title="View template"
            >
              <Eye className="w-4 h-4" />
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0 hover:bg-accent hover:scale-110 transition-all duration-200"
                  title="More options"
                >
                  <MoreHorizontal className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                align="end"
                className="w-48 bg-popover border-border"
              >
                <DropdownMenuItem
                  onClick={() => handleViewTemplate(template)}
                  className="cursor-pointer text-popover-foreground hover:bg-accent"
                >
                  <Eye className="w-4 h-4 mr-2" />
                  View template
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => onEdit?.(template)}
                  className="cursor-pointer text-popover-foreground hover:bg-accent"
                >
                  <Edit className="w-4 h-4 mr-2" />
                  Edit template
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => onCopy?.(template)}
                  className="cursor-pointer text-popover-foreground hover:bg-accent"
                >
                  <Copy className="w-4 h-4 mr-2" />
                  Duplicate template
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => onDownload?.(template)}
                  className="cursor-pointer text-popover-foreground hover:bg-accent"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download template
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() =>
                    window.open(
                      `https://wa.me/?text=${encodeURIComponent(
                        'Template: ' + template.name
                      )}`,
                      '_blank'
                    )
                  }
                  className="cursor-pointer text-popover-foreground hover:bg-accent"
                >
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Test on WhatsApp
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() =>
                    onDelete ? onDelete(template) : handleDelete(template)
                  }
                  className="text-destructive focus:text-destructive cursor-pointer hover:bg-destructive/10"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete template
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        );
      },
    }),
  ];

  const table = useReactTable({
    data: tableData,
    columns,
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    onPaginationChange: setPagination,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    onGlobalFilterChange: setGlobalFilter,
    state: {
      sorting,
      columnFilters,
      globalFilter,
      pagination,
    },
  });

  return (
    <div className="space-y-4">
      {/* Search and Actions Bar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search templates..."
              value={globalFilter ?? ''}
              onChange={(event) => setGlobalFilter(String(event.target.value))}
              className="pl-10 bg-background border-input text-foreground"
            />
          </div>
          {globalFilter && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setGlobalFilter('')}
              className="border-border hover:bg-accent"
            >
              Clear
            </Button>
          )}
        </div>

        {onRefresh && (
          <Button
            variant="outline"
            size="sm"
            onClick={onRefresh}
            disabled={loading}
            className="flex items-center space-x-2 border-border hover:bg-accent"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </Button>
        )}
      </div>

      <Card className="shadow-sm bg-card border-border">
        <div className="overflow-x-auto">
          {templates.length === 0 && !loading ? (
            /* Empty State */
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                <MessageCircle className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-medium text-foreground mb-2">
                No templates found
              </h3>
              <p className="text-muted-foreground">
                {globalFilter
                  ? 'No templates match your search criteria.'
                  : 'Create your first WhatsApp template to get started.'}
              </p>
              {globalFilter && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setGlobalFilter('')}
                  className="mt-4 border-border hover:bg-accent"
                >
                  Clear search
                </Button>
              )}
            </div>
          ) : loading && templates.length === 0 ? (
            /* Loading State */
            <div className="text-center py-12">
              <RefreshCw className="w-8 h-8 animate-spin text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">
                Loading templates...
              </h3>
              <p className="text-muted-foreground">
                Please wait while we fetch your templates.
              </p>
            </div>
          ) : (
            /* TanStack Table */
            <Table>
              <TableHeader>
                {table.getHeaderGroups().map((headerGroup) => (
                  <TableRow
                    key={headerGroup.id}
                    className="bg-muted/30 border-border"
                  >
                    {headerGroup.headers.map((header) => (
                      <TableHead key={header.id} className="py-4 px-6">
                        {header.isPlaceholder
                          ? null
                          : flexRender(
                              header.column.columnDef.header,
                              header.getContext()
                            )}
                      </TableHead>
                    ))}
                  </TableRow>
                ))}
              </TableHeader>
              <TableBody className="divide-y divide-border">
                {table.getRowModel().rows?.length ? (
                  table.getRowModel().rows.map((row) => (
                    <TableRow
                      key={row.id}
                      data-state={row.getIsSelected() && 'selected'}
                      className="hover:bg-muted/30 transition-all duration-200 border-border"
                    >
                      {row.getVisibleCells().map((cell) => (
                        <TableCell key={cell.id} className="py-4 px-6">
                          {flexRender(
                            cell.column.columnDef.cell,
                            cell.getContext()
                          )}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : (
                  <TableRow className="border-border">
                    <TableCell
                      colSpan={columns.length}
                      className="h-24 text-center"
                    >
                      <div className="flex flex-col items-center space-y-2">
                        <Search className="w-8 h-8 text-muted-foreground/50" />
                        <span className="text-muted-foreground">
                          No results found.
                        </span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setGlobalFilter('')}
                          className="border-border hover:bg-accent"
                        >
                          Clear search
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </div>

        {/* Pagination */}
        {templates.length > 0 && (
          <div className="flex items-center justify-between space-x-2 py-4 px-6 border-t border-border">
            <div className="flex items-center space-x-4">
              <div className="text-sm text-muted-foreground">
                {table.getFilteredRowModel().rows.length === templates.length
                  ? `${templates.length} template${
                      templates.length === 1 ? '' : 's'
                    } total`
                  : `${table.getFilteredRowModel().rows.length} of ${
                      templates.length
                    } template${templates.length === 1 ? '' : 's'}`}
              </div>
              {table.getState().sorting.length > 0 && (
                <Badge
                  variant="outline"
                  className="text-xs border-border bg-muted/50"
                >
                  Sorted by:{' '}
                  {table
                    .getState()
                    .sorting.map(
                      (sort) => `${sort.id} (${sort.desc ? 'desc' : 'asc'})`
                    )
                    .join(', ')}
                </Badge>
              )}
              {loading && (
                <Badge
                  variant="outline"
                  className="text-xs border-border bg-muted/50"
                >
                  <RefreshCw className="w-3 h-3 animate-spin mr-1" />
                  Refreshing...
                </Badge>
              )}
            </div>

            <div className="flex items-center space-x-2">
              <p className="text-sm font-medium text-foreground">
                Rows per page
              </p>
              <Select
                value={`${table.getState().pagination.pageSize}`}
                onValueChange={(value) => {
                  table.setPageSize(Number(value));
                }}
              >
                <SelectTrigger className="h-8 w-[70px] bg-background border-input">
                  <SelectValue
                    placeholder={table.getState().pagination.pageSize}
                  />
                </SelectTrigger>
                <SelectContent side="top" className="bg-popover border-border">
                  {[5, 10, 20, 30, 40, 50].map((pageSize) => (
                    <SelectItem
                      key={pageSize}
                      value={`${pageSize}`}
                      className="text-popover-foreground"
                    >
                      {pageSize}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center space-x-6 lg:space-x-8">
              <div className="flex items-center space-x-2">
                <p className="text-sm font-medium text-foreground">
                  Page {table.getState().pagination.pageIndex + 1} of{' '}
                  {table.getPageCount()}
                </p>
                <span className="text-sm text-muted-foreground">
                  ({table.getPrePaginationRowModel().rows.length} total rows)
                </span>
              </div>

              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  className="hidden h-8 w-8 p-0 lg:flex border-border hover:bg-accent"
                  onClick={() => table.setPageIndex(0)}
                  disabled={!table.getCanPreviousPage()}
                >
                  <span className="sr-only">Go to first page</span>
                  <ChevronsLeft className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  className="h-8 w-8 p-0 border-border hover:bg-accent"
                  onClick={() => table.previousPage()}
                  disabled={!table.getCanPreviousPage()}
                >
                  <span className="sr-only">Go to previous page</span>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  className="h-8 w-8 p-0 border-border hover:bg-accent"
                  onClick={() => table.nextPage()}
                  disabled={!table.getCanNextPage()}
                >
                  <span className="sr-only">Go to next page</span>
                  <ChevronRight className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  className="hidden h-8 w-8 p-0 lg:flex border-border hover:bg-accent"
                  onClick={() => table.setPageIndex(table.getPageCount() - 1)}
                  disabled={!table.getCanNextPage()}
                >
                  <span className="sr-only">Go to last page</span>
                  <ChevronsRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        )}
      </Card>

      {/* Template Preview Dialog */}
      <Dialog open={previewDialogOpen} onOpenChange={setPreviewDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-card border-border">
          <DialogHeader>
            <DialogTitle className="text-xl font-semibold text-foreground">
              Template Preview
            </DialogTitle>
            <DialogDescription className="text-muted-foreground">
              {selectedTemplate && (
                <>
                  Template:{' '}
                  <span className="font-medium text-foreground">
                    {selectedTemplate.name}
                  </span>{' '}
                  • Category:{' '}
                  <span className="font-medium text-foreground">
                    {selectedTemplate.category}
                  </span>{' '}
                  • Status:{' '}
                  <span className="font-medium text-foreground">
                    {selectedTemplate.status}
                  </span>
                </>
              )}
            </DialogDescription>
          </DialogHeader>

          {selectedTemplate && (
            <div className="mt-4">
              <WhatsAppTemplateViewer
                template={selectedTemplate}
                showExpandedView={true}
                className="max-w-none"
              />
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default TemplateTable;
