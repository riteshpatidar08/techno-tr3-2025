import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import sideImg from '@/assets/campaign.svg';
import {
  Radio,
  FileText,
 
  Calendar,
  LayoutDashboard,
  Tags,
  FileSpreadsheet,

  RadioTower,
 
  
} from 'lucide-react';

interface SidebarItem {
  icon: React.ElementType;
  label: string;
  path: string;
}

interface CampaignSidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const CampaignSidebar: React.FC<CampaignSidebarProps> = ({
  activeTab,
  setActiveTab,
}) => {
  const navigate = useNavigate();
  const location = useLocation();

  const sidebarItems: SidebarItem[] = [
    {
      icon: FileText,
      label: 'Template Library',
      path: '/campaigns/template-library',
    },
    {
      icon: Radio,
      label: 'Your Templates',
      path: '/campaigns/your-templates',
    },
    {
      icon: Tags,
      label: 'Send By Tags',
      path: '/campaigns/send-by-tags',
    },
    {
      icon: FileSpreadsheet,
      label: 'CSV Campaign',
      path: '/campaigns/csv-campaign',
    },
    {
      icon: Radio,
      label: 'Broadcast',
      path: '/campaigns/broadcast',
    },
    {
      icon: RadioTower,
      label: 'Campaign History',
      path: '/campaigns/campaigns-history',
    },
    {
      icon: Calendar,
      label: 'Scheduled Campaign',
      path: '/campaigns/scheduled-campaigns',
    },
    {
      icon: LayoutDashboard,
      label: 'Campaign Dashboard',
      path: '/campaigns/campaign-dashboard',
    },
  ];

  useEffect(() => {
    const currentPath = location.pathname;

    if (currentPath.startsWith('/campaigns/')) {
      const activeItem = sidebarItems.find((item) => item.path === currentPath);
      if (activeItem) {
        setActiveTab(activeItem.label);
      } else if (
        currentPath === '/campaigns' ||
        currentPath === '/campaigns/'
      ) {
        setActiveTab('Your Templates');
      }
    }
  }, [location.pathname, setActiveTab]);

  const handleItemClick = (item: SidebarItem) => {
    navigate(item.path);
    setActiveTab(item.label);
  };

  const isItemActive = (item: SidebarItem) => {
    return location.pathname === item.path;
  };

  return (
    <div className="w-64 fixed top-16 left-0 bg-white border-r border-gray-200 h-screen overflow-y-auto z-40">
      <div className="p-4">
        <div className="flex flex-col items-center space-y-3">
          <div className="w-full overflow-hidden flex items-center justify-center">
            <img
              src={sideImg}
              alt="Campaign Logo"
              className="w-full h-full object-cover"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
                const nextElement = e.currentTarget
                  .nextElementSibling as HTMLElement;
                if (nextElement) {
                  nextElement.style.display = 'flex';
                }
              }}
            />
            <Radio
              className="w-24 h-24 text-gray-400"
              style={{ display: 'none' }}
            />
          </div>
          <div className="text-center">
            <h2 className="text-lg font-semibold text-gray-900">
              Campaign Manager
            </h2>
            <p className="text-sm text-gray-600">Manage your campaigns</p>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-1">
        {sidebarItems.map((item) => {
          const Icon = item.icon;
          const isActive = isItemActive(item);

          return (
            <Button
              key={item.label}
              variant={isActive ? 'secondary' : 'ghost'}
              className={`w-full justify-start transition-all duration-200 ${
                isActive
                  ? 'bg-green-50 text-green-600 border-r-2 border-green-500'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
              }`}
              onClick={() => handleItemClick(item)}
            >
              <Icon className="w-4 h-4 mr-2" />
              <span className="flex-1 text-left">{item.label}</span>
            </Button>
          );
        })}
      </div>
    </div>
  );
};

export default CampaignSidebar;
