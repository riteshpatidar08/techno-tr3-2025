import React from 'react';
import SwaggerUI from 'swagger-ui-react';
import 'swagger-ui-react/swagger-ui.css';

const ApiDocs = () => {
  return (
    <div style={{ height: '100vh' }}>
      <SwaggerUI url="https://petstore.swagger.io/v2/swagger.json" />
    </div>
  );
};

export default ApiDocs;
