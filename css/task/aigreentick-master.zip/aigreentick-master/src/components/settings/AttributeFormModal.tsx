import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { ContactAttribute } from './types';

interface AttributeFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (attribute: Omit<ContactAttribute, 'id' | 'createdAt'>) => void;
  editingAttribute?: ContactAttribute | null;
  title: string;
  description: string;
}

export const AttributeFormModal: React.FC<AttributeFormModalProps> = ({
  isOpen,
  onClose,
  onSave,
  editingAttribute,
  title,
  description,
}) => {
  const [formData, setFormData] = useState({
    name: '',
    type: 'text' as const,
    required: false,
    defaultValue: '',
  });

  useEffect(() => {
    if (editingAttribute) {
      setFormData({
        name: editingAttribute.name,
        type: editingAttribute.type,
        required: editingAttribute.required,
        defaultValue: editingAttribute.defaultValue || '',
      });
    } else {
      setFormData({
        name: '',
        type: 'text',
        required: false,
        defaultValue: '',
      });
    }
  }, [editingAttribute, isOpen]);

  const handleSave = () => {
    if (!formData.name.trim()) return;
    onSave(formData);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="border-0 shadow-xl">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="attr-name">Attribute Name</Label>
            <Input
              id="attr-name"
              value={formData.name}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, name: e.target.value }))
              }
              placeholder="e.g., Lead Source, Priority"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="attr-type">Data Type</Label>
            <Select
              value={formData.type}
              onValueChange={(value: 'text' | 'number' | 'date' | 'boolean') =>
                setFormData((prev) => ({ ...prev, type: value }))
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="text">Text</SelectItem>
                <SelectItem value="number">Number</SelectItem>
                <SelectItem value="date">Date</SelectItem>
                <SelectItem value="boolean">Boolean</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="attr-default">Default Value (Optional)</Label>
            <Input
              id="attr-default"
              value={formData.defaultValue}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  defaultValue: e.target.value,
                }))
              }
              placeholder="Default value"
            />
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox
              id="attr-required"
              checked={formData.required}
              onCheckedChange={(checked) =>
                setFormData((prev) => ({ ...prev, required: Boolean(checked) }))
              }
            />
            <Label htmlFor="attr-required">Required field</Label>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave}>
            {editingAttribute ? 'Save Changes' : 'Create Attribute'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
