import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Building2, Phone, Mail, MapPin, Globe } from 'lucide-react';
import { BusinessProfile as BusinessProfileType } from './types';
import { ProfilePictureSection } from './ProfilePictureSection';

interface BusinessProfileProps {
  businessProfile: BusinessProfileType;
  isLoading: boolean;
  onUpdate: (updates: Partial<BusinessProfileType>) => void;
  onSave: () => void;
}

export const BusinessProfile: React.FC<BusinessProfileProps> = ({
  businessProfile,
  isLoading,
  onUpdate,
  onSave,
}) => {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 mb-2">
          Business Profile
        </h1>
        <p className="text-muted-foreground">
          Manage your business information and public profile settings.
        </p>
      </div>

      <ProfilePictureSection />

      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building2 className="w-5 h-5" />
            Business Information
          </CardTitle>
          <CardDescription>
            This information will be displayed in your WhatsApp Business
            profile.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <div className="relative">
                <Phone className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  id="phone"
                  value={businessProfile.phoneNumber}
                  onChange={(e) => onUpdate({ phoneNumber: e.target.value })}
                  className="pl-10"
                  placeholder="+1 (555) 000-0000"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Business Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  value={businessProfile.emailForBusinessContact}
                  onChange={(e) =>
                    onUpdate({ emailForBusinessContact: e.target.value })
                  }
                  className="pl-10"
                  placeholder="business@company.com"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="about">About</Label>
              <Input
                id="about"
                value={businessProfile.about}
                onChange={(e) => onUpdate({ about: e.target.value })}
                placeholder="Brief description of your business"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="industry">Business Industry</Label>
              <Select
                value={businessProfile.businessIndustry}
                onValueChange={(value) => onUpdate({ businessIndustry: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Professional Services">
                    Professional Services
                  </SelectItem>
                  <SelectItem value="Technology">Technology</SelectItem>
                  <SelectItem value="Healthcare">Healthcare</SelectItem>
                  <SelectItem value="Education">Education</SelectItem>
                  <SelectItem value="Retail">Retail</SelectItem>
                  <SelectItem value="Finance">Finance</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2 lg:col-span-2">
              <Label htmlFor="address">Business Address</Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  id="address"
                  value={businessProfile.businessAddress}
                  onChange={(e) =>
                    onUpdate({ businessAddress: e.target.value })
                  }
                  className="pl-10"
                  placeholder="123 Business St, Suite 100, City, State 12345"
                />
              </div>
            </div>

            <div className="space-y-2 lg:col-span-2">
              <Label htmlFor="description">Business Description</Label>
              <Input
                id="description"
                value={businessProfile.businessDescription}
                onChange={(e) =>
                  onUpdate({ businessDescription: e.target.value })
                }
                placeholder="Detailed description of your business and services"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="website1">Primary Website</Label>
              <div className="relative">
                <Globe className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  id="website1"
                  value={businessProfile.businessWebsite1}
                  onChange={(e) =>
                    onUpdate({ businessWebsite1: e.target.value })
                  }
                  className="pl-10"
                  placeholder="https://www.company.com"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="website2">Secondary Website</Label>
              <div className="relative">
                <Globe className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  id="website2"
                  value={businessProfile.businessWebsite2}
                  onChange={(e) =>
                    onUpdate({ businessWebsite2: e.target.value })
                  }
                  className="pl-10"
                  placeholder="https://docs.company.com"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button disabled={isLoading} onClick={onSave}>
          {isLoading ? 'Saving...' : 'Save Changes'}
        </Button>
      </div>
    </div>
  );
};
