import React, { useState, useCallback, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  User,
  Settings,
  Tag,
  Download,
  MessageSquare,
  Building2,
  Phone,
  Mail,
  Globe,
  MapPin,
  Clock,
  Languages,
  HelpCircle,
  ArrowRight,
  Search,
  Plus,
  Edit,
  Trash2,
  MoreHorizontal,
  ChevronLeft,
  ChevronRight,
  Save,
  X,
  Upload,
  Camera,
} from 'lucide-react';
interface BusinessProfile {
  id: string;
  name: string;
  profilePicture: string;
  phoneNumber: string;
  businessAddress: string;
  emailForBusinessContact: string;
  businessWebsite1: string;
  businessWebsite2: string;
  about: string;
  businessDescription: string;
  businessIndustry: string;
}

interface GeneralSettings {
  customerTimeZone: string;
  language: string;
  supportButtonEnabled: boolean;
  contentDirection: string;
  sendReportSchedule: string;
}

interface ContactAttribute {
  id: string;
  name: string;
  type: 'text' | 'number' | 'date' | 'boolean';
  required: boolean;
  defaultValue?: string;
  createdAt: string;
}

interface Tag {
  id: string;
  name: string;
  color: string;
  description?: string;
  usageCount: number;
  createdAt: string;
}
const routes = {
  'business-profile': 'Business Profile',
  general: 'General Settings',
  'tags-attributes': 'Tags & Attributes',
  'import-export': 'Import/Export',
  'message-deletion': 'Message Deletion',
} as const;

type RouteKey = keyof typeof routes;
const staticBusinessProfile: BusinessProfile = {
  id: '1',
  name: 'aiGreenTick',
  profilePicture: '',
  phoneNumber: '+14798024855',
  businessAddress: '123 Business St, Suite 100, Business City, BC 12345',
  emailForBusinessContact: 'support@wati.io',
  businessWebsite1: 'https://wati.io',
  businessWebsite2: 'https://docs.wati.io',
  about: 'WATI.io - WhatsApp Official API Partner',
  businessDescription: 'WATI Trial Sandbox for WhatsApp Business API',
  businessIndustry: 'Professional Services',
};

const staticGeneralSettings: GeneralSettings = {
  customerTimeZone:
    '(GMT+08:00) Beijing, Chongqing, Hong Kong, Urumqi, Kuala Lumpur, Singapore, Taipei, Perth, Irkutsk, Ulaanbaatar',
  language: 'English',
  supportButtonEnabled: false,
  contentDirection: 'Initial',
  sendReportSchedule: '',
};

const staticAttributes: ContactAttribute[] = [
  {
    id: '1',
    name: 'Channel',
    type: 'text',
    required: false,
    createdAt: '2024-01-15',
  },
  {
    id: '2',
    name: 'Source',
    type: 'text',
    required: false,
    createdAt: '2024-01-10',
  },
  {
    id: '3',
    name: 'type',
    type: 'text',
    required: false,
    createdAt: '2024-01-05',
  },
  {
    id: '4',
    name: 'Priority',
    type: 'text',
    required: true,
    defaultValue: 'Medium',
    createdAt: '2024-01-01',
  },
  {
    id: '5',
    name: 'Lead Score',
    type: 'number',
    required: false,
    createdAt: '2023-12-20',
  },
];

const staticTags: Tag[] = [
  {
    id: '1',
    name: 'VIP Customer',
    color: '#10b981',
    usageCount: 45,
    createdAt: '2024-01-15',
  },
  {
    id: '2',
    name: 'Lead',
    color: '#f59e0b',
    usageCount: 123,
    createdAt: '2024-01-10',
  },
  {
    id: '3',
    name: 'Support',
    color: '#ef4444',
    usageCount: 67,
    createdAt: '2024-01-05',
  },
  {
    id: '4',
    name: 'Newsletter',
    color: '#3b82f6',
    usageCount: 89,
    createdAt: '2024-01-01',
  },
];

const sidebarItems = [
  { id: 'business-profile', label: 'Business Profile', icon: Building2 },
  { id: 'general', label: 'General Settings', icon: Settings },
  { id: 'tags-attributes', label: 'Tags & Attributes', icon: Tag },
  { id: 'import-export', label: 'Import/Export', icon: Download },
  { id: 'message-deletion', label: 'Message Deletion', icon: MessageSquare },
];

const UserSettings: React.FC = () => {
  const [currentRoute, setCurrentRoute] =
    useState<RouteKey>('business-profile');
  const [businessProfile, setBusinessProfile] = useState<BusinessProfile>(
    staticBusinessProfile
  );
  const [generalSettings, setGeneralSettings] = useState<GeneralSettings>(
    staticGeneralSettings
  );
  const [attributes, setAttributes] =
    useState<ContactAttribute[]>(staticAttributes);
  const [tags, setTags] = useState<Tag[]>(staticTags);
  const [isLoading, setIsLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [attributeSearch, setAttributeSearch] = useState('');
  const [tagSearch, setTagSearch] = useState('');
  const [showAddAttribute, setShowAddAttribute] = useState(false);
  const [showAddTag, setShowAddTag] = useState(false);
  const [editingAttribute, setEditingAttribute] =
    useState<ContactAttribute | null>(null);
  const [editingTag, setEditingTag] = useState<Tag | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [newAttribute, setNewAttribute] = useState({
    name: '',
    type: 'text' as const,
    required: false,
    defaultValue: '',
  });

  const [newTag, setNewTag] = useState({
    name: '',
    color: '#3b82f6',
    description: '',
  });
  const updateBusinessProfile = useCallback(
    async (updatedProfile: Partial<BusinessProfile>) => {
      setIsLoading(true);
      try {
        setBusinessProfile((prev) => ({ ...prev, ...updatedProfile }));
        await new Promise((resolve) => setTimeout(resolve, 500));
      } finally {
        setIsLoading(false);
      }
    },
    []
  );

  const updateGeneralSettings = useCallback(
    async (updatedSettings: Partial<GeneralSettings>) => {
      setIsLoading(true);
      try {
        setGeneralSettings((prev) => ({ ...prev, ...updatedSettings }));
        await new Promise((resolve) => setTimeout(resolve, 500));
      } finally {
        setIsLoading(false);
      }
    },
    []
  );

  const createAttribute = useCallback(async () => {
    if (!newAttribute.name.trim()) return;

    const attribute: ContactAttribute = {
      id: Date.now().toString(),
      ...newAttribute,
      createdAt: new Date().toISOString().split('T')[0],
    };

    setAttributes((prev) => [...prev, attribute]);
    setNewAttribute({
      name: '',
      type: 'text',
      required: false,
      defaultValue: '',
    });
    setShowAddAttribute(false);
  }, [newAttribute]);

  const updateAttribute = useCallback(
    async (id: string, updates: Partial<ContactAttribute>) => {
      setAttributes((prev) =>
        prev.map((attr) => (attr.id === id ? { ...attr, ...updates } : attr))
      );
      setEditingAttribute(null);
    },
    []
  );

  const deleteAttribute = useCallback(async (id: string) => {
    setAttributes((prev) => prev.filter((attr) => attr.id !== id));
  }, []);

  const createTag = useCallback(async () => {
    if (!newTag.name.trim()) return;

    const tag: Tag = {
      id: Date.now().toString(),
      ...newTag,
      usageCount: 0,
      createdAt: new Date().toISOString().split('T')[0],
    };

    setTags((prev) => [...prev, tag]);
    setNewTag({ name: '', color: '#3b82f6', description: '' });
    setShowAddTag(false);
  }, [newTag]);

  const updateTag = useCallback(async (id: string, updates: Partial<Tag>) => {
    setTags((prev) =>
      prev.map((tag) => (tag.id === id ? { ...tag, ...updates } : tag))
    );
    setEditingTag(null);
  }, []);

  const deleteTag = useCallback(async (id: string) => {
    setTags((prev) => prev.filter((tag) => tag.id !== id));
  }, []);
  const filteredAttributes = useMemo(
    () =>
      attributes.filter((attr) =>
        attr.name.toLowerCase().includes(attributeSearch.toLowerCase())
      ),
    [attributes, attributeSearch]
  );

  const filteredTags = useMemo(
    () =>
      tags.filter((tag) =>
        tag.name.toLowerCase().includes(tagSearch.toLowerCase())
      ),
    [tags, tagSearch]
  );
  const paginatedAttributes = useMemo(() => {
    const start = (currentPage - 1) * rowsPerPage;
    return filteredAttributes.slice(start, start + rowsPerPage);
  }, [filteredAttributes, currentPage, rowsPerPage]);

  const totalPages = Math.ceil(filteredAttributes.length / rowsPerPage);
  const ProfilePictureSection = () => (
    <div className="mb-8">
      <Label className="text-sm font-medium mb-4 block">Profile Picture</Label>
      <div className="flex items-center space-x-6">
        <div className="relative group">
          <div className="w-24 h-24 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center shadow-lg">
            <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
              <MessageSquare className="w-5 h-5 text-green-600" />
            </div>
          </div>
          <div className="absolute inset-0 bg-black bg-opacity-50 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer">
            <Camera className="w-6 h-6 text-white" />
          </div>
        </div>
        <div className="flex-1">
          <div className="text-2xl font-bold text-gray-900 mb-2">wati</div>
          <p className="text-sm text-muted-foreground mb-4">
            Recommended: Square image, at least 256x256px
          </p>
          <Button
            variant="outline"
            className="text-green-600 border-green-600 hover:bg-green-50"
            onClick={() =>
              document.getElementById('profile-picture-input')?.click()
            }
          >
            <Upload className="w-4 h-4 mr-2" />
            Change Picture
          </Button>
          <input
            id="profile-picture-input"
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) {
                console.log('Uploading:', file);
              }
            }}
          />
        </div>
      </div>
    </div>
  );
  const BusinessProfileContent = () => (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 mb-2">
          Business Profile
        </h1>
        <p className="text-muted-foreground">
          Manage your business information and public profile settings.
        </p>
      </div>

      <ProfilePictureSection />

      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building2 className="w-5 h-5" />
            Business Information
          </CardTitle>
          <CardDescription>
            This information will be displayed in your WhatsApp Business
            profile.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <div className="relative">
                <Phone className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  id="phone"
                  value={businessProfile.phoneNumber}
                  onChange={(e) =>
                    updateBusinessProfile({ phoneNumber: e.target.value })
                  }
                  className="pl-10"
                  placeholder="+1 (555) 000-0000"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Business Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  value={businessProfile.emailForBusinessContact}
                  onChange={(e) =>
                    updateBusinessProfile({
                      emailForBusinessContact: e.target.value,
                    })
                  }
                  className="pl-10"
                  placeholder="business@company.com"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="about">About</Label>
              <Input
                id="about"
                value={businessProfile.about}
                onChange={(e) =>
                  updateBusinessProfile({ about: e.target.value })
                }
                placeholder="Brief description of your business"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="industry">Business Industry</Label>
              <Select
                value={businessProfile.businessIndustry}
                onValueChange={(value) =>
                  updateBusinessProfile({ businessIndustry: value })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Professional Services">
                    Professional Services
                  </SelectItem>
                  <SelectItem value="Technology">Technology</SelectItem>
                  <SelectItem value="Healthcare">Healthcare</SelectItem>
                  <SelectItem value="Education">Education</SelectItem>
                  <SelectItem value="Retail">Retail</SelectItem>
                  <SelectItem value="Finance">Finance</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2 lg:col-span-2">
              <Label htmlFor="address">Business Address</Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  id="address"
                  value={businessProfile.businessAddress}
                  onChange={(e) =>
                    updateBusinessProfile({ businessAddress: e.target.value })
                  }
                  className="pl-10"
                  placeholder="123 Business St, Suite 100, City, State 12345"
                />
              </div>
            </div>

            <div className="space-y-2 lg:col-span-2">
              <Label htmlFor="description">Business Description</Label>
              <Input
                id="description"
                value={businessProfile.businessDescription}
                onChange={(e) =>
                  updateBusinessProfile({ businessDescription: e.target.value })
                }
                placeholder="Detailed description of your business and services"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="website1">Primary Website</Label>
              <div className="relative">
                <Globe className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  id="website1"
                  value={businessProfile.businessWebsite1}
                  onChange={(e) =>
                    updateBusinessProfile({ businessWebsite1: e.target.value })
                  }
                  className="pl-10"
                  placeholder="https://www.company.com"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="website2">Secondary Website</Label>
              <div className="relative">
                <Globe className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  id="website2"
                  value={businessProfile.businessWebsite2}
                  onChange={(e) =>
                    updateBusinessProfile({ businessWebsite2: e.target.value })
                  }
                  className="pl-10"
                  placeholder="https://docs.company.com"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button
          disabled={isLoading}
          onClick={() => console.log('Saving profile...')}
        >
          {isLoading ? 'Saving...' : 'Save Changes'}
        </Button>
      </div>
    </div>
  );
  const GeneralSettingsContent = () => (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 mb-2">
          General Settings
        </h1>
        <p className="text-muted-foreground">
          Configure your account preferences and system settings.
        </p>
      </div>

      <ProfilePictureSection />

      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Reports & Scheduling
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <p className="font-medium">Send Report Schedule</p>
              <p className="text-sm text-muted-foreground">
                Configure automated report delivery
              </p>
            </div>
            <Button className="bg-green-600 hover:bg-green-700">
              Create Schedule
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            System Preferences
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="timezone">Customer TimeZone</Label>
            <Select
              value={generalSettings.customerTimeZone}
              onValueChange={(value) =>
                updateGeneralSettings({ customerTimeZone: value })
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="(GMT+08:00) Beijing, Chongqing, Hong Kong, Urumqi, Kuala Lumpur, Singapore, Taipei, Perth, Irkutsk, Ulaanbaatar">
                  (GMT+08:00) Asia/Singapore
                </SelectItem>
                <SelectItem value="(GMT+00:00) Greenwich Mean Time">
                  (GMT+00:00) UTC
                </SelectItem>
                <SelectItem value="(GMT-05:00) Eastern Standard Time">
                  (GMT-05:00) America/New_York
                </SelectItem>
                <SelectItem value="(GMT+05:30) India Standard Time">
                  (GMT+05:30) Asia/Kolkata
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="language">
                Language <span className="text-red-500">*</span>
              </Label>
              <div className="relative">
                <Languages className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Select
                  value={generalSettings.language}
                  onValueChange={(value) =>
                    updateGeneralSettings({ language: value })
                  }
                >
                  <SelectTrigger className="pl-10">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="English">English</SelectItem>
                    <SelectItem value="Spanish">Español</SelectItem>
                    <SelectItem value="French">Français</SelectItem>
                    <SelectItem value="German">Deutsch</SelectItem>
                    <SelectItem value="Chinese">中文</SelectItem>
                    <SelectItem value="Japanese">日本語</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="support-button">
                Support Button <span className="text-red-500">*</span>
              </Label>
              <Select
                value={generalSettings.supportButtonEnabled ? 'Yes' : 'No'}
                onValueChange={(value) =>
                  updateGeneralSettings({
                    supportButtonEnabled: value === 'Yes',
                  })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Yes">Enabled</SelectItem>
                  <SelectItem value="No">Disabled</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="content-direction">
                Content Direction <span className="text-red-500">*</span>
              </Label>
              <Select
                value={generalSettings.contentDirection}
                onValueChange={(value) =>
                  updateGeneralSettings({ contentDirection: value })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Initial">Auto-detect</SelectItem>
                  <SelectItem value="LTR">Left to Right</SelectItem>
                  <SelectItem value="RTL">Right to Left</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button disabled={isLoading}>
          {isLoading ? 'Saving...' : 'Save Settings'}
        </Button>
      </div>
    </div>
  );
  const EditAttributeDialog = ({
    attribute,
    onClose,
  }: {
    attribute: ContactAttribute;
    onClose: () => void;
  }) => {
    const [editForm, setEditForm] = useState({
      name: attribute.name,
      type: attribute.type,
      required: attribute.required,
      defaultValue: attribute.defaultValue || '',
    });

    const handleSave = () => {
      updateAttribute(attribute.id, editForm);
      onClose();
    };

    return (
      <DialogContent className="border-0 shadow-xl">
        <DialogHeader>
          <DialogTitle>Edit Attribute</DialogTitle>
          <DialogDescription>
            Modify the contact attribute details.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="edit-attr-name">Attribute Name</Label>
            <Input
              id="edit-attr-name"
              value={editForm.name}
              onChange={(e) =>
                setEditForm((prev) => ({ ...prev, name: e.target.value }))
              }
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="edit-attr-type">Data Type</Label>
            <Select
              value={editForm.type}
              onValueChange={(value: 'text' | 'number' | 'date' | 'boolean') =>
                setEditForm((prev) => ({ ...prev, type: value }))
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="text">Text</SelectItem>
                <SelectItem value="number">Number</SelectItem>
                <SelectItem value="date">Date</SelectItem>
                <SelectItem value="boolean">Boolean</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="edit-attr-default">Default Value</Label>
            <Input
              id="edit-attr-default"
              value={editForm.defaultValue}
              onChange={(e) =>
                setEditForm((prev) => ({
                  ...prev,
                  defaultValue: e.target.value,
                }))
              }
            />
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox
              id="edit-attr-required"
              checked={editForm.required}
              onCheckedChange={(checked) =>
                setEditForm((prev) => ({ ...prev, required: Boolean(checked) }))
              }
            />
            <Label htmlFor="edit-attr-required">Required field</Label>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave}>Save Changes</Button>
        </DialogFooter>
      </DialogContent>
    );
  };
  const EditTagDialog = ({
    tag,
    onClose,
  }: {
    tag: Tag;
    onClose: () => void;
  }) => {
    const [editForm, setEditForm] = useState({
      name: tag.name,
      color: tag.color,
      description: tag.description || '',
    });

    const handleSave = () => {
      updateTag(tag.id, editForm);
      onClose();
    };

    return (
      <DialogContent className="border-0 shadow-xl">
        <DialogHeader>
          <DialogTitle>Edit Tag</DialogTitle>
          <DialogDescription>Modify the tag details.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="edit-tag-name">Tag Name</Label>
            <Input
              id="edit-tag-name"
              value={editForm.name}
              onChange={(e) =>
                setEditForm((prev) => ({ ...prev, name: e.target.value }))
              }
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="edit-tag-color">Color</Label>
            <div className="flex items-center space-x-2">
              <input
                id="edit-tag-color"
                type="color"
                value={editForm.color}
                onChange={(e) =>
                  setEditForm((prev) => ({ ...prev, color: e.target.value }))
                }
                className="w-12 h-10 rounded border"
              />
              <Input
                value={editForm.color}
                onChange={(e) =>
                  setEditForm((prev) => ({ ...prev, color: e.target.value }))
                }
                placeholder="#3b82f6"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="edit-tag-description">Description</Label>
            <Input
              id="edit-tag-description"
              value={editForm.description}
              onChange={(e) =>
                setEditForm((prev) => ({
                  ...prev,
                  description: e.target.value,
                }))
              }
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave}>Save Changes</Button>
        </DialogFooter>
      </DialogContent>
    );
  };
  const TagsAttributesContent = () => (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 mb-2">
          Tags & Attributes
        </h1>
        <p className="text-muted-foreground">
          Manage contact attributes and tags for better organization and
          segmentation.
        </p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Contact Attributes</CardTitle>
                <CardDescription>
                  Custom fields to store additional contact information
                </CardDescription>
              </div>
              <Dialog
                open={showAddAttribute}
                onOpenChange={setShowAddAttribute}
              >
                <DialogTrigger asChild>
                  <Button size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Attribute
                  </Button>
                </DialogTrigger>
                <DialogContent className="border-0 shadow-xl">
                  <DialogHeader>
                    <DialogTitle>Create Contact Attribute</DialogTitle>
                    <DialogDescription>
                      Add a new custom field for storing contact information.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="attr-name">Attribute Name</Label>
                      <Input
                        id="attr-name"
                        value={newAttribute.name}
                        onChange={(e) =>
                          setNewAttribute((prev) => ({
                            ...prev,
                            name: e.target.value,
                          }))
                        }
                        placeholder="e.g., Lead Source, Priority"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="attr-type">Data Type</Label>
                      <Select
                        value={newAttribute.type}
                        onValueChange={(
                          value: 'text' | 'number' | 'date' | 'boolean'
                        ) =>
                          setNewAttribute((prev) => ({ ...prev, type: value }))
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="text">Text</SelectItem>
                          <SelectItem value="number">Number</SelectItem>
                          <SelectItem value="date">Date</SelectItem>
                          <SelectItem value="boolean">Boolean</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="attr-default">
                        Default Value (Optional)
                      </Label>
                      <Input
                        id="attr-default"
                        value={newAttribute.defaultValue}
                        onChange={(e) =>
                          setNewAttribute((prev) => ({
                            ...prev,
                            defaultValue: e.target.value,
                          }))
                        }
                        placeholder="Default value"
                      />
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="attr-required"
                        checked={newAttribute.required}
                        onCheckedChange={(checked) =>
                          setNewAttribute((prev) => ({
                            ...prev,
                            required: Boolean(checked),
                          }))
                        }
                      />
                      <Label htmlFor="attr-required">Required field</Label>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button
                      variant="outline"
                      onClick={() => setShowAddAttribute(false)}
                    >
                      Cancel
                    </Button>
                    <Button onClick={createAttribute}>Create Attribute</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search or add..."
                  value={attributeSearch}
                  onChange={(e) => setAttributeSearch(e.target.value)}
                  className="pl-10"
                />
              </div>

              <div className="rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow className="border-b">
                      <TableHead>Attribute name</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedAttributes.map((attribute) => (
                      <TableRow
                        key={attribute.id}
                        className="border-b border-gray-100"
                      >
                        <TableCell className="font-medium">
                          {attribute.name}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end space-x-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setEditingAttribute(attribute)}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => deleteAttribute(attribute.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-muted-foreground">
                    Rows per page:
                  </span>
                  <Select
                    value={rowsPerPage.toString()}
                    onValueChange={(value) => {
                      setRowsPerPage(Number(value));
                      setCurrentPage(1);
                    }}
                  >
                    <SelectTrigger className="w-16">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">5</SelectItem>
                      <SelectItem value="10">10</SelectItem>
                      <SelectItem value="20">20</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center space-x-4">
                  <span className="text-sm text-muted-foreground">
                    {(currentPage - 1) * rowsPerPage + 1}-
                    {Math.min(
                      currentPage * rowsPerPage,
                      filteredAttributes.length
                    )}{' '}
                    of {filteredAttributes.length}
                  </span>

                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() =>
                        setCurrentPage((prev) => Math.max(1, prev - 1))
                      }
                      disabled={currentPage === 1}
                    >
                      <ChevronLeft className="w-4 h-4" />
                      Previous
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() =>
                        setCurrentPage((prev) => Math.min(totalPages, prev + 1))
                      }
                      disabled={currentPage === totalPages}
                    >
                      Next
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Tags</CardTitle>
                <CardDescription>
                  Organize and categorize your contacts with custom tags
                </CardDescription>
              </div>
              <Dialog open={showAddTag} onOpenChange={setShowAddTag}>
                <DialogTrigger asChild>
                  <Button size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Tags
                  </Button>
                </DialogTrigger>
                <DialogContent className="border-0 shadow-xl">
                  <DialogHeader>
                    <DialogTitle>Create Tag</DialogTitle>
                    <DialogDescription>
                      Add a new tag for organizing contacts.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="tag-name">Tag Name</Label>
                      <Input
                        id="tag-name"
                        value={newTag.name}
                        onChange={(e) =>
                          setNewTag((prev) => ({
                            ...prev,
                            name: e.target.value,
                          }))
                        }
                        placeholder="e.g., VIP Customer, Lead"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="tag-color">Color</Label>
                      <div className="flex items-center space-x-2">
                        <input
                          id="tag-color"
                          type="color"
                          value={newTag.color}
                          onChange={(e) =>
                            setNewTag((prev) => ({
                              ...prev,
                              color: e.target.value,
                            }))
                          }
                          className="w-12 h-10 rounded border"
                        />
                        <Input
                          value={newTag.color}
                          onChange={(e) =>
                            setNewTag((prev) => ({
                              ...prev,
                              color: e.target.value,
                            }))
                          }
                          placeholder="#3b82f6"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="tag-description">
                        Description (Optional)
                      </Label>
                      <Input
                        id="tag-description"
                        value={newTag.description}
                        onChange={(e) =>
                          setNewTag((prev) => ({
                            ...prev,
                            description: e.target.value,
                          }))
                        }
                        placeholder="Brief description of this tag"
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button
                      variant="outline"
                      onClick={() => setShowAddTag(false)}
                    >
                      Cancel
                    </Button>
                    <Button onClick={createTag}>Create Tag</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search or add..."
                  value={tagSearch}
                  onChange={(e) => setTagSearch(e.target.value)}
                  className="pl-10"
                />
              </div>

              <div className="rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow className="border-b">
                      <TableHead>Tag name</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredTags.map((tag) => (
                      <TableRow
                        key={tag.id}
                        className="border-b border-gray-100"
                      >
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <div
                              className="w-3 h-3 rounded-full"
                              style={{ backgroundColor: tag.color }}
                            />
                            <span className="font-medium">{tag.name}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end space-x-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setEditingTag(tag)}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => deleteTag(tag.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-muted-foreground">
                    Rows per page:
                  </span>
                  <Select value="5">
                    <SelectTrigger className="w-16">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">5</SelectItem>
                      <SelectItem value="10">10</SelectItem>
                      <SelectItem value="20">20</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center space-x-4">
                  <span className="text-sm text-muted-foreground">
                    1-{Math.min(5, filteredTags.length)} of{' '}
                    {filteredTags.length}
                  </span>

                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm" disabled>
                      <ChevronLeft className="w-4 h-4" />
                      Previous
                    </Button>
                    <Button variant="outline" size="sm" disabled>
                      Next
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
  const ImportExportContent = () => (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 mb-2">
          Import/Export Chats
        </h1>
        <p className="text-muted-foreground">
          Import and export your chat history and conversation data.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Download className="w-5 h-5" />
              Export Chats
            </CardTitle>
            <CardDescription>
              Download your chat history in various formats
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Export Format</Label>
              <Select defaultValue="csv">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="csv">CSV Format</SelectItem>
                  <SelectItem value="json">JSON Format</SelectItem>
                  <SelectItem value="xlsx">Excel Format</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Date Range</Label>
              <div className="grid grid-cols-2 gap-2">
                <Input type="date" placeholder="From" />
                <Input type="date" placeholder="To" />
              </div>
            </div>
            <Button className="w-full">
              <Download className="w-4 h-4 mr-2" />
              Export Chats
            </Button>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="w-5 h-5" />
              Import Chats
            </CardTitle>
            <CardDescription>
              Upload chat history from external sources
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-6 text-center">
              <Upload className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-sm text-muted-foreground mb-2">
                Drag and drop your file here, or click to browse
              </p>
              <Button variant="outline" size="sm">
                Choose File
              </Button>
            </div>
            <div className="text-xs text-muted-foreground">
              Supported formats: CSV, JSON, XLSX (Max size: 10MB)
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  const MessageDeletionContent = () => (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 mb-2">
          Message Deletion
        </h1>
        <p className="text-muted-foreground">
          Configure automatic message deletion policies and manage message
          retention.
        </p>
      </div>

      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5" />
            Auto-Delete Settings
          </CardTitle>
          <CardDescription>
            Automatically delete messages after specified time periods
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <p className="font-medium">Enable Auto-Delete</p>
              <p className="text-sm text-muted-foreground">
                Automatically delete messages older than specified period
              </p>
            </div>
            <Checkbox />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Delete Messages After</Label>
              <Select defaultValue="90">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="30">30 days</SelectItem>
                  <SelectItem value="60">60 days</SelectItem>
                  <SelectItem value="90">90 days</SelectItem>
                  <SelectItem value="180">6 months</SelectItem>
                  <SelectItem value="365">1 year</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Backup Before Delete</Label>
              <Select defaultValue="yes">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="yes">Yes, create backup</SelectItem>
                  <SelectItem value="no">No backup needed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
  const Sidebar = () => (
    <div className="w-64 bg-white border-r border-gray-200 min-h-screen">
      <div className="p-4">
        <div className="flex flex-col items-center space-y-3">
          <div className="w-full overflow-hidden flex items-center justify-center">
            <div className="w-24 h-24 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center shadow-lg">
              <Settings className="w-8 h-8 text-white" />
            </div>
          </div>
          <div className="text-center">
            <h2 className="text-lg font-semibold text-gray-900">
              Settings Manager
            </h2>
            <p className="text-sm text-gray-600">Manage your settings</p>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-1">
        {sidebarItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentRoute === item.id;

          return (
            <Button
              key={item.id}
              variant={isActive ? 'secondary' : 'ghost'}
              className={`w-full justify-start transition-all duration-200 ${
                isActive
                  ? 'bg-green-50 text-green-600 border-r-2 border-green-500'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
              }`}
              onClick={() => setCurrentRoute(item.id as RouteKey)}
            >
              <Icon className="w-4 h-4 mr-2" />
              <span className="flex-1 text-left">{item.label}</span>
            </Button>
          );
        })}
      </div>
    </div>
  );
  const renderContent = () => {
    switch (currentRoute) {
      case 'business-profile':
        return <BusinessProfileContent />;
      case 'general':
        return <GeneralSettingsContent />;
      case 'tags-attributes':
        return <TagsAttributesContent />;
      case 'import-export':
        return <ImportExportContent />;
      case 'message-deletion':
        return <MessageDeletionContent />;
      default:
        return <BusinessProfileContent />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex">
        <Sidebar />

        <div className="flex-1">
          <div className="p-8 max-w-6xl mx-auto">{renderContent()}</div>
        </div>
      </div>

      {editingAttribute && (
        <Dialog
          open={!!editingAttribute}
          onOpenChange={() => setEditingAttribute(null)}
        >
          <EditAttributeDialog
            attribute={editingAttribute}
            onClose={() => setEditingAttribute(null)}
          />
        </Dialog>
      )}

      {editingTag && (
        <Dialog open={!!editingTag} onOpenChange={() => setEditingTag(null)}>
          <EditTagDialog tag={editingTag} onClose={() => setEditingTag(null)} />
        </Dialog>
      )}
    </div>
  );
};

export default UserSettings;
