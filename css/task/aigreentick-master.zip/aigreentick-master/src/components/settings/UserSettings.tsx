import React, { useState, useCallback } from 'react';
import {
  RouteKey,
  BusinessProfile as BusinessProfileType,
  GeneralSettings as GeneralSettingsType,
  ContactAttribute,
  Tag,
} from './types';
import {
  staticBusinessProfile,
  staticGeneralSettings,
  staticAttributes,
  staticTags,
} from './constants';
import { Sidebar } from './Sidebar';
import { BusinessProfile } from './BusinessProfile';
import { GeneralSettings } from './GeneralSettings';
import { TagsAttributes } from './TagsAttributes';
import { ImportExport } from './ImportExport';
import { MessageDeletion } from './MessageDeletion';

const UserSettings: React.FC = () => {
  const [currentRoute, setCurrentRoute] =
    useState<RouteKey>('business-profile');
  const [businessProfile, setBusinessProfile] = useState<BusinessProfileType>(
    staticBusinessProfile
  );
  const [generalSettings, setGeneralSettings] = useState<GeneralSettingsType>(
    staticGeneralSettings
  );
  const [attributes, setAttributes] =
    useState<ContactAttribute[]>(staticAttributes);
  const [tags, setTags] = useState<Tag[]>(staticTags);
  const [isLoading, setIsLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const updateBusinessProfile = useCallback(
    async (updatedProfile: Partial<BusinessProfileType>) => {
      setIsLoading(true);
      try {
        setBusinessProfile((prev) => ({ ...prev, ...updatedProfile }));
        await new Promise((resolve) => setTimeout(resolve, 500));
      } finally {
        setIsLoading(false);
      }
    },
    []
  );

  const updateGeneralSettings = useCallback(
    async (updatedSettings: Partial<GeneralSettingsType>) => {
      setIsLoading(true);
      try {
        setGeneralSettings((prev) => ({ ...prev, ...updatedSettings }));
        await new Promise((resolve) => setTimeout(resolve, 500));
      } finally {
        setIsLoading(false);
      }
    },
    []
  );

  const createAttribute = useCallback(
    async (newAttribute: Omit<ContactAttribute, 'id' | 'createdAt'>) => {
      const attribute: ContactAttribute = {
        id: Date.now().toString(),
        ...newAttribute,
        createdAt: new Date().toISOString().split('T')[0],
      };
      setAttributes((prev) => [...prev, attribute]);
    },
    []
  );

  const updateAttribute = useCallback(
    async (id: string, updates: Partial<ContactAttribute>) => {
      setAttributes((prev) =>
        prev.map((attr) => (attr.id === id ? { ...attr, ...updates } : attr))
      );
    },
    []
  );

  const deleteAttribute = useCallback(async (id: string) => {
    setAttributes((prev) => prev.filter((attr) => attr.id !== id));
  }, []);

  const createTag = useCallback(
    async (newTag: Omit<Tag, 'id' | 'createdAt' | 'usageCount'>) => {
      const tag: Tag = {
        id: Date.now().toString(),
        ...newTag,
        usageCount: 0,
        createdAt: new Date().toISOString().split('T')[0],
      };
      setTags((prev) => [...prev, tag]);
    },
    []
  );

  const updateTag = useCallback(async (id: string, updates: Partial<Tag>) => {
    setTags((prev) =>
      prev.map((tag) => (tag.id === id ? { ...tag, ...updates } : tag))
    );
  }, []);

  const deleteTag = useCallback(async (id: string) => {
    setTags((prev) => prev.filter((tag) => tag.id !== id));
  }, []);
  const renderContent = () => {
    switch (currentRoute) {
      case 'business-profile':
        return (
          <BusinessProfile
            businessProfile={businessProfile}
            isLoading={isLoading}
            onUpdate={updateBusinessProfile}
            onSave={() => console.log('Saving profile...')}
          />
        );
      case 'general':
        return (
          <GeneralSettings
            generalSettings={generalSettings}
            isLoading={isLoading}
            onUpdate={updateGeneralSettings}
            onSave={() => console.log('Saving settings...')}
          />
        );
      case 'tags-attributes':
        return (
          <TagsAttributes
            attributes={attributes}
            tags={tags}
            currentPage={currentPage}
            rowsPerPage={rowsPerPage}
            onPageChange={setCurrentPage}
            onRowsPerPageChange={setRowsPerPage}
            onCreateAttribute={createAttribute}
            onUpdateAttribute={updateAttribute}
            onDeleteAttribute={deleteAttribute}
            onCreateTag={createTag}
            onUpdateTag={updateTag}
            onDeleteTag={deleteTag}
          />
        );
      case 'import-export':
        return <ImportExport />;
      case 'message-deletion':
        return <MessageDeletion />;
      default:
        return (
          <BusinessProfile
            businessProfile={businessProfile}
            isLoading={isLoading}
            onUpdate={updateBusinessProfile}
            onSave={() => console.log('Saving profile...')}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex">
        <Sidebar currentRoute={currentRoute} onRouteChange={setCurrentRoute} />

        <div className="flex-1">
          <div className="p-8 max-w-6xl mx-auto">{renderContent()}</div>
        </div>
      </div>
    </div>
  );
};

export default UserSettings;
