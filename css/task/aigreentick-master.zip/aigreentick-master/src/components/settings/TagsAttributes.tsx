import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Search, Plus, Edit, Trash2 } from 'lucide-react';
import { ContactAttribute, Tag } from './types';
import { Pagination } from './Pagination';
import { AttributeFormModal } from './AttributeFormModal';
import { TagFormModal } from './TagFormModal';

interface TagsAttributesProps {
  attributes: ContactAttribute[];
  tags: Tag[];
  currentPage: number;
  rowsPerPage: number;
  onPageChange: (page: number) => void;
  onRowsPerPageChange: (rows: number) => void;
  onCreateAttribute: (
    attribute: Omit<ContactAttribute, 'id' | 'createdAt'>
  ) => void;
  onUpdateAttribute: (id: string, updates: Partial<ContactAttribute>) => void;
  onDeleteAttribute: (id: string) => void;
  onCreateTag: (tag: Omit<Tag, 'id' | 'createdAt' | 'usageCount'>) => void;
  onUpdateTag: (id: string, updates: Partial<Tag>) => void;
  onDeleteTag: (id: string) => void;
}

export const TagsAttributes: React.FC<TagsAttributesProps> = ({
  attributes,
  tags,
  currentPage,
  rowsPerPage,
  onPageChange,
  onRowsPerPageChange,
  onCreateAttribute,
  onUpdateAttribute,
  onDeleteAttribute,
  onCreateTag,
  onUpdateTag,
  onDeleteTag,
}) => {
  const [attributeSearch, setAttributeSearch] = useState('');
  const [tagSearch, setTagSearch] = useState('');
  const [showAddAttribute, setShowAddAttribute] = useState(false);
  const [showAddTag, setShowAddTag] = useState(false);
  const [editingAttribute, setEditingAttribute] =
    useState<ContactAttribute | null>(null);
  const [editingTag, setEditingTag] = useState<Tag | null>(null);

  const filteredAttributes = attributes.filter((attr) =>
    attr.name.toLowerCase().includes(attributeSearch.toLowerCase())
  );

  const filteredTags = tags.filter((tag) =>
    tag.name.toLowerCase().includes(tagSearch.toLowerCase())
  );

  const paginatedAttributes = filteredAttributes.slice(
    (currentPage - 1) * rowsPerPage,
    currentPage * rowsPerPage
  );

  const totalPages = Math.ceil(filteredAttributes.length / rowsPerPage);

  const handleCreateAttribute = (
    attribute: Omit<ContactAttribute, 'id' | 'createdAt'>
  ) => {
    onCreateAttribute(attribute);
    setShowAddAttribute(false);
  };

  const handleUpdateAttribute = (
    attribute: Omit<ContactAttribute, 'id' | 'createdAt'>
  ) => {
    if (editingAttribute) {
      onUpdateAttribute(editingAttribute.id, attribute);
      setEditingAttribute(null);
    }
  };

  const handleCreateTag = (
    tag: Omit<Tag, 'id' | 'createdAt' | 'usageCount'>
  ) => {
    onCreateTag(tag);
    setShowAddTag(false);
  };

  const handleUpdateTag = (
    tag: Omit<Tag, 'id' | 'createdAt' | 'usageCount'>
  ) => {
    if (editingTag) {
      onUpdateTag(editingTag.id, tag);
      setEditingTag(null);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 mb-2">
          Tags & Attributes
        </h1>
        <p className="text-muted-foreground">
          Manage contact attributes and tags for better organization and
          segmentation.
        </p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Contact Attributes</CardTitle>
                <CardDescription>
                  Custom fields to store additional contact information
                </CardDescription>
              </div>
              <Button size="sm" onClick={() => setShowAddAttribute(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add Attribute
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search or add..."
                  value={attributeSearch}
                  onChange={(e) => setAttributeSearch(e.target.value)}
                  className="pl-10"
                />
              </div>

              <div className="rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow className="border-b">
                      <TableHead>Attribute name</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedAttributes.map((attribute) => (
                      <TableRow
                        key={attribute.id}
                        className="border-b border-gray-100"
                      >
                        <TableCell className="font-medium">
                          {attribute.name}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end space-x-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setEditingAttribute(attribute)}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => onDeleteAttribute(attribute.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                rowsPerPage={rowsPerPage}
                totalItems={filteredAttributes.length}
                onPageChange={onPageChange}
                onRowsPerPageChange={onRowsPerPageChange}
              />
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Tags</CardTitle>
                <CardDescription>
                  Organize and categorize your contacts with custom tags
                </CardDescription>
              </div>
              <Button size="sm" onClick={() => setShowAddTag(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add Tags
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search or add..."
                  value={tagSearch}
                  onChange={(e) => setTagSearch(e.target.value)}
                  className="pl-10"
                />
              </div>

              <div className="rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow className="border-b">
                      <TableHead>Tag name</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredTags.map((tag) => (
                      <TableRow
                        key={tag.id}
                        className="border-b border-gray-100"
                      >
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <div
                              className="w-3 h-3 rounded-full"
                              style={{ backgroundColor: tag.color }}
                            />
                            <span className="font-medium">{tag.name}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end space-x-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setEditingTag(tag)}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => onDeleteTag(tag.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-muted-foreground">
                    Rows per page:
                  </span>
                  <span className="text-sm">5</span>
                </div>
                <div className="flex items-center space-x-4">
                  <span className="text-sm text-muted-foreground">
                    1-{Math.min(5, filteredTags.length)} of{' '}
                    {filteredTags.length}
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <AttributeFormModal
        isOpen={showAddAttribute}
        onClose={() => setShowAddAttribute(false)}
        onSave={handleCreateAttribute}
        title="Create Contact Attribute"
        description="Add a new custom field for storing contact information."
      />

      <AttributeFormModal
        isOpen={!!editingAttribute}
        onClose={() => setEditingAttribute(null)}
        onSave={handleUpdateAttribute}
        editingAttribute={editingAttribute}
        title="Edit Attribute"
        description="Modify the contact attribute details."
      />

      <TagFormModal
        isOpen={showAddTag}
        onClose={() => setShowAddTag(false)}
        onSave={handleCreateTag}
        title="Create Tag"
        description="Add a new tag for organizing contacts."
      />

      <TagFormModal
        isOpen={!!editingTag}
        onClose={() => setEditingTag(null)}
        onSave={handleUpdateTag}
        editingTag={editingTag}
        title="Edit Tag"
        description="Modify the tag details."
      />
    </div>
  );
};
