import React from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { MessageSquare, Upload, Camera } from 'lucide-react';

export const ProfilePictureSection: React.FC = () => {
  return (
    <div className="mb-8">
      <Label className="text-sm font-medium mb-4 block">Profile Picture</Label>
      <div className="flex items-center space-x-6">
        <div className="relative group">
          <div className="w-24 h-24 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center shadow-lg">
            <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
              <MessageSquare className="w-5 h-5 text-green-600" />
            </div>
          </div>
          <div className="absolute inset-0 bg-black bg-opacity-50 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer">
            <Camera className="w-6 h-6 text-white" />
          </div>
        </div>
        <div className="flex-1">
          <div className="text-2xl font-bold text-gray-900 mb-2">
            Ai Green Tick
          </div>
          <p className="text-sm text-muted-foreground mb-4">
            Recommended: Square image, at least 256x256px
          </p>
          <Button
            variant="outline"
            className="text-green-600 border-green-600 hover:bg-green-50"
            onClick={() =>
              document.getElementById('profile-picture-input')?.click()
            }
          >
            <Upload className="w-4 h-4 mr-2" />
            Change Picture
          </Button>
          <input
            id="profile-picture-input"
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) {
                console.log('Uploading:', file);
              }
            }}
          />
        </div>
      </div>
    </div>
  );
};
