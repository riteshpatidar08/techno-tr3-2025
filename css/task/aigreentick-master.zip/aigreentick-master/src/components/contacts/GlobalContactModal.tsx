import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { X, Plus } from 'lucide-react';
import { GlobalContactFormData } from './types';
import 'react-phone-number-input/style.css';
import PhoneInput from 'react-phone-number-input';

interface GlobalContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (contact: GlobalContactFormData) => void;
}

export const GlobalContactModal: React.FC<GlobalContactModalProps> = ({
  isOpen,
  onClose,
  onSave,
}) => {
  const [globalContactForm, setGlobalContactForm] =
    useState<GlobalContactFormData>({
      name: '',
      mobile: '',
      attributes: [],
    });

  const handleGlobalContactFormChange = (
    field: keyof Omit<GlobalContactFormData, 'attributes'>,
    value: string
  ) => {
    setGlobalContactForm((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const addCustomAttribute = () => {
    setGlobalContactForm((prev) => ({
      ...prev,
      attributes: [...prev.attributes, { key: '', value: '' }],
    }));
  };

  const updateCustomAttribute = (
    index: number,
    field: 'key' | 'value',
    value: string
  ) => {
    setGlobalContactForm((prev) => ({
      ...prev,
      attributes: prev.attributes.map((attr, i) =>
        i === index ? { ...attr, [field]: value } : attr
      ),
    }));
  };

  const removeCustomAttribute = (index: number) => {
    setGlobalContactForm((prev) => ({
      ...prev,
      attributes: prev.attributes.filter((_, i) => i !== index),
    }));
  };

  const handleSaveGlobalContact = () => {
    onSave(globalContactForm);
    setGlobalContactForm({
      name: '',
      mobile: '',
      attributes: [],
    });
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md mx-auto bg-white border-0 shadow-2xl rounded-xl p-0 overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <DialogTitle className="text-lg font-semibold text-gray-900">
            Add Contact
          </DialogTitle>
       
        </div>

        <div className="p-6 space-y-4">
          <div>
            <label className="text-sm font-medium text-gray-700 mb-2 block">
              Name
            </label>
            <Input
              placeholder="Name"
              value={globalContactForm.name}
              onChange={(e) =>
                handleGlobalContactFormChange('name', e.target.value)
              }
              className="border-gray-300 focus:border-green-500 focus:ring-green-500"
            />
          </div>

          <div>
            <label className="text-sm font-medium text-gray-700 mb-2 block">
              Phone Number
            </label>
            <PhoneInput
              international
              defaultCountry="IN"
              value={globalContactForm.mobile}
              onChange={(value) =>
                handleGlobalContactFormChange('mobile', value || '')
              }
              className="w-full px-3 py-2 phone-input border border-gray-300 rounded-md  text-sm"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-medium text-gray-700">
                Custom Attribute(Optional)
              </label>
            </div>

            {globalContactForm.attributes.map((attr, index) => (
              <div key={index} className="flex gap-2 mb-2">
                <Input
                  placeholder="Key"
                  value={attr.key}
                  onChange={(e) =>
                    updateCustomAttribute(index, 'key', e.target.value)
                  }
                  className="border-gray-300"
                />
                <Input
                  placeholder="Value"
                  value={attr.value}
                  onChange={(e) =>
                    updateCustomAttribute(index, 'value', e.target.value)
                  }
                  className="border-gray-300"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => removeCustomAttribute(index)}
                  className="text-red-500 hover:text-red-600"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            ))}

            <Button
              variant="outline"
              size="sm"
              onClick={addCustomAttribute}
              className="text-green-500 hover:text-green-600 border-green-300"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Attribute
            </Button>
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button
              onClick={handleSaveGlobalContact}
              className="bg-green-500 hover:bg-green-600 text-white"
            >
              Save
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
