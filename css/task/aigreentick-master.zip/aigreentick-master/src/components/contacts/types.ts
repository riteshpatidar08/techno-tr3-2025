export interface Contact {
  id: number;
  name: string;
  phonebook: string;
  mobile: string;
  var1: string;
  var2: string;
  var3: string;
  var4: string;
  added: string;
}

export interface GlobalContact {
  id: number;
  name: string;
  phone: string;
  source: string;
  attributes: Record<string, string>;
  hasWhatsApp: boolean;
}

export interface Phonebook {
  name: string;
  daysAgo: number;
  status: string;
}

export interface ContactFormData {
  name: string;
  mobile: string;
  var1: string;
  var2: string;
  var3: string;
  var4: string;
  var5: string;
}

export interface GlobalContactFormData {
  name: string;
  mobile: string;
  attributes: { key: string; value: string }[];
}

export type SortOption = 'Last Updated' | 'Name' | 'Phone Number';
export type TabValue = 'paste' | 'csv';
