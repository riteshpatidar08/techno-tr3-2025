import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { X, Trash2, Plus } from 'lucide-react';
export interface FilterCondition {
  id: string;
  attribute: string;
  operation: string;
  value: string;
}

export interface FilterModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyFilter: (conditions: FilterCondition[]) => void;
  existingConditions?: FilterCondition[];
}
const AVAILABLE_ATTRIBUTES = [
  { value: 'channel', label: 'Channel' },
  { value: 'source', label: 'Source' },
  { value: 'type', label: 'Type' },
  { value: 'priority', label: 'Priority' },
  { value: 'leadScore', label: 'Lead Score' },
  { value: 'name', label: 'Name' },
  { value: 'phone', label: 'Phone Number' },
  { value: 'hasWhatsApp', label: 'Has WhatsApp' },
];
const getOperationsForAttribute = (attribute: string) => {
  switch (attribute) {
    case 'leadScore':
      return [
        { value: 'equals', label: 'Equals' },
        { value: 'greaterThan', label: 'Greater than' },
        { value: 'lessThan', label: 'Less than' },
        { value: 'greaterThanOrEqual', label: 'Greater than or equal' },
        { value: 'lessThanOrEqual', label: 'Less than or equal' },
      ];
    case 'hasWhatsApp':
      return [{ value: 'equals', label: 'Equals' }];
    case 'name':
    case 'phone':
      return [
        { value: 'contains', label: 'Contains' },
        { value: 'equals', label: 'Equals' },
        { value: 'startsWith', label: 'Starts with' },
        { value: 'endsWith', label: 'Ends with' },
      ];
    default:
      return [
        { value: 'equals', label: 'Equals' },
        { value: 'contains', label: 'Contains' },
        { value: 'notEquals', label: 'Not equals' },
      ];
  }
};
const getInputTypeForAttribute = (attribute: string) => {
  switch (attribute) {
    case 'leadScore':
      return 'number';
    case 'hasWhatsApp':
      return 'select';
    default:
      return 'text';
  }
};
const getPredefinedValues = (attribute: string) => {
  switch (attribute) {
    case 'hasWhatsApp':
      return [
        { value: 'true', label: 'Yes' },
        { value: 'false', label: 'No' },
      ];
    case 'priority':
      return [
        { value: 'high', label: 'High' },
        { value: 'medium', label: 'Medium' },
        { value: 'low', label: 'Low' },
      ];
    case 'source':
      return [
        { value: 'whatsapp', label: 'WhatsApp' },
        { value: 'manual', label: 'Manual' },
        { value: 'wati', label: 'Wati' },
        { value: 'import', label: 'Import' },
      ];
    case 'type':
      return [
        { value: 'customer', label: 'Customer' },
        { value: 'lead', label: 'Lead' },
        { value: 'prospect', label: 'Prospect' },
        { value: 'test', label: 'Test' },
      ];
    case 'channel':
      return [
        { value: 'web', label: 'Web' },
        { value: 'mobile', label: 'Mobile' },
        { value: 'social', label: 'Social Media' },
        { value: 'referral', label: 'Referral' },
      ];
    default:
      return [];
  }
};

export const ContactFilterModal: React.FC<FilterModalProps> = ({
  isOpen,
  onClose,
  onApplyFilter,
  existingConditions = [],
}) => {
  const [conditions, setConditions] = useState<FilterCondition[]>(
    existingConditions.length > 0
      ? existingConditions
      : [{ id: crypto.randomUUID(), attribute: '', operation: '', value: '' }]
  );

  const addNewCondition = () => {
    setConditions([
      ...conditions,
      { id: crypto.randomUUID(), attribute: '', operation: '', value: '' },
    ]);
  };

  const removeCondition = (id: string) => {
    if (conditions.length > 1) {
      setConditions(conditions.filter((condition) => condition.id !== id));
    }
  };

  const updateCondition = (
    id: string,
    field: keyof FilterCondition,
    value: string
  ) => {
    setConditions(
      conditions.map((condition) => {
        if (condition.id === id) {
          const updated = { ...condition, [field]: value };
          if (field === 'attribute') {
            updated.operation = '';
            updated.value = '';
          }
          if (field === 'operation') {
            updated.value = '';
          }

          return updated;
        }
        return condition;
      })
    );
  };

  const handleApply = () => {
    const validConditions = conditions.filter(
      (condition) =>
        condition.attribute && condition.operation && condition.value
    );
    onApplyFilter(validConditions);
    onClose();
  };

  const handleReset = () => {
    setConditions([
      { id: crypto.randomUUID(), attribute: '', operation: '', value: '' },
    ]);
  };

  const renderValueInput = (condition: FilterCondition) => {
    const inputType = getInputTypeForAttribute(condition.attribute);
    const predefinedValues = getPredefinedValues(condition.attribute);

    if (inputType === 'select' || predefinedValues.length > 0) {
      return (
        <Select
          value={condition.value}
          onValueChange={(value) =>
            updateCondition(condition.id, 'value', value)
          }
        >
          <SelectTrigger className="border-0 bg-gray-50">
            <SelectValue placeholder="Select value" />
          </SelectTrigger>
          <SelectContent className="border-0 shadow-lg">
            {predefinedValues.map((option) => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      );
    }

    return (
      <Input
        type={inputType}
        placeholder="Enter value"
        value={condition.value}
        onChange={(e) => updateCondition(condition.id, 'value', e.target.value)}
        className="border-0 bg-gray-50"
      />
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl bg-white border-0 shadow-2xl">
        <DialogHeader className="flex flex-row items-center justify-between space-y-0 pb-6">
          <DialogTitle className="text-xl font-semibold text-gray-900">
            Filter contacts
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {conditions.map((condition, index) => (
            <div
              key={condition.id}
              className="grid grid-cols-4 gap-4 items-center"
            >
              <div>
                <Select
                  value={condition.attribute}
                  onValueChange={(value) =>
                    updateCondition(condition.id, 'attribute', value)
                  }
                >
                  <SelectTrigger className="border-0 bg-gray-50">
                    <SelectValue placeholder="Attribute" />
                  </SelectTrigger>
                  <SelectContent className="border-0 shadow-lg">
                    {AVAILABLE_ATTRIBUTES.map((attr) => (
                      <SelectItem key={attr.value} value={attr.value}>
                        {attr.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Select
                  value={condition.operation}
                  onValueChange={(value) =>
                    updateCondition(condition.id, 'operation', value)
                  }
                  disabled={!condition.attribute}
                >
                  <SelectTrigger className="border-0 bg-gray-50">
                    <SelectValue placeholder="Operation" />
                  </SelectTrigger>
                  <SelectContent className="border-0 shadow-lg">
                    {condition.attribute &&
                      getOperationsForAttribute(condition.attribute).map(
                        (op) => (
                          <SelectItem key={op.value} value={op.value}>
                            {op.label}
                          </SelectItem>
                        )
                      )}
                  </SelectContent>
                </Select>
              </div>

              <div>{renderValueInput(condition)}</div>

              <div className="flex justify-center">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => removeCondition(condition.id)}
                  disabled={conditions.length === 1}
                  className="h-8 w-8 p-0 text-red-500 hover:text-red-600 hover:bg-red-50"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}

          <div className="pt-4">
            <Button
              variant="outline"
              onClick={addNewCondition}
              className="text-green-600 border-green-600 hover:bg-green-50 border-0 bg-green-50"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add new Segment
            </Button>
          </div>
        </div>

        <div className="flex items-center justify-between pt-6 border-t border-gray-200">
          <Button
            variant="outline"
            onClick={handleReset}
            className="text-gray-600 border-0 bg-gray-50"
          >
            Reset Filters
          </Button>

          <div className="flex space-x-3">
            <Button
              variant="outline"
              onClick={onClose}
              className="border-0 bg-gray-50"
            >
              Cancel
            </Button>
            <Button
              onClick={handleApply}
              className="bg-green-600 hover:bg-green-700 text-white"
              disabled={
                !conditions.some((c) => c.attribute && c.operation && c.value)
              }
            >
              Apply
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
