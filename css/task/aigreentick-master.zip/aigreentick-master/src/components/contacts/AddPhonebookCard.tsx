import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, Phone, Plus } from 'lucide-react';

interface AddPhonebookCardProps {
  onAddPhonebook: (name: string) => void;
}

export const AddPhonebookCard: React.FC<AddPhonebookCardProps> = ({
  onAddPhonebook,
}) => {
  const [phonebookName, setPhonebookName] = useState('');

  const handleAddPhonebook = () => {
    if (phonebookName.trim()) {
      onAddPhonebook(phonebookName.trim());
      setPhonebookName('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleAddPhonebook();
    }
  };

  return (
    <Card className="shadow-sm border-0 bg-white">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center text-lg font-semibold text-gray-900">
          <div className="w-5 h-5 bg-green-500 rounded flex items-center justify-center mr-3">
            <CheckCircle className="w-3 h-3 text-white" />
          </div>
          Add phonebook
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="flex items-end space-x-4">
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Enter phonebook name
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <div className="w-4 h-4 bg-green-500 rounded flex items-center justify-center">
                  <Phone className="w-2.5 h-2.5 text-white" />
                </div>
              </div>
              <Input
                placeholder="Enter phonebook name"
                value={phonebookName}
                onChange={(e) => setPhonebookName(e.target.value)}
                onKeyPress={handleKeyPress}
                className="pl-10 border-gray-300 focus:border-green-500 focus:ring-green-500"
              />
            </div>
          </div>
          <Button
            onClick={handleAddPhonebook}
            disabled={!phonebookName.trim()}
            className="bg-green-500 hover:bg-green-600 text-white shadow-sm px-6 disabled:bg-gray-300 disabled:cursor-not-allowed"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
