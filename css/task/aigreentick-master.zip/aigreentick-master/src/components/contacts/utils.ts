import { GlobalContact, SortOption } from './types';

export const filterContacts = (
  contacts: GlobalContact[],
  searchTerm: string
): GlobalContact[] => {
  if (!searchTerm.trim()) return contacts;

  return contacts.filter(
    (contact) =>
      contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.phone.includes(searchTerm)
  );
};

export const sortContacts = (
  contacts: GlobalContact[],
  sortBy: SortOption
): GlobalContact[] => {
  return [...contacts].sort((a, b) => {
    switch (sortBy) {
      case 'Name':
        return a.name.localeCompare(b.name);
      case 'Phone Number':
        return a.phone.localeCompare(b.phone);
      case 'Last Updated':
      default:
        return b.id - a.id;
    }
  });
};

export const paginateContacts = (
  contacts: GlobalContact[],
  currentPage: number,
  rowsPerPage: number
): GlobalContact[] => {
  const startIndex = (currentPage - 1) * rowsPerPage;
  return contacts.slice(startIndex, startIndex + rowsPerPage);
};

export const getTotalPages = (
  totalItems: number,
  rowsPerPage: number
): number => {
  return Math.ceil(totalItems / rowsPerPage);
};

export const getStartIndex = (
  currentPage: number,
  rowsPerPage: number
): number => {
  return (currentPage - 1) * rowsPerPage;
};

export const downloadSampleCSV = (): void => {
  const csvContent =
    'name,mobile,var1,var2,var3,var4,var5\nJohn Doe,1234567890,value1,value2,value3,value4,value5';
  const blob = new Blob([csvContent], { type: 'text/csv' });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'sample_contacts.csv';
  link.click();
  window.URL.revokeObjectURL(url);
};

export const exportContactsToCSV = (contacts: GlobalContact[]): void => {
  const csvContent = [
    'name,phone,source,attributes',
    ...contacts.map(
      (contact) =>
        `${contact.name},${contact.phone},${contact.source},"${Object.entries(
          contact.attributes
        )
          .map(([k, v]) => `${k}:${v}`)
          .join(';')}"`
    ),
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv' });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'contacts_export.csv';
  link.click();
  window.URL.revokeObjectURL(url);
};
