import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from '@/components/ui/pagination';
import {
  Users,
  Plus,
  Search,
  Filter,
  Upload,
  Download,
  Trash2,
  Edit3,
  MessageCircle,
  MoreHorizontal,
  X,
} from 'lucide-react';
import { GlobalContact, SortOption } from './types';
import { ContactFilterModal, FilterCondition } from './ContactFilterModal';

interface GlobalContactsTableProps {
  contacts: GlobalContact[];
  filteredContacts: GlobalContact[];
  paginatedContacts: GlobalContact[];
  selectedContacts: Set<number>;
  searchTerm: string;
  sortBy: SortOption;
  currentPage: number;
  totalPages: number;
  rowsPerPage: number;
  startIndex: number;
  onContactSelect: (contactId: number) => void;
  onSelectAll: () => void;
  onSearchChange: (term: string) => void;
  onSortChange: (sort: SortOption) => void;
  onPageChange: (page: number) => void;
  onRowsPerPageChange: (rows: number) => void;
  onAddContact: () => void;
  onEditContact: (contact: GlobalContact) => void;
  onDeleteContact: (contactId: number) => void;
  onExportContacts: () => void;
  onImportContacts: () => void;
  onDeleteSelected: () => void;
  onOpenWhatsAppModal?: (contact: GlobalContact) => void;
  onApplyFilters?: (conditions: FilterCondition[]) => void;
}

export const GlobalContactsTable: React.FC<GlobalContactsTableProps> = ({
  contacts,
  filteredContacts,
  paginatedContacts,
  selectedContacts,
  searchTerm,
  sortBy,
  currentPage,
  totalPages,
  rowsPerPage,
  startIndex,
  onContactSelect,
  onSelectAll,
  onSearchChange,
  onSortChange,
  onPageChange,
  onRowsPerPageChange,
  onAddContact,
  onEditContact,
  onDeleteContact,
  onExportContacts,
  onImportContacts,
  onDeleteSelected,
  onOpenWhatsAppModal,
  onApplyFilters,
}) => {
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [activeFilters, setActiveFilters] = useState<FilterCondition[]>([]);

  const handleApplyFilters = (conditions: FilterCondition[]) => {
    setActiveFilters(conditions);
    onApplyFilters?.(conditions);
  };

  const handleRemoveFilter = (filterId: string) => {
    const updatedFilters = activeFilters.filter((f) => f.id !== filterId);
    setActiveFilters(updatedFilters);
    onApplyFilters?.(updatedFilters);
  };

  const handleClearAllFilters = () => {
    setActiveFilters([]);
    onApplyFilters?.([]);
  };

  return (
    <>
      <Card className="shadow-sm border-0 bg-white">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center text-lg font-semibold text-gray-900">
              <div className="w-5 h-5 bg-green-500 rounded flex items-center justify-center mr-3">
                <Users className="w-3 h-3 text-white" />
              </div>
              Contacts
              <span className="ml-2 text-sm text-gray-500">
                ({filteredContacts.length} in total)
              </span>
            </CardTitle>
            <div className="flex items-center space-x-2">
            
              <Button
                onClick={onAddContact}
                className="bg-green-500 hover:bg-green-600 text-white"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Contact
              </Button>
            </div>
          </div>
          <p className="text-sm text-gray-600 mt-2">
            Contact list stores the list of numbers that you've interacted with.
            You can even manually export or import contacts.
          </p>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <label className="text-sm font-medium text-gray-700">
                  Sorted by:
                </label>
                <Select value={sortBy} onValueChange={onSortChange}>
                  <SelectTrigger className="w-40 border-0 bg-gray-50">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-0 shadow-lg">
                    <SelectItem value="Last Updated">Last Updated</SelectItem>
                    <SelectItem value="Name">Name</SelectItem>
                    <SelectItem value="Phone Number">Phone Number</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="w-4 h-4 text-gray-400" />
                </div>
                <Input
                  placeholder="Search..."
                  value={searchTerm}
                  onChange={(e) => onSearchChange(e.target.value)}
                  className="pl-10 w-64 border-0 bg-gray-50"
                />
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowFilterModal(true)}
                className={`${
                  activeFilters.length > 0
                    ? 'bg-green-500 text-white border-green-500 hover:bg-green-600'
                    : 'bg-gray-50 text-gray-700 border-0 hover:bg-gray-100'
                }`}
              >
                <Filter className="w-4 h-4 mr-2" />
                Filter
                {activeFilters.length > 0 && (
                  <Badge className="ml-2 bg-white text-green-600 text-xs">
                    {activeFilters.length}
                  </Badge>
                )}
              </Button>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" onClick={onExportContacts}>
                <Upload className="w-4 h-4 mr-2" />
                Export
              </Button>
              <Button variant="outline" size="sm" onClick={onImportContacts}>
                <Download className="w-4 h-4 mr-2" />
                Import
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="text-red-500 border-red-300"
                onClick={onDeleteSelected}
                disabled={selectedContacts.size === 0}
              >
                <Trash2 className="w-4 h-4" />
                {selectedContacts.size > 0 && ` (${selectedContacts.size})`}
              </Button>
            </div>
          </div>

          {activeFilters.length > 0 && (
            <div className="mb-4 p-3 bg-blue-50 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-blue-900">
                  Active Filters:
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleClearAllFilters}
                  className="text-blue-600 hover:text-blue-800 h-6 text-xs"
                >
                  Clear all
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {activeFilters.map((filter) => (
                  <div
                    key={filter.id}
                    className="flex items-center bg-white border border-blue-200 rounded-md px-2 py-1 text-xs"
                  >
                    <span className="text-blue-800">
                      {filter.attribute} {filter.operation} "{filter.value}"
                    </span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleRemoveFilter(filter.id)}
                      className="ml-1 h-4 w-4 p-0 text-blue-600 hover:text-blue-800"
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="rounded-lg overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="border-b-0">
                  <TableHead className="w-12">
                    <Checkbox
                      checked={
                        selectedContacts.size === paginatedContacts.length &&
                        paginatedContacts.length > 0
                      }
                      onCheckedChange={onSelectAll}
                    />
                  </TableHead>
                  <TableHead>Basic info</TableHead>
                  <TableHead>Phone number</TableHead>
                  <TableHead>Source</TableHead>
                  <TableHead>Contact Attributes</TableHead>
               
                  <TableHead className="w-12">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedContacts.map((contact) => (
                  <TableRow
                    key={contact.id}
                    className="hover:bg-gray-50 border-b-0"
                  >
                    <TableCell>
                      <Checkbox
                        checked={selectedContacts.has(contact.id)}
                        onCheckedChange={() => onContactSelect(contact.id)}
                      />
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-3">
                        <div className="text-sm font-medium text-blue-600">
                          {contact.name}
                        </div>
                        {contact.hasWhatsApp && (
                          <button
                            onClick={() => onOpenWhatsAppModal?.(contact)}
                            className="hover:scale-110 transition-transform cursor-pointer"
                            title="Send WhatsApp message"
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="16"
                              height="16"
                              viewBox="0 0 16 16"
                              fill="none"
                            >
                              <g clipPath="url(#clip0_1092_5761)">
                                <path
                                  d="M8.00018 0.640015C3.94194 0.640015 0.640184 3.94177 0.640184 8.00001C0.640184 9.26721 0.967544 10.5133 1.58834 11.6128L0.652024 14.9536C0.621304 15.0634 0.651064 15.1811 0.730424 15.2627C0.791544 15.3258 0.874744 15.36 0.960184 15.36C0.985784 15.36 1.0117 15.3568 1.03698 15.3507L4.5237 14.4871C5.58834 15.0586 6.78738 15.36 8.00018 15.36C12.0584 15.36 15.3602 12.0583 15.3602 8.00001C15.3602 3.94177 12.0584 0.640015 8.00018 0.640015ZM11.7026 10.5971C11.5451 11.033 10.7899 11.4307 10.4271 11.4842C10.1013 11.5319 9.68914 11.5523 9.23666 11.4103C8.96242 11.3239 8.61042 11.2093 8.15954 11.017C6.26418 10.2087 5.02642 8.32417 4.9317 8.19969C4.8373 8.07521 4.16018 7.18817 4.16018 6.27009C4.16018 5.35201 4.64818 4.90049 4.82162 4.71361C4.99506 4.52673 5.19954 4.48001 5.32562 4.48001C5.4517 4.48001 5.57746 4.48161 5.68786 4.48673C5.80402 4.49249 5.95986 4.44289 6.11314 4.80705C6.27058 5.18081 6.6485 6.09889 6.69522 6.19265C6.74258 6.28609 6.77394 6.39521 6.71122 6.51969C6.6485 6.64417 6.61714 6.72193 6.52242 6.83105C6.4277 6.94017 6.32402 7.07425 6.2389 7.15809C6.14418 7.25121 6.04594 7.35201 6.15602 7.53889C6.2661 7.72577 6.6453 8.33665 7.20722 8.83137C7.92882 9.46689 8.53778 9.66401 8.72658 9.75745C8.91538 9.85089 9.02578 9.83521 9.13586 9.71073C9.24594 9.58593 9.60818 9.16577 9.73394 8.97921C9.8597 8.79265 9.98578 8.82337 10.1592 8.88577C10.3327 8.94785 11.2616 9.39905 11.4504 9.49249C11.6392 9.58593 11.7653 9.63265 11.8127 9.71041C11.86 9.78785 11.86 10.1616 11.7026 10.5971Z"
                                  fill="#2CB742"
                                ></path>
                              </g>
                              <defs>
                                <clipPath id="clip0_1092_5761">
                                  <rect
                                    width="16"
                                    height="16"
                                    fill="white"
                                  ></rect>
                                </clipPath>
                              </defs>
                            </svg>
                          </button>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <span className="text-sm text-gray-900">
                          {contact.phone}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="secondary"
                        className="bg-gray-100 text-gray-700 border-0"
                      >
                        {contact.source}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {Object.keys(contact.attributes).length > 0 ? (
                        Object.entries(contact.attributes).map(
                          ([key, value]) => (
                            <Badge
                              key={key}
                              variant="outline"
                              className="mr-1 text-xs border-0 bg-gray-50"
                            >
                              {key}: {value}
                            </Badge>
                          )
                        )
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </TableCell>
                  
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 w-8 p-0"
                          >
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent
                          align="end"
                          className="border-0 shadow-lg"
                        >
                          <DropdownMenuItem
                            onClick={() => onEditContact(contact)}
                          >
                            <Edit3 className="w-4 h-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => onDeleteContact(contact.id)}
                            className="text-red-600"
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          <div className="flex items-center justify-between mt-6">
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-700">Rows per page:</span>
              <Select
                value={rowsPerPage.toString()}
                onValueChange={(value) => {
                  onRowsPerPageChange(Number(value));
                  onPageChange(1);
                }}
              >
                <SelectTrigger className="w-20 border-0 bg-gray-50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="border-0 shadow-lg">
                  <SelectItem value="5">5</SelectItem>
                  <SelectItem value="10">10</SelectItem>
                  <SelectItem value="20">20</SelectItem>
                  <SelectItem value="50">50</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-700">
                {startIndex + 1}-
                {Math.min(startIndex + rowsPerPage, filteredContacts.length)} of{' '}
                {filteredContacts.length}
              </span>
              <Pagination>
                <PaginationContent>
                  <PaginationItem>
                    <PaginationPrevious
                      onClick={() => onPageChange(Math.max(1, currentPage - 1))}
                      className={
                        currentPage === 1
                          ? 'pointer-events-none opacity-50'
                          : 'cursor-pointer'
                      }
                    />
                  </PaginationItem>

                  {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                    let pageNumber;
                    if (totalPages <= 5) {
                      pageNumber = i + 1;
                    } else if (currentPage <= 3) {
                      pageNumber = i + 1;
                    } else if (currentPage >= totalPages - 2) {
                      pageNumber = totalPages - 4 + i;
                    } else {
                      pageNumber = currentPage - 2 + i;
                    }

                    return (
                      <PaginationItem key={pageNumber}>
                        <PaginationLink
                          onClick={() => onPageChange(pageNumber)}
                          isActive={currentPage === pageNumber}
                          className="cursor-pointer"
                        >
                          {pageNumber}
                        </PaginationLink>
                      </PaginationItem>
                    );
                  })}

                  <PaginationItem>
                    <PaginationNext
                      onClick={() =>
                        onPageChange(Math.min(totalPages, currentPage + 1))
                      }
                      className={
                        currentPage === totalPages
                          ? 'pointer-events-none opacity-50'
                          : 'cursor-pointer'
                      }
                    />
                  </PaginationItem>
                </PaginationContent>
              </Pagination>
            </div>
          </div>
        </CardContent>
      </Card>

      <ContactFilterModal
        isOpen={showFilterModal}
        onClose={() => setShowFilterModal(false)}
        onApplyFilter={handleApplyFilters}
        existingConditions={activeFilters}
      />
    </>
  );
};
