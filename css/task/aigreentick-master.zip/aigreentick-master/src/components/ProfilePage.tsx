import React, { useState, useEffect } from 'react';
import {
  User,
  Mail,
  Phone,
  Building,
  MapPin,
  Globe,
  CreditCard,
  DollarSign,
  Shield,
  Calendar,
  Camera,
  Edit,
  Save,
  X,
  Settings,
  Key,
  Download,
  Upload,
  Activity,
  Clock,
  CheckCircle,
  AlertCircle,
  Copy,
  Eye,
  EyeOff,
  Menu,
  LogOut,
  ChevronRight,
  Wallet,
} from 'lucide-react';

interface User {
  id: number;
  role_id: number;
  created_by: number | null;
  country_id: number;
  name: string;
  mobile: string;
  profile_photo: string | null;
  rememberToken: string | null;
  api_token: string;
  email: string;
  company_name: string | null;
  city: string | null;
  market_msg_charge: number | null;
  utilty_msg_charge: number;
  auth_msg_charge: number;
  balance: number;
  balance_enabled: number;
  online_status: string;
  agent_id: number | null;
  credit: number;
  debit: number;
  status: string;
  domain: string | null;
  logo: string | null;
  is_demo: string;
  demo_end: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  webhook_token: string | null;
  permission: any[];
}

const sidebarItems = [
  { id: 'profile', label: 'Profile', icon: User },
  { id: 'billing', label: 'Billing', icon: Wallet },
  { id: 'settings', label: 'Settings', icon: Settings },
  { id: 'activity', label: 'Activity', icon: Activity },
];

export default function ProfilePage() {
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState('profile');
  const [isEditing, setIsEditing] = useState(false);
  const [showApiToken, setShowApiToken] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    mobile: '',
    company_name: '',
    city: '',
    domain: '',
  });

  useEffect(() => {
    try {
      const storedUserData = localStorage.getItem('ai_green_tick_user');

      if (storedUserData) {
        const userData = JSON.parse(storedUserData);
        setUser(userData);
        setFormData({
          name: userData.name || '',
          email: userData.email || '',
          mobile: userData.mobile || '',
          company_name: userData.company_name || '',
          city: userData.city || '',
          domain: userData.domain || '',
        });
      } else {
        console.warn(
          'No user data found in localStorage with key "ai_green_tick_user"'
        );
      }
    } catch (error) {
      console.error('Error loading user data from localStorage:', error);
    }
  }, []);

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    if (user) {
      const updatedUser = {
        ...user,
        name: formData.name,
        email: formData.email,
        mobile: formData.mobile,
        company_name: formData.company_name,
        city: formData.city,
        domain: formData.domain,
        updated_at: new Date().toISOString(),
      };

      localStorage.setItem('ai_green_tick_user', JSON.stringify(updatedUser));

      setUser(updatedUser);

      console.log('Profile data saved to localStorage:', updatedUser);
    }
    setIsEditing(false);
  };

  const handleCancel = () => {
    if (user) {
      setFormData({
        name: user.name || '',
        email: user.email || '',
        mobile: user.mobile || '',
        company_name: user.company_name || '',
        city: user.city || '',
        domain: user.domain || '',
      });
    }
    setIsEditing(false);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case '1':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
            <CheckCircle className="w-3 h-3 mr-1" />
            Active
          </span>
        );
      case '0':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
            <AlertCircle className="w-3 h-3 mr-1" />
            Inactive
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
            {status}
          </span>
        );
    }
  };

  const getOnlineStatusBadge = (status: string) => {
    return status === '1' ? (
      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
        <div className="w-2 h-2 bg-green-500 rounded-full mr-1 animate-pulse"></div>
        Online
      </span>
    ) : (
      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
        <div className="w-2 h-2 bg-gray-500 rounded-full mr-1"></div>
        Offline
      </span>
    );
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <User className="w-8 h-8 text-green-600" />
          </div>
          <p className="text-gray-600 mb-2">Loading user profile...</p>
          <p className="text-sm text-gray-500">
            Make sure user data is stored in localStorage with key
            "ai_green_tick_user"
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <div
        className={`fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg transform transition-transform duration-300 ease-in-out ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        } lg:translate-x-0 lg:static lg:inset-0`}
      >
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center">
            <div className="w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center mr-3">
              <span className="text-white font-bold text-sm">W</span>
            </div>
            <h2 className="text-xl font-semibold text-gray-900">aiGreenTick</h2>
          </div>
          <button
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden p-1 rounded-md hover:bg-gray-100"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <nav className="mt-6 px-3">
          {sidebarItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between px-3 py-3 text-left rounded-lg mb-1 transition-colors ${
                  activeTab === item.id
                    ? 'bg-green-50 text-green-700'
                    : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                <div className="flex items-center">
                  <Icon className="w-5 h-5 mr-3" />
                  <span className="font-medium">{item.label}</span>
                </div>
                {activeTab === item.id && (
                  <ChevronRight className="w-4 h-4 text-green-500" />
                )}
              </button>
            );
          })}
        </nav>

        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-200">
          <button className="w-full flex items-center px-3 py-2 text-gray-700 hover:bg-gray-50 rounded-lg transition-colors">
            <LogOut className="w-5 h-5 mr-3" />
            <span className="font-medium">Sign Out</span>
          </button>
        </div>
      </div>

      <div className="flex-1 lg:ml-0">
        <div className="bg-white shadow-sm border-b border-gray-200">
          <div className="flex items-center justify-between px-6 py-4">
            <div className="flex items-center">
              <button
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden p-2 rounded-md hover:bg-gray-100 mr-4"
              >
                <Menu className="w-5 h-5 text-gray-600" />
              </button>
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  <span className="text-green-700 font-semibold text-lg">
                    {user.name
                      .split(' ')
                      .map((n) => n[0])
                      .join('')}
                  </span>
                </div>
                <div>
                  <h1 className="text-xl font-semibold text-gray-900">
                    {user.name}
                  </h1>
                  <p className="text-sm text-gray-500">{user.email}</p>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              {getStatusBadge(user.status)}
              {getOnlineStatusBadge(user.online_status)}
              {user.is_demo === 'on' && (
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                  Demo Account
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="p-6">
          {activeTab === 'profile' && (
            <div className="space-y-6">
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-4">
                    <div className="relative">
                      <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center">
                        <span className="text-green-700 font-bold text-2xl">
                          {user.name
                            .split(' ')
                            .map((n) => n[0])
                            .join('')}
                        </span>
                      </div>
                      <button className="absolute -bottom-1 -right-1 w-8 h-8 bg-white border-2 border-gray-200 rounded-full flex items-center justify-center shadow-sm hover:shadow-md transition-shadow">
                        <Camera className="w-4 h-4 text-gray-600" />
                      </button>
                    </div>
                    <div>
                      <h2 className="text-2xl font-bold text-gray-900">
                        {user.name}
                      </h2>
                      <p className="text-gray-500 mt-1">{user.email}</p>
                      <p className="text-sm text-gray-400 mt-1">
                        ID: {user.id}
                      </p>
                    </div>
                  </div>
                  <div className="flex space-x-3">
                    {!isEditing ? (
                      <button
                        onClick={() => setIsEditing(true)}
                        className="inline-flex items-center px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors font-medium"
                      >
                        <Edit className="w-4 h-4 mr-2" />
                        Edit Profile
                      </button>
                    ) : (
                      <div className="flex space-x-2">
                        <button
                          onClick={handleSave}
                          className="inline-flex items-center px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors font-medium"
                        >
                          <Save className="w-4 h-4 mr-2" />
                          Save
                        </button>
                        <button
                          onClick={handleCancel}
                          className="inline-flex items-center px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
                        >
                          <X className="w-4 h-4 mr-2" />
                          Cancel
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                  <div className="px-6 py-4 border-b border-gray-200">
                    <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                      <User className="w-5 h-5 mr-2 text-green-500" />
                      Personal Information
                    </h3>
                  </div>
                  <div className="p-6 space-y-4">
                    <div>
                      <label className="text-sm font-medium text-gray-700 block mb-2">
                        Full Name
                      </label>
                      {isEditing ? (
                        <input
                          type="text"
                          value={formData.name}
                          onChange={(e) =>
                            handleInputChange('name', e.target.value)
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none transition-colors"
                        />
                      ) : (
                        <p className="text-gray-900 font-medium">{user.name}</p>
                      )}
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700 block mb-2">
                        Email
                      </label>
                      {isEditing ? (
                        <input
                          type="email"
                          value={formData.email}
                          onChange={(e) =>
                            handleInputChange('email', e.target.value)
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none transition-colors"
                        />
                      ) : (
                        <div className="flex items-center">
                          <Mail className="w-4 h-4 mr-2 text-gray-400" />
                          <p className="text-gray-900">{user.email}</p>
                        </div>
                      )}
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700 block mb-2">
                        Mobile
                      </label>
                      {isEditing ? (
                        <input
                          type="text"
                          value={formData.mobile}
                          onChange={(e) =>
                            handleInputChange('mobile', e.target.value)
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none transition-colors"
                        />
                      ) : (
                        <div className="flex items-center">
                          <Phone className="w-4 h-4 mr-2 text-gray-400" />
                          <p className="text-gray-900">{user.mobile}</p>
                        </div>
                      )}
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700 block mb-2">
                        City
                      </label>
                      {isEditing ? (
                        <input
                          type="text"
                          value={formData.city}
                          onChange={(e) =>
                            handleInputChange('city', e.target.value)
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none transition-colors"
                        />
                      ) : (
                        <div className="flex items-center">
                          <MapPin className="w-4 h-4 mr-2 text-gray-400" />
                          <p className="text-gray-900">
                            {user.city || 'Not specified'}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                  <div className="px-6 py-4 border-b border-gray-200">
                    <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                      <Building className="w-5 h-5 mr-2 text-green-500" />
                      Company Information
                    </h3>
                  </div>
                  <div className="p-6 space-y-4">
                    <div>
                      <label className="text-sm font-medium text-gray-700 block mb-2">
                        Company Name
                      </label>
                      {isEditing ? (
                        <input
                          type="text"
                          value={formData.company_name}
                          onChange={(e) =>
                            handleInputChange('company_name', e.target.value)
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none transition-colors"
                        />
                      ) : (
                        <p className="text-gray-900">
                          {user.company_name || 'Not specified'}
                        </p>
                      )}
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700 block mb-2">
                        Domain
                      </label>
                      {isEditing ? (
                        <input
                          type="text"
                          value={formData.domain}
                          onChange={(e) =>
                            handleInputChange('domain', e.target.value)
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none transition-colors"
                        />
                      ) : (
                        <div className="flex items-center">
                          <Globe className="w-4 h-4 mr-2 text-gray-400" />
                          <p className="text-gray-900">
                            {user.domain || 'Not specified'}
                          </p>
                        </div>
                      )}
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700 block mb-2">
                        Role ID
                      </label>
                      <p className="text-gray-900">{user.role_id}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700 block mb-2">
                        Agent ID
                      </label>
                      <p className="text-gray-900">
                        {user.agent_id || 'Not assigned'}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                <div className="px-6 py-4 border-b border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                    <Shield className="w-5 h-5 mr-2 text-green-500" />
                    Account Details
                  </h3>
                </div>
                <div className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                      <label className="text-sm font-medium text-gray-700 block mb-2">
                        User ID
                      </label>
                      <p className="text-gray-900 font-mono text-lg">
                        {user.id}
                      </p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700 block mb-2">
                        Country ID
                      </label>
                      <p className="text-gray-900">{user.country_id}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700 block mb-2">
                        Created
                      </label>
                      <div className="flex items-center">
                        <Calendar className="w-4 h-4 mr-2 text-gray-400" />
                        <p className="text-gray-900">
                          {formatDate(user.created_at)}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'billing' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                      <DollarSign className="w-5 h-5 mr-2 text-green-500" />
                      Current Balance
                    </h3>
                  </div>
                  <div className="text-3xl font-bold text-gray-900 mb-2">
                    {formatCurrency(user.balance)}
                  </div>
                  <p className="text-sm text-gray-500">
                    Balance {user.balance_enabled ? 'Enabled' : 'Disabled'}
                  </p>
                </div>

                <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                      <Upload className="w-5 h-5 mr-2 text-green-500" />
                      Total Credit
                    </h3>
                  </div>
                  <div className="text-3xl font-bold text-green-600 mb-2">
                    {formatCurrency(user.credit)}
                  </div>
                  <p className="text-sm text-gray-500">Total credited amount</p>
                </div>

                <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                      <Download className="w-5 h-5 mr-2 text-red-500" />
                      Total Debit
                    </h3>
                  </div>
                  <div className="text-3xl font-bold text-red-600 mb-2">
                    {formatCurrency(user.debit)}
                  </div>
                  <p className="text-sm text-gray-500">Total debited amount</p>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                <div className="px-6 py-4 border-b border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                    <CreditCard className="w-5 h-5 mr-2 text-green-500" />
                    Message Charges
                  </h3>
                </div>
                <div className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="p-4 bg-gray-50 rounded-lg border border-gray-100">
                      <h4 className="font-semibold text-gray-900 mb-2">
                        Marketing Messages
                      </h4>
                      <p className="text-2xl font-bold text-gray-900 mb-1">
                        {user.market_msg_charge
                          ? formatCurrency(user.market_msg_charge)
                          : 'N/A'}
                      </p>
                      <p className="text-sm text-gray-500">per message</p>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-lg border border-gray-100">
                      <h4 className="font-semibold text-gray-900 mb-2">
                        Utility Messages
                      </h4>
                      <p className="text-2xl font-bold text-gray-900 mb-1">
                        {formatCurrency(user.utilty_msg_charge)}
                      </p>
                      <p className="text-sm text-gray-500">per message</p>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-lg border border-gray-100">
                      <h4 className="font-semibold text-gray-900 mb-2">
                        Auth Messages
                      </h4>
                      <p className="text-2xl font-bold text-gray-900 mb-1">
                        {formatCurrency(user.auth_msg_charge)}
                      </p>
                      <p className="text-sm text-gray-500">per message</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="space-y-6">
              <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                <div className="px-6 py-4 border-b border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                    <Key className="w-5 h-5 mr-2 text-green-500" />
                    API Configuration
                  </h3>
                </div>
                <div className="p-6 space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700 block mb-2">
                      API Token
                    </label>
                    <div className="flex items-center space-x-2">
                      <input
                        type={showApiToken ? 'text' : 'password'}
                        value={user.api_token}
                        readOnly
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 font-mono text-sm"
                      />
                      <button
                        onClick={() => setShowApiToken(!showApiToken)}
                        className="px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        {showApiToken ? (
                          <EyeOff className="w-4 h-4" />
                        ) : (
                          <Eye className="w-4 h-4" />
                        )}
                      </button>
                      <button
                        onClick={() => copyToClipboard(user.api_token)}
                        className="px-3 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700 block mb-2">
                      Webhook Token
                    </label>
                    <div className="flex items-center space-x-2">
                      <input
                        type="password"
                        value={user.webhook_token || 'Not configured'}
                        readOnly
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 font-mono text-sm"
                      />
                      <button className="px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                        <Copy className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {user.is_demo === 'on' && (
                <div className="bg-white rounded-lg shadow-sm border border-orange-200">
                  <div className="px-6 py-4 border-b border-orange-200">
                    <h3 className="text-lg font-semibold text-orange-800 flex items-center">
                      <AlertCircle className="w-5 h-5 mr-2" />
                      Demo Account Information
                    </h3>
                  </div>
                  <div className="p-6">
                    <div className="bg-orange-50 p-4 rounded-lg border border-orange-100">
                      <p className="text-orange-700 mb-2">
                        This is a demo account with limited functionality.
                      </p>
                      <p className="text-sm text-orange-600">
                        Demo expires on: {formatDate(user.demo_end)}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'activity' && (
            <div className="space-y-6">
              <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                <div className="px-6 py-4 border-b border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                    <Activity className="w-5 h-5 mr-2 text-green-500" />
                    Recent Activity
                  </h3>
                </div>
                <div className="p-6">
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3 p-4 bg-blue-50 rounded-lg border border-blue-100">
                      <Clock className="w-5 h-5 text-blue-500" />
                      <div>
                        <p className="font-medium text-gray-900">
                          Profile Updated
                        </p>
                        <p className="text-sm text-gray-500">
                          {formatDate(user.updated_at)}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3 p-4 bg-green-50 rounded-lg border border-green-100">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                      <div>
                        <p className="font-medium text-gray-900">
                          Account Created
                        </p>
                        <p className="text-sm text-gray-500">
                          {formatDate(user.created_at)}
                        </p>
                      </div>
                    </div>
                    {user.is_demo === 'on' && (
                      <div className="flex items-center space-x-3 p-4 bg-orange-50 rounded-lg border border-orange-100">
                        <AlertCircle className="w-5 h-5 text-orange-500" />
                        <div>
                          <p className="font-medium text-gray-900">
                            Demo Account Active
                          </p>
                          <p className="text-sm text-gray-500">
                            Expires: {formatDate(user.demo_end)}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
