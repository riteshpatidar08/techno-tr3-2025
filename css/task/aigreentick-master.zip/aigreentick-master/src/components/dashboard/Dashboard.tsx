import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  fetchDashboardData,
  selectDashboardData,
  selectDashboardLoading,
  selectDashboardError,
  selectDashboardLastUpdated,
  clearError,
} from '@/redux/dashboardSlice';
import DashboardHeader from './DashboardHeader';
import StatsGrid from './StatsGrid';
import UserProfileCard from './UserProfileCard';
import RecentConversations from './RecentConversations';
import MessageActivityCard from './MessageActivityCard';
import UnreadMessagesCard from './UnreadMessagesCard';
import ActiveChatbotsCard from './ActiveChatbotsCard';
import ErrorBoundary from './ErrorBoundary';

export default function Dashboard() {
  const dispatch = useDispatch();
  const dashboardData = useSelector(selectDashboardData);
  const loading = useSelector(selectDashboardLoading);
  const error = useSelector(selectDashboardError);
  const lastUpdated = useSelector(selectDashboardLastUpdated);

  console.log(dashboardData);

  useEffect(() => {
    dispatch(fetchDashboardData());
  }, [dispatch]);

  const handleRefresh = () => {
    dispatch(fetchDashboardData());
  };

  const handleDismissError = () => {
    dispatch(clearError());
  };

  const handleViewAllConversations = () => {
    console.log('Navigate to conversations');
  };

  const handleCreateChatbot = () => {
    console.log('Navigate to chatbot creation');
  };

  const handleManageChatbot = (chatbotId: string) => {
    console.log('Manage chatbot:', chatbotId);
  };
  if (error) {
    return (
      <ErrorBoundary
        error={error}
        onRetry={handleRefresh}
        onDismiss={handleDismissError}
      />
    );
  }

  return (
    <div className="min-h-screen   p-4 lg:p-12">
      <DashboardHeader
        userName={dashboardData?.user?.name}
        loading={loading}
        lastUpdated={lastUpdated}
        onRefresh={handleRefresh}
      />

      <StatsGrid data={dashboardData} loading={loading} />

      <UserProfileCard user={dashboardData?.user} />

      <RecentConversations
        conversations={dashboardData?.recent_conversations}
        onViewAll={handleViewAllConversations}
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* <MessageActivityCard
          activityData={dashboardData?.message_activity}
          loading={loading}
        /> */}

        <div className="space-y-6">
          {/* <UnreadMessagesCard
            unreadMessages={dashboardData?.unread_messages}
            unreadCount={dashboardData?.unread_count}
          /> */}

          {/* <ActiveChatbotsCard
            chatbots={dashboardData?.chatbots}
            chatbotCount={dashboardData?.chatbot_count}
            onCreateChatbot={handleCreateChatbot}
            onManageChatbot={handleManageChatbot}
          /> */}
        </div>
      </div>
    </div>
  );
}
