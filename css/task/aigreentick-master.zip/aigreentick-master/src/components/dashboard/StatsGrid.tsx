import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import {
  MessageCircle,
  TrendingUp,
  BarChart3,
  Bot,
  Loader2,
} from 'lucide-react';

interface StatsData {
  chatbot_count?: number;
  template_count?: number;
  report_count?: number;
  balance?: number;
}

interface StatsGridProps {
  data: StatsData | null;
  loading: boolean;
}

const StatsGrid: React.FC<StatsGridProps> = ({ data, loading }) => {
  const statsConfig = [
    {
      title: 'AI Chatbots',
      value: data?.chatbot_count || 0,
      icon: Bot,
      bgColor: 'bg-chart-1/10',
      iconBg: 'bg-chart-1',
      iconColor: 'text-white',
      textColor: 'text-chart-1',
      borderColor: 'border-chart-1/20',
    },
    {
      title: 'Templates',
      value: data?.template_count || 0,
      icon: MessageCircle,
      bgColor: 'bg-chart-1/10',
      iconBg: 'bg-chart-1',
      iconColor: 'text-white',
      textColor: 'text-chart-1',
      borderColor: 'border-chart-1/20',
    },
    {
      title: 'Reports',
      value: data?.report_count || 0,
      icon: BarChart3,
      bgColor: 'bg-chart-1/10',
      iconBg: 'bg-chart-1',
      iconColor: 'text-white',
      textColor: 'text-chart-1',
      borderColor: 'border-chart-1/20',
    },
    {
      title: 'Balance',
      value: `₹${data?.balance || 0}`,
      icon: TrendingUp,
      bgColor: 'bg-chart-1/10',
      iconBg: 'bg-chart-1',
      iconColor: 'text-white',
      textColor: 'text-chart-1',
      borderColor: 'border-chart-1/20',
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {statsConfig.map((stat, index) => {
        const Icon = stat.icon;
        return (
          <Card
            key={index}
            className={`bg-card border-border transition-all duration-300 hover:scale-[1.02] group ${stat.bgColor} ${stat.borderColor} border-2`}
          >
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="text-sm font-medium text-muted-foreground group-hover:text-foreground transition-colors">
                  {stat.title}
                </div>
                <div
                  className={`flex items-center justify-center w-12 h-12 ${stat.iconBg} rounded-xl transition-all duration-300 group-hover:scale-110`}
                >
                  <Icon className={`w-6 h-6 ${stat.iconColor}`} />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div
                  className={`text-3xl font-bold ${stat.textColor} transition-colors`}
                >
                  {loading ? (
                    <div className="flex items-center space-x-2">
                      <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
                      <span className="text-muted-foreground">...</span>
                    </div>
                  ) : (
                    stat.value
                  )}
                </div>

                {!loading && (
                  <div className="flex flex-col items-end space-y-1">
                    <div className="flex items-center text-xs text-muted-foreground">
                      <TrendingUp className="w-3 h-3 mr-1" />
                      <span>+12%</span>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      vs last month
                    </div>
                  </div>
                )}
              </div>

              {/* Progress Bar */}
              {!loading && (
                <div className="mt-4 space-y-2">
                  <div className="w-full bg-muted/50 rounded-full h-1.5 overflow-hidden">
                    <div
                      className={`h-full ${stat.iconBg} transition-all duration-500 ease-out`}
                      style={{
                        width: `${Math.min(
                          100,
                          typeof stat.value === 'string'
                            ? Math.random() * 80 + 20
                            : (stat.value / 100) * 80 + 20
                        )}%`,
                      }}
                    ></div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
};

export default StatsGrid;
