import React from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MessageCircle, ArrowRight, Clock, User } from 'lucide-react';

interface RecentConversationsProps {
  conversations?: any[];
  onViewAll?: () => void;
}

const RecentConversations: React.FC<RecentConversationsProps> = ({
  conversations = [],
  onViewAll,
}) => {
  const formatTimestamp = (timestamp: string) => {
    if (!timestamp) return '';
    const now = new Date();
    const messageTime = new Date(timestamp);
    const diffInHours =
      (now.getTime() - messageTime.getTime()) / (1000 * 60 * 60);

    if (diffInHours < 1) {
      return 'Just now';
    } else if (diffInHours < 24) {
      return `${Math.floor(diffInHours)}h ago`;
    } else {
      return messageTime.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
      });
    }
  };

  const getInitials = (name: string) => {
    if (!name) return 'U';
    const words = name.split(' ');
    if (words.length >= 2) {
      return words[0].charAt(0) + words[1].charAt(0);
    }
    return name.charAt(0);
  };

  const isOnline = (lastSeen?: string) => {
    if (!lastSeen) return false;
    const lastSeenTime = new Date(lastSeen);
    const now = new Date();
    return now.getTime() - lastSeenTime.getTime() < 5 * 60 * 1000; // 5 minutes
  };

  return (
    <Card className="bg-card border-border transition-all duration-300 hover:border-primary/20 mb-6">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center justify-center w-12 h-12 bg-primary rounded-xl">
              <MessageCircle className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="text-xl font-semibold text-card-foreground">
                Recent Conversations
              </CardTitle>
              <CardDescription className="text-muted-foreground mt-1">
                Latest messages from your contacts
              </CardDescription>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {conversations.length > 0 && (
              <Badge
                variant="outline"
                className="bg-chart-2/10 text-chart-2 border-chart-2/20 font-medium"
              >
                {conversations.length} active
              </Badge>
            )}
            <Button
              variant="ghost"
              className="text-primary hover:text-primary/80 hover:bg-primary/10 transition-colors"
              onClick={onViewAll}
            >
              View All
              <ArrowRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="pt-0">
        {conversations.length > 0 ? (
          <div className="space-y-2">
            {conversations.slice(0, 5).map((conversation, index) => (
              <div
                key={index}
                className="flex items-center space-x-4 p-3 rounded-lg hover:bg-accent transition-colors cursor-pointer group"
              >
                {/* Avatar with Online Status */}
                <div className="relative">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                    <span className="text-primary-foreground text-sm font-semibold">
                      {getInitials(conversation.name)}
                    </span>
                  </div>
                  {isOnline(conversation.lastSeen) && (
                    <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 bg-chart-2 border-2 border-card rounded-full"></div>
                  )}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2 mb-1">
                    <p className="text-sm font-semibold text-card-foreground truncate group-hover:text-primary transition-colors">
                      {conversation.name || 'Unknown Contact'}
                    </p>
                    {conversation.unreadCount > 0 && (
                      <Badge className="bg-destructive text-destructive-foreground text-xs px-2 py-0.5 min-w-[20px] text-center">
                        {conversation.unreadCount > 9
                          ? '9+'
                          : conversation.unreadCount}
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground truncate leading-tight">
                    {conversation.lastMessage || 'No recent messages'}
                  </p>
                </div>

                {/* Timestamp and Status */}
                <div className="flex flex-col items-end space-y-1">
                  <div className="flex items-center text-xs text-muted-foreground">
                    <Clock className="w-3 h-3 mr-1" />
                    {formatTimestamp(conversation.timestamp)}
                  </div>

                  {/* Message Status */}
                  {conversation.status && (
                    <Badge
                      variant="outline"
                      className={`text-xs px-2 py-0.5 ${
                        conversation.status === 'delivered'
                          ? 'bg-chart-2/10 text-chart-2 border-chart-2/20'
                          : conversation.status === 'read'
                          ? 'bg-chart-5/10 text-chart-5 border-chart-5/20'
                          : 'bg-muted text-muted-foreground border-border'
                      }`}
                    >
                      {conversation.status}
                    </Badge>
                  )}
                </div>
              </div>
            ))}

            {/* Show More Indicator */}
            {conversations.length > 5 && (
              <div className="pt-2 border-t border-border">
                <Button
                  variant="ghost"
                  onClick={onViewAll}
                  className="w-full text-sm text-muted-foreground hover:text-foreground hover:bg-accent"
                >
                  View {conversations.length - 5} more conversations
                  <ArrowRight className="w-4 h-4 ml-1" />
                </Button>
              </div>
            )}
          </div>
        ) : (
          /* Empty State */
          <div className="flex flex-col items-center justify-center h-40 text-center">
            <div className="flex items-center justify-center w-20 h-20 bg-muted/50 rounded-2xl mb-4">
              <MessageCircle className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="text-base font-medium text-card-foreground mb-2">
              No conversations yet
            </h3>
            <p className="text-sm text-muted-foreground mb-4 max-w-sm">
              When customers start messaging you, their conversations will
              appear here
            </p>
            <Button
              onClick={onViewAll}
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              <User className="w-4 h-4 mr-2" />
              Start a conversation
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default RecentConversations;
